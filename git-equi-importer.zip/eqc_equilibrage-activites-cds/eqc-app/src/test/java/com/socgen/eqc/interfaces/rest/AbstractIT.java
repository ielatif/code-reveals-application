package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.client.SgSignInClient;
import com.socgen.dga.idp.jaxrs.SgSignIn;
import com.socgen.dga.idp.server.SgSignInMock;
import com.socgen.dga.idp.server.SgSignInMockServer;
import com.socgen.dga.idp.server.model.Role;
import com.socgen.dga.idp.server.model.SgUser;
import com.socgen.eqc.EqcApplication;
import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import org.junit.Rule;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@ExtendWith({SpringExtension.class})
@TestInstance(Lifecycle.PER_CLASS)
@ActiveProfiles("test")
@SpringBootTest(classes = EqcApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class AbstractIT {

    protected static AtomicLong SEQUENCE = new AtomicLong(1L);
    protected static final String CLIENT_ID_DE_BASE = "0000";
    private static final SgUser SG_USER_DE_BASE = new SgUser("A000001", "Marc", "De Base", "basic@sg.com",
        "0000", "ITIM/ASI/SDC/SDA", Collections.emptyMap());
    protected static final String BEARER_DE_BASE = "bearer 0000";
    /**
     * LOGGER.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractIT.class);
    private static SgSignInMockServer sgSignInMockServer;
    /**
     * Logger pour analyse des log.
     */
    @Rule
    public TestRule watcher = new TestWatcher() {
        protected void starting(final Description description) {
            LOGGER.debug("Starting test: {} - {}", description.getClassName(), description.getMethodName());
        }
    };
    @Autowired
    protected SgSignIn sgSignIn;
    @Value("${spring.jersey.application-path:/}")
    private String apiPath;
    @Value("${server.ssl.enabled:/}")
    private Boolean sslEnabled;
    /**
     * Port aléatoire pour test.
     */
    @LocalServerPort
    private int port;

    @MockBean
    SgSignInClient sgSignInClient;

    @BeforeAll
    public static void startSgSignInMockServer() {
        if (sgSignInMockServer == null) {
            sgSignInMockServer = new SgSignInMockServer();
            sgSignInMockServer.start();
        }
        System.setProperty("app.sg-sign-in.serverUrl", sgSignInMockServer.getServerUrl());
    }

    @BeforeEach
    public void setupAbstract() {
        MockitoAnnotations.initMocks(this);
        sgSignIn.setServerURL(sgSignInMockServer.getServerUrl());
        RestAssured.baseURI = sgSignInMockServer.getProxyUrl();

        Mockito.when(sgSignInClient.getAccessToken()).thenReturn("bearer 0001");

        RestAssured.basePath = apiPath;
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.defaultParser = Parser.JSON;

        setUserDeBase();
    }

    private void setUserDeBase() {
        sgSignIn.setClientId(AbstractIT.CLIENT_ID_DE_BASE);
        sgSignInMockServer.ssopProxyMock((Boolean.TRUE.equals(sslEnabled) ? "https" : "http") + "://localhost:" + port,
            RestAssured.basePath,
            SgSignInMock.forClientId(AbstractIT.CLIENT_ID_DE_BASE)
                .andAccessToken(AbstractIT.BEARER_DE_BASE)
                .thenReturnSgUser(AbstractIT.SG_USER_DE_BASE));
    }

    protected String setCustomUserWithRoles(String... roles) {

        Map<String, List<Role>> customRoles = buildMapRole(roles);

        SgUser customUser =
            new SgUser(SG_USER_DE_BASE.getUserId(),
                SG_USER_DE_BASE.getFirstName(),
                SG_USER_DE_BASE.getLastName(),
                SG_USER_DE_BASE.getEmail(),
                SG_USER_DE_BASE.getPhone(),
                SG_USER_DE_BASE.getServiceName(),
                customRoles);

        return setCustomUser(customUser);
    }

    protected String setCustomUser(SgUser customUser) {

        String token = genereToken();
        setUserMock(token, customUser, CLIENT_ID_DE_BASE);
        return token;
    }


    protected Map<String, List<Role>> buildMapRole(String... roleNames) {
        Map<String, List<Role>> mapRole = new HashMap<>();
        List<Role> listRole = new ArrayList<>();
        for (String roleName : roleNames) {
            Role role = new Role();
            role.setName(roleName);
            listRole.add(role);
        }
        mapRole.put(sgSignIn.getTrigram(), listRole);
        return mapRole;
    }

    protected void setUserMock(String bearer, SgUser sgUser, String clientId) {
        sgSignIn.setClientId(clientId);
        sgSignInMockServer.ssopProxyMock((Boolean.TRUE.equals(sslEnabled) ? "https" : "http") + "://localhost:" + port,
            RestAssured.basePath,
            SgSignInMock.forClientId(clientId)
                .andAccessToken(bearer)
                .thenReturnSgUser(sgUser));

    }

    protected String genereToken() {
        return String.format("Bearer %04d", SEQUENCE.getAndIncrement());
    }
}
