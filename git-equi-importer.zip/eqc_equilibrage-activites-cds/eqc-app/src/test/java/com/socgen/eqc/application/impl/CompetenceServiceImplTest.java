package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.ExpertiseService;
import com.socgen.eqc.application.mock.TupleExpertiseMock;
import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Competence;
import com.socgen.eqc.domain.model.DefaultExpertise;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.domain.model.Expertise;
import com.socgen.eqc.domain.model.Niveau;
import com.socgen.eqc.infrastructure.persistance.CompetenceRepository;
import com.socgen.eqc.infrastructure.persistance.ExpertiseRepository;
import com.socgen.eqc.infrastructure.persistance.NiveauRepository;
import com.socgen.eqc.interfaces.rest.dto.CompetenceDto;
import com.socgen.eqc.interfaces.rest.dto.ProfilDto;
import com.socgen.eqc.mapper.CompetenceMapper;
import com.socgen.eqc.mapper.CompetenceMapperImpl;
import com.socgen.eqc.mapper.ExpertiseMapper;
import com.socgen.eqc.mapper.ExpertiseMapperImpl;
import com.socgen.eqc.mapper.NiveauMapper;
import com.socgen.eqc.mapper.NiveauMapperImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anySet;

@ExtendWith(MockitoExtension.class)
class CompetenceServiceImplTest {


    @InjectMocks
    private CompetenceServiceImpl competenceService;

    @Mock
    private CompetenceRepository competenceRepository;

    @Mock
    private ExpertiseService expertiseService;

    @Spy
    private ExpertiseMapper expertiseMapper = new ExpertiseMapperImpl();

    @Spy
    private CompetenceMapper competenceMapper = new CompetenceMapperImpl();

    @Spy
    private NiveauMapper niveauMapper = new NiveauMapperImpl();

    @Mock
    private ExpertiseRepository expertiseRepository;

    @Mock
    private NiveauRepository niveauRepository;

    @Mock
    private AffiliationService affiliationService;

    @Captor
    private ArgumentCaptor<Competence> competenceCaptor;

    @Mock
    private AffectationService affectationService;

    @Test
    void should_get_profil_by_collab() {

        Collaborateur collaborateur = Collaborateur.builder().matricule("A100000").build();

        Expertise expertise1 = Expertise.builder().activite
                (ActiviteParams.builder().code("act1").defaultExpertises(new HashSet<>() {{
                    add(DefaultExpertise.builder().niveau(Niveau.builder().id(2L).build()).dateDebut(LocalDate.of(2020, 12, 01)).build());
                }}).build())
                .niveau(Niveau.builder().id(2L).build())
                .nombreDossier(25F).build();
        Expertise expertise2 = Expertise.builder().activite
                (ActiviteParams.builder().code("act2").defaultExpertises(new HashSet<>() {{
                    add(DefaultExpertise.builder().niveau(Niveau.builder().id(3L).build()).dateDebut(LocalDate.of(2020, 12, 29)).build());
                    add(DefaultExpertise.builder().niveau(Niveau.builder().id(2L).build()).dateDebut(LocalDate.of(2020, 12, 01))
                            .dateFin(LocalDate.of(2020, 12, 29)).build());
                }})
                        .build())
                .niveau(Niveau.builder().id(3L).build()).nombreDossier(40F).build();
        Expertise expertise3 = Expertise.builder().activite
                (ActiviteParams.builder().code("act3").defaultExpertises(new HashSet<>() {{
                    add(DefaultExpertise.builder().niveau(Niveau.builder().id(3L).build()).dateDebut(LocalDate.of(2020, 12, 01)).build());
                }})
                        .build())
                .niveau(Niveau.builder().id(3L).build()).nombreDossier(50F).build();

        Expertise expertise4 = Expertise.builder().activite
                (ActiviteParams.builder().code("act1").defaultExpertises(new HashSet<>() {{
                    add(DefaultExpertise.builder().niveau(Niveau.builder().id(2L).build()).dateDebut(LocalDate.of(2020, 12, 01)).build());
                }})
                        .build())
                .niveau(Niveau.builder().id(3L).build()).nombreDossier(60F).build();

        Expertise expertise5 = Expertise.builder().activite
                (ActiviteParams.builder().code("act2").defaultExpertises(new HashSet<>() {{
                    add(DefaultExpertise.builder().niveau(Niveau.builder().id(3L).build()).dateDebut(LocalDate.of(2020, 12, 29)).build());
                    add(DefaultExpertise.builder().niveau(Niveau.builder().id(2L).build()).dateDebut(LocalDate.of(2020, 12, 01))
                            .dateFin(LocalDate.of(2020, 12, 29)).build());
                }})
                        .build())
                .niveau(Niveau.builder().id(2L).build()).nombreDossier(40F).build();

        List<Expertise> expertises = new ArrayList<>() {{
            add(expertise1);
            add(expertise2);
            add(expertise5);
            add(expertise3);
        }};

        Competence competence1 = Competence.builder().id(1L).expertise(expertise4)
                .collaborateur(collaborateur).build();

        Mockito.when(competenceRepository
                .findByCollaborateurMatricule(collaborateur.getMatricule()))
                .thenReturn(List.of(competence1));

        Affiliation affiliation = Affiliation.builder().collaborateur(collaborateur)
                .equipe(Equipe.builder().code(30001L).build()).dateEntree(LocalDate.of(2020, 12, 12)).build();

        Mockito.when(affiliationService
                .findLastByMatricule(collaborateur.getMatricule()))
                .thenReturn(Optional.of(affiliation));

        Mockito.when(expertiseService.getCommonExpertise())
                .thenReturn(expertises);

        Mockito.when(affiliationService.findByMatriculeAndDate(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(Optional.of(affiliation));

        Mockito.when(expertiseService.getExpertiseByActivites(anySet()))
                .thenReturn(Arrays.asList(
                        new TupleExpertiseMock("act1", 2L, 25F),
                        new TupleExpertiseMock("act1", 3L, 60F),
                        new TupleExpertiseMock("act2", 2L, 40F),
                        new TupleExpertiseMock("act3", 3L, 50F)
                ));


        ProfilDto profilResult = competenceService.getProfilByCollaborateur(collaborateur.getMatricule(), 30001L,
                LocalDate.of(2020, 12, 11), LocalDate.of(2020, 12, 15));

        Assertions.assertEquals(3, profilResult.getCompetences().size());

        CompetenceDto CompetenceDto2 = expertiseMapper.expertiseToCompetenceDto(expertise5);
        CompetenceDto2.setMapNombreDossiers(new HashMap<>() {{
            put(2L, 40F);
        }});
        CompetenceDto CompetenceDto3 = expertiseMapper.expertiseToCompetenceDto(expertise3);
        CompetenceDto3.setMapNombreDossiers(new HashMap<>() {{
            put(3L, 50F);
        }});
        List<CompetenceDto> competenceDto1 = competenceMapper.competenceListToCompetenceDtoList(List.of(competence1));
        competenceDto1.get(0).setMapNombreDossiers(new HashMap<>() {{
            put(2L, 25F);
            put(3L, 60F);
        }});

        Set<CompetenceDto> resultSet = new HashSet<>() {{
            add(CompetenceDto3);
            add(CompetenceDto2);
        }};

        resultSet.addAll(competenceDto1);
        List<CompetenceDto> expectedResult = new ArrayList<>(resultSet);
        List<CompetenceDto> actualResult = new ArrayList<>(profilResult.getCompetences());

        expectedResult.sort(Comparator.comparing(CompetenceDto::getCodeActivite));

        actualResult.sort(Comparator.comparing(CompetenceDto::getCodeActivite));

        Assertions.assertEquals(expectedResult, actualResult);
    }


    @Test
    void should_update_profil() {

        CompetenceDto competenceDto1 = CompetenceDto.builder().id(10L).codeActivite("act1").idNiveau(2L).isUpdated(true).build();
        CompetenceDto competenceDto2 = CompetenceDto.builder().codeActivite("act2").idNiveau(3L).isUpdated(false).build();

        Expertise expertise = Expertise.builder().id(10L).activite(ActiviteParams.builder().code("act1").build())
                .niveau(Niveau.builder().id(4L).build()).build();

        List<CompetenceDto> actionCompetenceDto = Arrays.asList(competenceDto1, competenceDto2);

        Mockito.when(expertiseService.getExpertiseByActiviteAndNiveau(competenceDto1.getCodeActivite(),
                competenceDto1.getIdNiveau()))
                .thenReturn(expertise);

        competenceService.updateProfilCollaborateur("A100000", actionCompetenceDto);

        Mockito.verify(competenceRepository, Mockito.atMostOnce()).save(competenceCaptor.capture());

        Competence competence = competenceCaptor.getValue();

        Assertions.assertEquals(competence.getExpertise().getActivite().getCode(), competenceDto1.getCodeActivite());
        Assertions.assertEquals(10L, competence.getId());
        Assertions.assertEquals(competence.getExpertise().getId(), expertise.getId());

    }

    @Test
    void should_get_profil_by_collabs() {

        List<Collaborateur> collaborateurs = List.of(Collaborateur.builder().matricule("A100000").build(), Collaborateur.builder().matricule("A200000").build());
        List<Affiliation> affiliations = new ArrayList<>();
        collaborateurs.forEach(collaborateur -> {
            Affiliation affiliation = Affiliation.builder().collaborateur(collaborateur)
                    .equipe(Equipe.builder().code(30001L).build()).dateEntree(LocalDate.of(2020, 12, 12)).build();
            affiliations.add(affiliation);
        });

        Map<String, List<Affiliation>> affiliationByCollab = affiliations.stream()
                .collect(Collectors.groupingBy(affiliation -> affiliation.getCollaborateur().getMatricule()));

        Niveau niveau0 = Niveau.builder().id(0L).build();
        Niveau niveau1 = Niveau.builder().id(1L).build();
        Niveau niveau2 = Niveau.builder().id(2L).build();

        ActiviteParams act1 = ActiviteParams.builder().code("act1").defaultExpertises(new HashSet<>() {{
            add(DefaultExpertise.builder().niveau(niveau0).dateDebut(LocalDate.of(2020, 12, 01)).build());
        }}).build();

        ActiviteParams act2 = ActiviteParams.builder().code("act2").defaultExpertises(new HashSet<>() {{
            add(DefaultExpertise.builder().niveau(niveau0).dateDebut(LocalDate.of(2020, 12, 01)).build());
        }}).build();

        Expertise firstExpertiseAct1 = Expertise.builder().id(1L).activite
                (act1).niveau(niveau1).nombreDossier(25F).build();

        Expertise SecondExpertiseAct1 = Expertise.builder().id(2L).activite
                (act1).niveau(niveau2).nombreDossier(40F).build();

        Expertise firstExpertiseAct2 = Expertise.builder().id(3L).activite
                (act2).niveau(niveau1).nombreDossier(50F).build();

        Expertise SecondExpertiseAct2 = Expertise.builder().id(4L).activite
                (act2).niveau(niveau2).nombreDossier(60F).build();

        Expertise expertiseDefaultAct1 = Expertise.builder().id(5L).activite
                (act2).niveau(niveau0).nombreDossier(0F).build();

        Expertise expertiseDefaultAct2 = Expertise.builder().id(6L).activite
                (act2).niveau(niveau0).nombreDossier(0F).build();

        List<Expertise> expertises = new ArrayList<>() {{
            add(firstExpertiseAct1);
            add(SecondExpertiseAct1);
            add(firstExpertiseAct2);
            add(SecondExpertiseAct2);
            add(expertiseDefaultAct1);
            add(expertiseDefaultAct2);
        }};

        Competence competence1 = Competence.builder().id(1L).expertise(firstExpertiseAct1)
                .collaborateur(collaborateurs.get(0)).build();
        Competence competence2 = Competence.builder().id(2L).expertise(SecondExpertiseAct2)
                .collaborateur(collaborateurs.get(0)).build();
        Competence competence3 = Competence.builder().id(3L).expertise(SecondExpertiseAct1)
                .collaborateur(collaborateurs.get(1)).build();
        Competence competence4 = Competence.builder().id(4L).expertise(firstExpertiseAct2)
                .collaborateur(collaborateurs.get(1)).build();


        List<Competence> competences = new ArrayList<>() {{
            add(competence1);
            add(competence2);
            add(competence3);
            add(competence4);
        }};

        Map<Collaborateur, List<Competence>> collaborateurCompetenceMap = competences.stream().collect(Collectors.groupingBy(Competence::getCollaborateur));

        Mockito.when(competenceRepository
                .findByCollaborateurMatriculeIn(collaborateurs.stream().map(Collaborateur::getMatricule)
                        .collect(Collectors.toList())))
                .thenReturn(competences);

        Mockito.when(expertiseService.getCommonExpertise())
                .thenReturn(expertises);


        List<Competence> competenceListResult = competenceService.getProfilByCollaborateurs(collaborateurs, affiliationByCollab);

        Assertions.assertEquals(4, competenceListResult.size());

    }

    @Test
    void should_get_profil_service_traitement() {

        List<Collaborateur> collaborateurs = List.of(Collaborateur.builder().matricule("A100000").build(), Collaborateur.builder().matricule("A200000").build());
        Affiliation affiliation1 = Affiliation.builder().collaborateur(collaborateurs.get(0))
                .equipe(Equipe.builder().code(30001L).build()).dateEntree(LocalDate.of(2020, 12, 12)).build();

        Affiliation affiliation2 = Affiliation.builder().collaborateur(collaborateurs.get(1))
                .equipe(Equipe.builder().code(30001L).build()).dateEntree(LocalDate.of(2020, 12, 12)).build();

        List<Affiliation> affiliations = Arrays.asList(affiliation1, affiliation2);


        Mockito.when(affiliationService
                .findByEquipeAndDate(Mockito.eq(30001L),  any()))
                .thenReturn(affiliations);


        Niveau niveau0 = Niveau.builder().id(0L).build();
        Niveau niveau1 = Niveau.builder().id(1L).build();
        Niveau niveau2 = Niveau.builder().id(2L).build();

        ActiviteParams act1 = ActiviteParams.builder().code("act1").defaultExpertises(new HashSet<>() {{
            add(DefaultExpertise.builder().niveau(niveau0).dateDebut(LocalDate.of(2020, 12, 01)).build());
        }}).build();

        ActiviteParams act2 = ActiviteParams.builder().code("act2").defaultExpertises(new HashSet<>() {{
            add(DefaultExpertise.builder().niveau(niveau0).dateDebut(LocalDate.of(2020, 12, 01)).build());
        }}).build();

        Expertise firstExpertiseAct1 = Expertise.builder().id(1L).activite
                (act1).niveau(niveau1).nombreDossier(25F).build();

        Expertise SecondExpertiseAct2 = Expertise.builder().id(4L).activite
                (act2).niveau(niveau2).nombreDossier(60F).build();


        Competence competence1 = Competence.builder().id(1L).expertise(firstExpertiseAct1)
                .collaborateur(collaborateurs.get(0)).build();
        Competence competence2 = Competence.builder().id(2L).expertise(SecondExpertiseAct2)
                .collaborateur(collaborateurs.get(1)).build();


        List<Competence> competences = new ArrayList<>() {{
            add(competence1);
            add(competence2);
        }};

        Mockito.when(competenceRepository
                .findByCollaborateurMatriculeIn(collaborateurs.stream().map(Collaborateur::getMatricule)
                        .collect(Collectors.toList())))
                .thenReturn(competences);


        List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> competenceListResult = competenceService.getProfilByServiceTraitement(30001L);

        Assertions.assertEquals(2, competenceListResult.size());

        competenceListResult.stream().filter(competenceDto -> competenceDto.getMatricule().equals("A100000"))
                .forEach(competenceDto -> {
                    Assertions.assertEquals("act1", competenceDto.getCodeActivite());
                    Assertions.assertEquals(1L, competenceDto.getIdExpertise());
                    Assertions.assertEquals(1L, competenceDto.getIdNiveau());
                });

        competenceListResult.stream().filter(competenceDto -> competenceDto.getMatricule().equals("A200000"))
                .forEach(competenceDto -> {
                    Assertions.assertEquals("act2", competenceDto.getCodeActivite());
                    Assertions.assertEquals(4L, competenceDto.getIdExpertise());
                    Assertions.assertEquals(2L, competenceDto.getIdNiveau());
                });
    }
}
