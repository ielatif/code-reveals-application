package com.socgen.eqc.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CacheClearerSchedulerTest {

    @Mock
    private CacheManager cacheManager;

    @InjectMocks
    private CacheClearerScheduler cacheClearerScheduler;

    @Mock
    private Cache cache;

    @Captor
    private ArgumentCaptor<String> captureCacheName;

    @Test
    void should_clear_cache_when_call_evict_cache_by_name() {

        when(cacheManager.getCache(captureCacheName.capture())).thenReturn(cache);
        cacheClearerScheduler.evictCacheByName("caheRES");
        verify(cache, Mockito.times(1)).clear();
        assertEquals("caheRES", captureCacheName.getValue());
    }
}
