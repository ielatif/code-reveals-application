package com.socgen.eqc.infrastructure.entite.structure;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.socgen.eqc.application.impl.DomainSample;
import com.socgen.eqc.config.EqcProperties;
import com.socgen.eqc.domain.model.EsFiliereToExclude;
import com.socgen.eqc.domain.model.LibelleEntiteStructure;
import com.socgen.eqc.domain.model.ParamsFictionalTetePerim;
import com.socgen.eqc.domain.model.ParamsFictionalTetePerimId;
import com.socgen.eqc.infrastructure.entite.structure.domain.*;
import com.socgen.eqc.infrastructure.persistance.EsFiliereToExcludeRepository;
import com.socgen.eqc.infrastructure.persistance.LibelleEntiteStructureRepository;
import com.socgen.eqc.infrastructure.persistance.ParamsFictionalTetePerimRepository;
import com.socgen.eqc.infrastructure.persistance.TetePerimetreRepository;
import com.socgen.eqc.infrastructure.res.ResClient;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Answers.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.*;

@ExtendWith({MockitoExtension.class})
class EntiteStructureServiceImplTests {

    @Mock
    private ResClient resClient;

    @Mock
    private LibelleEntiteStructureRepository libelleEntiteStructureRepository;

    @Mock
    private EsFiliereToExcludeRepository esFiliereToExcludeRepository;

    @Mock(answer = RETURNS_DEEP_STUBS)
    private EqcProperties eqcProperties;

    @InjectMocks
    private EntiteStructureServiceImpl entiteStructureService;

    @Mock
    private ParamsFictionalTetePerimRepository paramsFictionalTetePerimRepository;

    @Mock
    private TetePerimetreRepository tetePerimetreRepository;


    @Test
    void testFindAllAllEntiteStructure() throws IOException {
        //setup
        CentreService centreService = DomainSample.centreService.get();
        CentreService filiere1 = DomainSample.filiere1.get();
        CentreService filiere2 = DomainSample.filiere2.get();
        List<CentreService> centreServices = List.of(centreService, filiere1, filiere2);
        List<ParamsFictionalTetePerim> paramsFictionalTetePerims = List.of(
                ParamsFictionalTetePerim.builder()
                        .fictionalTetePerim(99999999L)
                        .paramsFictionalTetePerimId(new ParamsFictionalTetePerimId(3000334023L, 3000336334L, 3000382099L))
                        .build()
        );
        Collection collection = new ArrayList();
        collection.add("99999999");
        List<TetePerimetre> tetePerimetres = List.of(TetePerimetre.builder().id("99999999").libelle("Libelle tete perim fictive").active(true).build());
        when(eqcProperties.getContributeur().getDepartementBddf()).thenReturn(List.of("3000334215"));
        when(eqcProperties.getContributeur().getCodeType()).thenReturn(List.of("022", "023", "024"));
        when(eqcProperties.getContributeur().getFilieres()).thenReturn(List.of("3000334495", "3000334497"));
        when(resClient.getEntiteStructure()).thenReturn(centreServices);
        when(libelleEntiteStructureRepository.getAll()).thenReturn(mockLibellesEs());
        when(esFiliereToExcludeRepository.findAll()).thenReturn(Arrays.asList(
                EsFiliereToExclude.builder().code("3000334497").type("FILIERE").build(),
                EsFiliereToExclude.builder().code("3000331002").type("UG").build(),
                EsFiliereToExclude.builder().code("3000382001").type("ST").build())
        );

        when(paramsFictionalTetePerimRepository.findAll()).thenReturn(paramsFictionalTetePerims);
        when(tetePerimetreRepository.findAllById(any())).thenReturn(tetePerimetres);

        //Run the test
        entiteStructureService.afterPropertiesSet();
        List<CentreService> centreServices1 = entiteStructureService.getEntiteStructureFromRes();

        //Verify the results
        assertEquals(2, centreServices1.size());
        CentreService cs = centreServices1.get(0);
        CentreService csFiliere = centreServices1.get(1);

        assertFalse(cs.isFiliere());

        assertEquals("3000334023", centreService.getId());
        //Vérification pour le mapping de CDS
        assertEquals("VAL DE FONTENAY", cs.getLibelle());
        assertEquals(1, cs.getUniteGestions().size());
        assertEquals("DIR OPE CLIPRI", cs.getUniteGestions().get(0).getLibelle());
        assertEquals(3, cs.getUniteGestions().get(0).getServiceTraitements().size());
        assertEquals("OPE CLIPRI 1", cs.getUniteGestions().get(0).getServiceTraitements().get(0)
                .getLibelle());
        assertEquals("OPE CLIPRI 2", cs.getUniteGestions().get(0).getServiceTraitements().get(1)
                .getLibelle());

        assertEquals("OPE CLIPRI 3", cs.getUniteGestions().get(0).getServiceTraitements().get(2)
                .getLibelle());

        assertEquals(1, cs.getUniteGestions().get(0).getServiceTraitements().get(2)
                .getListeTetePerimetre().size());

        assertEquals("99999999", cs.getUniteGestions().get(0).getServiceTraitements().get(2)
                .getListeTetePerimetre().get(0).getId());

        assertEquals("Libelle tete perim fictive", cs.getUniteGestions().get(0).getServiceTraitements().get(2)
                .getListeTetePerimetre().get(0).getLibelle());

        assertTrue(cs.getUniteGestions().get(0).getServiceTraitements().get(2)
                .getListeTetePerimetre().get(0).getActive());

        assertTrue(csFiliere.isFiliere());
        assertEquals("3000334495", csFiliere.getId());
        assertEquals("FIA", csFiliere.getLibelle());
        assertEquals(1, csFiliere.getUniteGestions().size());

        assertEquals("BDDF OTX FIA TOUL DIR FIA", csFiliere.getUniteGestions().get(0).getLibelle());
        assertEquals(1, csFiliere.getUniteGestions().get(0).getServiceTraitements().size());
        assertEquals("BDDF OTX FIA TOUL FIA 1", csFiliere.getUniteGestions().get(0).getServiceTraitements().get(0)
                .getLibelle());
        verify(libelleEntiteStructureRepository, Mockito.times(3)).saveAll(
                anyList()
        );

    }

    private Map<String, String> mockLibellesEs() throws IOException {
        byte[] bytes = getClass().getResourceAsStream("/libelles_es.csv").readAllBytes();
        Map<String, String> map = new HashMap<>();
        CsvMapper mapper = new CsvMapper();
        CsvSchema schema = mapper.schemaFor(LibelleEntiteStructure.class);
        schema = schema.withColumnSeparator(';').withNullValue("NULL").withoutEscapeChar();
        MappingIterator<LibelleEntiteStructure> iterator = mapper.readerFor(LibelleEntiteStructure.class).with(schema)
                .readValues(bytes);
        while (iterator.hasNext()) {
            LibelleEntiteStructure libelleEntiteStructure = iterator.next();
            map.put(libelleEntiteStructure.getCode(), libelleEntiteStructure.getLibelle());
        }
        return map;
    }

    @Test
    void testReworkListCentreService() throws Exception {
        // Setup
        final TetePerimetre tetePerimetre1 = TetePerimetre.builder()
                .id("idTeteDePerimtre1")
                .libelle("libelleTeteDePerimtre1")
                .active(true)
                .build();
        final TetePerimetre tetePerimetre2 = TetePerimetre.builder()
                .id("idTeteDePerimtre2")
                .libelle("libelleTeteDePerimtre2")
                .active(true)
                .build();
        final ServiceTraitement serviceTraitement1 = ServiceTraitement.builder()
                .id("idServiceTraitement1")
                .libelle("libelleServiceTraitement1")
                .ville("villeServiceTraitement1")
                .listeTetePerimetre(Arrays.asList(tetePerimetre1))
                .build();
        final ServiceTraitement serviceTraitement2 = ServiceTraitement.builder()
                .id("idServiceTraitement2")
                .libelle("libelleServiceTraitement2")
                .ville("villeServiceTraitement2")
                .listeTetePerimetre(Arrays.asList(tetePerimetre2))
                .build();
        final UniteGestion uniteGestion1 = UniteGestion.builder()
                .id("idUniteGestion1")
                .libelle("libelleUniteGestion1")
                .ville("villeUniteGestion1")
                .serviceTraitements(Arrays.asList(serviceTraitement1))
                .build();
        final UniteGestion uniteGestion2 = UniteGestion.builder()
                .id("idUniteGestion2")
                .libelle("libelleUniteGestion2")
                .ville("villeUniteGestion2")
                .serviceTraitements(Arrays.asList(serviceTraitement2))
                .build();
        final CentreService centreService = CentreService.builder()
                .id("idCentreService")
                .ville("villeCentreService")
                .filiere(true)
                .libelle("libelleCentreService")
                .uniteGestions(Arrays.asList(uniteGestion1, uniteGestion2))
                .build();

        // Run the test
        Map<String, TetePerimetre> parametreTetePeri = new HashMap<>();
        final List<CentreService> result = entiteStructureService.reworkListCentreService(Arrays.asList(centreService), parametreTetePeri);
        centreService.setTeteDePerimetres(new ObjectMapper().readTree("{\"idTeteDePerimtre2\":{\"id\":\"idTeteDePerimtre2\",\"active\":true,\"libelle\":\"libelleTeteDePerimtre2\",\"ugs\":{\"idUniteGestion2\":{\"id\":\"idUniteGestion2\",\"ville\":\"villeUniteGestion2\",\"libelle\":\"libelleUniteGestion2\",\"sts\":{\"idServiceTraitement2\":{\"id\":\"idServiceTraitement2\",\"libelle\":\"libelleServiceTraitement2\",\"ville\":\"villeServiceTraitement2\",\"listeTetePerimetre\":[{\"id\":\"idTeteDePerimtre2\",\"libelle\":\"libelleTeteDePerimtre2\",\"active\":true}]}}}}},\"idTeteDePerimtre1\":{\"id\":\"idTeteDePerimtre1\",\"active\":true,\"libelle\":\"libelleTeteDePerimtre1\",\"ugs\":{\"idUniteGestion1\":{\"id\":\"idUniteGestion1\",\"ville\":\"villeUniteGestion1\",\"libelle\":\"libelleUniteGestion1\",\"sts\":{\"idServiceTraitement1\":{\"id\":\"idServiceTraitement1\",\"libelle\":\"libelleServiceTraitement1\",\"ville\":\"villeServiceTraitement1\",\"listeTetePerimetre\":[{\"id\":\"idTeteDePerimtre1\",\"libelle\":\"libelleTeteDePerimtre1\",\"active\":true}]}}}}}}"));

        // Verify the results
        assertEquals(Arrays.asList(centreService), result);
    }

}
