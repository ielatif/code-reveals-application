package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.config.CacheTestConfig;
import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.infrastructure.smbo.dto.CorrespondanceActiviteDto;
import com.socgen.eqc.infrastructure.smbo.dto.CorrespondanceDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.TetePerimetreDto;
import io.restassured.response.Response;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.ExpectedException;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Arrays;
import java.util.List;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@SuppressWarnings("unchecked")
@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "smbo-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
@ExtendWith({HoverflyExtension.class, SpringExtension.class})
@Import(CacheTestConfig.class)
@EnableCaching
class ActiviteParamsResourceIT extends AbstractIT {

    @Rule
    public final ExpectedException exception = ExpectedException.none();
    
    @Test
    @Sql({"/db/clean-db.sql"})
    void testGetAllActivite() {
        // Setup

        // Run the test
        List<ActiviteParams> activites = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .get("activites-params").as(List.class);

        // Verify the results
        Assertions.assertEquals(11, activites.size());
    }

    @Test
    @Sql({"/db/clean-db.sql"})
    void testGetAllTetePerimetres() {

        // Run the test
        List<TetePerimetreDto> tetePerimetreDtos = given()
                .header("Authorization", setCustomUserWithRoles("ADMINISTRER"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .get("/tete-perimetres").as(List.class);

        // Verify the results
        Assertions.assertEquals(9, tetePerimetreDtos.size());
    }


    @Test
    @Sql({"/db/clean-db.sql"})
    void testGetCorrespondanceByTetePerimetre() {

        // Run the test
        List<CorrespondanceActiviteDto> listCorrespondanceActiviteDto = given()
                .header("Authorization", setCustomUserWithRoles("ADMINISTRER"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .queryParam("tetePerimetres",3000350989L)
                .get("correspondances").as(List.class);

        // Verify the results
        Assertions.assertEquals(1, listCorrespondanceActiviteDto.size());
    }

    @Test
    @Sql({"/db/clean-db.sql"})
    void testSaveCorrespondances() {
        CorrespondanceActiviteDto correspondanceActiviteDto = CorrespondanceActiviteDto.builder()
                .id(1L)
                .correspondanceList(Arrays.asList(CorrespondanceDto.builder().id("1222").idNature(10L).type("CR").build()))
                .build();
        // Run the test
        Response post = given()
                .header("Authorization", setCustomUserWithRoles("ADMINISTRER"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON)
                .body(correspondanceActiviteDto).when()
                .post("correspondances/");
        // Verify the results
        Assertions.assertEquals(204,post.getStatusCode());
    }
}
