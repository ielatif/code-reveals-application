package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.application.ExtensionPerimetreService;
import com.socgen.eqc.config.EqcProperties;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.infrastructure.persistance.ExtensionPerimetreRepository;
import com.socgen.eqc.infrastructure.persistance.RenfortRepository;
import com.socgen.eqc.interfaces.rest.dto.Action;
import com.socgen.eqc.interfaces.rest.dto.ActionRenfortDto;
import com.socgen.eqc.interfaces.rest.dto.DuplicationDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.mapper.ActionMapper;
import com.socgen.eqc.mapper.ActionMapperImpl;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Answers.RETURNS_DEEP_STUBS;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RenfortServiceImplTest {

    @Mock
    private RenfortRepository renfortRepository;

    @Mock
    private AffectationService affectationService;

    @Mock
    private EquipeService equipeService;

    @Spy
    private ActionMapper actionMapper = new ActionMapperImpl();

    @InjectMocks
    private RenfortServiceImpl renfortService;

    @Captor
    private ArgumentCaptor<List<Renfort>> captureRenfortList;

    @Mock(answer = RETURNS_DEEP_STUBS)
    private EqcProperties eqcProperties;

    @Mock
    private ExtensionPerimetreService extensionPerimetreService;

    @Captor
    private ArgumentCaptor<Renfort> captureRenfortGhabi;

    @Mock
    private ExtensionPerimetreRepository extensionPerimetreRepository;

    @Test
    void should_update_renfort_inter_filiere() {
        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");

        ActionRenfortDto actionRenfortDto1 = buildActionRenfortDto(1L, "A0000", LocalDate
                .of(2020, 1, 1), Action.DELETE, Intervalle.APRES_MIDI, 3000324057L, 3000324056L, 3000324051L, 3000324052L, 3000324052L, 3000324057L, "RENFORT- MOLIERE", (byte)5);

        ActionRenfortDto actionRenfortDto2 = buildActionRenfortDto(2L, "A0001", LocalDate
                .of(2020, 1, 1), Action.CREATE, Intervalle.APRES_MIDI, 3000324057L, 3000324056L, 3000324051L, 3000324052L, 3000324052L, 3000324010L, "RENFORT- MOLIERE", (byte)5);

        final List<ActionRenfortDto> actionRenforts = Arrays.asList(actionRenfortDto1, actionRenfortDto2);

        when(renfortRepository.findById(1L)).thenReturn(Optional.of(Renfort.builder().id(1L).build()));
        when(eqcProperties.getContributeur().getFilieres()).thenReturn(List.of("3000324057"));
        Mockito.lenient().when(equipeService.findById(anyLong())).thenReturn(Equipe.builder().build());

        // Run the test2
        renfortService.updateOrDelete(actionRenforts, sgUserPrincipalMock);

        // Verify the results
        verify(extensionPerimetreService, Mockito.never()).createExtension(Mockito.eq(actionRenfortDto2.getMatricule()), Mockito.eq(sgUserPrincipalMock.getCurrentUser().getUserId()), captureRenfortGhabi.capture());
        verify(renfortRepository, Mockito.atMostOnce()).saveAll(captureRenfortList.capture());
        List<Renfort> value = captureRenfortList.getValue();
        assertEquals(1, value.size());
        verify(affectationService, Mockito.only()).removeAll(Mockito.anyList());
        verify(renfortRepository, Mockito.atMostOnce()).deleteAll(captureRenfortList.capture());
        value = captureRenfortList.getValue();
        assertEquals(1, value.size());
    }

    @Test
    void should_update_one_renfort_inter_filiere_and_one_renfort_ghabi() {
        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");

        ActionRenfortDto actionRenfortDto1 = buildActionRenfortDto(1L, "A0000", LocalDate
                        .of(2020, 1, 1), Action.CREATE, Intervalle.MATIN, 3000324058L, 3000324056L, 3000324051L, 3000324052L,
                3000324057L, 3000324010L, "RENFORT- ORLEAN", (byte)5);

        ActionRenfortDto actionRenfortDto2 = buildActionRenfortDto(2L, "A0001", LocalDate
                        .of(2030, 1, 1), Action.CREATE, Intervalle.APRES_MIDI, 3000324057L, 3000324056L, 3000324051L,
                3000324057L, 3000324057L, 3000324010L, "RENFORT- MOLIERE", (byte)5);

        final List<ActionRenfortDto> actionRenforts = Arrays.asList(actionRenfortDto1, actionRenfortDto2);
        when(eqcProperties.getContributeur().getFilieres()).thenReturn(List.of("3000324057"));

        List<Renfort> renfortGhabiExpected = actionMapper.toListRenforts(List.of(actionRenfortDto2));
        when(equipeService.save(Equipe.builder().codeCds(3000324058L).codeUg(3000324056L).code(3000324051L).formatSemainier(Byte.valueOf("5")).build())).thenReturn(Equipe.builder().codeCds(3000324058L).codeUg(3000324056L).code(3000324051L).formatSemainier(Byte.valueOf("5")).build());
        when(equipeService.save(Equipe.builder().codeCds(3000324057L).codeUg(3000324056L).code(3000324051L).formatSemainier(Byte.valueOf("5")).build())).thenReturn(Equipe.builder().codeCds(3000324057L).codeUg(3000324056L).code(3000324051L).formatSemainier(Byte.valueOf("5")).build());
        Mockito.lenient().when(equipeService.findById(anyLong())).thenReturn(Equipe.builder().build());

        // Run the test2
        renfortService.updateOrDelete(actionRenforts, sgUserPrincipalMock);

        // Verify the results
        verify(extensionPerimetreService, Mockito.atMostOnce()).createExtension(Mockito.eq(actionRenfortDto2.getMatricule()), Mockito.eq(sgUserPrincipalMock.getCurrentUser().getUserId()), captureRenfortGhabi.capture());

        Renfort renfortGhabiToSave = captureRenfortGhabi.getValue();

        verify(renfortRepository, Mockito.atMostOnce()).saveAll(captureRenfortList.capture());
        List<Renfort> value = captureRenfortList.getValue();
        assertEquals(2, value.size());
        assertEquals(renfortGhabiToSave, renfortGhabiExpected.get(0));

        verify(renfortRepository, Mockito.never()).deleteAll(captureRenfortList.capture());
        value = captureRenfortList.getValue();
        assertEquals(2, value.size());
    }

    @Test
    void should_update_two_renfort_intra_filiere_inter_ug() {
        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");

        ActionRenfortDto actionRenfortDto1 = buildActionRenfortDto(1L, "A0001", LocalDate
                        .of(2030, 1, 1), Action.CREATE, Intervalle.MATIN, 3000324057L, 3000324056L, 3000324051L, 3000324052L,
                3000324057L, 3000324010L, "RENFORT- ORLEAN", (byte)5);

        ActionRenfortDto actionRenfortDto2 = buildActionRenfortDto(2L, "A0001", LocalDate
                        .of(2030, 1, 1), Action.CREATE, Intervalle.APRES_MIDI, 3000324057L, 3000324056L, 3000324051L,
                3000324053L, 3000324057L, 3000324010L, "RENFORT- MOLIERE", (byte)5);

        final List<ActionRenfortDto> actionRenforts = Arrays.asList(actionRenfortDto1, actionRenfortDto2);
        List<Renfort> renfortGhabiExpected = actionMapper.toListRenforts(List.of(actionRenfortDto1));
        when(eqcProperties.getContributeur().getFilieres()).thenReturn(List.of("3000324057"));
        when(equipeService.save(renfortGhabiExpected.get(0).getEquipe())).thenReturn(renfortGhabiExpected.get(0).getEquipe());
        Mockito.lenient().when(equipeService.findById(anyLong())).thenReturn(Equipe.builder().build());

        // Run the test2
        renfortService.updateOrDelete(actionRenforts, sgUserPrincipalMock);

        // Verify the results
        verify(extensionPerimetreService, Mockito.atMostOnce()).createExtension(Mockito.eq(actionRenfortDto2.getMatricule()), Mockito.eq(sgUserPrincipalMock.getCurrentUser().getUserId()), captureRenfortGhabi.capture());

        List<Renfort> renfortsGhabiToSave = captureRenfortGhabi.getAllValues();

        verify(renfortRepository, Mockito.atMostOnce()).saveAll(captureRenfortList.capture());
        List<Renfort> value = captureRenfortList.getValue();
        assertEquals(2, value.size());

        Assertions.assertArrayEquals(renfortsGhabiToSave.toArray(), renfortGhabiExpected.toArray());
        value = captureRenfortList.getValue();
        assertEquals(2, value.size());
    }

    @Test
    void should_update_two_renfort_intra_filiere_intra_ug() {

        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");

        ActionRenfortDto actionRenfortDto1 = buildActionRenfortDto(1L, "A0001", LocalDate
                        .of(2030, 1, 1), Action.CREATE, Intervalle.MATIN, 3000324057L, 3000324056L, 3000324051L, 3000324052L,
                3000324057L, 3000324056L, "RENFORT- ORLEAN", (byte)5);

        ActionRenfortDto actionRenfortDto2 = buildActionRenfortDto(2L, "A0001", LocalDate
                        .of(2030, 1, 1), Action.CREATE, Intervalle.APRES_MIDI, 3000324057L, 3000324056L, 3000324051L,
                3000324053L, 3000324057L, 3000324056L, "RENFORT- MOLIERE", (byte)5);

        final List<ActionRenfortDto> actionRenforts = Arrays.asList(actionRenfortDto1, actionRenfortDto2);
        when(eqcProperties.getContributeur().getFilieres()).thenReturn(List.of("3000324057"));

        List<Renfort> renfortGhabiExpected = actionMapper.toListRenforts(List.of(actionRenfortDto1));
        when(equipeService.save(renfortGhabiExpected.get(0).getEquipe())).thenReturn(renfortGhabiExpected.get(0).getEquipe());
        Mockito.lenient().when(equipeService.findById(anyLong())).thenReturn(Equipe.builder().build());

        // Run the test2
        renfortService.updateOrDelete(actionRenforts, sgUserPrincipalMock);

        // Verify the results
        verify(extensionPerimetreService, Mockito.atMost(0)).createExtension(Mockito.eq(actionRenfortDto2.getMatricule()), Mockito.eq(sgUserPrincipalMock.getCurrentUser().getUserId()), captureRenfortGhabi.capture());

        List<Renfort> renfortsGhabiToSave = captureRenfortGhabi.getAllValues();
        assertEquals(0, renfortsGhabiToSave.size());

        verify(renfortRepository, Mockito.atMostOnce()).saveAll(captureRenfortList.capture());
        List<Renfort> value = captureRenfortList.getValue();
        assertEquals(2, value.size());
        value = captureRenfortList.getValue();
        assertEquals(2, value.size());
    }

    private ActionRenfortDto buildActionRenfortDto(Long id, String matricule, LocalDate date, Action action, Intervalle intervalle, Long codeCdsAide, Long codeUgAide, Long codeStAide, Long codeStRattach, Long cdsRattachement, Long ugRattachement, String libellerenfort, Byte formatSemainier) {
        ActionRenfortDto actionRenfortDto1 = new ActionRenfortDto();
        actionRenfortDto1.setId(id);
        actionRenfortDto1.setMatricule(matricule);
        actionRenfortDto1.setDate(date);
        actionRenfortDto1.setAction(action);
        actionRenfortDto1.setIntervalle(intervalle);
        actionRenfortDto1.setCodeCdsAide(codeCdsAide);
        actionRenfortDto1.setCodeUgAide(codeUgAide);
        actionRenfortDto1.setCodeStAide(codeStAide);
        actionRenfortDto1.setCodeStRattachement(codeStRattach);
        actionRenfortDto1.setLibelleRenfort(libellerenfort);
        actionRenfortDto1.setCodeCdsRattachement(cdsRattachement);
        actionRenfortDto1.setCodeUgRattachement(ugRattachement);
        actionRenfortDto1.setFormatSemainier(formatSemainier);
        return actionRenfortDto1;

    }

    @Test
    void should_find_renforts_inter_UG_from_today() {
        when(renfortRepository.findByCollaborateurMatriculeAndDate("a474508", LocalDate.now()))
                .thenReturn(
                        List.of(Renfort.builder()
                                .id(1L)
                                .codeUgRattachement(357L)
                                .codeUgAide(358L)
                                .build()
                        )
                );
        // Run Test
        List<Renfort> renfortList = renfortService.findRenfortsInterUGFromToday("a474508");
        // Verify the results
        assertEquals(1, renfortList.size());
    }

    @Test
    void supprimerSemaine() {
        LocalDate dateFin = LocalDate.of(2020, 2, 8);
        LocalDate dateDebut = LocalDate.of(2020, 2, 2);
        List<String> matricules = List.of("X171001");
        SuppressionSemaineDto dto = SuppressionSemaineDto.builder()
                .dateFin(dateFin.minusDays(1))
                .dateDebut(dateDebut.plusDays(1))
                .codeServiceTraitement(1L)
                .matricules(matricules)
                .matriculesRenfort(List.of("X171002"))
                .build();
        renfortService.supprimerSemaine(dto);
        verify(renfortRepository, Mockito.times(1)).deleteByCollaborateurs(
                matricules,
                dateDebut,
                dateFin,
                1L
        );
    }

    @Test
    void supprimerSemaineEmptyList() {
        LocalDate dateFin = LocalDate.of(2020, 2, 8);
        LocalDate dateDebut = LocalDate.of(2020, 2, 2);
        SuppressionSemaineDto dto = SuppressionSemaineDto.builder()
                .dateFin(dateFin.minusDays(1))
                .dateDebut(dateDebut.plusDays(1))
                .codeServiceTraitement(1L)
                .matricules(Lists.emptyList())
                .matriculesRenfort(List.of("X171002"))
                .build();
        Renfort renfort = Renfort.builder()
                .id(1L)
                .codeCdsAide(1212L)
                .build();
        Mockito.lenient().when(renfortRepository.
                findByCodeStRattachementAndDateBetweenAndCollaborateurMatriculeIn
                        (any(), any(), any(), any())).thenReturn(Collections.singletonList(renfort));
        renfortService.supprimerSemaine(dto);
        verify(renfortRepository, Mockito.never()).deleteByCollaborateurs(any(), any(), any(), any());
    }

    @Test
    void supprimerSemaineWithExtensions() {
        LocalDate dateFin = LocalDate.of(2020, 2, 8);
        LocalDate dateDebut = LocalDate.of(2020, 2, 2);
        List<String> matricules = List.of("X171001");
        SuppressionSemaineDto dto = SuppressionSemaineDto.builder()
                .dateFin(dateFin.minusDays(1))
                .dateDebut(dateDebut.plusDays(1))
                .codeServiceTraitement(1L)
                .matricules(matricules)
                .matriculesRenfort(List.of("X171002"))
                .build();
        Renfort renfort = Renfort.builder()
                .extensionPerimetre(ExtensionPerimetre.builder()
                        .id(1L)
                        .idGhabi(1L)
                        .dateCreation(LocalDate.of(2020, 1, 1).atStartOfDay())
                        .build())
                .build();
        when(renfortRepository.
                findByCodeStRattachementAndDateBetweenAndCollaborateurMatriculeIn
                        (any(), any(), any(), any())).thenReturn(Collections.singletonList(renfort));
        renfortService.supprimerSemaine(dto);
        verify(renfortRepository, Mockito.times(1)).deleteByCollaborateurs(
                matricules,
                dateDebut,
                dateFin,
                1L
        );
        verify(extensionPerimetreService, Mockito.times(1)).deleteExtensionAsync(any());
    }

    @Test
    void should_delete_all_extension_perimetre_when_remove_all_renfort() {
        Renfort renfort1 = Renfort.builder()
                .extensionPerimetre(ExtensionPerimetre.builder()
                        .id(1L)
                        .idGhabi(1L)
                        .dateCreation(LocalDate.of(2020, 1, 1).atStartOfDay())
                        .build())
                .build();
        Renfort renfort2 = Renfort.builder()
                .build();
        renfortService.removeAll("X100100", Arrays.asList(renfort1, renfort2));

        verify(extensionPerimetreService, Mockito.times(1)).deleteExtensionAsync(
                List.of(renfort1)
        );
    }

    private List<Renfort> getRenfort(LocalDate date){
        List<Renfort> renfortList = new ArrayList<>();
        if(LocalDate.now().isEqual(date)) {
            Renfort renfort = Renfort.builder()
                    .date(date.plusDays(1))
                    .collaborateur(
                            Collaborateur.builder()
                                    .matricule("A474508")
                                    .idRhLocal("A474508")
                                    .loginWindows("A474508")
                                    .nom("Dupont")
                                    .prenom("Jean")
                                    .build()
                    )
                    .codeCdsAide(1L)
                    .codeUgAide(2L)
                    .equipe(Equipe.builder().codeCds(1L).codeUg(2L).code(3L).build())
                    .codeCdsRattachement(4L)
                    .codeUgRattachement(5L)
                    .codeStRattachement(6L)
                    .build();
            renfortList.add(renfort);
        }
        return renfortList;
    }
    @Test
    void testDupliquer() {
        // Setup
        LocalDate dateSource = LocalDate.now();
        LocalDate dateCible = LocalDate.now().minusWeeks(1);
        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");
        final DuplicationDto duplicationDto = DuplicationDto.builder().dateCible(dateSource).dateSource(dateCible)
                .matricules(List.of("X171001")).build();
        Mockito.when(renfortRepository
                .findByCollaborateurMatriculeInAndDateBetween(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(getRenfort(dateSource)).thenReturn(getRenfort(dateCible));
        when(eqcProperties.getContributeur().getFilieres()).thenReturn(List.of("3000324057"));
        // Run the test
        renfortService.dupliquerSemaine(duplicationDto.getDateSource(), duplicationDto.getDateCible(), duplicationDto.getMatricules(), sgUserPrincipalMock);
        // Verify the results
        Mockito.verify(renfortRepository, Mockito.atLeastOnce()).saveAll(captureRenfortList.capture());
        Assertions.assertEquals(1, captureRenfortList.getValue().size());
    }
}
