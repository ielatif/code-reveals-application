package com.socgen.eqc.application.mock;

import com.socgen.eqc.application.CompetenceService;
import org.mockito.Mockito;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;


public class FakeCompetenceService {

    private final CompetenceService mock;

    public FakeCompetenceService() {
        this.mock = Mockito.mock(CompetenceService.class);
        init();
    }

    private void init() {
        //when(mock.getProfilByCollaborateurs(any())).thenReturn(List.of(FakeDomain.competenceSupplier.get()));
    }

    public CompetenceService getMock() {
        return mock;
    }
}
