package com.socgen.eqc.config;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import java.util.ArrayList;
import java.util.List;

@TestConfiguration
public class CacheTestConfig {

    @Bean(name = "testCacheManager")
    @Primary
    public CacheManager cacheManager() {
        SimpleCacheManager cacheManager = new SimpleCacheManager();
        List<ConcurrentMapCache> caches = new ArrayList<>();
        caches.add(new ConcurrentMapCache("SmboActivitesCache"));
        caches.add(new ConcurrentMapCache("SmboTetePerimetresCache"));
        caches.add(new ConcurrentMapCache("SmboFamillesCache"));

        cacheManager.setCaches(caches);
        return cacheManager;
    }
}
