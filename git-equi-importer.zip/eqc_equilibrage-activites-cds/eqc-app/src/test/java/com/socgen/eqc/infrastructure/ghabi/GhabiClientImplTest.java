package com.socgen.eqc.infrastructure.ghabi;


import com.socgen.eqc.application.exception.GhabiException;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionDto;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionResponseDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GhabiClientImplTest {

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private Client ghabitClientTarget;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private ApplicationProperties applicationProperties;


    @InjectMocks
    GhabiClientImpl ghabiClient;

    private Invocation.Builder ghabiDemandeInvocationBuilder;

    private Invocation.Builder ghabiDeleteInvocationBuilder;

    private Invocation.Builder ghabiGetInvocationBuilder;

    private Invocation.Builder ghabiUpdateInvocationBuilder;

    private GhabiExtensionDto ghabiExtensionDto = new GhabiExtensionDto();

    private GhabiExtensionResponseDto ghabiExtensionResponseDto = new GhabiExtensionResponseDto();

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private Response response;

    @Captor
    private ArgumentCaptor<Entity> captureEntity;

    private static Long ID_EXTENSION = 1482L;

    @BeforeEach
    void setup() {
        lenient().when(applicationProperties.getGhabi().getExtensionPerimetrePath()).thenReturn("perim-path");
        lenient().when(applicationProperties.getGhabi().getServerUrl()).thenReturn("server-path");
        lenient().when(applicationProperties.getSgConnect().getPassword()).thenReturn("sgconnect-passw");

        URI path = UriBuilder.fromPath(applicationProperties.getGhabi().getServerUrl())
                .path(applicationProperties.getGhabi().getExtensionPerimetrePath())
                .build();

        ghabiDemandeInvocationBuilder = ghabitClientTarget.target(path)
                .request()
                .header("Content-Type", MediaType.MULTIPART_FORM_DATA)
                .accept(MediaType.APPLICATION_JSON_TYPE);

        ghabiDeleteInvocationBuilder = ghabitClientTarget.target(path)
                .request(MediaType.MULTIPART_FORM_DATA)
                .accept(MediaType.APPLICATION_JSON_TYPE);


        ghabiGetInvocationBuilder = ghabitClientTarget.target(path)
                .path(String.valueOf((ID_EXTENSION)))
                .request()
                .accept(MediaType.APPLICATION_JSON_TYPE);

        ghabiUpdateInvocationBuilder = ghabitClientTarget.target(path)
                .request()
                .header("Content-Type", MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON  );

        ghabiExtensionResponseDto.setId(1L);
        ghabiExtensionResponseDto.setStatus(2);
        ghabiExtensionResponseDto.setCreateurId("createur");
        ghabiExtensionResponseDto.setDateDebut("2030-01-01");
        ghabiExtensionResponseDto.setDateFin("2030-01-04");
        ghabiExtensionResponseDto.setUtilisateurId("util");
        ghabiExtensionResponseDto.setPerimStIds(Arrays.asList("30003000"));
        ghabiExtensionResponseDto.setUtilisateurStId("31003100");

        ghabiExtensionDto.setCreateurId("createur");
        ghabiExtensionDto.setDateDebut("2030-01-01");
        ghabiExtensionDto.setDateFin("2030-01-04");
        ghabiExtensionDto.setId(1L);
        ghabiExtensionDto.setPerimStIds(Arrays.asList("30003000"));
        ghabiExtensionDto.setUtilisateurId("Utilisateur");
        ghabiExtensionDto.setUtilisateurStId("31003100");
    }

    @Test
    void should_create_ghabi_request() throws GhabiException {
		// When
        Mockito.when(response.getStatusInfo().getFamily()).thenReturn(Response.Status.Family.SUCCESSFUL);
        Mockito.when(response.readEntity(Mockito.any(GenericType.class))).thenReturn(ghabiExtensionResponseDto);

        when(ghabiDemandeInvocationBuilder.post(any())).thenReturn(response);

        // Given
        Object expectedResult = ghabiClient.createExtension(ghabiExtensionDto);

        // Then
        assertThat(expectedResult).isInstanceOf(GhabiExtensionResponseDto.class);
    }

    @Test
    void should_throw_exception_when_creating_ghabi_request() {
		// When
        Mockito.when(response.getStatusInfo().getFamily()).thenReturn(Response.Status.Family.SERVER_ERROR);
        when(ghabiDemandeInvocationBuilder.post(any())).thenReturn(response);

        // Given
        Throwable thrown = catchThrowable(() -> { ghabiClient.createExtension(ghabiExtensionDto); });

        // Then
        assertThat(thrown).isInstanceOf(GhabiException.class);
    }

    @Test
    void should_delete_ghabi_request() {
    	// When
        Mockito.when(response.getStatusInfo().getFamily()).thenReturn(Response.Status.Family.SUCCESSFUL);
        when(ghabiDeleteInvocationBuilder.build(eq("DELETE"), captureEntity.capture()).invoke()).thenReturn(null);

        // Given
        ghabiClient.deleteExtension(1L);

        // Then
        Entity<Form> entityFormCapture = captureEntity.getValue();
        Form form =entityFormCapture.getEntity();

        assertThat(form.asMap().get("id").get(0)).isEqualTo("1");
    }

    @Test
    void should_get_detail_extension() {

        Mockito.when(response.readEntity(Mockito.any(GenericType.class))).thenReturn(ghabiExtensionResponseDto);
        Mockito.when(response.getStatusInfo().getFamily()).thenReturn(Response.Status.Family.SUCCESSFUL);
        when(ghabiGetInvocationBuilder.buildGet().invoke()).thenReturn(response);

        // Given
        Object expectedResult = ghabiClient.getExtensionDetail(ID_EXTENSION);

        // Then
        assertThat(expectedResult).isInstanceOf(GhabiExtensionResponseDto.class);
    }


    @Test
    void should_update_extension() {

        Mockito.when(response.readEntity(Mockito.any(GenericType.class))).thenReturn(ghabiExtensionResponseDto);
        Mockito.when(response.getStatusInfo().getFamily()).thenReturn(Response.Status.Family.SUCCESSFUL);
        when(ghabiUpdateInvocationBuilder.buildPut(Entity.json(ghabiExtensionDto)).invoke()).thenReturn(response);

        // Given
        Object expectedResult = ghabiClient.updateExtension(ghabiExtensionDto);

        // Then
        assertThat(expectedResult).isInstanceOf(GhabiExtensionResponseDto.class);
    }
}
