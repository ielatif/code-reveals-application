package com.socgen.eqc.interfaces.rest;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.socgen.eqc.domain.model.ParamsFictionalTetePerim;
import com.socgen.eqc.domain.model.ParamsFictionalTetePerimId;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.infrastructure.persistance.ParamsFictionalTetePerimRepository;
import com.socgen.eqc.infrastructure.persistance.TetePerimetreRepository;
import com.socgen.eqc.infrastructure.res.ResClient;
import io.specto.hoverfly.junit5.HoverflyExtension;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.jdbc.Sql;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;


@ExtendWith({HoverflyExtension.class})
class EntiteStructureResourceIT extends AbstractIT {

    @MockBean
    private ResClient resClient;

    @MockBean
    ParamsFictionalTetePerimRepository paramsFictionalTetePerimRepository;
    @MockBean
    private TetePerimetreRepository tetePerimetreRepository;

    @Test
    @Sql("/db/interfaces/rest/EntiteStructureResourceIT/libelles_es.sql")
    @DisplayName("Doit récupérer les ES et exclure les CDSs Corse et les STs NEG et AJU")
    void should_retrieve_and_exclude_es() throws IOException {
        // Setup
        InputStream resFile = getClass().getResourceAsStream("/res.json");
        List<CentreService> centreServices = new ObjectMapper().readValue(resFile, new TypeReference<>() {
        });

        when(resClient.getEntiteStructure()).thenReturn(centreServices);

        List<ParamsFictionalTetePerim> listFictionalTetePerim = new ArrayList<>();
        ParamsFictionalTetePerim paramsFictionalTetePerim = new ParamsFictionalTetePerim();
        paramsFictionalTetePerim.setFictionalTetePerim(3000359245L);
        paramsFictionalTetePerim.setParamsFictionalTetePerimId(new ParamsFictionalTetePerimId(3000334008L,3000336323L, 3000319856L));
        listFictionalTetePerim.add(paramsFictionalTetePerim);

        when(paramsFictionalTetePerimRepository.findAll()).thenReturn(listFictionalTetePerim);

        List<TetePerimetre> tetesPerim = Arrays.asList(
                TetePerimetre.builder().id("3000359245").libelle("tet1").active(true).build()
        );

        when(tetePerimetreRepository.findAllById(any())).thenReturn(tetesPerim);

        assertThat(centreServices.size()).isEqualTo(27);
        assertThat(centreServices).flatExtracting("uniteGestions").flatExtracting("serviceTraitements")
                .extracting("libelle", String.class)
                .anyMatch(libelle -> libelle.contains("NEG") || libelle.contains("AJU"));

        CentreService[] centreServ = given().header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE).accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .queryParam("codeServiceRattachement","124578")
                .get("entites-structure")
                .as(CentreService[].class);
        // Run the test
        List<CentreService> expectedResult = Arrays.asList(centreServ);

        // Verify the results
        assertThat(expectedResult).size().isEqualTo(19);
        assertThat(expectedResult)
                .flatExtracting("uniteGestions").flatExtracting("serviceTraitements")
                .extracting("libelle").doesNotContain("NEG", "AJU");
        assertThat(expectedResult.stream().filter(centreService -> centreService.getId().equals("3000334008")).collect(Collectors.toList())).flatExtracting("uniteGestions").flatExtracting("serviceTraitements")
                .flatExtracting("listeTetePerimetre")
                .isEqualTo(
                        Arrays.asList(
                                TetePerimetre.builder().id("3000359245").libelle("tet1").active(true).build(),
                                TetePerimetre.builder().id("3000359245").libelle("tet1").active(true).build(),
                                TetePerimetre.builder().id("3000359245").libelle("tet1").active(true).build()
                        )
                );
    }

}
