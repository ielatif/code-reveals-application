package com.socgen.eqc.infrastructure.extraction;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.*;
import com.socgen.eqc.application.*;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.application.impl.ActiviteParamsServiceImpl;
import com.socgen.eqc.application.impl.CompetenceServiceImpl;
import com.socgen.eqc.application.impl.ExtractServiceImpl;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.domain.model.TypeActivite;
import com.socgen.eqc.domain.model.Unite;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.infrastructure.persistance.*;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.SmboClientImpl;
import com.socgen.eqc.infrastructure.smbo.dto.*;
import com.socgen.eqc.interfaces.rest.dto.IndicateurSearchDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurEtpInputDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.StockATraiterStDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.StockOutputDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteParamsDto;
import com.socgen.eqc.interfaces.rest.planning.dto.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.planning.dto.IndicateurDto;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.Answers.RETURNS_DEEP_STUBS;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "smbo-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
@ExtendWith({HoverflyExtension.class, MockitoExtension.class})
class ExtractServiceImplTest {

    @InjectMocks
    private ExtractServiceImpl extractService;

    @Mock(answer = RETURNS_DEEP_STUBS)
    private ApplicationProperties mockApplicationProperties;


    @Mock
    private ExtractionBuilder extractionBuilder;

    @Mock
    private  ExtractPlanningCollabRepository extractPlanningCollabRepository;

    @Mock
    private  SmboClient smboClient;

    @Mock
    private  IndicateurService indicateurService;

    @Mock
    private  LibelleEntiteStructureRepository libelleEntiteStructureRepository;

    @Mock
    private  ActiviteRepository activiteRepository;

    @Mock
    private  IndicateurUgService indicateurUgService;

    @Mock
    private  EquipeRepository equipeRepository;

    @Mock
    private  CompetenceServiceImpl competenceService;

    @Mock
    private ExpertiseService expertiseService;

    @Mock
    private CorrespondancesService correspondancesService;

    @Mock
    private IndicateursSuiviActiviteService indicateursSuiviActiviteService;

    @Mock
    private static ActiviteParamsService activiteParamsService;

    @Mock
    private TetePerimetreService tetePerimetreService;


    Client mockSmboClient = ClientBuilder.newBuilder()
            .register(new JacksonJaxbJsonProvider().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false))
            .build();

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(extractionBuilder, "extractPlanningCollabRepository", extractPlanningCollabRepository);
        ReflectionTestUtils.setField(extractionBuilder, "smboClient", smboClient);
        ReflectionTestUtils.setField(extractionBuilder, "libelleEntiteStructureRepository", libelleEntiteStructureRepository);
        ReflectionTestUtils.setField(extractionBuilder, "equipeRepository", equipeRepository);
        ReflectionTestUtils.setField(extractionBuilder, "indicateurService", indicateurService);
        ReflectionTestUtils.setField(extractionBuilder, "indicateurUgService", indicateurUgService);
        ReflectionTestUtils.setField(extractionBuilder, "activiteRepository", activiteRepository);
        ReflectionTestUtils.setField(extractionBuilder, "competenceService", competenceService);
        ReflectionTestUtils.setField(competenceService, "expertiseService", expertiseService);
        ReflectionTestUtils.setField(extractionBuilder, "correspondancesService", correspondancesService);
        ReflectionTestUtils.setField(extractionBuilder, "indicateursSuiviActiviteService", indicateursSuiviActiviteService);
        ReflectionTestUtils.setField(extractionBuilder, "activiteParamsService", activiteParamsService);
        ReflectionTestUtils.setField(extractionBuilder, "tetePerimetreService", tetePerimetreService);
    }

    @Test
    void should_call_method_for_extract_planning_collab_when_extraction_type_equel_to_planningcollab() {


       byte[] bos = extractService.buildExtraction("planningCollab", List.of("3000324059"), List.of("10001001"), "2022-01-01", "2022-01-08");

        verify(extractPlanningCollabRepository, Mockito.atMostOnce()).findPlanningCollab(List.of("3000324059"),LocalDate.parse("2022-01-01", DateTimeFormatter.ISO_DATE),
                LocalDate.parse("2022-01-08", DateTimeFormatter.ISO_DATE));

        verify(smboClient, Mockito.atMostOnce()).getAllFamilles();
    }

    @Test
    void should_call_method_for_extract_planning_collab_when_extraction_type_equel_to_planningactivite() {


        when(indicateurUgService.computeIndicateur(IndicateurSearchDto.builder()
                .listCodeServiceTraitement(List.of("3000324059").stream().map(Long::valueOf).collect(Collectors.toList()))
                .dateDebut(LocalDate.parse("2022-01-01"))
                .dateFin(LocalDate.now().plusDays(1))
                .build()
        )).thenReturn(IndicateurActiviteDto.builder()
                .indicateurs(
                        List.of(
                                IndicateurDto.builder().capacite(BigDecimal.ONE)
                                        .codeActivite("ACT1")
                                        .codeFamille("FAM1")
                                        .date(LocalDate.of(2022, 01, 01))
                                        .etp(BigDecimal.ONE)
                                        .serviceTraitementId(3000324059L)
                                        .unite(Unite.DOSSIERS)
                                        .build(),
                                IndicateurDto.builder().capacite(BigDecimal.ONE)
                                        .codeActivite("ACT2")
                                        .codeFamille("FAM2")
                                        .date(LocalDate.of(2022, 01, 02))
                                        .etp(BigDecimal.ONE)
                                        .serviceTraitementId(3000324059L)
                                        .unite(Unite.DOSSIERS)
                                        .build(),
                                IndicateurDto.builder().capacite(BigDecimal.ONE)
                                        .codeActivite("ACT4")
                                        .codeFamille("FAM4")
                                        .date(LocalDate.now())
                                        .etp(BigDecimal.ONE)
                                        .serviceTraitementId(3000324059L)
                                        .unite(Unite.DOSSIERS)
                                        .build(),
                                IndicateurDto.builder().capacite(BigDecimal.ONE)
                                        .codeActivite("ACT5")
                                        .codeFamille("FAM5")
                                        .date(LocalDate.now())
                                        .etp(BigDecimal.ONE)
                                        .serviceTraitementId(3000324059L)
                                        .unite(Unite.DOSSIERS)
                                        .build()
                        )
                ).build());


        List<ActiviteParams> activiteParams = List.of(
                ActiviteParams.builder()
                .code("ACT1")
                .codeFamille("FAM1")
                .type(TypeActivite.SIMPLE)
                .unite(Unite.DOSSIERS)
                .build(),
                ActiviteParams.builder()
                        .code("ACT2")
                        .codeFamille("FAM2")
                        .type(TypeActivite.SIMPLE)
                        .unite(Unite.DOSSIERS)
                        .build(),
                ActiviteParams.builder()
                        .code("ACT3")
                        .codeFamille("FAM3")
                        .type(TypeActivite.SIMPLE)
                        .unite(Unite.DOSSIERS)
                        .build(),
                ActiviteParams.builder()
                        .code("ACT4")
                        .codeFamille("FAM4")
                        .type(TypeActivite.FAMILLE)
                        .unite(Unite.DOSSIERS)
                        .build(),
                ActiviteParams.builder()
                        .code("ACT5")
                        .codeFamille("FAM5")
                        .type(TypeActivite.SIMPLE)
                        .unite(Unite.DOSSIERS)
                        .maskDate(null)
                        .build()
        );

        when(activiteRepository.findByCodeIn(anyList())).thenReturn(activiteParams);

        Map<String, Map<Long, Float>> expertiseByActivite  = new HashMap<>();

        expertiseByActivite.put("ACT3", new HashMap<>(){
            {
                put(3L, 15F);
            }
        });
        expertiseByActivite.put("ACT4", new HashMap<>(){
            {
                put(3L, 25F);
            }
        });
        expertiseByActivite.put("ACT5", new HashMap<>(){
            {
                put(3L, 30F);
            }
        });

        when(competenceService.buildNombresDossier(anySet())).thenReturn(expertiseByActivite);

        when(equipeRepository.findAllByCodeIn(List.of("3000324059").stream().map(Long::new).collect(Collectors.toList())))
                .thenReturn(List.of(
                        Equipe.builder()
                        .codeCds(3000L)
                        .codeUg(2000L)
                        .code(3000324059L)
                        .build(),
                        Equipe.builder()
                                .codeCds(4000L)
                                .codeUg(5000L)
                                .code(3000324060L)
                                .build()
                ));

        when(indicateurService.getStockTraiter(IndicateurInputDto.builder()
                .listCodeServiceTraitement(List.of("3000324059"))
                .tetePerimetre(List.of("10001001"))
                .dateDebut("2022-01-01")
                .dateFin(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
                .build(), true)).thenReturn(List.of(
                com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto
                .builder()
                        .codeActivite("ACT1")
                        .codeFamille("FAM1")
                        .libelleActivite("ACTIV1")
                        .libelleFamille("FAMILLE1")
                        .stocks(
                                List.of(
                                        StockATraiterStDto.builder()
                                        .codeServiceTraitement("3000324059")
                                        .stocksATraiter(
                                                List.of(
                                                        StockOutputDto.builder()
                                                        .day("2022-01-01")
                                                        .stockDossierTermine(BigInteger.ONE)
                                                        .stockDossierTraiter(BigInteger.ONE)
                                                        .build()
                                                )
                                        )
                                        .build()
                                )
                        )
                        .build(),
                com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto
                        .builder()
                        .codeActivite("ACT2")
                        .codeFamille("FAM2")
                        .libelleActivite("ACTIV2")
                        .libelleFamille("FAMILLE2")
                        .stocks(
                                List.of(
                                        StockATraiterStDto.builder()
                                                .codeServiceTraitement("3000324059")
                                                .stocksATraiter(
                                                        List.of(
                                                                StockOutputDto.builder()
                                                                        .day("2022-01-02")
                                                                        .stockDossierTermine(BigInteger.TEN)
                                                                        .stockDossierTraiter(BigInteger.TEN)
                                                                        .build()
                                                        )
                                                )
                                                .build()
                                )
                        )
                        .build(),
                com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto
                        .builder()
                        .codeActivite("ACT3")
                        .codeFamille("FAM3")
                        .libelleActivite("ACTIV3")
                        .libelleFamille("FAMILLE3")
                        .stocks(
                                List.of(
                                        StockATraiterStDto.builder()
                                                .codeServiceTraitement("3000324060")
                                                .stocksATraiter(
                                                        List.of(
                                                                StockOutputDto.builder()
                                                                        .day("2022-01-03")
                                                                        .stockDossierTermine(BigInteger.ONE)
                                                                        .stockDossierTraiter(BigInteger.ONE)
                                                                        .build()
                                                        )
                                                )
                                                .build()
                                )
                        )
                        .build(),
                com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto
                        .builder()
                        .codeActivite("ACT4")
                        .codeFamille("FAM4")
                        .libelleActivite("ACTIV4")
                        .libelleFamille("FAMILLE4")
                        .stocks(
                                List.of(
                                        StockATraiterStDto.builder()
                                                .codeServiceTraitement("3000324059")
                                                .stocksATraiter(
                                                        List.of(
                                                                StockOutputDto.builder()
                                                                        .day(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
                                                                        .stockDossierTermine(BigInteger.ONE)
                                                                        .stockDossierTraiter(BigInteger.ONE)
                                                                        .build()
                                                        )
                                                )
                                                .build()
                                )
                        )
                        .build(),
                com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto
                        .builder()
                        .codeActivite("ACT5")
                        .codeFamille("FAM5")
                        .libelleActivite("ACTIV5")
                        .libelleFamille("FAMILLE5")
                        .stocks(
                                List.of(
                                        StockATraiterStDto.builder()
                                                .codeServiceTraitement("3000324059")
                                                .stocksATraiter(
                                                        List.of(
                                                                StockOutputDto.builder()
                                                                        .day(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
                                                                        .stockDossierTermine(BigInteger.ONE)
                                                                        .stockDossierTraiter(BigInteger.ONE)
                                                                        .build()
                                                        )
                                                )
                                                .build()
                                )
                        )
                        .build()
        ));
        List<RefFamilleDto> refFamilleDtos = Arrays.asList(
                RefFamilleDto.builder().code("FAM1").libelle("FAMILLE1").activites(new HashSet<>(Arrays.asList(RefActiviteDto.builder().code("ACT1").libelle("ACTIV1").build()))).build(),
                RefFamilleDto.builder().code("FAM2").libelle("FAMILLE2").activites(new HashSet<>(Arrays.asList(RefActiviteDto.builder().code("ACT2").libelle("ACTIV2").build()))).build(),
                RefFamilleDto.builder().code("FAM3").libelle("FAMILLE3").activites(new HashSet<>(Arrays.asList(RefActiviteDto.builder().code("ACT3").libelle("ACTIV3").build()))).build(),
                RefFamilleDto.builder().code("FAM4").libelle("FAMILLE4").activites(new HashSet<>(Arrays.asList(RefActiviteDto.builder().code("ACT4").libelle("ACTIV4").build()))).build(),
                RefFamilleDto.builder().code("FAM5").libelle("FAMILLE5").activites(new HashSet<>(Arrays.asList(RefActiviteDto.builder().code("ACT5").libelle("ACTIV5").build()))).build()
        );
        when(smboClient.getAllFamilles()).thenReturn(refFamilleDtos);

        byte[] bos = extractService.buildExtraction("planningActivites", List.of("3000324059"), List.of("10001001"), "2022-01-01", LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

        verify(extractPlanningCollabRepository, Mockito.atMostOnce()).findPlanningCollab(List.of("3000324059"),LocalDate.parse("2022-01-01", DateTimeFormatter.ISO_DATE),
                LocalDate.now().plusDays(1));

        verify(smboClient, Mockito.atMostOnce()).getAllFamilles();
        verify(libelleEntiteStructureRepository, Mockito.atMostOnce()).getAll();

        verify(equipeRepository, Mockito.atMostOnce()).findAllByCodeIn(List.of("3000324059").stream().map(Long::new).collect(Collectors.toList()));

        verify(indicateurService, Mockito.atMostOnce()).getStockTraiter(IndicateurInputDto.builder()
                .listCodeServiceTraitement(List.of("3000324059"))
                .tetePerimetre(List.of("10001001"))
                .dateDebut("2022-01-01")
                .dateFin(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
                .build(), true);

        verify(indicateurUgService, Mockito.atMostOnce()).computeIndicateur(IndicateurSearchDto.builder()
                .listCodeServiceTraitement(List.of("3000324059").stream().map(Long::valueOf).collect(Collectors.toList()))
                .dateDebut(LocalDate.parse("2022-01-01"))
                .dateFin(LocalDate.parse(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))))
                .build()
        );

        verify(activiteRepository, Mockito.atMostOnce()).findByCodeIn(anyList());

        verify(competenceService, Mockito.atMostOnce()).buildNombresDossier(anySet());

    }



    @Test
    void should_call_method_for_extract_planning_collab_when_extraction_type_equel_to_pilotageactivite() throws IOException {

        InputStream indicSuivieActiviteFile = getClass().getResourceAsStream("/indicateurSuivieActivites.json");
        String suivieActivitesResponse = new ObjectMapper().readValue(indicSuivieActiviteFile, new TypeReference<>() {}).toString();
        JsonElement jsonElementSuivieActiv = new JsonParser().parse(suivieActivitesResponse);
        JsonObject indicateurSuiviActivites = jsonElementSuivieActiv.getAsJsonObject();

        InputStream etpsFile = getClass().getResourceAsStream("/etpsResponse.json");
        String etpResponse = new ObjectMapper().readValue(etpsFile, new TypeReference<>() {}).toString();
        JsonElement jsonElementEtp = new JsonParser().parse(etpResponse);
        JsonObject etpsInfo = jsonElementEtp.getAsJsonObject();

        when(indicateurService.getEtps(
                IndicateurEtpInputDto.builder()
                        .listCodeServiceTraitement("3000324055")
                        .dateDebut("2022-01-01")
                        .dateFin("2022-01-05")
                        .build()
        )).thenReturn(etpsInfo);

        when(indicateursSuiviActiviteService.getIndicateurSuiviActivite(
                IndicateurInputDto.builder()
                        .listCodeServiceTraitement(List.of("3000324055"))
                        .tetePerimetre(List.of("10001001"))
                        .dateDebut("2022-01-01")
                        .dateFin("2022-01-05")
                        .build()
        )).thenReturn(indicateurSuiviActivites);

        List<ReferentielProcessusDto> referentielProcessusDtos = List.of(

                ReferentielProcessusDto.builder().code("PROC4452")
                        .dateCreation(LocalDate.of(2022, 01, 01))
                        .dateDerniereMaj(LocalDate.of(2022, 01, 02))
                        .dateDesactivation(LocalDate.of(2022, 01, 10))
                        .libelle("ProcLibelle4452")
                        .id(4452L)
                        .source(Source.HARMONIE)
                        .taches(
                                List.of(
                                        ReferentielTacheDto.builder().code("T1").id(1L).libelle("TACHE1").build(),
                                        ReferentielTacheDto.builder().code("TZ").id(2L).libelle("TACHE2").build()
                                )
                        )
                        .natures(
                                List.of(
                                        NatureDto.builder().code(500L).id(3L).libelle("NATURE1").build(),
                                        NatureDto.builder().code(600L).id(4L).libelle("NATURE2").build()
                                )
                        )
                        .build(),
                ReferentielProcessusDto.builder().code("PROC111")
                        .dateCreation(LocalDate.of(2022, 01, 8))
                        .dateDerniereMaj(LocalDate.of(2022, 01, 9))
                        .dateDesactivation(LocalDate.of(2022, 01, 11))
                        .libelle("ProcLibelle111")
                        .id(111L)
                        .source(Source.HARMONIE)
                        .taches(
                                List.of(
                                        ReferentielTacheDto.builder().code("T3").id(3L).libelle("TACHE3").build()
                                )
                        )
                        .natures(
                                List.of(
                                        NatureDto.builder().code(700L).id(4L).libelle("NATURE4").build()
                                )
                        )
                        .build(),
                ReferentielProcessusDto.builder().code("PROC15")
                        .dateCreation(LocalDate.of(2022, 01, 20))
                        .dateDerniereMaj(LocalDate.of(2022, 01, 21))
                        .dateDesactivation(LocalDate.of(2022, 01, 22))
                        .libelle("ProcLibelle15")
                        .id(15L)
                        .source(Source.HARMONIE)
                        .taches(
                                List.of(
                                        ReferentielTacheDto.builder().code("T4").id(4L).libelle("TACHE4").build()
                                )
                        )
                        .natures(
                                List.of(
                                        NatureDto.builder().code(800L).id(5L).libelle("NATURE5").build()
                                )
                        )
                        .build()
        );

        when(activiteParamsService.findAll()).thenReturn(List.of(ActiviteParamsDto.builder().code("CRI01").unite(Unite.TACHES).build(),
                ActiviteParamsDto.builder().code("CRI02").unite(Unite.TACHES).build()));
        when(correspondancesService.getProcessusByTetePerimetre(
                List.of("10001001").stream().map(Long::valueOf).collect(Collectors.toList())
                , Source.ALL
        )).thenReturn(referentielProcessusDtos);

        when(equipeRepository.findAllByCodeIn(List.of("3000324055").stream().map(Long::new).collect(Collectors.toList())))
                .thenReturn(List.of(
                        Equipe.builder()
                                .codeCds(3000L)
                                .codeUg(2000L)
                                .code(3000324055L)
                                .build()
                ));

        List<RefFamilleDto> refFamilleDtos = Arrays.asList(
                RefFamilleDto.builder().code("CRECLIPRI_OPPI").libelle("FAMILLE1")
                        .activites(new HashSet<>(Arrays.asList(
                                RefActiviteDto.builder().code("CRI01").libelle("LibCRI01").uniteMesure(List.of("TACHES")).build(),
                                RefActiviteDto.builder().code("CRI02").libelle("LibCRI02").uniteMesure(List.of("TACHES")).build()
                        ))).build()
        );

        when(smboClient.getAllFamilles()).thenReturn(refFamilleDtos);

        byte[] bos = extractService.buildExtraction("pilotageActivites", List.of("3000324055"), List.of("10001001"), "2022-01-01", "2022-01-05");

        verify(indicateursSuiviActiviteService, Mockito.atMostOnce()).getIndicateurSuiviActivite(
                IndicateurInputDto.builder()
                        .listCodeServiceTraitement(List.of("3000324055"))
                        .tetePerimetre(List.of("10001001"))
                        .dateDebut("2022-01-01")
                        .dateFin("2022-01-05")
                        .build()
        );

        verify(correspondancesService, Mockito.atMostOnce()).getProcessusByTetePerimetre(
                List.of("10001001").stream().map(Long::valueOf).collect(Collectors.toList())
                , Source.ALL
        );

        verify(equipeRepository, Mockito.atMostOnce()).findAllByCodeIn(List.of("3000324055").stream().map(Long::new).collect(Collectors.toList()));

    }

    @Test
    void should_throw_exception_when_extract_planning_fail() {

        Throwable thrown = catchThrowable(() -> { extractService.buildExtraction("planningColab2", List.of("3000324059"), List.of("10001001"), "2022-01-01", "2022-01-08"); });

        // Then
        assertThat(thrown).isInstanceOf(BusinessException.class);
    }

    @Test
    void should_call_method_for_extract_competences() {


        when(tetePerimetreService.findTetePerimetreById("10001001"))
                .thenReturn(TetePerimetre.builder().id("10001001").libelle("TPR 1").build());

        byte[] bos = extractService.buildExtraction("competences", List.of("3000324059"), List.of("10001001"), "2022-01-01", "2022-01-08");

        verify(extractPlanningCollabRepository, Mockito.atMostOnce()).findPlanningCollab(List.of("3000324059"),LocalDate.parse("2022-01-01", DateTimeFormatter.ISO_DATE),
                LocalDate.parse("2022-01-08", DateTimeFormatter.ISO_DATE));

        verify(smboClient, Mockito.atMostOnce()).getAllFamilles();
        verify(libelleEntiteStructureRepository, Mockito.atMostOnce()).getAll();
        verify(tetePerimetreService, Mockito.atMostOnce()).findTetePerimetreById("10001001");

    }

}
