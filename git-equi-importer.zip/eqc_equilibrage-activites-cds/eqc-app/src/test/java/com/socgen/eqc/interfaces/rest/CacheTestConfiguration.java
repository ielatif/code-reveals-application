package com.socgen.eqc.interfaces.rest;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheFactoryBean;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableCaching
public class CacheTestConfiguration {

    @Bean
    public CacheManager cacheManager() {
        SimpleCacheManager cacheManager = new SimpleCacheManager();
        List<Cache> caches = new ArrayList<>();
        caches.add(cacheBeanRES().getObject());
        caches.add(cacheBeanPEO().getObject());
        cacheManager.setCaches(caches);
        return cacheManager;
    }


    @Bean
    public ConcurrentMapCacheFactoryBean cacheBeanRES() {
        ConcurrentMapCacheFactoryBean cacheFactoryBean = new ConcurrentMapCacheFactoryBean();
        cacheFactoryBean.setName("ResCache");

        return cacheFactoryBean;
    }

    @Bean
    public ConcurrentMapCacheFactoryBean cacheBeanPEO() {
        ConcurrentMapCacheFactoryBean cacheFactoryBean = new ConcurrentMapCacheFactoryBean();
        cacheFactoryBean.setName("PeopleCache");

        return cacheFactoryBean;
    }


}
