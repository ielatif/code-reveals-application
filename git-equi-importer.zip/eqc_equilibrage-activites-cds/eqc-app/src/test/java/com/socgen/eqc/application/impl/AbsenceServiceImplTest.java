package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.mock.FakeDomain;
import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Intervalle;
import com.socgen.eqc.infrastructure.gershwin.service.GershwinService;
import com.socgen.eqc.infrastructure.persistance.AbsenceRepository;
import com.socgen.eqc.interfaces.rest.dto.Action;
import com.socgen.eqc.interfaces.rest.dto.ActionAbsenceDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.interfaces.rest.planning.dto.AbsenceGershwinDto;
import com.socgen.eqc.mapper.ActionMapper;
import com.socgen.eqc.mapper.ActionMapperImpl;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.*;
import static java.util.Collections.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AbsenceServiceImplTest {

    //TODO ajouter des tests pour les absences gershwin
    @Mock
    private AbsenceRepository mockAbsenceRepository;

    @Mock
    private AffiliationService affiliationService;

    @Mock
    private GershwinService mockGershwinService;

    private ActionMapper actionMapper = new ActionMapperImpl();

    private AbsenceServiceImpl absenceServiceImplUnderTest;

    @Captor
    private ArgumentCaptor<List<Absence>> listArgumentCaptor;

    @BeforeEach
    void setUp() {
        absenceServiceImplUnderTest = new AbsenceServiceImpl(mockGershwinService, mockAbsenceRepository, actionMapper, affiliationService);
    }

    @Test
    void testUpdate() {
        // Setup
        ActionAbsenceDto actionAbsenceDto1 = ActionAbsenceDto.builder().id(1L).matricule("matricule_1")
            .date(LocalDate.of(2017, 1, 1)).action(Action.CREATE).intervalle(Intervalle.MATIN).build();
        ActionAbsenceDto actionAbsenceDto2 = ActionAbsenceDto.builder().id(2L).matricule("matricule_2")
            .date(LocalDate.of(2017, 1, 2)).action(Action.DELETE).intervalle(Intervalle.APRES_MIDI).build();
        ActionAbsenceDto actionAbsenceDto3 = ActionAbsenceDto.builder().id(3L).matricule("matricule_3")
            .date(LocalDate.of(2017, 1, 3)).action(Action.UPDATE).intervalle(Intervalle.TOUTE_JOURNEE).build();

        final List<ActionAbsenceDto> actionAbsences = asList(actionAbsenceDto1, actionAbsenceDto2, actionAbsenceDto3);

        // Run the test2
        absenceServiceImplUnderTest.updateOrDelete(actionAbsences);

        // Verify the results
        verify(mockAbsenceRepository, Mockito.atMostOnce()).saveAll(listArgumentCaptor.capture());
        List<Absence> value = listArgumentCaptor.getValue();
        assertThat(value).hasSize(2);
        verify(mockAbsenceRepository, Mockito.atMostOnce()).deleteAll(listArgumentCaptor.capture());
        value = listArgumentCaptor.getValue();
	    assertThat(value).hasSize(1);
    }

    @Test
	void testFindAbsences() {
		// Given
	    List<Absence> absencesEqc = new ArrayList<>();
	    absencesEqc.add(new Absence(1L, "X007007", LocalDate.of(2021, 3, 15), Intervalle.TOUTE_JOURNEE));
	    absencesEqc.add(new Absence(2L, "X007007", LocalDate.of(2021, 3, 16), Intervalle.MATIN));
	    absencesEqc.add(new Absence(3L, "X007007", LocalDate.of(2021, 3, 17), Intervalle.APRES_MIDI));
	    absencesEqc.add(new Absence(4L, "X007007", LocalDate.of(2021, 3, 18), Intervalle.APRES_MIDI));

	    List<Absence> absencesGershwin = new ArrayList<>();
	    absencesGershwin.add(new Absence(null, "X007007", LocalDate.of(2021, 3, 15), Intervalle.MATIN));
	    absencesGershwin.add(new Absence(null, "X007007", LocalDate.of(2021, 3, 16), Intervalle.TOUTE_JOURNEE));
	    absencesGershwin.add(new Absence(null, "X007007", LocalDate.of(2021, 3, 17), Intervalle.APRES_MIDI));
	    absencesGershwin.add(new Absence(null, "X007007", LocalDate.of(2021, 3, 18), Intervalle.TOUTE_JOURNEE));
	    when(mockAbsenceRepository.findByMatriculeCollaborateurInAndDateBetween(any(), any(), any())).thenReturn(absencesEqc);
	    when(mockGershwinService.findAbsence(1L, List.of(Collaborateur.builder().matricule("X007007").build()), LocalDate.of(2021, 3, 15), LocalDate.of(2021, 3, 19))).thenReturn(absencesGershwin);

	    // When
	    List<Absence> absences = absenceServiceImplUnderTest.findAbsences(1L, singletonList(Collaborateur.builder().matricule("X007007").build()), LocalDate.of(2021, 3, 15), LocalDate.of(2021, 3, 19));

	    // Then
	    assertThat(absences).hasSize(5);
    }

    @Test
    void testFindAbsence() {
        //setup
        PlanningSearchDto planningSearchDto = PlanningSearchDto.builder()
            .dateDebut(LocalDate.of(2019, 1, 1))
            .build();
        Affiliation affiliation = Affiliation.builder()
            .collaborateur(Collaborateur.builder()
                .matricule("X171001")
                .build())
            .build();

        Mockito.when(affiliationService.findByPlanningSearchDto(planningSearchDto)).thenReturn(List.of(affiliation));
        Mockito.when(mockAbsenceRepository.findByMatriculeCollaborateurInAndDateBetween(Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(asList(FakeDomain.absenceSupplier.get()));
        //run
        AbsenceGershwinDto absenceGershwinDto = absenceServiceImplUnderTest.findAbsence(planningSearchDto);
        //Verify
        Assertions.assertEquals(1, absenceGershwinDto.getAbsences().size());
        Assertions.assertEquals(FakeDomain.absenceSupplier.get().getIntervalle(), absenceGershwinDto.getAbsences().get(0).getIntervalle());

    }

    @Test
    void testSupprimerSemaine() {
        LocalDate dateFin = LocalDate.of(2020, 2, 8);
        LocalDate dateDebut = LocalDate.of(2020, 2, 2);
        List<String> matricules = List.of("X171001");
        SuppressionSemaineDto dto = SuppressionSemaineDto.builder()
            .dateFin(dateFin.minusDays(1))
            .dateDebut(dateDebut.plusDays(1))
            .codeServiceTraitement(1L)
            .matricules(matricules)
            .matriculesRenfort(List.of("X171002"))
            .build();
        absenceServiceImplUnderTest.supprimerSemaine(dto);
        Mockito.verify(mockAbsenceRepository, Mockito.times(1)).deleteAllByMatriculeCollaborateurInAndDateBetween(
            matricules,
            dateDebut,
            dateFin
        );
    }
    @Test
    void testSupprimerSemaineEmptyDto() {
        LocalDate dateFin = LocalDate.of(2020, 2, 8);
        LocalDate dateDebut = LocalDate.of(2020, 2, 2);
        List<String> matricules = List.of("X171001");
        SuppressionSemaineDto dto = SuppressionSemaineDto.builder()
            .dateFin(dateFin.minusDays(1))
            .dateDebut(dateDebut.plusDays(1))
            .codeServiceTraitement(1L)
            .matricules(Lists.emptyList())
            .matriculesRenfort(List.of("X171002"))
            .build();
        absenceServiceImplUnderTest.supprimerSemaine(dto);
        Mockito.verify(mockAbsenceRepository, Mockito.never()).deleteAllByMatriculeCollaborateurInAndDateBetween(
            matricules,
            dateDebut,
            dateFin
        );
    }
}
