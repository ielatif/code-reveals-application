package com.socgen.eqc.application.mock;

import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;

import java.util.function.Supplier;

// @formatter:off
public class FakeDto {

    public static final Supplier<CollaborateurDto> collaborateurSupplier = () -> CollaborateurDto.builder()
        .matricule("X171001")
        .idRhLocal("GLX171001")
        .loginWindows("X171001")
        .nom("snow")
        .prenom("jon")
        .build();

}
