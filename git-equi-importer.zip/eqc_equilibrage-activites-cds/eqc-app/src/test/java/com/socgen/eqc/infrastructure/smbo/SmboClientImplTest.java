package com.socgen.eqc.infrastructure.smbo;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.smbo.dto.*;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;

@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "smbo-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
@ExtendWith({HoverflyExtension.class, MockitoExtension.class})
class SmboClientImplTest {

    @Rule
    public final ExpectedException exception = ExpectedException.none();

    @Mock
    private ApplicationProperties mockApplicationProperties;

    private SmboClientImpl smboClientImplUnderTest;

    @BeforeEach
    void setUp() {
        Client mockSmboClient = ClientBuilder.newBuilder()
                .register(new JacksonJaxbJsonProvider().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false))
                .build();
        smboClientImplUnderTest = new SmboClientImpl(mockSmboClient, mockApplicationProperties);
    }

    @Test
    void test_get_all_processus_by_tete_perimetre() {

        // Configure ApplicationProperties.getSmbo(...).
        final ApplicationProperties.Smbo smbo = new ApplicationProperties.Smbo();
        smbo.setServerUrl("http://localhost:8440/api");
        when(mockApplicationProperties.getSmbo()).thenReturn(smbo);

        // Run the test
        List<ReferentielProcessusDto> result = smboClientImplUnderTest.getAllProcessusByTetePerimetre(Collections.singletonList(3000350989L), Source.ALL);

        // Verify the results
        assertEquals("DMDCHQ", result.get(0).getCode());
    }

    @Test
    void test_get_all_correspondance_by_tete_perimetre() {

        // Configure ApplicationProperties.getSmbo(...).
        final ApplicationProperties.Smbo smbo = new ApplicationProperties.Smbo();
        smbo.setServerUrl("http://localhost:8440/api");
        when(mockApplicationProperties.getSmbo()).thenReturn(smbo);

        // Run the test
        List<CorrespondanceActiviteDto> result = smboClientImplUnderTest.getAllCorrespondanceByTetePerimetre(Collections.singletonList(3000350989L));

        // Verify the results
        assertEquals(140L, result.get(0).getId());
    }

    @Test
    void should_get_indicateurs() {

        // Configure ApplicationProperties.getSmbo(...).
        final ApplicationProperties.Smbo smbo = new ApplicationProperties.Smbo();
        smbo.setServerUrl("http://localhost:8440/api");
        when(mockApplicationProperties.getSmbo()).thenReturn(smbo);

        IndicateurInputDto indicateurInputDto = IndicateurInputDto.builder().tetePerimetre(Collections.singletonList("3000350988")).listCodeServiceTraitement(List.of("3000324055")).dateDebut("2021-12-15").dateFin("2021-12-13").build();

        // Run the test
        List<IndicateurActiviteDto> result = smboClientImplUnderTest.getIndicateurBrut(List.of("3000324055"), LocalDate.parse("2021-12-13"), LocalDate.parse("2021-12-15"), Collections.singletonList("3000350988"));

        // Verify the results
        assertEquals(3, result.size());
        assertEquals("CRI04", result.get(0).getCodeActivite());
        assertEquals("CRI02", result.get(1).getCodeActivite());
        assertEquals("CRI01", result.get(2).getCodeActivite());

    }

    @Test
    void should_save_processus() {

        // Configure ApplicationProperties.getSmbo(...).
        final ApplicationProperties.Smbo smbo = new ApplicationProperties.Smbo();
        smbo.setServerUrl("http://localhost:8440/api");
        when(mockApplicationProperties.getSmbo()).thenReturn(smbo);

        RefProcessusInputDto refProcessusInputDto = RefProcessusInputDto.builder()
                .codeTetePerimetre("30003003")
                .code("")
                .libelle("Test saisie Global")
                .source(Source.SAISIE_GLOBALE)
                .informations("info tests")
                .build();


        // Run the test
        RefProcessusOutputDto result = smboClientImplUnderTest.saveOrUpdateProcessus(refProcessusInputDto);

        // Verify the results
        assertEquals("PROCESUSS-2201", result.getCode());
        assertEquals("2022-02-15", result.getDateCreation());
        assertEquals("Test saisie Global", result.getLibelle());
        assertEquals("30003003", result.getCodesTetePerimetre().get(0));
        assertEquals("info tests", result.getInformations());

    }

    @Test
    void should_get_indicateurs_suivi_activite() {

        // Configure ApplicationProperties.getSmbo(...).
        final ApplicationProperties.Smbo smbo = new ApplicationProperties.Smbo();
        smbo.setServerUrl("http://localhost:8440/api");
        when(mockApplicationProperties.getSmbo()).thenReturn(smbo);

        // Run the test
        String result = smboClientImplUnderTest.getIndicateurSuivieActivite("2022-01-01", "2022-03-01",  List.of("3000350989"), List.of("3000324060"));

        // Verify the results
        assertFalse(result.isEmpty());

    }


    @Test
    void should_get_indicateurs_saisie_globale() {

        // Configure ApplicationProperties.getSmbo(...).
        final ApplicationProperties.Smbo smbo = new ApplicationProperties.Smbo();
        smbo.setServerUrl("http://localhost:8440/api");
        when(mockApplicationProperties.getSmbo()).thenReturn(smbo);

        // Run the test
        List<SaisieGlobaleStockOutputDto> saisieGlobaleIndicateurs = smboClientImplUnderTest.getSaisieGlobaleIndicateurs(List.of(30003000L), "3000", "X178253");

        // Verify the results
        assertFalse(saisieGlobaleIndicateurs.isEmpty());

    }

}
