package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.infrastructure.persistance.ExtractPlanningCollabRepository;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPlanningCollabDto;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_OCTET_STREAM;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.when;
@ExtendWith({HoverflyExtension.class})
@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "smbo-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
class ExtractResourceIT extends AbstractIT {
    @MockBean
    private ExtractPlanningCollabRepository extractPlanningCollabRepository;

    @MockBean
    @Qualifier("appToAppSmboClient")
    private SmboClient appToAppSmboClient;

    @Test
    void should_extract_planning_collab() {

        ExtractPlanningCollabDto extractPlanningCollabDto1 = ExtractPlanningCollabDto.builder()
                .activiteCode("ACT-10102")
                .codeFiliere("fil1")
                .filiere("filire1")
                .codeFiliereAidante("filiereAidante1")
                .codeFiliereAidee("codeFiliereAidee1")
                .codeSt("st1")
                .codeStAidant("codeStAidant1")
                .codeStAide("codeStAide1")
                .codeUg("ug1")
                .codeUgAidante("codeUgAidante1")
                .codeUgAidee("codeUgAidee1")
                .commentairePrincipal("comment1")
                .dateAffectation("2022-01-02")
                .etp("1")
                .familleCode("SUCCESSIONS_847")
                .filiereAidante("fileiereAidant1")
                .build();

        ExtractPlanningCollabDto extractPlanningCollabDto2 = ExtractPlanningCollabDto.builder()
                .activiteCode("ACT-10108")
                .codeFiliere("fil2")
                .filiere("filire2")
                .codeFiliereAidante("filiereAidante2")
                .codeFiliereAidee("codeFiliereAidee2")
                .codeSt("st2")
                .codeStAidant("codeStAidant2")
                .codeStAide("codeStAide2")
                .codeUg("ug2")
                .codeUgAidante("codeUgAidante2")
                .codeUgAidee("codeUgAidee2")
                .commentairePrincipal("comment2")
                .dateAffectation("2022-01-02")
                .etp("1")
                .familleCode("SUCCESSIONS_712")
                .filiereAidante("fileiereAidant2")
                .build();
        when(extractPlanningCollabRepository.findPlanningCollab(List.of("3000324059"),LocalDate.parse("2022-01-01", DateTimeFormatter.ISO_DATE),
                LocalDate.parse("2022-01-08", DateTimeFormatter.ISO_DATE))).thenReturn(List.of(extractPlanningCollabDto1, extractPlanningCollabDto2));

        int status = given()
                .header("Authorization", BEARER_DE_BASE)
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_OCTET_STREAM)
                .queryParam("listCodeSt", "3000324059n")
                .queryParam("from", "2022-01-01")
                .queryParam("to", "2022-01-08")
                .get("extraction/planningCollab").statusCode();

        Mockito.verify(extractPlanningCollabRepository, atMost(1)).findPlanningCollab(List.of("3000324059"),LocalDate.parse("2022-01-01", DateTimeFormatter.ISO_DATE),
                LocalDate.parse("2022-01-08", DateTimeFormatter.ISO_DATE));
        Mockito.verify(appToAppSmboClient, atMost(1)).getAllFamilles();
        assertEquals(200, status);
    }
}
