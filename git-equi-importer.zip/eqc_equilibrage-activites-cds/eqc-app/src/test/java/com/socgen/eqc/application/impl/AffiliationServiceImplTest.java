package com.socgen.eqc.application.impl;

import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.MockitoAnnotations.initMocks;

class AffiliationServiceImplTest {

    @Mock
    private AffiliationRepository mockAffiliationRepository;

    private AffiliationServiceImpl affiliationServiceImplUnderTest;

    @BeforeEach
    void setUp() {
        initMocks(this);
        affiliationServiceImplUnderTest = new AffiliationServiceImpl(mockAffiliationRepository);
    }

    @Test
    void testFindByMatriculeAndDate() {
        // Setup
        Affiliation affiliation = Affiliation.builder().id(123L).build();
        Mockito.when(mockAffiliationRepository.findByMatriculeAndDate(Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(Arrays.asList(affiliation));
        final String matricule = "matricule";
        final LocalDate date = LocalDate.of(2020, 10, 10);

        // Run the test
        final Optional<Affiliation> result = affiliationServiceImplUnderTest.findByMatriculeAndDate(matricule, LocalDate.of(2020, 10, 9), date);

        // Verify the results
        assertTrue(result.isPresent());
        Assert.assertEquals(123L, result.get().getId().longValue());
    }
}
