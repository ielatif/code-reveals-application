package com.socgen.eqc.application.mock;

import javax.persistence.Tuple;
import javax.persistence.TupleElement;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TupleCompetenceMock implements Tuple {


    TupleElement<String> matricule = new StringTupleElement("Mat 1");
    TupleElement<String> lastModifiedDate = new StringTupleElement("11-06-2021");

    @Override
    public <X> X get(TupleElement<X> tupleElement) {
        return (X) get(tupleElement.getAlias());
    }

    @Override
    public <X> X get(String alias, Class<X> type) {
        return (X) get(alias);
    }

    @Override
    public Object get(String alias) {
        Map<String, TupleElement> elements = getMapElements();
        if (elements.get(alias).getJavaType().equals(BigInteger.class)) {
            return new BigInteger(elements.get(alias).getAlias());
        }
        return elements.get(alias).getAlias();
    }

    @Override
    public <X> X get(int i, Class<X> type) {
        return (X) String.valueOf(i);
    }

    @Override
    public Object get(int i) {
        return get(i, Object.class);
    }

    @Override
    public Object[] toArray() {
        return new Object[] {matricule.getAlias().toLowerCase(), lastModifiedDate.getAlias().toLowerCase()};
    }

    @Override
    public List<TupleElement<?>> getElements() {
        return Arrays.asList(matricule, lastModifiedDate);
    }

    public Map getMapElements() {
        Map<String, TupleElement> mapTuple = new HashMap<>();
        mapTuple.put("matricule", matricule);
        mapTuple.put("lastModifiedDate", lastModifiedDate);
        return mapTuple;
    }

    private static class StringTupleElement implements TupleElement<String> {

        private final String value;

        private StringTupleElement(String value) {
            this.value = value;
        }

        @Override
        public Class<? extends String> getJavaType() {
            return String.class;
        }

        @Override
        public String getAlias() {
            return value;
        }
    }

}
