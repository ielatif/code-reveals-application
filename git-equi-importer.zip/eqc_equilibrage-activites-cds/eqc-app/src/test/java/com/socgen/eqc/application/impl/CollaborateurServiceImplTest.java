package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AbsenceService;
import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.RenfortService;
import com.socgen.eqc.application.mock.TupleCompetenceMock;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.infrastructure.people.client.PeopleClient;
import com.socgen.eqc.infrastructure.people.dto.ListPeopleDto;
import com.socgen.eqc.infrastructure.people.dto.PeopleDto;
import com.socgen.eqc.infrastructure.persistance.CollaborateurRepository;
import com.socgen.eqc.infrastructure.persistance.CompetenceRepository;
import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.persistence.Tuple;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class CollaborateurServiceImplTest {

    @Mock
    private PeopleClient mockPeopleClient;
    @Mock
    private AffiliationService mockAffiliationService;
    @Mock
    private CollaborateurRepository mockCollaborateurRepository;
    @Mock
    private AffectationService affectationService;
    @Mock
    private RenfortService mockRenfortService;

    @Mock
    private CompetenceRepository mockCompetenceRepository;

    @Mock
    private AbsenceService mockAbsenceService;

    private CollaborateurServiceImpl collaborateurServiceImplUnderTest;

    private ListPeopleDto listPeopleDto = new ListPeopleDto();

    @BeforeEach
    void setUp() {
        collaborateurServiceImplUnderTest = new CollaborateurServiceImpl(mockPeopleClient, mockAffiliationService, mockCollaborateurRepository,
                affectationService, mockRenfortService,mockAbsenceService, mockCompetenceRepository);
        var peopleList = IntStream.rangeClosed(1, 10).mapToObj(value -> {
            var people = new PeopleDto();
            people.setIdCnxRtfe("mat " + value);
            people.setNom("nom " + value);
            people.setPrenom("pernom " + value);
            people.setIdRhLocal("");
            return people;
        }).collect(Collectors.toList());
        listPeopleDto.setDatas(peopleList);
    }

    @Test
    void testFindByMatricules() {
        // Setup
        Mockito.when(mockPeopleClient.findPeopleByListMatricule(Mockito.any())).thenReturn(listPeopleDto);

        // Run the test
        final List<CollaborateurDto> result = collaborateurServiceImplUnderTest.findByMatricules("");

        // Verify the results
        assertEquals(10, result.size());
        assertEquals("nom 1", result.get(0).getNom());
    }

    @Test
    void testFindNewCollaborateurs() {
        // Setup
        Mockito.when(mockPeopleClient.findPeopleByListCodeSt(Mockito.any())).thenReturn(listPeopleDto);
        Affiliation affiliation = Affiliation.builder()
                .collaborateur(Collaborateur.builder().matricule("Mat 1").build()).build();
        Mockito.when(mockAffiliationService.findByEquipeAndDate(Mockito.any(), Mockito.any()))
                .thenReturn(Collections.singletonList(affiliation));
        // Run the test
        final List<CollaborateurDto> result = collaborateurServiceImplUnderTest.findNewCollaborateurs(1L);
        // Verify the results
        assertEquals(9, result.size());
        assertEquals(9, result.stream().filter(pepoleElem -> pepoleElem.getIdRhLocal().contains("GL")).count());
        assertEquals("nom 2", result.get(0).getNom());
    }

    @Test
    void should_find_all_collaborateurs() {
        // Setup

        Affiliation affiliation1 = Affiliation.builder()
                .collaborateur(Collaborateur.builder().matricule("Mat 1").idRhLocal("GL1000").build()).build();
        Affiliation affiliation2 = Affiliation.builder()
                .collaborateur(Collaborateur.builder().matricule("Mat 2").idRhLocal("GL2000").build())
                .dateSortie(LocalDate.of(2019, 12, 24)).build();

        List<Affiliation> affiliations = Arrays.asList(affiliation1, affiliation2);
        Tuple tuple = new TupleCompetenceMock();
        Mockito.when(mockAffiliationService.findByEquipeAndDate(Mockito.any(), Mockito.any()))
                .thenReturn(affiliations);

        Mockito.when(mockCompetenceRepository.findLastModifiedDateByMatricules(Mockito.anyList()))
                .thenReturn(List.of(tuple));

        // Run the test
        final List<CollaborateurDto> result = collaborateurServiceImplUnderTest.findCollaborateurs(1L);
        // Verify the results
        assertEquals(1, result.size());
        assertEquals("11-06-2021", result.get(0).getLastModifiedProfilDate());
    }
}
