package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.exception.GhabiException;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.infrastructure.ghabi.GhabiClient;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionDto;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionResponseDto;
import com.socgen.eqc.infrastructure.persistance.ExtensionPerimetreAllowedUgRepository;
import com.socgen.eqc.infrastructure.persistance.ExtensionPerimetreRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Optional;

import static java.util.Collections.singletonList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ExtensionPerimetreServiceImplTest {

	@InjectMocks
	private ExtensionPerimetreServiceImpl extensionPerimetreService;

	@Mock
	private GhabiClient ghabiClient;

	@Mock
	private ExtensionPerimetreRepository extensionPerimetreRepository;

	@Mock
	private ExtensionPerimetreAllowedUgRepository extensionPerimetreAllowedUgRepository;

	@Test
	void should_create_demande_ghabi() throws GhabiException {
		GhabiExtensionResponseDto ghabiExtensionResponseDto = new GhabiExtensionResponseDto();
		ghabiExtensionResponseDto.setId(100L);
		ghabiExtensionResponseDto.setStatus(2);
		Mockito.when(ghabiClient.createExtension(Mockito.any(GhabiExtensionDto.class))).thenReturn(ghabiExtensionResponseDto);

		ExtensionPerimetre extensionPerimetreExpected = ExtensionPerimetre.builder().idGhabi(ghabiExtensionResponseDto.getId())
				.etat(ghabiExtensionResponseDto.getStatus())
				.dateCreation(LocalDateTime.now()).build();

		Optional<ExtensionPerimetre> extensionPerimetreResult = extensionPerimetreService.createExtension("X100100", "X178253", getRenfort());

		verify(ghabiClient, atMostOnce()).createExtension(Mockito.any(GhabiExtensionDto.class));

		Assertions.assertThat(extensionPerimetreResult.get())
				.usingRecursiveComparison()
				.ignoringFields("dateCreation")
				.isEqualTo(extensionPerimetreExpected);
	}

	@Test
	void should_delete_demande_ghabi_when_status_extension_is_2() {
		Renfort renfort = getRenfort();

		GhabiExtensionResponseDto ghabiExtensionResponseDto = getExtensionResponseWithStatus(2);
		Mockito.when(ghabiClient.getExtensionDetail(renfort.getExtensionPerimetre().getIdGhabi())).thenReturn(ghabiExtensionResponseDto);

		extensionPerimetreService.deleteExtension(singletonList(renfort));
		verify(ghabiClient, atMostOnce()).deleteExtension(renfort.getExtensionPerimetre().getIdGhabi());
		verify(extensionPerimetreRepository, atMostOnce()).delete(renfort.getExtensionPerimetre());
	}

	@Test
	void should_call_update_extension_when_delete_ghabi_and_status_extension_is_1() {
		Renfort renfort = getRenfort();

		GhabiExtensionResponseDto ghabiExtensionResponseDto = getExtensionResponseWithStatus(1);
		Mockito.when(ghabiClient.getExtensionDetail(renfort.getExtensionPerimetre().getIdGhabi())).thenReturn(ghabiExtensionResponseDto);

		extensionPerimetreService.deleteExtension(singletonList(renfort));
		verify(ghabiClient, atMostOnce()).updateExtension(Mockito.any(GhabiExtensionDto.class));
		verify(extensionPerimetreRepository, atMostOnce()).delete(renfort.getExtensionPerimetre());
	}

	@Test
	void should_create_intraday_extension_when_renfort_is_created_for_today() throws GhabiException {

		GhabiExtensionResponseDto ghabiExtensionResponseDto = new GhabiExtensionResponseDto();
		ghabiExtensionResponseDto.setId(100L);
		ghabiExtensionResponseDto.setStatus(2);

		Mockito.when(ghabiClient.createExtension(Mockito.any(GhabiExtensionDto.class))).thenReturn(ghabiExtensionResponseDto);
		Mockito.when(extensionPerimetreAllowedUgRepository.existsById(Mockito.anyString())).thenReturn(Boolean.TRUE);

		ExtensionPerimetre extensionPerimetreExpected = ExtensionPerimetre.builder()
				.idGhabi(ghabiExtensionResponseDto.getId())
				.etat(ghabiExtensionResponseDto.getStatus())
				.dateCreation(LocalDateTime.of(LocalDate.now(), LocalTime.now(ZoneOffset.UTC).plusMinutes(5)))
				.build();

		Optional<ExtensionPerimetre> extensionPerimetreResult = extensionPerimetreService.createExtension("X100100", "X178253", getTodayRenfort());

		verify(ghabiClient, atMostOnce()).createExtension(Mockito.any(GhabiExtensionDto.class));
		verify(extensionPerimetreAllowedUgRepository, atMostOnce()).existsById(getTodayRenfort().getCodeUgRattachement().toString());

		Assertions.assertThat(extensionPerimetreResult.get())
				.usingRecursiveComparison()
				.ignoringFields("dateCreation")
				.isEqualTo(extensionPerimetreExpected);

	}

	private Renfort getRenfort() {
		return Renfort.builder()
				.intervalle(Intervalle.MATIN)
				.date(LocalDate.of(2021, 01, 01))
				.extensionPerimetre(ExtensionPerimetre.builder().idGhabi(100L).etat(2).build())
				.collaborateur(Collaborateur.builder().matricule("Z100100").build())
				.codeStRattachement(30003000L)
				.equipe(Equipe.builder().code(1000L).build())
				.build();
	}

	private Renfort getTodayRenfort() {
		return Renfort.builder()
				.intervalle(Intervalle.MATIN)
				.date(LocalDate.now())
				.extensionPerimetre(ExtensionPerimetre.builder().idGhabi(100L).etat(2).build())
				.collaborateur(Collaborateur.builder().matricule("Z100100").build())
				.codeStRattachement(30003000L)
				.codeUgRattachement(3000346551L)
				.equipe(Equipe.builder().code(1000L).build())
				.build();
	}

    private GhabiExtensionResponseDto getExtensionResponseWithStatus(Integer status) {
		GhabiExtensionResponseDto ghabiExtensionResponseDto = new GhabiExtensionResponseDto();
		ghabiExtensionResponseDto.setUtilisateurId("Z017116");
		ghabiExtensionResponseDto.setCreateurId("X100100");
		ghabiExtensionResponseDto.setStatus(status);
		ghabiExtensionResponseDto.setId(2L);
		ghabiExtensionResponseDto.setDateCreation("2021-04-26T19:30:00");
		ghabiExtensionResponseDto.setDateDebut( "2021-04-26T19:30:00");
		ghabiExtensionResponseDto.setDateFin("2021-04-27T09:06:48");
		ghabiExtensionResponseDto.setPerimStIds(Arrays.asList("3000324195"));

		return ghabiExtensionResponseDto;
	}
}
