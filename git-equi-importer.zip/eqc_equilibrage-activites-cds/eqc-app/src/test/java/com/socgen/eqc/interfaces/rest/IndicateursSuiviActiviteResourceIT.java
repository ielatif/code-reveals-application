package com.socgen.eqc.interfaces.rest;

import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.junit.jupiter.api.Assertions.assertFalse;

@ExtendWith({HoverflyExtension.class})
@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "smbo-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
class IndicateursSuiviActiviteResourceIT extends AbstractIT {
    @Test
    @DisplayName("Récuperation des indicateurs suivi d'activite")
    void should_get_indicateurs() {
        String indicateursSuiviActivite = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .queryParam("listCodeServiceTraitement", "3000324060")
                .queryParam("tetePerimetre", "3000350989")
                .queryParam("dateDebut", "2022-01-01")
                .queryParam("dateFin", "2022-03-01")
                .get("indicateurs-suivi-activite")
                .body().asString();
        assertFalse(indicateursSuiviActivite.isEmpty());
    }
}
