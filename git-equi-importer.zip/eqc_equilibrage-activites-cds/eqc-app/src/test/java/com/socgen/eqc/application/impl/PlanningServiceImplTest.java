package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.mock.*;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;
import com.socgen.eqc.interfaces.rest.planning.dto.PlanningStDto;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.MockitoAnnotations.openMocks;

class PlanningServiceImplTest {

    private final FakeAffiliationService fakeAffiliationService = new FakeAffiliationService();
    private final FakeAffectationService fackeAffectationService = new FakeAffectationService();
    private final FakeCollaborateurService fakeCollaborateurService = new FakeCollaborateurService();
    private final FakeEquipeService fakeEquipeService = new FakeEquipeService();
    private final FakeRenfortService fakeRenfortService = new FakeRenfortService();
    private final FakeAbsenceService fakeAbsenceService = new FakeAbsenceService();
    private final FakeCompetenceService fakeCompetenceService = new FakeCompetenceService();

    @Rule
    public ExpectedException exceptionRule = ExpectedException.none();

    @Captor
    private ArgumentCaptor<List<Affiliation>> listAffiliationArgumentCaptor;
    private PlanningServiceImpl planningServiceImplUnderTest;

    @BeforeEach
    void setUp() {
        openMocks(this);
        planningServiceImplUnderTest = new PlanningServiceImpl(fakeCollaborateurService.getMock(), fakeEquipeService
                .getMock(), fakeAffiliationService.getMock(), fackeAffectationService
                .getMock(), fakeRenfortService.getMock(), fakeAbsenceService.getMock(), fakeCompetenceService.getMock());
    }

    @Test
    void testFindByPlanningSearchDto() {
        // Setup
        final PlanningSearchDto planningSearch = PlanningSearchDto.builder().dateDebut(LocalDate.of(2020, 1, 1))
                .codeServiceTraitement(111111L).build();
        // Run the test
        final PlanningStDto result = planningServiceImplUnderTest.findByPlanningSearchDto(planningSearch);
        // Verify the results
        assertEquals(1, result.getCollaborateurs().size());
        assertEquals(1, result.getAffectations().size());
    }

    @Test
    void testAjouterCollaborateur() {
        // Run the test
        planningServiceImplUnderTest
                .ajouterCollaborateur(333333L, 111111L, 222222L, List.of(CollaborateurDto.builder().build()));
        // Verify the results
        Mockito.verify(fakeAffiliationService.getMock(), Mockito.times(1))
                .saveAll(listAffiliationArgumentCaptor.capture());
        List<Affiliation> value = listAffiliationArgumentCaptor.getValue();
        Assert.assertEquals("X171001", value.get(0).getCollaborateur().getMatricule());
    }

    @Test
    void testSupprimerSemaine() {
        SuppressionSemaineDto suppressionSemaineDto = new SuppressionSemaineDto();
        planningServiceImplUnderTest.supprimerSemaine(suppressionSemaineDto);
        Mockito.verify(fackeAffectationService.getMock(), Mockito.times(1)).supprimerSemaine(suppressionSemaineDto);
        Mockito.verify(fakeRenfortService.getMock(), Mockito.times(1)).supprimerSemaine(suppressionSemaineDto);
        Mockito.verify(fakeAbsenceService.getMock(), Mockito.times(1)).supprimerSemaine(suppressionSemaineDto);
    }

    @Test
    @DisplayName("devrait retourner les renforts par ST")
    void testFindPlanningRenfortByPlanningSearchDto() {
        PlanningStDto planningRenfortByPlanningSearchDto = planningServiceImplUnderTest.findPlanningRenfortByPlanningSearchDto(PlanningSearchDto.builder().build());
        Assertions.assertFalse(planningRenfortByPlanningSearchDto.getRenforts().isEmpty());
        Assertions.assertFalse(planningRenfortByPlanningSearchDto.getCollaborateurs().isEmpty());
        Assertions.assertFalse(planningRenfortByPlanningSearchDto.getAffectations().isEmpty());
    }

}