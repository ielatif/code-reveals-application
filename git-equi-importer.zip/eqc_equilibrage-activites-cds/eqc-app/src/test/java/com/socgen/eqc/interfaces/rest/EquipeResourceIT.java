package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.interfaces.rest.dto.EquipeDto;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import io.restassured.response.Response;
import java.util.List;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.hamcrest.MatcherAssert.assertThat;

class EquipeResourceIT extends AbstractIT {

    @Autowired
    private EquipeService equipeService;

    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/EquipeResourceIT/equipe.sql"})
    @DisplayName("Recupérer toutes les équipes")
    void should_get_equipes() {

        List<EquipeDto> equipeDtos = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .get("equipes").as(List.class);

        assertThat(equipeDtos.size(), Matchers.equalTo(2));
    }

    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/EquipeResourceIT/equipe.sql"})
    @DisplayName("Mettre à jour une équipe")
    void should_update_equipes() {

        EquipeDto equipeDto = EquipeDto.builder().code(3000324051L).codeUg(3000324056L)
                .codeCds(3000324057L).formatSemainier((byte)5).build();
        Equipe equipeDto1 = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .body(equipeDto)
                .put("equipes").as(Equipe.class);


        assertThat(equipeDto.getFormatSemainier(), Matchers.equalTo(equipeDto1.getFormatSemainier()));
    }
}
