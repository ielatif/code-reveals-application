package com.socgen.eqc.application.mock;

import com.socgen.eqc.application.CollaborateurService;
import org.mockito.Mockito;

import java.util.List;

public class FakeCollaborateurService {

    private final CollaborateurService mock;

    public FakeCollaborateurService() {
        this.mock = Mockito.mock(CollaborateurService.class);
        init();
    }

    private void init() {

        Mockito.when(mock.findByMatricules(Mockito.any())).thenReturn(List.of(FakeDto.collaborateurSupplier.get()));

        Mockito.when(mock.findNewCollaborateurs(Mockito.any()))
            .thenReturn(List.of(FakeDto.collaborateurSupplier.get()));

        Mockito.when(mock.findByPlanningSearchDto(Mockito.any()))
            .thenReturn(List.of(FakeDomain.collaborateurSupplier.get()));

        Mockito.when(mock.getCollaborateursByMatriculeFromEqc(Mockito.any()))
            .thenReturn(List.of(FakeDto.collaborateurSupplier.get()));

        Mockito.when(mock.findCollaborateurs(Mockito.any())).thenReturn(List.of(FakeDto.collaborateurSupplier.get()));

        Mockito.when(mock.save(Mockito.any())).thenReturn(FakeDomain.collaborateurSupplier.get());

    }

    public CollaborateurService getMock() {
        return mock;
    }
}
