package com.socgen.eqc.application.mock;

import com.socgen.eqc.application.RenfortService;
import org.mockito.Mockito;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class FakeRenfortService {

    private final RenfortService mock;

    public FakeRenfortService() {
        this.mock = Mockito.mock(RenfortService.class);
        init();
    }

    private void init() {
        when(mock.findByMatricule(any())).thenReturn(List.of(FakeDomain.renfortSupplier.get()));
        when(mock.findRenfortEntrant(any(), any(), any())).thenReturn(List.of(FakeDomain.renfortSupplier.get()));
        when(mock.findRenfortSortant(any())).thenReturn(List.of(FakeDomain.renfortSupplier.get()));
        when(mock.searchRenfortByMatriculeAndCodeStAideAndDate(any(), any(), any()))
            .thenReturn(FakeDomain.renfortSupplier.get());
    }

    public RenfortService getMock() {
        return mock;
    }
}
