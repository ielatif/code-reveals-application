package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Affectation;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AffectationRepositoryTest extends AbstractDataJpaTest {

    @Autowired
    private AffectationRepository affectationRepositoryUnderTest;

    @Test
    @Sql({"/db/infrastructure/persistance/AffectationRepositoryTest/affectationRepositoryTest.sql"})
    void testFindAllByCollaborateurMatriculeAndDateGreaterThanEqual() {
        // Setup
        final Long affiliationId = 1L;
        final LocalDate date = LocalDate.of(2019, 12, 24);
        // Run the test
        List<Affectation> allAffectation = affectationRepositoryUnderTest.findAll();
        affectationRepositoryUnderTest.deleteByAffiliationIdAndDateAfter(affiliationId, date);
        List<Affectation> allAffectationAfterDelete = affectationRepositoryUnderTest.findAll();

        // Verify the results
        assertEquals(2, allAffectation.size());
        assertEquals(1, allAffectationAfterDelete.size());

    }
}
