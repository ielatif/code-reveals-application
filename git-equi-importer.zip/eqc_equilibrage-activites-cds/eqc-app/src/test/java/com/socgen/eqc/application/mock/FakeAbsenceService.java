package com.socgen.eqc.application.mock;

import com.socgen.eqc.application.AbsenceService;
import org.mockito.Mockito;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class FakeAbsenceService {

    private final AbsenceService mock;

    public FakeAbsenceService() {
        this.mock = Mockito.mock(AbsenceService.class);
        init();
    }

    private void init() {
        when(mock.findAbsences(any(), any(), any(), any())).thenReturn(List.of(FakeDomain.absenceSupplier.get()));
    }

    public AbsenceService getMock() {
        return mock;
    }
}
