package com.socgen.eqc.infrastructure.people.client;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.people.dto.ListPeopleDto;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.util.List;

import static java.util.Arrays.*;
import static java.util.Collections.*;
import static org.junit.jupiter.api.Assertions.*;

@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "people-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
@ExtendWith({HoverflyExtension.class, MockitoExtension.class})
class PeopleClientImplTest {

    private final Client mockRestClient = ClientBuilder.newBuilder()
        .register(new JacksonJaxbJsonProvider().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false))
        .build();

    @Mock
    private ApplicationProperties mockApplicationProperties;

    private PeopleClientImpl peopleClientImplUnderTest;

    @BeforeEach
    void setUp() {
        peopleClientImplUnderTest = new PeopleClientImpl(mockRestClient, mockApplicationProperties);
    }

    @Test
    void testFindPeople() {
        // Setup
        var people = new ApplicationProperties.People();
        people.setServerUrl("http://localhost:8440/sds-services-people-api/api/v1");
        Mockito.when(mockApplicationProperties.getPeople()).thenReturn(people);
        final List<Long> codesSt = singletonList(1254L);
        final List<String> matricules = asList("15331920", "15331921");

        // Run the test
        final ListPeopleDto result = peopleClientImplUnderTest.findPeople(codesSt, matricules);

        // Verify the results
        assertEquals(4, result.getDatas().size());
        assertEquals("Laurent", result.getDatas().get(0).getPrenom());
    }
}
