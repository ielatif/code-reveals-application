package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.RenfortService;
import com.socgen.eqc.infrastructure.entite.structure.EntiteStructureService;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.ServiceTraitement;
import com.socgen.eqc.infrastructure.entite.structure.domain.UniteGestion;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.params.provider.Arguments.*;
import static org.mockito.MockitoAnnotations.*;

class PerimetreServiceImplTest {

    @Mock
    private EntiteStructureService mockEntiteStructureService;

    @Mock
    private RenfortService renfortService;

    private PerimetreServiceImpl perimetreServiceImplUnderTest;


    @BeforeEach
    public void setUp() {
        initMocks(this);
        perimetreServiceImplUnderTest = new PerimetreServiceImpl(mockEntiteStructureService, renfortService);
        // Setup
        ServiceTraitement serviceTraitement1 = ServiceTraitement.builder().id("st1Id").libelle("st1").build();
        ServiceTraitement serviceTraitement2 = ServiceTraitement.builder().id("st2Id").libelle("st2").build();

        UniteGestion uniteGestion1 = UniteGestion.builder().id("UG1id").libelle("ug1")
            .serviceTraitements(Collections.singletonList(serviceTraitement1)).build();
        UniteGestion uniteGestion2 = UniteGestion.builder().id("UG2id").libelle("ug2")
            .serviceTraitements(Collections.singletonList(serviceTraitement2)).build();

        CentreService centreService1 = CentreService.builder().id("cs1Id").libelle("cs1")
            .uniteGestions(Collections.singletonList(uniteGestion1)).build();
        CentreService centreService2 = CentreService.builder().id("cs2Id").libelle("cs2")
            .uniteGestions(Collections.singletonList(uniteGestion2)).build();

        List<CentreService> centreServices = Arrays.asList(centreService1, centreService2);

        Mockito.when(mockEntiteStructureService.getEntiteStructureFromRes()).thenReturn(centreServices);
    }

    @MethodSource("generator")
    @ParameterizedTest(name = "testGetEntiteStructure of {1}")
    void testGetEntiteStructure(String code, String idCds) {
        // Run the test
        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");

        List<CentreService> result = perimetreServiceImplUnderTest.getPerimetre(code, sgUserPrincipalMock);
        // Verify the results
        Assertions.assertFalse(result.isEmpty());
        Assertions.assertEquals(idCds, result.get(0).getId());
    }

    @MethodSource("generator")
    @ParameterizedTest(name = "testGetEntiteStructure of {1}")
    void testGetEntiteStructureFromProfileAndPerimetrePilotage(String code, String idCds) {
        // Run the test
        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal(
                "{" +
                        "\"customParams\":{\n" +
                        "      \"sgstructureatt\":\"IdEs=st1Id:LibelleEs=ST FIL FIA RUN OFF CRE CLIPRI 1:" +
                        "Tel=00 00 00 00 00:Fax=00 00 00 00 00:Adr=RUN OFF CRE CLIPRI 1 RUN OFF CRE CLIPRI 1:" +
                        "CodePostal=94120:Ville=FONTENAY-SOUS-BOIS:Pays=FR:LUN=O,07H00,21H00:MAR=O,07H00,21H00:" +
                        "MER=O,07H00,21H00:JEU=O,07H00,21H00:VEN=O,07H00,21H00:SAM=O,07H00,21H00:DIM=N,,:PH=188704," +
                        "IdEs=st2Id:LibelleEs=bla bla\"\n" +
                        "   },\n" +
                        "\"userId\": \"X178253\"," +
                        "\"firstName\": \"AAAA\"," +
                        "\"lastName\": \"BBBB\"," +
                        "\"roles\":{\"EQC\":[{\"name\":\"GERER_PLANNING\",\"parameters\":[{\"name\":\"Perimetre\"," +
                        "\"value\":\"ug1,ug2\"}]},{\"name\":\"CONSULTER_MOIS\",\"parameters\":[{\"name\":\"Perimetre\"," +
                        "\"value\":\"ug1,ug2\"}]},{\"name\":\"ADMINISTRER\",\"parameters\":[{\"name\":\"Perimetre\"," +
                        "\"value\":\"ug1,ug2\"}]}]}" +
                        "}");

        List<CentreService> result = perimetreServiceImplUnderTest.getPerimetre(code, sgUserPrincipalMock);
        // Verify the results
        Assertions.assertFalse(result.isEmpty());
        Assertions.assertEquals(idCds, result.get(0).getId());
    }

    // and then somewhere in this test class
    private static Stream<Arguments> generator() {

        return Stream
            .of(of("123", "cs1Id"), of("596", "cs1Id"), of("UG1id", "cs1Id"), of("st1Id", "cs1Id"), of("cs1Id", "cs1Id"), of("UG2id", "cs2Id"));
    }

}
