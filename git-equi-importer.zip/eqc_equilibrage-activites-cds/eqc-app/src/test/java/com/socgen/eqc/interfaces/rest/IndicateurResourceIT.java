package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.StockATraiterStDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.StockOutputDto;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith({HoverflyExtension.class})
@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "smbo-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
class IndicateurResourceIT extends AbstractIT {

    @Test
    @DisplayName("Récuperation des stocks a traiter")
    void should_get_indicateurs() {

        IndicateurActiviteDto [] indicateurs = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .queryParam("listCodeServiceTraitement", "3000324055")
                .queryParam("tetePerimetre", "3000350988")
                .queryParam("dateDebut", "2021-12-13")
                .queryParam("dateFin", "2021-12-15")
                .get("indicateurs")
                .as(IndicateurActiviteDto[].class);

        List<IndicateurActiviteDto> indicateurStockExpected = Arrays.asList(indicateurs);
        assertThat(indicateurStockExpected.size(), Matchers.equalTo(3));
        Optional<IndicateurActiviteDto> indicateurWithStock = indicateurStockExpected.stream().filter(indicateurActiviteDto -> indicateurActiviteDto.getCodeActivite().equals("CRI01"))
                .findFirst();

        assertTrue(indicateurStockExpected.contains(IndicateurActiviteDto.builder().codeActivite("CRI01").stocks(
                List.of(StockATraiterStDto.builder().codeServiceTraitement("3000324055").stocksATraiter(
                        List.of(StockOutputDto.builder().day("2021-12-14")
                                .stockTacheTraiter(new BigInteger("15"))
                                .stockDossierTraiter(new BigInteger("8"))
                                .stockTacheTermine(new BigInteger("0"))
                                .stockDossierTermine(new BigInteger("0")).build(),
                                StockOutputDto.builder().day("2021-12-13")
                                        .stockTacheTraiter(new BigInteger("15"))
                                        .stockDossierTraiter(new BigInteger("8"))
                                        .stockTacheTermine(new BigInteger("0"))
                                        .stockDossierTermine(new BigInteger("0")).build(),
                                StockOutputDto.builder().day("2021-12-15")
                                        .stockTacheTraiter(new BigInteger("15"))
                                        .stockDossierTraiter(new BigInteger("8"))
                                        .stockTacheTermine(new BigInteger("0"))
                                        .stockDossierTermine(new BigInteger("0")).build())
                ).build())
        ).build()));

        assertTrue(indicateurWithStock.isPresent());
        assertEquals(3, indicateurWithStock.get().getStocks()
                .stream().filter(stock -> stock.getCodeServiceTraitement()
                        .equals("3000324055")).findFirst().get().getStocksATraiter().size()
        );
    }

    @Test
    @DisplayName("Récuperation des indicateurs ETP")
    void should_get_etp_indicateurs() {

        String payload = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .queryParam("stCodes", "3000324060")
                .queryParam("dateDebut", "2021-01-13")
                .queryParam("dateFin", "2021-12-15")
                .get("indicateurs/etps").body().asString();

        System.out.println("Etp payload:  " + payload);

        assertTrue(!payload.isEmpty());
    }
}
