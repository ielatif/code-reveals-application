package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.infrastructure.persistance.AffectationRepository;
import com.socgen.eqc.infrastructure.persistance.CompetenceRepository;
import com.socgen.eqc.interfaces.rest.dto.Action;
import com.socgen.eqc.interfaces.rest.dto.ActionAffectationDto;
import com.socgen.eqc.interfaces.rest.dto.DuplicationDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.mapper.ActionMapperImpl;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;

@ExtendWith(MockitoExtension.class)
class AffectationServiceImplTest {

    @Mock
    private AffectationRepository mockAffectationRepository;

    @Spy
    private ActionMapperImpl actionMapper;

    @Mock
    private AffiliationService mockAffiliationService;

    @Mock
    private CompetenceRepository competenceRepository;

    private AffectationServiceImpl affectationServiceImplUnderTest;

    @Captor
    private ArgumentCaptor<List<Affectation>> listArgumentCaptor;

    @Captor
    private ArgumentCaptor<List<Long>> listIdAffectationCaptor;

    @Captor
    private ArgumentCaptor<List<Affectation>> captureAffectation;

    @BeforeEach
    void setUp() {
        actionMapper.setAffiliationService(mockAffiliationService);
        affectationServiceImplUnderTest = new AffectationServiceImpl(mockAffectationRepository, actionMapper, mockAffiliationService, competenceRepository);
    }

    @Test
    void testUpdate() {
        // Setup
        ActionAffectationDto actionAffectationDto1 = ActionAffectationDto.builder().id(1L).matricule("matricule1")
            .date(LocalDate.of(2017, 1, 1)).action(Action.CREATE).codeActivite("codeActivite").pourcentage(10L)
            .nombreDossier(100D).build();
        ActionAffectationDto actionAffectationDto2 = ActionAffectationDto.builder().id(2L).matricule("matricule2")
            .date(LocalDate.of(2017, 1, 2)).action(Action.UPDATE).codeActivite("codeActivite").pourcentage(20L)
            .nombreDossier(100D).build();
        ActionAffectationDto actionAffectationDto3 = ActionAffectationDto.builder().id(3L).matricule("matricule3")
            .date(LocalDate.of(2017, 1, 3)).action(Action.DELETE).codeActivite("codeActivite").pourcentage(30L)
            .nombreDossier(100D).build();

        final List<ActionAffectationDto> actionAffectations = Arrays
            .asList(actionAffectationDto1, actionAffectationDto2, actionAffectationDto3);
        Mockito.when(mockAffiliationService.findByMatriculeAndDate(Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(Optional.of(Affiliation.builder().build()));
        // Run the test
        affectationServiceImplUnderTest.updateOrDelete(actionAffectations);

        // Verify the results
        Mockito.verify(mockAffectationRepository, Mockito.atMostOnce()).saveAll(listArgumentCaptor.capture());
        List<Affectation> value = listArgumentCaptor.getValue();
        Assertions.assertEquals(2, value.size());
        Mockito.verify(mockAffectationRepository, Mockito.atMostOnce())
            .deleteAllByIdIn(listIdAffectationCaptor.capture());
        List<Long> idsList = listIdAffectationCaptor.getValue();
        Assertions.assertEquals(1, idsList.size());
        Assertions.assertEquals(3L, idsList.get(0).longValue());
    }

    @Test
    void testDupliquer() {
        // Setup
        LocalDate dateSource = LocalDate.now();
        LocalDate dateCible = LocalDate.now().minusWeeks(1);
        final DuplicationDto duplicationDto = DuplicationDto.builder().dateCible(dateSource).dateSource(dateCible)
            .matricules(List.of("X171001")).build();
        Mockito.when(mockAffiliationService.findActiveByMatricules(Mockito.any())).thenReturn(Lists.emptyList());
        Mockito.when(mockAffectationRepository
            .findByAffiliationIdInAndDateBetween(Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(getAffectation(dateSource)).thenReturn(getAffectation(dateCible));
        // Run the test
        affectationServiceImplUnderTest.dupliquerSemaine(duplicationDto.getDateSource(), duplicationDto.getDateCible(), duplicationDto.getMatricules());
        // Verify the results
        Mockito.verify(mockAffectationRepository, Mockito.atLeastOnce()).saveAll(captureAffectation.capture());
        Assertions.assertEquals(1, captureAffectation.getValue().size());
    }

    private List<Affectation> getAffectation(LocalDate date) {
        Affectation affectation = Affectation.builder().date(date.plusDays(1))
            .expertise(Expertise.builder().id(1L).build())
            .affiliation(Affiliation.builder().collaborateur(Collaborateur.builder().matricule("X171001").build())
                .build()).activite(ActiviteParams.builder().code("CIP-" + new Random().nextInt()).build())
            .build();
        return List.of(affectation);
    }

    @Test
    void testUpdateCapaciteTheorique() {
        // Setup
        ActiviteParams activite = ActiviteParams.builder().code("Act-10").build();
        Competence competence = Competence.builder().id(1L)
            .expertise(Expertise.builder().nombreDossier(100F).activite(activite).build()).build();
        List<Competence> listUpdateCompetence = List.of(competence);
        List<Affectation> listAffectationByMatricule = List
            .of(Affectation.builder().pourcentage(10L).activite(activite).build());
        Mockito.when(mockAffectationRepository.findAllByMatricule(Mockito.any(), Mockito.any()))
            .thenReturn(listAffectationByMatricule);
        //run
        affectationServiceImplUnderTest.updateCapaciteTheorique("X171001", listUpdateCompetence);

        // Verify the results
        Mockito.verify(mockAffectationRepository, Mockito.times(1)).saveAll(captureAffectation.capture());
        List<Affectation> affectations = captureAffectation.getValue();
        Assertions.assertEquals(1, affectations.size());
        Assert.assertEquals(Double.valueOf(10), affectations.get(0).getNombreDossier());
    }

    @Test
    void testUpdateCapaciteTheoriqueByExpertise() {
        // Setup
        ActiviteParams activite = ActiviteParams.builder().code("Act-10").build();
        Set<Expertise> expertises = Set.of(Expertise.builder().activite(activite).build());
        Mockito.when(mockAffectationRepository.findByExpertiseIdInAndDateAfter(Mockito.any(), Mockito.any()))
            .thenReturn(List
                .of(Affectation.builder().expertise(Expertise.builder().nombreDossier(100F).build()).activite(activite)
                    .pourcentage(10L).build()));
        // Run the test
        affectationServiceImplUnderTest.updateCapaciteTheorique(expertises);
        // Verify the results
        Mockito.verify(mockAffectationRepository, Mockito.times(1)).saveAll(captureAffectation.capture());
        List<Affectation> affectations = captureAffectation.getValue();
        Assertions.assertEquals(1, affectations.size());
        Assert.assertEquals(Double.valueOf(10), affectations.get(0).getNombreDossier());
    }

    @Test
    void testSupprimerSemaine() {
        List<String> matricules = List.of("x171001");
        List<String> matriculesRenfort = List.of("x171002");
        LocalDate dateDebut = LocalDate.of(2021, 1, 1);
        LocalDate dateFin = LocalDate.of(2021, 1, 8);
        SuppressionSemaineDto dto = SuppressionSemaineDto.builder()
            .matriculesRenfort(matriculesRenfort)
            .matricules(matricules)
            .codeServiceTraitement(1L)
            .dateDebut(dateDebut)
            .dateFin(dateFin)
            .build();
        affectationServiceImplUnderTest.supprimerSemaine(dto);
        Mockito.verify(mockAffectationRepository, Mockito.times(1)).deleteByMatricules(matricules, dateDebut, dateFin, 1L);
        Mockito.verify(mockAffectationRepository, Mockito.times(1)).deleteRenfortEntrant(matriculesRenfort, dateDebut, dateFin, 1L);
    }

    @Test
    @DisplayName("should not call the repository if the lists empty")
    void testSupprimerSemaineWithEmptyList() {
        List<String> matricules = Lists.emptyList();
        List<String> matriculesRenfort = Lists.emptyList();
        LocalDate dateDebut = LocalDate.of(2021, 1, 1);
        LocalDate dateFin = LocalDate.of(2021, 1, 8);
        SuppressionSemaineDto dto = SuppressionSemaineDto.builder()
            .matriculesRenfort(matriculesRenfort)
            .matricules(matricules)
            .codeServiceTraitement(1L)
            .dateDebut(dateDebut)
            .dateFin(dateFin)
            .build();
        affectationServiceImplUnderTest.supprimerSemaine(dto);
        Mockito.verify(mockAffectationRepository, Mockito.times(0)).deleteByMatricules(matricules, dateDebut, dateFin, 1L);
        Mockito.verify(mockAffectationRepository, Mockito.times(0)).deleteRenfortEntrant(matriculesRenfort, dateDebut, dateFin, 1L);
    }
}
