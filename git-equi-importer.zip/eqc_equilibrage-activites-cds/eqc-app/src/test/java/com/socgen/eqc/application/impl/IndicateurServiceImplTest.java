package com.socgen.eqc.application.impl;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.persistance.ExportEtpRepository;
import com.socgen.eqc.infrastructure.persistance.IndicateurEtpRepository;
import com.socgen.eqc.infrastructure.smbo.SmboClientImpl;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurEtpInputDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.StockATraiterStDto;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "smbo-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
@ExtendWith({HoverflyExtension.class, MockitoExtension.class})
class IndicateurServiceImplTest {

    @InjectMocks
    private IndicateurServiceImpl indicateurService;

    @Mock
    private SmboClientImpl smboClientService;

    @Mock
    private IndicateurEtpRepository indicateurEtpRepository;

    @Mock
    private ApplicationProperties mockApplicationProperties;

    private final Client mockSmboClient = ClientBuilder.newBuilder()
            .register(new JacksonJaxbJsonProvider().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false))
            .build();

    @Test
    void should_get_indicateurs() {

        ReflectionTestUtils.setField(smboClientService, "smboClient", mockSmboClient);
        ReflectionTestUtils.setField(smboClientService, "applicationProperties", mockApplicationProperties);

        final ApplicationProperties.Smbo smbo = new ApplicationProperties.Smbo();
        smbo.setServerUrl("http://localhost:8440/api");
        when(mockApplicationProperties.getSmbo()).thenReturn(smbo);

        IndicateurInputDto indicateurInputDto = IndicateurInputDto.builder().tetePerimetre(Collections.singletonList("3000350988")).listCodeServiceTraitement(List.of("3000324055")).dateDebut("2021-12-13").dateFin("2021-12-15").build();

        when(smboClientService.getIndicateurBrut(indicateurInputDto.getListCodeServiceTraitement(),
                LocalDate.parse(indicateurInputDto.getDateDebut()),
                LocalDate.parse(indicateurInputDto.getDateFin()), indicateurInputDto.getTetePerimetre()))
                .thenCallRealMethod();

        List<IndicateurActiviteDto> indicateursStockTraiter = indicateurService.getStockTraiter(indicateurInputDto, false);

        assertEquals(3, indicateursStockTraiter.size());

        Optional<IndicateurActiviteDto> indicateurWithStock = indicateursStockTraiter.stream()
                .filter(indicateurActiviteDto -> indicateurActiviteDto.getCodeActivite().equals("CRI01"))
                .findFirst();

        assertTrue(indicateursStockTraiter.contains(IndicateurActiviteDto.builder().codeActivite("CRI02").stocks(
                List.of(StockATraiterStDto.builder().codeServiceTraitement("3000324055").stocksATraiter(Collections.emptyList()).build())
        ).build()));

        assertTrue(indicateurWithStock.isPresent());
        assertEquals(3, indicateurWithStock.get().getStocks()
                .stream().filter(stock -> stock.getCodeServiceTraitement()
                        .equals("3000324055")).findFirst().get().getStocksATraiter().size()
        );
    }

    @Test
    void should_indicateurs_be_empty_when_date_debut_is_after_date_fin() {

        IndicateurInputDto indicateurInputDto = IndicateurInputDto.builder().tetePerimetre(Collections.singletonList("3000350988")).listCodeServiceTraitement(List.of("3000324055")).dateDebut("2021-12-15").dateFin("2021-12-13").build();

        lenient().when(smboClientService.getIndicateurBrut(indicateurInputDto.getListCodeServiceTraitement(),
                LocalDate.parse(indicateurInputDto.getDateDebut()),
                LocalDate.parse(indicateurInputDto.getDateFin()), indicateurInputDto.getTetePerimetre()))
                .thenCallRealMethod();

        List<IndicateurActiviteDto> indicateursStockTraiter = indicateurService.getStockTraiter(indicateurInputDto, false);

        assertEquals(0, indicateursStockTraiter.size());
    }

    @Test
    void should_get_etps_indicateurs() {

        final Gson gson = new GsonBuilder().create();

        final String payload = "[\n" +
                "            {\n" +
                "                \"codeFamille\": \"OPECLICOM_499\",\n" +
                "                \"codeActivite\": \"ACT-10020\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.008045977011494253,\n" +
                "                \"etpRenfortMoyen\": 0.0\n" +
                "            },\n" +
                "            {\n" +
                "                \"codeFamille\": \"OPECLICOM_499\",\n" +
                "                \"codeActivite\": \"ACT-1182\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.13360153256704982,\n" +
                "                \"etpRenfortMoyen\": 0.0\n" +
                "            },\n" +
                "            {\n" +
                "                \"codeFamille\": \"CRECLIPRI_OPPI\",\n" +
                "                \"codeActivite\": \"ACT-1198\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.0,\n" +
                "                \"etpRenfortMoyen\": 0.0\n" +
                "            }]";

        Type etpListType = new TypeToken<List<JsonObject>>() {}.getType();

        List<JsonObject> expectedResult = gson.fromJson(payload, etpListType);

        when(indicateurEtpRepository.getEtps(anyString(), anyString(), anyList())).thenReturn(expectedResult);

        JsonObject etpResult = this.indicateurService.getEtps(
                IndicateurEtpInputDto.builder()
                        .dateDebut("2021-01-01")
                        .dateFin("2022-01-11")
                        .listCodeServiceTraitement("2001122,32212200").build());


        assertEquals(true,  etpResult.has("sts"));
        assertEquals("2021-01-01",  etpResult.get("dateDebut").getAsString());
        assertEquals("2022-01-11",  etpResult.get("dateFin").getAsString());
        assertEquals(2,  etpResult.get("sts").getAsJsonArray().size());

    }

    @Test
    void should_merge_etps_brut_and_etps_renfort() {

        final Gson gson = new GsonBuilder().create();

        final String payload1 = "[\n" +
                "            {\n" +
                "                \"codeFamille\": \"OPECLICOM_499\",\n" +
                "                \"codeActivite\": \"ACT-10020\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.008045977011494253,\n" +
                "                \"etpRenfortMoyen\": 0.0\n" +
                "            },\n" +
                "            {\n" +
                "                \"codeFamille\": \"OPECLICOM_499\",\n" +
                "                \"codeActivite\": \"ACT-1182\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.13360153256704982,\n" +
                "                \"etpRenfortMoyen\": 0.0\n" +
                "            },\n" +
                "            {\n" +
                "                \"codeFamille\": \"CRECLIPRI_OPPI\",\n" +
                "                \"codeActivite\": \"ACT-1198\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.22,\n" +
                "                \"etpRenfortMoyen\": 0.11\n" +
                "            }]";
        final String payload2 = "[\n" +
                "            {\n" +
                "                \"codeFamille\": \"OPECLICOM_499\",\n" +
                "                \"codeActivite\": \"ACT-10020\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.008045977011494253,\n" +
                "                \"etpRenfortMoyen\": 0.0\n" +
                "            },\n" +
                "            {\n" +
                "                \"codeFamille\": \"OPECLICOM_499\",\n" +
                "                \"codeActivite\": \"ACT-1182\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.13360153256704982,\n" +
                "                \"etpRenfortMoyen\": 0.0\n" +
                "            },\n" +
                "            {\n" +
                "                \"codeFamille\": \"CRECLIPRI_OPP1\",\n" +
                "                \"codeActivite\": \"ACT-1198\",\n" +
                "                \"equipeId\": 3000324133,\n" +
                "                \"etpTotalMoyen\": 0.55,\n" +
                "                \"etpRenfortMoyen\": 0.66\n" +
                "            }]";

        Type etpListType = new TypeToken<List<JsonObject>>() {}.getType();

        List<JsonObject> etpsBrut = gson.fromJson(payload1, etpListType);
        List<JsonObject> etpsRenfort = gson.fromJson(payload2, etpListType);

        when(indicateurEtpRepository.getEtps(anyString(), anyString(), anyList())).thenReturn(etpsBrut);
        when(indicateurEtpRepository.getEtpsRenfort(anyString(), anyString(), anyList())).thenReturn(etpsRenfort);

        JsonObject etpResult = this.indicateurService.getEtps(
                IndicateurEtpInputDto.builder()
                        .dateDebut("2021-01-01")
                        .dateFin("2022-01-11")
                        .listCodeServiceTraitement("2001122,32212200").build());


        assertEquals(true,  etpResult.has("sts"));
        assertEquals("2021-01-01",  etpResult.get("dateDebut").getAsString());
        assertEquals("2022-01-11",  etpResult.get("dateFin").getAsString());
        assertEquals(2,  etpResult.get("sts").getAsJsonArray().size());

    }


}
