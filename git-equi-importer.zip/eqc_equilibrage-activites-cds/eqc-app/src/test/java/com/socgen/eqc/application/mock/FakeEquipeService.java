package com.socgen.eqc.application.mock;

import com.socgen.eqc.application.EquipeService;
import org.mockito.Mockito;

public class FakeEquipeService {

    private final EquipeService mock;

    public FakeEquipeService() {
        this.mock = Mockito.mock(EquipeService.class);
        init();
    }

    private void init() {
        Mockito.when(mock.findById(Mockito.any())).thenReturn(FakeDomain.equipeSupplier.get());
    }

    public EquipeService getMock() {
        return mock;
    }
}
