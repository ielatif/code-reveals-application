package com.socgen.eqc.infrastructure.sgConnect;

import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.sgconnect.SgConnectServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Answers;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import java.net.URI;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SgConnectServiceImplTest {

    @Mock
    private Client sgConnect;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private ApplicationProperties applicationProperties;

    @InjectMocks
    private SgConnectServiceImpl sgConnectService;

    @Captor
    private ArgumentCaptor<URI> captureURI;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private WebTarget webTarget;

    @BeforeEach
    void setup() {
        lenient().when(applicationProperties.getSgConnect().getServerUrl()).thenReturn("sgconnect-serverurl");
        lenient().when(applicationProperties.getSgConnect().getUsername()).thenReturn("sgconnect-username");
        lenient().when(applicationProperties.getSgConnect().getPassword()).thenReturn("sgconnect-passw");
        lenient().when(applicationProperties.getSgConnect().getScope()).thenReturn("sgconnect-scope");
    }

    @Test
    void should_call_sg_connect_server_when_get_basic_athentification() {
        when(sgConnect.target(captureURI.capture())).thenReturn(webTarget);
        sgConnectService.getBasicAuthentication();

        assertThat(captureURI.getValue().getPath()).isEqualTo("sgconnect-serverurl");
    }
}
