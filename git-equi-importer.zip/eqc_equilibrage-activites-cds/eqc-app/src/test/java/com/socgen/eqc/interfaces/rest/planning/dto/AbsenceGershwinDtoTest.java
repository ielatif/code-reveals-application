package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.application.mock.FakeDomain;
import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.domain.model.Renfort;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class AbsenceGershwinDtoTest {

    @Test
    void testFromDomain() {
        // Setup
        final List<Absence> absences = List.of(FakeDomain.absenceSupplier.get());
        final List<Affectation> affectations = List.of(FakeDomain.affectationSupplier.get());
        final List<Renfort> renforts = List.of(FakeDomain.renfortSupplier.get());
        // Run the test
        final AbsenceGershwinDto result = AbsenceGershwinDto.fromDomain(absences);

        // Verify the results
        assertThat(result.getAbsences().get(0).getIntervalle()).isEqualTo(FakeDomain.absenceSupplier.get().getIntervalle());
    }
}
