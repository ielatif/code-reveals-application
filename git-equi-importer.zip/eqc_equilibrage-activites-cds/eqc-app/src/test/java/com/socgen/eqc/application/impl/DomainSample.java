package com.socgen.eqc.application.impl;

import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.ServiceTraitement;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.infrastructure.entite.structure.domain.UniteGestion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.function.Supplier;

public class DomainSample {

//    public static final Supplier<Activite> act1 = () -> Activite.builder().code("A1245")
//            .libelle("activite1").build();

    public static final Collaborateur collaborateur = Collaborateur.builder().matricule("X101001").build();
    public static final Equipe equipe = Equipe.builder().code(1L).build();
    public static final Affiliation affiliation = Affiliation.builder().collaborateur(collaborateur).equipe(equipe).build();

//    public static final Supplier<Affectation> AFFECTATION_X101001 = () -> Affectation.builder().activite(act1.get())
//            .date(LocalDate.of(2020, 1, 1)).id(1L).pourcentage(10L).affiliation(affiliation).build();
//
//    public static final Supplier<Affectation> AFFECTATION_X201001 = () -> Affectation.builder().activite(act1.get())
//            .date(LocalDate.of(2020, 1, 2)).id(1L).pourcentage(20L).affiliation(affiliation).build();

//    public static final Supplier<Activite> ACTIVITE_1 = () -> Activite.builder().code("A1245")
//            .famille(Famille.builder().code("F01").build()).libelle("Act 1").build();
//    public static final Supplier<Activite> ACTIVITE_2 = () -> Activite.builder().code("A2245")
//            .famille(Famille.builder().code("F02").build()).libelle("Act 2").build();

    public static final Supplier<ServiceTraitement> serviceTraitement1 = () -> ServiceTraitement.builder()
            .id("3000319868")
            .libelle("BDDF CDS VDF OPE CLIPRI 1")
            .listeTetePerimetre(Arrays.asList(
                    TetePerimetre.builder()
                            .id("3000359245")
                            .libelle("PSC OPE CLIPRI")
                            .build()))
            .build();

    public static final Supplier<ServiceTraitement> serviceTraitement2 = () -> ServiceTraitement.builder()
            .id("3000387407")
            .libelle("BDDF CDS VDF OPE CLIPRI 2")
            .listeTetePerimetre(Arrays.asList(
                    TetePerimetre.builder()
                            .id("3000359245")
                            .libelle("PSC OPE CLIPRI")
                            .build()))
            .build();

    public static final Supplier<ServiceTraitement> serviceTraitementWithEmptyTetePerimetre = () -> ServiceTraitement.builder()
            .id("3000382099")
            .libelle("BDDF CDS VDF OPE CLIPRI 3")
            .listeTetePerimetre(new ArrayList<>())
            .build();

    public static final Supplier<ServiceTraitement> serviceTraitementForFiliere1 = () -> ServiceTraitement.builder()
            .id("3000382000")
            .libelle("BDDF OTX FIA TOUL FIA 1")
            .listeTetePerimetre(Arrays.asList(
                    TetePerimetre.builder()
                            .id("3000359245")
                            .libelle("FINANCEMENT ASSURANCES")
                            .build()))
            .build();

    public static final Supplier<ServiceTraitement> serviceTraitementForFiliere2 = () -> ServiceTraitement.builder()
            .id("3000382001")
            .libelle("BDDF OTX FIA TOUL FIA 1")
            .listeTetePerimetre(Arrays.asList(
                    TetePerimetre.builder()
                            .id("3000359245")
                            .libelle("FINANCEMENT ASSURANCES")
                            .build()))
            .build();

    public static final Supplier<ServiceTraitement> serviceTraitementForFiliere3 = () -> ServiceTraitement.builder()
            .id("3000382002")
            .libelle("BDDF OTX FIA MAR FIA 1")
            .listeTetePerimetre(Arrays.asList(
                    TetePerimetre.builder()
                            .id("3000359245")
                            .libelle("FINANCEMENT ASSURANCES")
                            .build()))
            .build();

    public static final Supplier<UniteGestion> uniteGestion = () -> UniteGestion.builder().id("3000336334")
            .libelle("BDDF CDS VDF DIR OPE CLIPRI")
            .serviceTraitements(new ArrayList<>(Arrays.asList(serviceTraitement1.get(),serviceTraitement2.get(), serviceTraitementWithEmptyTetePerimetre.get())))
            .build();

    public static final Supplier<UniteGestion> uniteGestionForFiliere1 = () -> UniteGestion.builder().id("3000331000")
            .libelle("BDDF OTX FIA TOUL DIR FIA")
            .serviceTraitements(new ArrayList<>(Arrays.asList(serviceTraitementForFiliere1.get(), serviceTraitementForFiliere2.get())))
            .build();

    public static final Supplier<UniteGestion> uniteGestionForFiliere2 = () -> UniteGestion.builder().id("3000331001")
            .libelle("BDDF OTX FIA MAR DIR FIA")
            .serviceTraitements(new ArrayList<>(Arrays.asList(serviceTraitementForFiliere3.get())))
            .build();

    public static final Supplier<UniteGestion> uniteGestionForFiliere3 = () -> UniteGestion.builder().id("3000331002")
            .libelle("BDDF OTX FIA LIL DIR FIA")
            .serviceTraitements(new ArrayList<>(Arrays.asList(serviceTraitementForFiliere1.get())))
            .build();

    public static final Supplier<CentreService> centreService = () -> CentreService.builder().id("3000334023").libelle("BDDF SERV CLIENT FONTENAY")
            .uniteGestions(new ArrayList<>(Arrays.asList(uniteGestion.get()))).build();

    public static final Supplier<CentreService> filiere1 = () -> CentreService.builder().id("3000334495").libelle("BDDF OTX FILIERE FINANCEMT ASSURANC")
            .uniteGestions(new ArrayList<>(Arrays.asList(uniteGestionForFiliere1.get(), uniteGestionForFiliere3.get()))).build();

    public static final Supplier<CentreService> filiere2 = () -> CentreService.builder().id("3000334497").libelle("BDDF OTX FILIERE OPE PERSONNE PHYS")
            .uniteGestions(new ArrayList<>(Arrays.asList(uniteGestionForFiliere2.get()))).build();
}
