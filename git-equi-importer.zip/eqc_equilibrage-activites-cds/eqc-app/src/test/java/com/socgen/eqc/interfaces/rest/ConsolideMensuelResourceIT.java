package com.socgen.eqc.interfaces.rest;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ConsolideMensuelResourceIT extends AbstractIT {

    @Test
    @Sql({"/db/clean-db.sql", "/db/interfaces/rest/PlanningResourceIT/planning.sql"})
    void testGenerate() {
        // Setup
        final LocalDate date = LocalDate.of(2019, 12, 1);

        // Run the test
        int statusCode = given().header("Authorization", setCustomUserWithRoles("CONSULTER_MOIS"))
            .header("x-ibm-client-id", CLIENT_ID_DE_BASE).accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
            .queryParam("date", date.toString()).post("consolideMensuel").statusCode();

        // Verify the results
        assertEquals(200, statusCode);
    }

}
