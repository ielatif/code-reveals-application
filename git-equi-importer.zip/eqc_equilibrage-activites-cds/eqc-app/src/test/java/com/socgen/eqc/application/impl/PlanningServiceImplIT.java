package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.PlanningService;
import com.socgen.eqc.config.SgSigninOAuthClientFilter;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.infrastructure.persistance.AffectationRepository;
import com.socgen.eqc.interfaces.rest.dto.Action;
import com.socgen.eqc.interfaces.rest.dto.ActionAffectationDto;
import com.socgen.eqc.interfaces.rest.dto.ActionsPlanningDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Slf4j
@DirtiesContext
class PlanningServiceImplIT {

    @Autowired
    private PlanningService planningService;

    @Autowired
    private AffectationRepository affectationRepository;

    @SpyBean
    private AffectationService affectationService;

    @MockBean
    private SgSigninOAuthClientFilter sgSigninOAuthClientFilter;
    private PlanningSearchDto planningSearchDto;
    private ActionsPlanningDto actionsPlanningDto;
    private SgUserPrincipal sgUserPrincipal;

    @BeforeEach
    void setUp() {
        planningSearchDto = new PlanningSearchDto(1L, LocalDate.of(2020, 10, 12), LocalDate
            .of(2020, 10, 16));
        ActionAffectationDto actionAffectationDto1 = ActionAffectationDto.builder().id(1L).matricule("Z017094")
            .date(LocalDate.of(2020, 10, 15)).action(Action.UPDATE).codeActivite("CRI01").pourcentage(80L).idExpertise(401)
            .nombreDossier(1D).build();

        ActionAffectationDto actionAffectationDto2 = ActionAffectationDto.builder().id(8L).matricule("Z017094").idExpertise(401)
            .date(LocalDate.of(2020, 10, 14)).action(Action.DELETE).codeActivite("CRI06").pourcentage(80L)
            .nombreDossier(1D).build();
        List<ActionAffectationDto> actionAffectations = Arrays.asList(actionAffectationDto1, actionAffectationDto2);
        actionsPlanningDto = new ActionsPlanningDto(actionAffectations, Collections
            .emptyList(), Collections.emptyList());
        sgUserPrincipal = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");

    }

    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/PlanningResourceIT/planning.sql"})
    void testUpdatePlanning() {
        //Step

        //run test
        planningService.update(planningSearchDto, actionsPlanningDto, sgUserPrincipal);
        //Verify
        List<Affectation> affectationList = affectationRepository.findAll();
        Assertions.assertEquals(3, affectationList.size());
        Assertions.assertEquals(80L, affectationList.get(0).getPourcentage().longValue());
    }

    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/PlanningResourceIT/planning.sql"})
    void testUpdatePlanningFail() {
        //Step
        Mockito.doThrow(new RuntimeException("Test RuntimeException!! ")).when(affectationService)
            .updateOrDelete(Mockito.any());
        //run test
        try {
            planningService.update(planningSearchDto, actionsPlanningDto, sgUserPrincipal);
        } catch (Exception e) {
            log.info("catch Exception", e);
        }
        //Verify
        List<Affectation> affectationList = affectationRepository.findAll();
        Assertions.assertEquals(3, affectationList.size());
        Assertions.assertEquals(50L, affectationList.get(0).getPourcentage().longValue());
    }


}

