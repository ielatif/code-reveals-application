package com.socgen.eqc.application.mock;

import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.impl.AffiliationServiceImpl;
import org.mockito.Mockito;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class FakeAffiliationService {

    private final AffiliationService mock;

    public FakeAffiliationService() {
        this.mock = Mockito.mock(AffiliationServiceImpl.class);
        init();
    }

    private void init() {
        when(mock.findByPlanningSearchDto(any())).thenReturn(List.of(FakeDomain.affiliationSupplier.get()));

        when(mock.findByListEquipe(any())).thenReturn(List.of(FakeDomain.affiliationSupplier.get()));

        when(mock.findByEquipeAndDate(any(), any())).thenReturn(List.of(FakeDomain.affiliationSupplier.get()));

        when(mock.findLastByMatricule(any())).thenReturn(Optional.of(FakeDomain.affiliationSupplier.get()));

        when(mock.findActiveByMatricules(any())).thenReturn(List.of(FakeDomain.affiliationSupplier.get()));

        when(mock.hasAffiliation(any())).thenReturn(true);
    }

    public AffiliationService getMock() {
        return mock;
    }
}
