package com.socgen.eqc.config;

import com.socgen.eqc.infrastructure.people.client.PeopleClientImpl;
import io.specto.hoverfly.junit5.HoverflyExtension;
import io.specto.hoverfly.junit5.api.HoverflyConfig;
import io.specto.hoverfly.junit5.api.HoverflySimulate;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.ws.rs.client.Client;

import static java.util.Collections.singletonList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@Slf4j
@ActiveProfiles("test")
@HoverflySimulate(config = @HoverflyConfig(proxyPort = 8440, webServer = true), source = @HoverflySimulate.Source(value = "people-simulation.json", type = HoverflySimulate.SourceType.DEFAULT_PATH), enableAutoCapture = true)
@ExtendWith({HoverflyExtension.class, SpringExtension.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EqcCacheConfigTest {

    @SpyBean(name = "restClient")
    private Client restClient;


    @MockBean
    private SgSigninOAuthClientFilter sgSigninOAuthClientFilter;

    @Autowired
    private PeopleClientImpl peopleClientImplUnderTest;

    @Test
    @DisplayName("Devrait être configuré pour stocker les entrées du cache par valeur")
    void testEhCacheConfig() {
        // Setup
        //run
        peopleClientImplUnderTest.findPeopleByListCodeSt(singletonList(1254L));
        peopleClientImplUnderTest.findPeopleByListCodeSt(singletonList(1254L));
        // Verify the results
        verify(restClient, times(1)).target(anyString());
    }

}
