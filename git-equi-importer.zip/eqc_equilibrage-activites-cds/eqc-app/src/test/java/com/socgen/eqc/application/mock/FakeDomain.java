package com.socgen.eqc.application.mock;

import com.socgen.eqc.domain.model.*;

import java.time.LocalDate;
import java.util.Set;
import java.util.function.Supplier;

// @formatter:off
public class FakeDomain {

    public static final Supplier<ActiviteRatio> activiteRatioSupplier = () ->ActiviteRatio.builder()
        .code("ACT-RATIO-1")
        .libelle("Activite Ratio")
        .ratioType(RatioType.builder().code("RATIO-TYPE-1").id(1L).libelle("sumeau").build())
        .tetePerimetre("tete-Perimetre-1")
        .build();



//    public static final Supplier<Famille> FamilleSupplier = () ->Famille.builder()
//        .tetePerimetre("tete-Perimetre-1")
//        .ordre(1)
//        .libelle("FAMILLE 1")
//        .code("FAM-1")
//        .build();

    public static final Supplier<Expertise> expertiseSupplier = () ->Expertise.builder()
        .activite(ActiviteParams.builder()
            .activiteRatio(activiteRatioSupplier.get())
            .code("ACT-1")
//            .famille(FamilleSupplier.get())
            .ordre(1)
            .build()
            )
        .nombreDossier(100F)
        .id(1L)
        .niveau(Niveau.builder().id(1L).libelle("NIVEAU 1").build())
        .build();


    public static final Supplier<ActiviteParams> activiteSupplier = () -> ActiviteParams.builder()
        .activiteRatio(activiteRatioSupplier.get())
        .expertises(Set.of(expertiseSupplier.get()))
        .code("ACT-1")
//        .famille(FamilleSupplier.get())
        .ordre(1)
        .build();



    public static final Supplier<Equipe> equipeSupplier = () -> Equipe.builder()
       .code(123456789L)
       .codeCds(111111L)
       .codeUg(222222L)
       .libelle("Equipe 1")
       .build();

    public static final Supplier<Collaborateur> collaborateurSupplier = () -> Collaborateur.builder()
        .matricule("X171001")
        .idRhLocal("GLX171001")
        .loginWindows("X171001")
        .nom("snow")
        .prenom("jon")
        .build();

    public static final Supplier<Affiliation> affiliationSupplier = () -> Affiliation.builder()
        .collaborateur(collaborateurSupplier.get())
        .equipe(equipeSupplier.get())
        .dateEntree(LocalDate.of(2020,1,1))
        .dateSortie(null)
        .id(1L)
        .build();

    public static final Supplier<Affectation> affectationSupplier = () -> Affectation.builder()
        .activite(activiteSupplier.get())
        .expertise(expertiseSupplier.get())
        .pourcentage(10L)
        .affiliation(affiliationSupplier.get())
        .renfort(null)
        .ordre(1)
        .date(LocalDate.of(2020,1,1))
        .nombreDossier(10D)
            .parametresCarte(ParametresCarte.builder().titre("commentPrinc").commentaire("commentSec").couleur(CouleurCarte.MAGENTA).build())
        .id(1L)
        .build();

    public static final Supplier<Renfort> renfortSupplier = () -> Renfort.builder()
        .date(LocalDate.of(2020,1,1))
        .collaborateur(collaborateurSupplier.get())
        .id(1L)
        .codeCdsAide(101010L)
        .codeCdsRattachement(111111L)
        .codeStRattachement(333333L)
        .codeUgAide(202020L)
        .codeUgRattachement(222222L)
        .equipe(equipeSupplier.get())
        .intervalle(Intervalle.TOUTE_JOURNEE)
        .build();

    public static final Supplier<Affectation> affectationForRenfortSupplier = () -> Affectation.builder()
            .activite(activiteSupplier.get())
            .expertise(expertiseSupplier.get())
            .pourcentage(10L)
            .affiliation(null)
            .renfort(renfortSupplier.get())
            .ordre(1)
            .date(LocalDate.of(2020, 1, 1))
            .nombreDossier(10D)
            .id(1L).build();


    public static final Supplier<Absence> absenceSupplier = () -> Absence.builder()
        .intervalle(Intervalle.TOUTE_JOURNEE)
        .date(LocalDate.of(2020,1,1))
        .id(1L)
        .matriculeCollaborateur("X171001")
        .build();

    public static final Supplier<Competence> competenceSupplier = () -> Competence.builder()
        .id(1L)
        .collaborateur(collaborateurSupplier.get())
        .expertise(expertiseSupplier.get())
        .build();

}
