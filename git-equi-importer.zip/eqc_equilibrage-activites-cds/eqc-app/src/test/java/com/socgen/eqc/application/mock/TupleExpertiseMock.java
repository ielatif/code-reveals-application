package com.socgen.eqc.application.mock;

import javax.persistence.Tuple;
import javax.persistence.TupleElement;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TupleExpertiseMock implements Tuple {

    TupleElement<String> codeActivite;
    TupleElement<Long> idNiveau;
    TupleElement<Float> nombreDossier;


    public TupleExpertiseMock(String codeActivite, Long idNiveau, Float nombreDossier) {
        this.codeActivite = new StringTupleElement(codeActivite);
        this.idNiveau = new LongTupleElement(idNiveau);
        this.nombreDossier = new FloatTupleElement(nombreDossier);
    }

    @Override
    public <X> X get(TupleElement<X> tupleElement) {
        return (X) get(tupleElement.getAlias());
    }

    @Override
    public <X> X get(String alias, Class<X> type) {
        return (X) get(alias);
    }

    @Override
    public Object get(String alias) {
        Map<String, TupleElement> elements = getMapElements();
        if (elements.get(alias).getJavaType().equals(BigInteger.class)) {
            return new BigInteger(elements.get(alias).getAlias());
        }
        return elements.get(alias).getAlias();
    }

    @Override
    public <X> X get(int i, Class<X> type) {
        return (X) String.valueOf(i);
    }

    @Override
    public Object get(int i) {
        return get(i, Object.class);
    }

    @Override
    public Object[] toArray() {
        return new Object[] {codeActivite.getAlias().toLowerCase(), idNiveau.getAlias().toLowerCase(), nombreDossier.getAlias().toLowerCase()};
    }

    @Override
    public List<TupleElement<?>> getElements() {
        return Arrays.asList(codeActivite, idNiveau, nombreDossier);
    }

    public Map getMapElements() {
        Map<String, TupleElement> mapTuple = new HashMap<>();
        mapTuple.put("codeActivite", codeActivite);
        mapTuple.put("idNiveau", idNiveau);
        mapTuple.put("nombreDossier", nombreDossier);
        return mapTuple;
    }

    private static class StringTupleElement implements TupleElement<String> {

        private final String value;

        private StringTupleElement(String value) {
            this.value = value;
        }

        @Override
        public Class<? extends String> getJavaType() {
            return String.class;
        }

        @Override
        public String getAlias() {
            return value;
        }
    }

    private static class LongTupleElement implements TupleElement<Long> {

        private final Long value;

        private LongTupleElement(Long value) {
            this.value = value;
        }

        @Override
        public Class<? extends Long> getJavaType() {
            return Long.class;
        }

        @Override
        public String getAlias() {
            return value.toString();
        }
    }

    private static class FloatTupleElement implements TupleElement<Float> {

        private final Float value;

        private FloatTupleElement(Float value) {
            this.value = value;
        }

        @Override
        public Class<? extends Float> getJavaType() {
            return Float.class;
        }

        @Override
        public String getAlias() {
            return value.toString();
        }
    }

}
