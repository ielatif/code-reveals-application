package com.socgen.eqc.infrastructure.gershwin.client;

import com.socgen.eqc.application.exception.TechnicalException;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.gershwin.model.AccessTokenErrorResponse;
import com.socgen.eqc.infrastructure.gershwin.model.AccessTokenResponse;
import com.socgen.eqc.infrastructure.gershwin.model.Approver;
import com.socgen.eqc.infrastructure.gershwin.model.ApproverDataListResponse;
import com.socgen.eqc.infrastructure.gershwin.model.UserDataCalendar;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.AdditionalAnswers.answer;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GershwinClientImplTests {

	@Mock(answer = Answers.RETURNS_DEEP_STUBS)
	private WebTarget ooormTarget;

	@Mock
	private ApplicationProperties.Gershwin gershwin;

	@InjectMocks
	GershwinClientImpl gershwinClient;

	private Invocation.Builder authorizationInvocationBuilder;
	private Invocation.Builder calendarInvocationBuilder;
	private Invocation.Builder ApproverInvocationBuilder;

	@BeforeEach
	void setup() {
		lenient().when(gershwin.getAuthorizationPath()).thenReturn("authorization-path");
		lenient().when(gershwin.getCalendarPath()).thenReturn("calendar-path");
		lenient().when(gershwin.getApproversPath()).thenReturn("approvers-path");

		authorizationInvocationBuilder = ooormTarget.path(gershwin.getAuthorizationPath())
				.request(MediaType.APPLICATION_JSON)
				.headers(any());

		calendarInvocationBuilder = ooormTarget.path(gershwin.getCalendarPath())
				.queryParam(any(), anyString())
				.queryParam(anyString(), anyString())
				.request(anyString())
				.headers(any())
				.header(anyString(), anyString())
				.header(anyString(), anyString())
				.header(anyString(), anyString())
				.accept(any(MediaType.class));

		ApproverInvocationBuilder = ooormTarget.path(gershwin.getApproversPath())
				.queryParam(any(), anyString())
				.queryParam(anyString(), anyBoolean())
				.request(anyString())
				.headers(any())
				.header(anyString(), anyString())
				.header(anyString(), anyString())
				.header(anyString(), anyString())
				.accept(any(MediaType.class));

		AccessTokenResponse accessTokenResponse = new AccessTokenResponse();
		accessTokenResponse.setAccessToken("access-token");
		Response authResponse = toInbound(Response.ok(accessTokenResponse).build());
		when(authorizationInvocationBuilder.post(any())).thenReturn(authResponse);
	}

	@Test
	void shouldThrowTechnicalExceptionWhenGettingAccessToken() {
		// Given
		AccessTokenErrorResponse accessTokenErrorResponse = new AccessTokenErrorResponse();
		accessTokenErrorResponse.setError("error");
		Response response = toInbound(Response.status(400).entity(accessTokenErrorResponse).build());
		when(authorizationInvocationBuilder.post(any())).thenReturn(response);

		// When
		Throwable thrown = catchThrowable(() -> { gershwinClient.getTeamCalendar("test", "test"); });

		// Then
		assertThat(thrown).isInstanceOf(TechnicalException.class);
	}

	@Test
	void shouldGetTeamCalendar() {
		// Given
		Response calendarResponse = toInbound(Response.ok(new UserDataCalendar()).build());
		when(calendarInvocationBuilder.get()).thenReturn(calendarResponse);

		// When
		Object response = gershwinClient.getTeamCalendar("test", "test");

		// Then
		assertThat(response).isInstanceOf(UserDataCalendar.class);
	}

	@Test
	void shouldThrowExceptionWhenGettingTeamCalendar() {
		// Given
		Response calendarResponse = toInbound(Response.status(400).build());
		when(calendarInvocationBuilder.get()).thenReturn(calendarResponse);

		// When
		Throwable thrown = catchThrowable(() -> { gershwinClient.getTeamCalendar("test", "test"); });

		// Then
		assertThat(thrown).isInstanceOf(ClientErrorException.class);
	}

	@Test
	void shouldHandleApproverNotFound() {
		// Given
		ApproverDataListResponse approverDataListResponse = new ApproverDataListResponse();
		approverDataListResponse.setData(new ArrayList<>());
		Response approverResponse = toInbound(Response.ok(approverDataListResponse).build());
		when(ApproverInvocationBuilder.get()).thenReturn(approverResponse);

		// When
		Optional<Approver> approver = gershwinClient.getApprover("test");

		// Then
		assertThat(approver).isNotPresent();
	}

	@Test
	void shouldGetApprover() {
		// Given
		ApproverDataListResponse approverDataListResponse = new ApproverDataListResponse();
		Approver approver = new Approver();
		approver.setId("GL000111");
		approverDataListResponse.setData(Collections.singletonList(approver));
		Response approverResponse = toInbound(Response.ok(approverDataListResponse).build());
		when(ApproverInvocationBuilder.get()).thenReturn(approverResponse);

		// When
		Optional<Approver> result = gershwinClient.getApprover("test");

		// Then
		assertThat(result).isPresent();
		assertThat(result.get().getId()).isEqualTo("GL000111");
	}

	@Test
	void shouldThrowExceptionWhenGettingApprover() {
		// Given
		Response approverResponse = toInbound(Response.status(400).build());
		when(ApproverInvocationBuilder.get()).thenReturn(approverResponse);

		// When
		Throwable thrown = catchThrowable(() -> { gershwinClient.getApprover("test"); });

		// Then
		assertThat(thrown).isInstanceOf(ClientErrorException.class);
	}

	// Hack : https://codingcraftsman.wordpress.com/2018/11/26/testing-and-mocking-jersey-responses/
	public static Response toInbound(Response asOutbound) {
		Response toReturn = spy(asOutbound);
		lenient().doAnswer(answer((Class type) -> readEntity(toReturn, type)))
				.when(toReturn)
				.readEntity(ArgumentMatchers.<Class>any());
		return toReturn;
	}

	private static <T> T readEntity(Response toReturn, Class type) {
		return (T) toReturn.getEntity();
	}

}