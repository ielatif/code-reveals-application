package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.mock.FakeAffectationService;
import com.socgen.eqc.application.mock.FakeAffiliationService;
import com.socgen.eqc.application.mock.FakeDomain;
import com.socgen.eqc.application.mock.FakeRenfortService;
import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.interfaces.rest.dto.IndicateurSearchDto;
import com.socgen.eqc.interfaces.rest.planning.dto.ContributorDto;
import com.socgen.eqc.interfaces.rest.planning.dto.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.planning.dto.ParametresCarteDTO;
import com.socgen.eqc.interfaces.rest.planning.dto.RenfortDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.MockitoAnnotations.initMocks;

class IndicateurUgServiceImplTest {

    private final FakeAffiliationService mockAffiliationService = new FakeAffiliationService();
    private final FakeRenfortService mockRenfortService = new FakeRenfortService();

    private IndicateurUgServiceImpl indicateurUgServiceImplUnderTest;

    @BeforeEach
    public void setUp() {
        List<Affectation> affectations = Stream.of("CRI1", "CRI2", "CRI3", "CRI4").map(this::createAffectation)
            .collect(Collectors.toList());
        FakeAffectationService mockAffectationService = new FakeAffectationService(affectations);
        initMocks(this);
        indicateurUgServiceImplUnderTest = new IndicateurUgServiceImpl(mockAffiliationService
            .getMock(), mockAffectationService.getMock(), mockRenfortService.getMock());
    }

    private Affectation createAffectation(String code) {
        Affectation affectation = FakeDomain.affectationSupplier.get();
        ActiviteParams activite = FakeDomain.activiteSupplier.get();
        activite.setCode(code);
        affectation.setActivite(activite);
        return affectation;
    }

    @Test
    void testComputeIndicateur() {
        // Setup
        // Run the test
        final IndicateurActiviteDto result = indicateurUgServiceImplUnderTest
            .computeIndicateur(IndicateurSearchDto.builder().build());

        ContributorDto expectedContributor = ContributorDto.builder()
                .loginWindows("X171001")
                .nom("snow").prenom("jon")
                .commentPrameteres(ParametresCarteDTO.builder().commentPrincipale("commentPrinc")
                        .commentSecondaire("commentSec").customStyle("Magenta").build())
                .renfort(null).pourcentContribution(10L).build();

        ContributorDto expectedContributorForRenfort = ContributorDto.builder()
                .loginWindows("X171001")
                .nom("snow").prenom("jon")
                .commentPrameteres(ParametresCarteDTO.builder().build())
                .renfort(RenfortDto.fromDomain(FakeDomain.renfortSupplier.get())).pourcentContribution(10L).build();
        // Verify the results
        assertEquals(5, result.getIndicateurs().size());
        assertEquals(Double.valueOf(10), result.getIndicateurs().get(0).getCapacite().doubleValue());
        assertEquals(Double.valueOf(0.1), result.getIndicateurs().get(0).getEtp().doubleValue());

        result.getIndicateurs().stream()
                .filter(indicateurDto -> List.of("CRI1", "CRI2", "CRI3", "CRI4").contains(indicateurDto.getCodeActivite()))
                .forEach(indicateurDto -> {
                    assertEquals(1, indicateurDto.getContributors().size());
                    assertEquals(expectedContributor, indicateurDto.getContributors().get(0));
                });

        result.getIndicateurs().stream()
                .filter(indicateurDto -> List.of("ACT-1").contains(indicateurDto.getCodeActivite()))
                .forEach(indicateurDto -> {
                    assertEquals(1, indicateurDto.getContributors().size());
                    assertEquals(expectedContributorForRenfort, indicateurDto.getContributors().get(0));
                });
    }
}
