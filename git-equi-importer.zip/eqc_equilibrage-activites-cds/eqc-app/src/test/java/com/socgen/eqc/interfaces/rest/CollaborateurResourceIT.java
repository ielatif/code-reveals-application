package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.infrastructure.persistance.CollaborateurRepository;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import java.util.List;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

class CollaborateurResourceIT extends AbstractIT {

    @Autowired
    private CollaborateurRepository collaborateurRepository;

    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/CollaborateurResourceIT/testRemove.sql"})
    void testRemove() {
        // Setup
        List<Collaborateur> allBeforeDelete = collaborateurRepository.findAll();
        Assert.assertEquals(2, allBeforeDelete.size());
        // Run the test
        int status = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when().queryParam("matricule", "Z017094")
                .delete("collaborateurs").statusCode();

        // Verify the results
        Assert.assertEquals(200, status);
        List<Collaborateur> allAfterDelete = collaborateurRepository.findAll();
        Assert.assertEquals(2, allAfterDelete.size());
    }

}
