package com.socgen.eqc.application.mock;

import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.impl.AffectationServiceImpl;
import com.socgen.eqc.domain.model.Affectation;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

public class FakeAffectationService {

    private final AffectationServiceImpl mock;
    private List<Affectation> affectations = new ArrayList<>();
    private List<Affectation> affectationsForRenfort = new ArrayList<>();


    public FakeAffectationService() {
        this.mock = Mockito.mock(AffectationServiceImpl.class);
        init();
    }

    public FakeAffectationService(List<Affectation> affectations) {
        this.affectations = affectations;
        this.mock = Mockito.mock(AffectationServiceImpl.class);
        init();
    }

    private void init() {
        affectationsForRenfort = List.of(FakeDomain.affectationForRenfortSupplier.get());
        affectations = affectations.isEmpty() ? List.of(FakeDomain.affectationSupplier.get()) : affectations;
        when(mock.findByAffiliationsAndDates(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(affectations);
        when(mock.findByRenfortsAndDates(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(affectationsForRenfort);
        when(mock.findByAffiliationsAndPlanningSearchDto(Mockito.any(), Mockito.any())).thenReturn(affectations);
    }

    public AffectationService getMock() {
        return mock;
    }
}
