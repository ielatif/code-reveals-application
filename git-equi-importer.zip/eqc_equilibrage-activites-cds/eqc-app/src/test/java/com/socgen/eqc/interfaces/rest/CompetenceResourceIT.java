package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.domain.model.Competence;
import com.socgen.eqc.infrastructure.persistance.CompetenceRepository;
import com.socgen.eqc.interfaces.rest.dto.ActiviteDto;
import com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.hamcrest.MatcherAssert.assertThat;

class CompetenceResourceIT extends AbstractIT {


    @Autowired
    private CompetenceRepository competenceRepository;

    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/CompetenceResourceIT/competence.sql"})
    @DisplayName("MAJ d'une expertise deja existante dans le profil")
    void should_update_profil_with_existing_expertise() {

        CompetenceDto competenceDto1 = CompetenceDto.builder()
                .id(1L)
                .codeActivite("CRI11").idNiveau(4L)
                .isUpdated(true).build();

        CompetenceDto competenceDto2 = CompetenceDto.builder()
                .codeActivite("CRI10").idNiveau(3L)
                .isUpdated(false).build();

        Response response = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .queryParam("matricule", "Z017094")
                .body(Arrays.asList(competenceDto1, competenceDto2))
                .put("competences");

        List<Competence> competences = competenceRepository.findAll();
        response.then().statusCode(HttpStatus.NO_CONTENT.value());
        assertThat(competences.size(), Matchers.equalTo(1));
        assertThat(competences.get(0).getId(), Matchers.equalTo(1L));
        assertThat(competences.get(0).getExpertise().getId(), Matchers.equalTo(5L));
        assertThat(competences.get(0).getCollaborateur().getMatricule(), Matchers.equalTo("Z017094"));
    }



    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/CompetenceResourceIT/competence.sql"})
    @DisplayName("Récuperation des compétences")
    void should_get_competences() {

        CompetenceDto[] competencesArray = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .queryParam("matricule", "Z017094")
                .queryParam("codeStRattachement", 3000324057L)
                .get("competences")
                .as(CompetenceDto[].class);
        List<CompetenceDto> competences = Arrays.asList(competencesArray);
        ActiviteDto activiteDto = new ActiviteDto();
        activiteDto.setCode("CRI11");

        assertThat(competences.size(), Matchers.equalTo(2));

        Assertions.assertThat(competences)
                .flatExtracting(CompetenceDto::getCodeActivite)
                .contains("CRI11", "CRI10");

        Assertions.assertThat(competences)
                .flatExtracting(CompetenceDto -> CompetenceDto.getMapNombreDossiers()
                        .values().stream().collect(Collectors.toList()))
                .contains(50F, 40F);
    }

    @Test
    @Sql({"/db/clean-db.sql","/db/interfaces/rest/CompetenceResourceIT/competence.sql"})
    @DisplayName("Récuperation des compétences par service de traitement")
    void should_get_competences_by_Service_taitement() {

        com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto [] competencesTab = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .get("competences/services-traitements/3000324057")
                .as(com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto[].class);


        List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> competences = Arrays.asList(competencesTab);

        assertThat(competences.size(), Matchers.equalTo(4));

        Assertions.assertThat(competences.stream()
                .filter(competenceDto -> competenceDto.getMatricule().equals("Z017094"))
                .map(competenceDto -> competenceDto.getCodeActivite()).collect(Collectors.toList())).isEqualTo(Arrays.asList("CRI11", "CRI10"));

        Assertions.assertThat(competences.stream()
                .filter(competenceDto -> competenceDto.getMatricule().equals("Z017096")).collect(Collectors.toList()))
                .flatExtracting(com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto::getCodeActivite)
                .contains("CRI11", "CRI10");



    }


}
