package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPlanningCollabDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@ExtendWith({MockitoExtension.class})
class ExtractPlanningCollabRepositoryTest {
    @InjectMocks
    private ExtractPlanningCollabRepository extractPlanningCollabRepository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private NamedParameterJdbcTemplate namedJdbcTemplate;


    @Mock
    ResultSet inputRs;

    @Captor
    private ArgumentCaptor<List<Absence>> listArgumentCaptor;

    @Test
    void should_test_row_map() throws SQLException {

        ExtractPlanningCollabRepository.ExtractPlanningCollabRowMapper extractPlanningCollabRowMapper = new ExtractPlanningCollabRepository.ExtractPlanningCollabRowMapper();
        // Run the test
        int rowNum = 1;

        when(inputRs.getString("codeFiliere")).thenReturn("codeFiliere1");
        when(inputRs.getString("filiere")).thenReturn("filiere1");
        when(inputRs.getString("codeUg")).thenReturn("codeUg1");
        when(inputRs.getString("ug")).thenReturn("ug1");
        when(inputRs.getString("codeSt")).thenReturn("codeSt1");
        when(inputRs.getString("st")).thenReturn("st1");
        when(inputRs.getString("matricule")).thenReturn("matricule1");
        when(inputRs.getString("nomCollaborateur")).thenReturn("nomCollaborateur1");
        when(inputRs.getString("sousEquipe")).thenReturn("sousEquipe1");
        when(inputRs.getString("dateAffectation")).thenReturn("2022-01-01");
        when(inputRs.getString("familleCode")).thenReturn("familleCode1");
        when(inputRs.getString("famille")).thenReturn("famille1");
        when(inputRs.getString("activiteCode")).thenReturn("activiteCode1");
        when(inputRs.getString("activite")).thenReturn("activite1");
        when(inputRs.getBigDecimal("etp")).thenReturn(new BigDecimal("1"));
        when(inputRs.getString("CommentairePrincipal")).thenReturn("comment");
        when(inputRs.getString("renfort")).thenReturn("renfort1");
        when(inputRs.getString("codeFiliereAidante")).thenReturn("codeFiliereAidante1");
        when(inputRs.getString("filiereAidante")).thenReturn("filiereAidante1");
        when(inputRs.getString("codeUgAidante")).thenReturn("codeUgAidante1");
        when(inputRs.getString("ugAidante")).thenReturn("ugAidante1");
        when(inputRs.getString("codeStAidant")).thenReturn("codeStAidant1");
        when(inputRs.getString("stAidant")).thenReturn("stAidant1");
        when(inputRs.getString("codeFiliereAidee")).thenReturn("codeFiliereAidee1");
        when(inputRs.getString("filiereAidee")).thenReturn("filiereAidee1");
        when(inputRs.getString("codeUgAidee")).thenReturn("codeUgAidee1");
        when(inputRs.getString("ugAidee")).thenReturn("ugAidee1");
        when(inputRs.getString("codeStAide")).thenReturn("codeStAide1");
        when(inputRs.getString("stAide")).thenReturn("stAide1");

        ExtractPlanningCollabDto result = extractPlanningCollabRowMapper.mapRow(inputRs, rowNum);

        ExtractPlanningCollabDto expectedDto = ExtractPlanningCollabDto.builder()
                .codeFiliere("codeFiliere1")
                .filiere("filiere1")
                .codeUg("codeUg1")
                .ug("ug1")
                .codeSt("codeSt1")
                .st("st1")
                .matricule("matricule1")
                .nomCollaborateur("nomCollaborateur1")
                .sousEquipe("sousEquipe1")
                .dateAffectation("2022-01-01")
                .familleCode("familleCode1")
                .famille("famille1")
                .activiteCode("activiteCode1")
                .activite("activite1")
                .etp(BigDecimal.ONE.setScale(2, RoundingMode.HALF_UP).toString())
                .commentairePrincipal("comment")
                .renfort("renfort1")
                .codeFiliereAidante("codeFiliereAidante1")
                .filiereAidante("filiereAidante1")
                .codeUgAidante("codeUgAidante1")
                .ugAidante("ugAidante1")
                .codeStAidant("codeStAidant1")
                .stAidant("stAidant1")
                .codeFiliereAidee("codeFiliereAidee1")
                .filiereAidee("filiereAidee1")
                .codeUgAidee("codeUgAidee1")
                .ugAidee("ugAidee1")
                .codeStAide("codeStAide1")
                .stAide("stAide1")
                .build();

        // Verify the results
        assertEquals(result, expectedDto);
    }

    @Test
    void should_call_jsdb_template_when_find_planning_collab_is_called() {

        extractPlanningCollabRepository.findPlanningCollab(List.of("3000324059"),LocalDate.parse("2022-01-01", DateTimeFormatter.ISO_DATE),
                LocalDate.parse("2022-01-08", DateTimeFormatter.ISO_DATE));

        verify(namedJdbcTemplate, Mockito.atMostOnce()).query(Mockito.any(String.class), Mockito.any(SqlParameterSource.class), Mockito.any(ExtractPlanningCollabRepository.ExtractPlanningCollabRowMapper.class));
    }
}
