package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleInputDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class SaisieGlobaleServiceImplTest {



    @InjectMocks
    private SaisieGlobaleServiceImpl saisieGlobaleService;

    @Mock
    private SmboClient smboClient;


    @Test
    void should_get_indicateurs_saisie_globale() {


        List<Long> tetePerimetres = Arrays.asList(30003000L, 30003001L);
        String codeSt = "3000";

        SgUserPrincipal sgUserPrincipalMock = new SgUserPrincipal("{\"userId\": \"X178253\"," +
                "\"firstName\": \"AAAA\"," +
                "\"lastName\": \"BBBB\"," +
                " \"roles\": {\"EQC\": []}}");

        saisieGlobaleService.getIndicateurs(tetePerimetres, codeSt, sgUserPrincipalMock);

        verify(smboClient, Mockito.atMostOnce()).getSaisieGlobaleIndicateurs(tetePerimetres, codeSt, sgUserPrincipalMock.getCurrentUser().getUserId());
    }

    @Test
    void should_add_stock_saisie_globale() {


        SaisieGlobaleInputDto saisieGlobaleInputDto = SaisieGlobaleInputDto.builder()
                .processusId(1L)
                .matricule("X178178")
                .stockRecus(2L)
                .stockTermines(3L)
                .codeST("3000").build();

        saisieGlobaleService.addStock(saisieGlobaleInputDto);

        verify(smboClient, Mockito.atMostOnce()).addStockSaisieGlobale(saisieGlobaleInputDto);
    }
}
