package com.socgen.eqc.interfaces.rest.converters;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LocalDateConverterTest {

    private LocalDateConverter localDateConverterUnderTest;

    @BeforeEach
    public void setUp() {
        localDateConverterUnderTest = new LocalDateConverter();
    }

    @Test
    void testFromString() {
        // Setup
        final String s = "2016-08-16";
        final LocalDate expectedResult = LocalDate.of(2016, 8, 16);

        // Run the test
        final LocalDate result = localDateConverterUnderTest.fromString(s);

        // Verify the results
        assertEquals(expectedResult, result);
    }

}
