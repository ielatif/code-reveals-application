package com.socgen.eqc.interfaces.rest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ContextConfiguration;

import static io.restassured.RestAssured.given;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@ContextConfiguration
class CacheResourceTest extends AbstractIT {

    @Test
    void should_clear_cache() {
        // Run the test
        int status = given()
                .header("Authorization", setCustomUserWithRoles("GERER_PLANNING"))
                .header("x-ibm-client-id", CLIENT_ID_DE_BASE)
                .accept(APPLICATION_JSON).contentType(APPLICATION_JSON).when()
                .delete("cache/ResCache").statusCode();

        // Verify the results
        Assertions.assertEquals(204, status);
    }
}
