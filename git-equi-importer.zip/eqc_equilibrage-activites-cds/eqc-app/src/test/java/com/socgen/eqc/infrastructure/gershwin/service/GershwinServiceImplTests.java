package com.socgen.eqc.infrastructure.gershwin.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Intervalle;
import com.socgen.eqc.infrastructure.gershwin.client.GershwinClient;
import com.socgen.eqc.infrastructure.gershwin.model.Approver;
import com.socgen.eqc.infrastructure.gershwin.model.UserDataCalendar;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GershwinServiceImplTests {

	@Mock
	private EquipeService mockEquipeService;

	@Mock
	private GershwinClient mockGershwinClient;

	@InjectMocks
	private GershwinServiceImpl gershwinServiceImpl;

	@Test
	void shouldGetAbsenceWhenManagerNotInTeam() {
		// Given
		Long idEquipe = 3003556677L;
		List<Collaborateur> collaborateurs = Arrays.asList(Collaborateur.builder().matricule("X1393933").idRhLocal("GL001393933").build(),
				Collaborateur.builder().matricule("X1393934").idRhLocal("GL001393934").build());
		Collaborateur manager1 = Collaborateur.builder().idRhLocal("GL000063461").matricule("X001111").build();
		Collaborateur manager2 = Collaborateur.builder().idRhLocal("GL000063462").matricule("X002222").build();
		Set<String> managers = new HashSet<>(Arrays.asList("GL000063461", "GL000063462"));
		LocalDate dateDebut = LocalDate.parse("2020-09-28");
		LocalDate dateFin = LocalDate.parse("2020-10-02");

		when(mockEquipeService.findManagersIdRh(idEquipe)).thenReturn(managers);
		UserDataCalendar absencesSeptembreManager1 = getUserDataCalendar("gershwin/manager-gl000063461-absences-09.json");
		UserDataCalendar absencesOctobreManager1 = getUserDataCalendar("gershwin/manager-gl000063461-absences-10.json");
		UserDataCalendar absencesSeptembreManager2 = getUserDataCalendar("gershwin/manager-gl000063462-absences-09.json");
		UserDataCalendar absencesOctobreManager2 = getUserDataCalendar("gershwin/manager-gl000063462-absences-10.json");
		when(mockGershwinClient.getTeamCalendar(manager1.getIdRhLocal(), "2020-09")).thenReturn(absencesSeptembreManager1);
		when(mockGershwinClient.getTeamCalendar(manager1.getIdRhLocal(), "2020-10")).thenReturn(absencesOctobreManager1);
		when(mockGershwinClient.getTeamCalendar(manager2.getIdRhLocal(), "2020-09")).thenReturn(absencesSeptembreManager2);
		when(mockGershwinClient.getTeamCalendar(manager2.getIdRhLocal(), "2020-10")).thenReturn(absencesOctobreManager2);

		// When
		List<Absence> absences = gershwinServiceImpl.findAbsence(idEquipe, collaborateurs, dateDebut, dateFin);

		// Then
		assertThat(absences).hasSize(6);

		assertThat(absences.get(0).getDate()).isEqualTo(LocalDate.parse("2020-09-28"));
		assertThat(absences.get(0).getIntervalle()).isEqualTo(Intervalle.MATIN);
		assertThat(absences.get(1).getDate()).isEqualTo(LocalDate.parse("2020-09-30"));
		assertThat(absences.get(1).getIntervalle()).isEqualTo(Intervalle.APRES_MIDI);
		assertThat(absences.get(2).getDate()).isEqualTo(LocalDate.parse("2020-10-01"));
		assertThat(absences.get(2).getIntervalle()).isEqualTo(Intervalle.TOUTE_JOURNEE);

		assertThat(absences.get(3).getDate()).isEqualTo(LocalDate.parse("2020-09-28"));
		assertThat(absences.get(3).getIntervalle()).isEqualTo(Intervalle.MATIN);
		assertThat(absences.get(4).getDate()).isEqualTo(LocalDate.parse("2020-09-30"));
		assertThat(absences.get(4).getIntervalle()).isEqualTo(Intervalle.APRES_MIDI);
		assertThat(absences.get(5).getDate()).isEqualTo(LocalDate.parse("2020-10-01"));
		assertThat(absences.get(5).getIntervalle()).isEqualTo(Intervalle.TOUTE_JOURNEE);
	}

	@Test
	void shouldGetManagerAbsenceWhenManagerInTeam() {
		Long idEquipe = 3003556677L;
		Collaborateur manager = Collaborateur.builder().idRhLocal("GL000063461").matricule("X001111").build();
		List<Collaborateur> collaborateurs = Arrays.asList(
				Collaborateur.builder().matricule("X1393933").idRhLocal("GL001393933").build(),
				manager);
		LocalDate dateDebut = LocalDate.parse("2020-09-28");
		LocalDate dateFin = LocalDate.parse("2020-10-02");
		Approver approver = new Approver();
		approver.setId("GL000063471");

		when(mockEquipeService.findManagersIdRh(idEquipe)).thenReturn(new HashSet<>(Arrays.asList("GL000063461")));
		UserDataCalendar absencesSeptembre = getUserDataCalendar("gershwin/manager-gl000063461-absences-09.json");
		UserDataCalendar absencesOctobre = getUserDataCalendar("gershwin/manager-gl000063461-absences-10.json");
		UserDataCalendar absencesManagerSeptembre = getUserDataCalendar("gershwin/absences-manager-09.json");
		UserDataCalendar absencesManagerOctobre = getUserDataCalendar("gershwin/absences-manager-10.json");
		when(mockGershwinClient.getTeamCalendar(manager.getIdRhLocal(), "2020-09")).thenReturn(absencesSeptembre);
		when(mockGershwinClient.getTeamCalendar(manager.getIdRhLocal(), "2020-10")).thenReturn(absencesOctobre);
		when(mockGershwinClient.getApprover(manager.getIdRhLocal())).thenReturn(Optional.of(approver));
		when(mockGershwinClient.getTeamCalendar(approver.getId(), "2020-09")).thenReturn(absencesManagerSeptembre);
		when(mockGershwinClient.getTeamCalendar(approver.getId(), "2020-10")).thenReturn(absencesManagerOctobre);

		List<Absence> absences = gershwinServiceImpl.findAbsence(idEquipe, collaborateurs, dateDebut, dateFin);

		assertThat(absences).hasSize(5);
		assertThat(absences.get(0).getDate()).isEqualTo(LocalDate.parse("2020-09-28"));
		assertThat(absences.get(0).getIntervalle()).isEqualTo(Intervalle.MATIN);
		assertThat(absences.get(1).getDate()).isEqualTo(LocalDate.parse("2020-09-30"));
		assertThat(absences.get(1).getIntervalle()).isEqualTo(Intervalle.APRES_MIDI);
		assertThat(absences.get(2).getDate()).isEqualTo(LocalDate.parse("2020-10-01"));
		assertThat(absences.get(2).getIntervalle()).isEqualTo(Intervalle.TOUTE_JOURNEE);
		assertThat(absences.get(3).getDate()).isEqualTo(LocalDate.parse("2020-09-28"));
		assertThat(absences.get(3).getIntervalle()).isEqualTo(Intervalle.MATIN);
		assertThat(absences.get(4).getDate()).isEqualTo(LocalDate.parse("2020-10-02"));
		assertThat(absences.get(4).getIntervalle()).isEqualTo(Intervalle.TOUTE_JOURNEE);
	}

	@Test
	void shouldBeEmptyWhenExceptionThrown() {
		Long idEquipe = 3003556677L;
		List<Collaborateur> collaborateurs = Arrays.asList(Collaborateur.builder().matricule("X1393933").idRhLocal("GL001393933").build());
		Collaborateur manager = Collaborateur.builder().idRhLocal("GL000063461").matricule("X001111").build();
		LocalDate dateDebut = LocalDate.parse("2020-09-28");
		LocalDate dateFin = LocalDate.parse("2020-10-02");

		when(mockEquipeService.findManagersIdRh(idEquipe)).thenReturn(new HashSet<>(Arrays.asList("GL000063461")));
		when(mockGershwinClient.getTeamCalendar(any(), any())).thenThrow(new RuntimeException());

		List<Absence> absences = gershwinServiceImpl.findAbsence(idEquipe, collaborateurs, dateDebut, dateFin);

		assertThat(absences).isEmpty();
	}

	private UserDataCalendar getUserDataCalendar(String path) {
		try {
			InputStream resource = getClass().getClassLoader().getResourceAsStream(path);
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.findAndRegisterModules();
			mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			return  mapper.readValue(resource, UserDataCalendar.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
