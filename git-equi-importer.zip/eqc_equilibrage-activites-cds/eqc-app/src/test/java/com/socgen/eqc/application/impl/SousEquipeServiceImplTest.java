

package com.socgen.eqc.application.impl;

import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.domain.model.SousEquipe;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import com.socgen.eqc.infrastructure.persistance.AffiliationSousEquipeRepository;
import com.socgen.eqc.infrastructure.persistance.EquipeRepository;
import com.socgen.eqc.infrastructure.persistance.SousEquipeRepository;
import com.socgen.eqc.interfaces.rest.dto.SousEquipeDto;
import com.socgen.eqc.mapper.AffiliationSousEquipeMapper;
import com.socgen.eqc.mapper.SousEquipeMapperImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class SousEquipeServiceImplTest {

    @Mock
    private SousEquipeRepository mockSousEquipeRepository;
    @Mock
    private EquipeRepository mockEquipeRepository;
    @Mock
    private AffiliationSousEquipeRepository mockAffiliationSousEquipeRepository;
    @Mock
    private AffiliationRepository mockAffiliationRepository;
    @Mock
    private AffiliationSousEquipeMapper mockAffiliationSousEquipeMapper;

    @Spy
    private SousEquipeMapperImpl mockSousEquipeMapper;

    private SousEquipeServiceImpl sousEquipeServiceImplUnderTest;

    @BeforeEach
    void setUp() throws Exception {
        sousEquipeServiceImplUnderTest = new SousEquipeServiceImpl(mockSousEquipeRepository, mockEquipeRepository, mockSousEquipeMapper, mockAffiliationSousEquipeRepository, mockAffiliationRepository, mockAffiliationSousEquipeMapper);
    }

    @Test
    void testGetByCodeEquipe() {
        // Setup
        SousEquipe sousEquipe = SousEquipe.builder()
                .equipe(Equipe.builder().code(125L).build())
                .build();
        Mockito.when(mockSousEquipeRepository.findByEquipeCode(Mockito.anyLong())).thenReturn(Collections.singletonList(sousEquipe));
        // Run the test
        List<SousEquipeDto> result = sousEquipeServiceImplUnderTest.getByCodeEquipe(123L);
        // Verify the results
        assertThat(result.isEmpty()).isFalse();
    }

    @Test
    void testCreate() {
        // Setup
        Equipe equipe = Equipe.builder().code(125L).build();
        SousEquipe sousEquipe = SousEquipe.builder()
                .equipe(equipe)
                .build();
        Mockito.when(mockEquipeRepository.findById(125L)).thenReturn(Optional.of(equipe));
        Mockito.when(mockSousEquipeRepository.save(Mockito.any())).thenReturn(sousEquipe);
        // Run the test
        SousEquipeDto result = sousEquipeServiceImplUnderTest.create(SousEquipeDto.builder().equipeId(125L).build());
        // Verify the results
        assertThat(result.getEquipeId()).isEqualTo(125L);
    }

    @Test
    void testUpdate() {
        // Setup
        Equipe equipe = Equipe.builder().code(125L).build();
        SousEquipe sousEquipe = SousEquipe.builder()
                .equipe(equipe)
                .build();
        Mockito.when(mockSousEquipeRepository.findById(Mockito.any())).thenReturn(Optional.of(sousEquipe));
        Mockito.when(mockSousEquipeRepository.save(Mockito.any())).thenReturn(sousEquipe);
        // Run the test
        SousEquipeDto result = sousEquipeServiceImplUnderTest.update(SousEquipeDto.builder().libelle("libelle_test").equipeId(125L).build());
        // Verify the results
        assertThat(result.getLibelle()).isEqualTo("libelle_test");
    }

    @Test
    void testDelete() {
        // Setup
        // Run the test
        sousEquipeServiceImplUnderTest.delete(125L);
        // Verify the results
        Mockito.verify(mockSousEquipeRepository, Mockito.times(1)).deleteById(125L);
    }

    @Test
    void testDeleteAll() {
        // Setup
        List<Long> ids = Arrays.asList(125L, 126L);
        // Run the test
        sousEquipeServiceImplUnderTest.delete(ids);
        // Verify the results
        Mockito.verify(mockSousEquipeRepository, Mockito.times(1)).deleteAllById(ids);
    }
}

