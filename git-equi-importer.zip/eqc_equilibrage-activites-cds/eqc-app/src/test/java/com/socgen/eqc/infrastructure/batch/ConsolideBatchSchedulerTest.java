package com.socgen.eqc.infrastructure.batch;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.launch.JobLauncher;

import java.time.LocalDate;

@ExtendWith(MockitoExtension.class)
class ConsolideBatchSchedulerTest {

    @Mock
    private JobLauncher mockJobLauncher;
    @Mock
    private Job mockCmBatchJob;

    private ConsolideBatchScheduler consolideBatchSchedulerUnderTest;

    @BeforeEach
    void setUp() {
        consolideBatchSchedulerUnderTest = new ConsolideBatchScheduler(mockJobLauncher, mockCmBatchJob);
    }

    @ParameterizedTest
    @ValueSource(strings = {"2020-10-05", "2020-10-08", "2020-10-11"})
    @DisplayName("devrait lancer le batch 2 fois")
    void should_launch_batch_2(LocalDate date) throws JobExecutionException {

        Mockito.when(mockJobLauncher.run(Mockito.any(), Mockito.any())).thenReturn(new JobExecution(1L));
        try (MockedStatic<LocalDate> theMock = Mockito.mockStatic(LocalDate.class, Mockito.CALLS_REAL_METHODS)) {
            theMock.when(LocalDate::now).thenReturn(date);
            // Run the test
            Assert.assertEquals(date, LocalDate.now());
            consolideBatchSchedulerUnderTest.schedule();

            // Verify the results
            Mockito.verify(mockJobLauncher, Mockito.times(2)).run(Mockito.any(), Mockito.any());
        }
    }

    @ParameterizedTest
    @ValueSource(strings = {"2020-10-26", "2020-10-19", "2020-10-12"})
    @DisplayName("devrait lancer le batch 1 fois")
    void should_launch_batch_1(LocalDate date) throws JobExecutionException {

        Mockito.when(mockJobLauncher.run(Mockito.any(), Mockito.any())).thenReturn(new JobExecution(1L));
        try (MockedStatic<LocalDate> theMock = Mockito.mockStatic(LocalDate.class, Mockito.CALLS_REAL_METHODS)) {
            theMock.when(LocalDate::now).thenReturn(date);
            // Run the test
            Assert.assertEquals(date, LocalDate.now());
            consolideBatchSchedulerUnderTest.schedule();

            // Verify the results
            Mockito.verify(mockJobLauncher, Mockito.times(1)).run(Mockito.any(), Mockito.any());
        }
    }

}
