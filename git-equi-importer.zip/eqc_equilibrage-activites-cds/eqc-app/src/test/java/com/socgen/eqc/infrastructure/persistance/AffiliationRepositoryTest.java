package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AffiliationRepositoryTest extends AbstractDataJpaTest {

    @Autowired
    private AffiliationRepository affiliationRepositoryUnderTest;

    @Test
    @Sql({"/db/infrastructure/persistance/AffiliationRepositoryTest/affiliationRepositoryTest.sql"})
    void testFindByEquipeAndDates() {
        // Setup
        final Long equipeId = 1L;
        LocalDate dateDebut = LocalDate.of(2017, 4, 1);
        LocalDate dateFin = LocalDate.of(2018, 5, 1);

        // Run the test
        final List<Affiliation> result = affiliationRepositoryUnderTest
            .findByEquipeIdAndDates(equipeId, dateDebut, dateFin);
        List<String> matriculeList = result.stream().map(Affiliation::getCollaborateur).map(Collaborateur::getMatricule)
            .collect(Collectors.toList());
        // Verify the results
        assertEquals(2, result.size());
        assertTrue(matriculeList.containsAll(Arrays.asList("A1", "A2")));
    }

    @Test
    @Sql({"/db/infrastructure/persistance/AffiliationRepositoryTest/affiliationRepositoryTest.sql"})
    void testFindByEquipeAndDate() {
        // Setup
        final Long equipeId = 1L;
        LocalDate date = LocalDate.of(2019, 4, 1);
        // Run the test
        final List<Affiliation> result = affiliationRepositoryUnderTest.findByEquipeIdAndDate(equipeId, date);
        List<String> matriculeList = result.stream().map(Affiliation::getCollaborateur).map(Collaborateur::getMatricule)
            .collect(Collectors.toList());
        // Verify the results
        assertEquals(1, result.size());
        assertEquals("A1", matriculeList.get(0));
    }

    @Test
    @Sql({"/db/infrastructure/persistance/AffiliationRepositoryTest/affiliationRepositoryTest.sql"})
    void testFindLastByMatricule() {
        // Setup
        String matricule = "A1";
        // Run the test
        List<Affiliation> all = affiliationRepositoryUnderTest.findAll();
        Affiliation lastByMatricule = affiliationRepositoryUnderTest.findActiveByMatricule(matricule);
        // Verify the results
        List<Affiliation> affiliationsA1 = all.stream()
            .filter(affiliation -> affiliation.getCollaborateur().getMatricule().equalsIgnoreCase("A1"))
            .collect(Collectors.toList());
        assertEquals(2, affiliationsA1.size());
        assertNull(lastByMatricule.getDateSortie());
        assertEquals("A1", lastByMatricule.getCollaborateur().getMatricule());
    }


    @Test
    @Sql({"/db/infrastructure/persistance/AffiliationRepositoryTest/testFindByMatriculeAndDates.sql"})
    void testFindByMatriculeAndDates() {
        List<Affiliation>  affiliation = affiliationRepositoryUnderTest
            .findByMatriculeAndDate("Z017094", LocalDate.of(2020, 10, 9), LocalDate.of(2020, 10, 10));
        assertEquals(87L, affiliation.get(0).getId().longValue());

    }
}
