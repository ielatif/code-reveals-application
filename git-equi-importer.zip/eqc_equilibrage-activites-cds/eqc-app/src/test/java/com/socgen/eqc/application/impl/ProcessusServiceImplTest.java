package com.socgen.eqc.application.impl;

import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.RefProcessusInputDto;
import com.socgen.eqc.infrastructure.smbo.dto.Source;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ProcessusServiceImplTest {

    @InjectMocks
    private ProcessusServiceImpl processusService;

    @Mock
    private SmboClient smboClient;
    
    @Captor
    private ArgumentCaptor<RefProcessusInputDto> captureReferentielProcessus;
    @Test
    void should_create_processus() {

        RefProcessusInputDto refProcessusInputDto = RefProcessusInputDto.builder()
                .codeTetePerimetre("30003001")
                .libelle("Test creation processus")
                .source(Source.SAISIE_GLOBALE)
                .build();

        processusService.saveOrUpdateProcessus(refProcessusInputDto);

        RefProcessusInputDto expectedCapturedProcessus = RefProcessusInputDto.builder()
                .libelle(refProcessusInputDto.getLibelle())
                .codeTetePerimetre("30003001")
                .source(refProcessusInputDto.getSource())
                .build();


        verify(smboClient, Mockito.atMostOnce()).saveOrUpdateProcessus(captureReferentielProcessus.capture());
        RefProcessusInputDto processusCaptured = captureReferentielProcessus.getValue();

        assertEquals(processusCaptured, expectedCapturedProcessus);
    }
}
