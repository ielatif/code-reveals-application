package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.infrastructure.people.client.PeopleClient;
import com.socgen.eqc.infrastructure.people.dto.ListPeopleDto;
import com.socgen.eqc.infrastructure.people.dto.PeopleDto;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import com.socgen.eqc.infrastructure.persistance.EquipeRepository;
import com.socgen.eqc.mapper.EquipeMapper;
import com.socgen.eqc.mapper.EquipeMapperImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

@ExtendWith(MockitoExtension.class)
class EquipeServiceImplTest {

	@Mock
	private AffiliationRepository affiliationRepository;

	@Mock
	private EquipeRepository equipeRepository;

	@Mock
	private PeopleClient peopleClient;

	private EquipeService equipeService;

	@Spy
	private EquipeMapper equipeMapper = new EquipeMapperImpl();

	@Captor
	private ArgumentCaptor<Equipe> captureEquipe;

	@BeforeEach
	void setUp() {
		equipeService = new EquipeServiceImpl(affiliationRepository, equipeRepository, peopleClient, equipeMapper);
	}

	@Test
	void shouldFindManagers() {

		// Given
		PeopleDto collaborateur = new PeopleDto();
		collaborateur.setCodeEmploi("1000");
		collaborateur.setIdRhLocal("GL00111111");
		collaborateur.setIdCnxRtfe("X111111");
		PeopleDto manager1 = new PeopleDto();
		manager1.setCodeEmploi("1123");
		manager1.setIdRhLocal("GL00222222");
		manager1.setIdCnxRtfe("X222222");
		PeopleDto manager2 = new PeopleDto();
		manager2.setCodeEmploi("1123");
		manager2.setIdRhLocal("GL00333333");
		manager2.setIdCnxRtfe("X333333");

		ListPeopleDto peopleDtos = new ListPeopleDto();
		peopleDtos.setDatas(Arrays.asList(collaborateur, manager1, manager2));

		Mockito.when(peopleClient.findPeopleByListCodeSt(Collections.singletonList(3003556677L))).thenReturn(peopleDtos);

		// When
		Set<String> managers = equipeService.findManagersIdRh(3003556677L);

		// Then
		assertThat(managers).hasSize(2);
	}

	@Test
	void shouldThrowExceptionWhenManagerNotFound() {

		// given
		PeopleDto collaborateur = new PeopleDto();
		collaborateur.setCodeEmploi("1000");
		collaborateur.setIdRhLocal("GL00111111");
		collaborateur.setIdCnxRtfe("X111111");

		ListPeopleDto peopleDtos = new ListPeopleDto();
		peopleDtos.setDatas(Arrays.asList(collaborateur));

		Mockito.when(peopleClient.findPeopleByListCodeSt(Collections.singletonList(3003556677L))).thenReturn(peopleDtos);

		// when
		Throwable thrown = catchThrowable(() -> {
			equipeService.findManagersIdRh(3003556677L);
		});

		// then
		assertThat(thrown)
				.isInstanceOf(BusinessException.class)
				.hasMessageContaining("Le responsable de l'équipe");
	}

	@Test
	void shouldSave(){
		Equipe equipe = Equipe.builder().code(3000324051L).codeUg(3000324056L)
				.codeCds(3000324057L).formatSemainier((byte)5).build();
		equipeService.save(equipe);
		Mockito.lenient().when(equipeService.save(Mockito.any())).thenReturn(equipe);
		verify(equipeRepository, Mockito.atMostOnce()).save(captureEquipe.capture());
		Equipe equipeValue = captureEquipe.getValue();
		assertEquals(equipe.getFormatSemainier(), equipeValue.getFormatSemainier());

	}
}