package com.socgen.eqc.infrastructure.batch.utils;

import lombok.experimental.UtilityClass;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@UtilityClass
public class UtilsDay {

    public static String getMonthYearTwoDigitFormat(LocalDate date) {
        NumberFormat numberFormat = new DecimalFormat("00");
        return numberFormat.format(date.getMonthValue()).concat("-").concat(String.valueOf(date.getYear()));
    }

    public static List<LocalDate> getDatesBetweenTwoDate(
            LocalDate startDate, LocalDate endDate) {

        long numOfDaysBetween = ChronoUnit.DAYS.between(startDate, endDate);
        return IntStream.iterate(0, i -> i + 1)
                .limit(numOfDaysBetween)
                .mapToObj(startDate::plusDays)
                .collect(Collectors.toList());
    }
}
