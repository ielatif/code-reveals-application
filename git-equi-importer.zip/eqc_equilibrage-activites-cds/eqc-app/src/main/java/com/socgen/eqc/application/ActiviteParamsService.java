package com.socgen.eqc.application;

import com.socgen.eqc.interfaces.rest.dto.ActiviteOrdreDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteParamsDto;

import java.util.List;

public interface ActiviteParamsService {

    List<ActiviteParamsDto> findAll();

    ActiviteParamsDto create(ActiviteParamsDto activiteParamsDto);

    ActiviteParamsDto update(ActiviteParamsDto activiteParamsDto);

    void updateOrdreActivites(List<ActiviteOrdreDto> activiteOrdreDtos);

}
