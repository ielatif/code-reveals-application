package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.socgen.eqc.infrastructure.smbo.dto.RefActiviteDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ActiviteDto implements Serializable {

    private RefActiviteDto refActiviteDto;
    private ActiviteParamsDto activiteParamsDto;

}
