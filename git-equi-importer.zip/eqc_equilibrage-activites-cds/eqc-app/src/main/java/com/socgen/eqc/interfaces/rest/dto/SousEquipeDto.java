package com.socgen.eqc.interfaces.rest.dto;


import lombok.*;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SousEquipeDto {

    private Long id;
    @NotBlank
    private String libelle;
    private String description;
    @NonNull
    private Long equipeId;
}
