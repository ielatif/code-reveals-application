package com.socgen.eqc.application;


import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteDto;

import java.util.List;


public interface ActiviteService {



    List<ActiviteParams> findByIdIn(List<String> activiteCodes);

    ActiviteDto update(ActiviteDto activiteInputDto);

    ActiviteDto create(ActiviteDto activiteInputDto);


}
