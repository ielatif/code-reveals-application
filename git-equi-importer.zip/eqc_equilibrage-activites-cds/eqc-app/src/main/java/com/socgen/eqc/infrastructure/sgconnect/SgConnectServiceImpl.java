package com.socgen.eqc.infrastructure.sgconnect;

import com.socgen.eqc.config.ApplicationProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;

@RequiredArgsConstructor
@Service
public class SgConnectServiceImpl implements SgConnectService {

    private final Client sgConnect;
    private final ApplicationProperties applicationProperties;
    public static final String SCOPE = "scope";

    @Override
    public Response getBasicAuthentication() {
        return getInvocationBuilder().get();
    }

    private Invocation.Builder getInvocationBuilder() {
        URI path = UriBuilder.fromPath(applicationProperties.getSgConnect().getServerUrl())
                .queryParam(SCOPE, applicationProperties.getSgConnect().getScope()).build();
        return sgConnect.target(path).request(MediaType.APPLICATION_JSON_TYPE);
    }
}
