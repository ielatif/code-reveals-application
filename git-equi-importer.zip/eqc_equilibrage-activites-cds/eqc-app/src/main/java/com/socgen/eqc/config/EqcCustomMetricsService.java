package com.socgen.eqc.config;

import com.socgen.eqc.infrastructure.entite.structure.EntiteStructureService;
import com.socgen.eqc.infrastructure.persistance.*;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.function.Supplier;

@Component
public class EqcCustomMetricsService {

    @Autowired
    private AffectationRepository affectationRepository;
    @Autowired
    private RenfortRepository renfortRepository;
    @Autowired
    private EntiteStructureService entiteStructureService;
    @Autowired
    private EquipeRepository equipeRepository;
    @Autowired
    private AffiliationRepository affiliationRepository;

    public EqcCustomMetricsService(MeterRegistry registry) {
        Gauge.builder("affectations_count", fetchAffectationCount()).register(registry);
        Gauge.builder("renforts_count", fetchRenfortCount()).register(registry);
        Gauge.builder("equipes_count", fetchEquipeCount()).register(registry);
        Gauge.builder("filieres_count", fetchFiliereCount()).register(registry);
        Gauge.builder("collaborateurs_count", fetchAffiliationCount()).register(registry);
    }

    public Supplier<Number> fetchAffectationCount() {
        return () -> affectationRepository.fetchAffectationCount();
    }

    public Supplier<Number> fetchRenfortCount() {
        return () -> renfortRepository.fetchRenfortCount();
    }

    public Supplier<Number> fetchEquipeCount() {
        return () -> equipeRepository.count();
    }

    public Supplier<Number> fetchAffiliationCount() {
        return () -> affiliationRepository.fetchAffiliationCount();
    }

    public Supplier<Number> fetchFiliereCount() {
        return () -> entiteStructureService.getEntiteStructureFromRes().size();
    }
}
