package com.socgen.eqc.infrastructure.batch.mapper;

import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Intervalle;
import com.socgen.eqc.infrastructure.batch.dto.AbsenceBatchDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface AbsenceMapper {


    @Mapping(target = "pourcentage", source = "intervalle", qualifiedByName = "getPourcentage")
    AbsenceBatchDto absenceToAbsenceBatchDto(Absence absence);


    @Named("getPourcentage")
    default Long getPourcentage(Intervalle intervalle) {

        if (intervalle == Intervalle.MATIN || intervalle == Intervalle.APRES_MIDI) {
            return 50L;
        }
        return 100L;
    }

}
