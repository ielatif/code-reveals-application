package com.socgen.eqc.infrastructure.persistance;

		import com.socgen.eqc.domain.model.ActiviteParams;
        import org.springframework.data.jpa.repository.JpaRepository;

		import java.util.List;

public interface ActiviteRepository extends JpaRepository<ActiviteParams, Long> {

	List<ActiviteParams> findByCodeIn(List<String> codeActivite);
	ActiviteParams findByCode(String code);
	List<ActiviteParams> findByCodeFamilleInAndMaskDateCompetenceIsNull(List<String> codesFamille);

}
