package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.annotations.SgSignInRolesAllowed;
import com.socgen.eqc.application.SousEquipeService;
import com.socgen.eqc.interfaces.rest.dto.SousEquipeDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

import static com.socgen.eqc.domain.model.RoleEqc.CONSULTER_PLANNING;
import static com.socgen.eqc.domain.model.RoleEqc.GERER_PLANNING;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/sous-equipes")
@Api(value = "sous-equipes")
@Slf4j
public class SousEquipeRessource {

    @Autowired
    private SousEquipeService sousEquipeService;

    @GET
    @ApiOperation(value = "Récupération des sous équipes par ST", notes = "Récupération des sous équipes par ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les sous équipes sont bien récupéré")
    })
    @Path("{codeServiceTraitement}")
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    public Response getSousEquipes(@PathParam("codeServiceTraitement") Long codeServiceTraitement) {
        return Response.ok(sousEquipeService.getByCodeEquipe(codeServiceTraitement)).build();
    }

    @POST
    @ApiOperation(value = "Création d'une sous équipe")
    @ApiResponses({
            @ApiResponse(code = 200, message = "La sous équipe est bien crée")
    })
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    public Response createSousEquipe(@Valid SousEquipeDto sousEquipeDto) {
        return Response.ok(sousEquipeService.create(sousEquipeDto)).build();
    }

    @PUT
    @ApiOperation(value = "Mise à jour d'une sous équipe")
    @ApiResponses({
            @ApiResponse(code = 200, message = "La sous équipe est bien mise à jour")
    })
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    public Response updateSousEquipe(@Valid SousEquipeDto sousEquipeDto) {
        return Response.ok(sousEquipeService.update(sousEquipeDto)).build();
    }

    @DELETE
    @ApiOperation(value = "Suppression d'une sous équipe")
    @ApiResponses({
            @ApiResponse(code = 200, message = "La sous équipe est bien supprimée")
    })
    @Path("{idSousEquipe}")
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    public Response deleteSousEquipe(@PathParam("idSousEquipe") Long idSousEquipe) {
        sousEquipeService.delete(idSousEquipe);
        return Response.ok().build();
    }

    @DELETE
    @ApiOperation(value = "Suppression de plusieurs sous équipes")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les sous équipe sont bien supprimées")
    })
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    public Response deleteSousEquipe(List<Long> idSousEquipes) {
        sousEquipeService.delete(idSousEquipes);
        return Response.ok().build();
    }

    @POST
    @ApiOperation(value = "Ajouter des membres à une sous équipe")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les membres sont bien ajoutés")
    })
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    @Path("{idSousEquipe}")
    public Response addMembres(@PathParam("idSousEquipe") Long idSousEquipe, List<Long> idAffiliations) {
        sousEquipeService.addMembres(idSousEquipe, idAffiliations);
        return Response.ok().build();
    }

    @DELETE
    @ApiOperation(value = "Supprimer des membres à une sous équipe")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les membres sont bien supprimés")
    })
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    @Path("/{idSousEquipe}/membres")
    public Response deleteMembres(@PathParam("idSousEquipe") Long idSousEquipe, List<Long> idMemebres) {
        sousEquipeService.deleteMembres(idMemebres);
        return Response.ok().build();
    }

    @GET
    @ApiOperation(value = "Récupération des membres des sous équipes par ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les membres sont bien récupéré")
    })
    @Path("/{codeServiceTraitement}/membres")
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING})
    public Response getMembreSousEquipes(@PathParam("codeServiceTraitement") Long codeServiceTraitement) {
        return Response.ok(sousEquipeService.getMembreByCodeEquipe(codeServiceTraitement)).build();
    }

}
