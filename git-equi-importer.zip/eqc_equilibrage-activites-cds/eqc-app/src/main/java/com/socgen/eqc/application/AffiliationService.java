package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.interfaces.rest.dto.IndicateurSearchDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import lombok.NonNull;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AffiliationService {

    List<Affiliation> findByPlanningSearchDto(PlanningSearchDto planningSearchDto);

    List<Affiliation> findByListEquipe(IndicateurSearchDto indicateurSearchDto);

    List<Affiliation> findByEquipeAndDate(@NonNull Long idEquipe, @NonNull LocalDate localDate);

    Affiliation findByPlanningSearchDto(@NonNull PlanningSearchDto planningSearchDto, @NonNull String matricule);

    void saveAll(List<Affiliation> affiliations);

    boolean hasAffiliation(@NonNull String matricule);

    void remove(String matricule);

    Optional<Affiliation> findLastByMatricule(String matricule);

    List<Affiliation> findActiveByMatricules(List<String> matricules);

    Optional<Affiliation> findByMatriculeAndDate(String matricule, LocalDate dateDebut, LocalDate date);

    List<Affiliation> findByMatriculeAndDateDebutAndDateFin(String matricule, LocalDate dateDebut, LocalDate dateFin);

    Optional<Affiliation> findByEquipeAndActiveByMatricule(@NonNull Long idEquipe, @NonNull String matricule);

    List<Affiliation> findByListEquipeAndActive(@NonNull List<Long> idsEquipes);
}
