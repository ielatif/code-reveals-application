package com.socgen.eqc.infrastructure.persistance;

import com.google.gson.JsonObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

@Repository
@RequiredArgsConstructor
@Slf4j
public class IndicateurEtpRepository {

    private final NamedParameterJdbcTemplate namedJdbcTemplate;

    private final String INDIC_ETP_SQL_QUERY = "with\n" +
            "    etpPlanifie as (\n" +
            "        SELECT ap.code as code_activite,\n" +
            "               affil.equipe_id,\n" +
            "               eq.format_semainier,\n" +
            "               ap.code_famille,\n" +
            "               sum(case\n" +
            "                       when affec.affiliation_id = affil.id\n" +
            "                           then round(cast(affec.pourcentage as numeric) / 100, 2)\n" +
            "                       else 0 end) as etp_planifie,\n" +
            "               case when (:dateFin) = (:dateDebut) then 1\n" +
            "                    else (:dateFin::date - :dateDebut::date) + 1 end as nbJoursTotal,\n" +
            "               ((:dateFin::date - :dateDebut::date) + 1) / 7 as nbSemaine\n" +
            "        FROM activite_params as ap\n" +
            "                 left join affectation affec on affec.code_activite = ap.code\n" +
            "                 left join affiliation affil on (affec.affiliation_id = affil.id)\n" +
            "                 left join equipe eq on eq.id = affil.equipe_id\n" +
            "        WHERE\n" +
            "            affec.date BETWEEN :dateDebut AND :dateFin\n" +
            "          and affil.equipe_id in (:stIds) \n" +
            "        group by ap.code_famille, ap.code, affil.equipe_id, eq.format_semainier\n" +
            "    ),\n" +
            "    etpRenfort as (\n" +
            "        SELECT affectation.code_activite,\n" +
            "               sum(case\n" +
            "                       when affectation.renfort_id is not null\n" +
            "                           then round(cast(affectation.pourcentage as numeric) / 100, 2)\n" +
            "                       else 0 end) as etp_renfort,\n" +
            "               renfort.code_st_aide\n" +
            "        FROM renfort\n" +
            "                 LEFT JOIN affectation ON affectation.renfort_id = renfort.id\n" +
            "        WHERE\n" +
            "            affectation.date BETWEEN (:dateDebut) AND (:dateFin)\n" +
            "          and renfort.code_st_aide in (:stIds) and renfort.date BETWEEN (:dateDebut) AND (:dateFin)\n" +
            "        group by affectation.code_activite, renfort.code_st_aide\n" +
            "    )\n" +
            "select\n" +
            "    etpPlanifie.code_famille,\n" +
            "    etpPlanifie.code_activite,\n" +
            "    case when etpPlanifie.equipe_id is null\n" +
            "        then etpRenfort.code_st_aide\n" +
            "        else etpPlanifie.equipe_id\n" +
            "        end as code_equipe,\n" +
            "    case when etpPlanifie.format_semainier = 5\n" +
            "             then round((COALESCE(etp_planifie,0) + COALESCE(etp_renfort,0)) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine * 2),2)\n" +
            "         else round((COALESCE(etp_planifie,0) + COALESCE(etp_renfort,0)) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine),2)\n" +
            "        end as etp_total_moyen,\n" +
            "    case when etpPlanifie.format_semainier = 5\n" +
            "             then round(COALESCE(etp_renfort,0) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine * 2),2)\n" +
            "         else round(COALESCE(etp_renfort,0) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine),2)\n" +
            "        end as etp_renfort_moyen\n" +
            "from\n" +
            "    etpPlanifie\n" +
            "        full outer join etpRenfort on etpPlanifie.code_activite = etpRenfort.code_activite\n" +
            "                                          and etpPlanifie.equipe_id = etpRenfort.code_st_aide \n" +
            "order by  etpPlanifie.code_activite, code_equipe;";

    private final String INDIC_ETP_RENFORT_SQL_QUERY = "with\n" +
            "    etpPlanifie as (\n" +
            "        SELECT ap.code as code_activite,\n" +
            "               affil.equipe_id,\n" +
            "               eq.format_semainier,\n" +
            "               ap.code_famille,\n" +
            "               sum(case\n" +
            "                       when affec.affiliation_id = affil.id\n" +
            "                           then round(cast(affec.pourcentage as numeric) / 100, 2)\n" +
            "                       else 0 end) as etp_planifie,\n" +
            "               case when (:dateFin) = (:dateDebut) then 1\n" +
            "                    else (:dateFin::date - :dateDebut::date) + 1 end as nbJoursTotal,\n" +
            "               ((:dateFin::date - :dateDebut::date) + 1) / 7 as nbSemaine\n" +
            "        FROM activite_params as ap\n" +
            "                 left join affectation affec on affec.code_activite = ap.code\n" +
            "                 left join affiliation affil on (affec.affiliation_id = affil.id)\n" +
            "                 left join equipe eq on eq.id = affil.equipe_id\n" +
            "        WHERE\n" +
            "            affec.date BETWEEN :dateDebut AND :dateFin\n" +
            "          and affil.equipe_id is null\n" +
            "        group by ap.code_famille, ap.code, affil.equipe_id, eq.format_semainier\n" +
            "    ),\n" +
            "    etpRenfort as (\n" +
            "        SELECT affectation.code_activite,\n" +
            "               sum(case\n" +
            "                       when affectation.renfort_id is not null\n" +
            "                           then round(cast(affectation.pourcentage as numeric) / 100, 2)\n" +
            "                       else 0 end) as etp_renfort,\n" +
            "               renfort.code_st_aide\n" +
            "        FROM renfort\n" +
            "                 LEFT JOIN affectation ON affectation.renfort_id = renfort.id\n" +
            "        WHERE\n" +
            "            affectation.date BETWEEN (:dateDebut) AND (:dateFin)\n" +
            "          and renfort.code_st_aide in (:stIds) and renfort.date BETWEEN (:dateDebut) AND (:dateFin)\n" +
            "        group by affectation.code_activite, renfort.code_st_aide\n" +
            "    )\n" +
            "select\n" +
            "    etpPlanifie.code_famille,\n" +
            "    etpPlanifie.code_activite,\n" +
            "    case when etpPlanifie.equipe_id is null\n" +
            "        then etpRenfort.code_st_aide\n" +
            "        else etpPlanifie.equipe_id\n" +
            "        end as code_equipe,\n" +
            "    case when etpPlanifie.format_semainier = 5\n" +
            "             then round((COALESCE(etp_planifie,0) + COALESCE(etp_renfort,0)) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine * 2),2)\n" +
            "         else round((COALESCE(etp_planifie,0) + COALESCE(etp_renfort,0)) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine),2)\n" +
            "        end as etp_total_moyen,\n" +
            "    case when etpPlanifie.format_semainier = 5\n" +
            "             then round(COALESCE(etp_renfort,0) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine * 2),2)\n" +
            "         else round(COALESCE(etp_renfort,0) / (etpPlanifie.nbJoursTotal - etpPlanifie.nbSemaine),2)\n" +
            "        end as etp_renfort_moyen\n" +
            "from\n" +
            "    etpPlanifie\n" +
            "        full outer join etpRenfort on etpPlanifie.code_activite = etpRenfort.code_activite\n" +
            "                                          and etpPlanifie.equipe_id is null\n" +
            "order by  etpPlanifie.code_activite, code_equipe;";



    public List<JsonObject> getEtps(final String from, final String to, final List<BigInteger> stIds) {

        SqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("dateDebut", LocalDate.parse(from, DateTimeFormatter.ISO_DATE))
                .addValue("dateFin", LocalDate.parse(to, DateTimeFormatter.ISO_DATE))
                .addValue("stIds", stIds);

        try {
            log.debug("Getting ETP indicators from {} to {} for STs {}", from, to, stIds);
            return this.namedJdbcTemplate.query (
                    INDIC_ETP_SQL_QUERY, parameters, new ExportEtpRowMapper()
            );
        } catch (final DataAccessException ex) {
            log.error("An error occurred while getting ETP export from DB", ex);
            return Collections.emptyList();
        }
    }

    public List<JsonObject> getEtpsRenfort(final String from, final String to, final List<BigInteger> stIds) {

        SqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("dateDebut", LocalDate.parse(from, DateTimeFormatter.ISO_DATE))
                .addValue("dateFin", LocalDate.parse(to, DateTimeFormatter.ISO_DATE))
                .addValue("stIds", stIds);

        try {
            log.debug("Getting ETP indicators from {} to {} for STs {}", from, to, stIds);
            return this.namedJdbcTemplate.query (
                    INDIC_ETP_RENFORT_SQL_QUERY, parameters, new ExportEtpRowMapper()
            );
        } catch (final DataAccessException ex) {
            log.error("An error occurred while getting ETP export from DB", ex);
            return Collections.emptyList();
        }
    }

    static class ExportEtpRowMapper implements RowMapper<JsonObject> {

        @Override
        public JsonObject mapRow(ResultSet rs, int rowNum) throws SQLException {

            JsonObject etpIndic = new JsonObject();

            etpIndic.addProperty("codeFamille", rs.getString("code_famille"));
            etpIndic.addProperty("codeActivite", rs.getString("code_activite"));
            etpIndic.addProperty("equipeId", rs.getLong("code_equipe"));
            etpIndic.addProperty("etpTotalMoyen", rs.getDouble("etp_total_moyen"));
            etpIndic.addProperty("etpRenfortMoyen", rs.getDouble("etp_renfort_moyen"));

            return etpIndic;
        }

    }
}
