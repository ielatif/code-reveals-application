package com.socgen.eqc.interfaces.rest.error;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ErrorDto {

    public static final String INTERNAL_SERVER_ERROR_MESSAGE = "Une erreur technique est survenue, merci de bien vouloir nous excuser pour la gêne occasionnée, nous vous invitons à réessayez ultérieurement";

    private String messageFonctionnel;
    private String messageTechnique;

    public static ErrorDto internalServerError(String messageTechnique) {
        return ErrorDto.builder().messageFonctionnel(INTERNAL_SERVER_ERROR_MESSAGE).messageTechnique(messageTechnique)
            .build();
    }
}
