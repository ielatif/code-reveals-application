package com.socgen.eqc.application.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.socgen.eqc.application.IndicateursSuiviActiviteService;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class IndicateursSuiviActiviteServiceImpl implements IndicateursSuiviActiviteService {

    private final SmboClient smboClient;

    private static final Gson gson = new GsonBuilder().create();

    @Override
    public JsonObject getIndicateurSuiviActivite(IndicateurInputDto indicateurInputDto) {

        return gson.fromJson(smboClient.getIndicateurSuivieActivite(indicateurInputDto.getDateDebut(),
                indicateurInputDto.getDateFin(), indicateurInputDto.getTetePerimetre(),
                indicateurInputDto.getListCodeServiceTraitement()),
                            JsonObject.class);
    }
}
