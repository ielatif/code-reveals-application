package com.socgen.eqc.interfaces.rest.dto.debranchement;

import com.socgen.eqc.infrastructure.debranchement.DebranchementTarget;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.ws.rs.QueryParam;

@Data
public class DebranchementDto {
    @NotBlank
    @QueryParam("target")
    private DebranchementTarget debranchementTarget;
}
