package com.socgen.eqc.application;

import com.google.gson.JsonObject;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurEtpInputDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;

import java.util.List;

public interface IndicateurService {

    List<IndicateurActiviteDto> getStockTraiter(IndicateurInputDto indicateurInputDto, Boolean isStockForExtraction);

    JsonObject getEtps(IndicateurEtpInputDto indicateurEtpInputDto);


}
