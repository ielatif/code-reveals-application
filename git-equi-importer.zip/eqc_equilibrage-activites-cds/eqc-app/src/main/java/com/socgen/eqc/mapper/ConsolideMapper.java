package com.socgen.eqc.mapper;

import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import com.socgen.eqc.interfaces.rest.dto.ConsolideMensTaux;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ConsolideMapper {

    @Mapping(target = "joursPresence", source = "joursPresence", qualifiedByName = "getPresenceDays")
    ConsolideMensTaux consolideMensuelToConsolideMensTaux(ConsolideMensuel consolideMensuel);

    List<ConsolideMensTaux> consolideMensuelListToConsolideMensTauxList(List<ConsolideMensuel> consolideMensuels);

    @Named("getPresenceDays")
    default String getPresenceDays(Double joursPresence) {
        Double decimalPart = joursPresence - joursPresence.intValue();
        String presenceDay = String.valueOf(joursPresence);

        if (decimalPart > 0) {
            return presenceDay.replace(".", ",");
        }

        return String.valueOf(joursPresence.intValue());
    }
}
