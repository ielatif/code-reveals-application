package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.socgen.eqc.domain.model.ActiviteRatio;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ActiviteRatioDto implements Serializable {

    private static final long serialVersionUID = 6981401352200432767L;

    @JsonProperty("code")
    private String code;

    @JsonProperty("libelle")
    private String libelle;

	private RatioTypeDto ratioType;

    public static ActiviteRatioDto toDto(ActiviteRatio domain) {
        ActiviteRatioDto dto = new ActiviteRatioDto();
        if (domain != null) {
            dto.code = domain.getCode();
            dto.libelle = domain.getLibelle();
            dto.setRatioType(new RatioTypeDto());
			dto.ratioType.setCode(domain.getRatioType().getCode());
            dto.ratioType.setLibelle(domain.getRatioType().getLibelle());
        }
        return dto;
    }

    public static List<ActiviteRatioDto> toListDto(List<ActiviteRatio> activitesRatio) {
        return activitesRatio.stream().map(ActiviteRatioDto::toDto).collect(Collectors.toList());
    }
}
