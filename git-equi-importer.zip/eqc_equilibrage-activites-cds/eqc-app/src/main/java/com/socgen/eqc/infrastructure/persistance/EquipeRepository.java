package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Equipe;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EquipeRepository extends JpaRepository<Equipe, Long> {
     Optional<Equipe> findByCode(Long code);
     List<Equipe> findAllByCodeIn(List<Long> code);
}
