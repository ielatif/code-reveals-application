package com.socgen.eqc.infrastructure.debranchement;

import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.interfaces.rest.dto.debranchement.DebranchementDto;
import com.socgen.eqc.interfaces.rest.dto.debranchement.DebranchementReponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.ws.rs.core.UriBuilder;

@Service
@RequiredArgsConstructor
public class DebranchementServiceImpl implements DebranchementService {

    @Autowired
    private ApplicationProperties applicationProperties;

    public DebranchementReponseDto getRedirectUrl(DebranchementDto debranchementDto) {
        String rbvRedirectUrl = applicationProperties.getRbv().getRedirectUrl();
        return new DebranchementReponseDto(UriBuilder.fromUri(rbvRedirectUrl)
                .queryParam("target", debranchementDto.getDebranchementTarget())
                .queryParam("source", "EQC")
                .build().toString());
    }
}
