package com.socgen.eqc.interfaces.rest.error;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
@Slf4j
public class UnhandledExceptionMapper implements ExceptionMapper<Exception> {

    @Override
    public Response toResponse(Exception e) {
        log.error("Exception : {}", e.getMessage(), e);
        return Response.status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .entity(ErrorDto.internalServerError(ExceptionUtils.getStackTrace(e))).build();
    }
}
