package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.IndicateurUgService;
import com.socgen.eqc.application.RenfortService;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.interfaces.rest.dto.IndicateurSearchDto;
import com.socgen.eqc.interfaces.rest.planning.dto.ContributorDto;
import com.socgen.eqc.interfaces.rest.planning.dto.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.planning.dto.IndicateurDto;
import com.socgen.eqc.interfaces.rest.planning.dto.ParametresCarteDTO;
import com.socgen.eqc.interfaces.rest.planning.dto.RenfortDto;
import lombok.AllArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Collections.emptyList;

@Service
@AllArgsConstructor
public class IndicateurUgServiceImpl implements IndicateurUgService {

    private final AffiliationService affiliationService;
    private final AffectationService affectationService;
    private final RenfortService renfortService;

    @Override
    public IndicateurActiviteDto computeIndicateur(@NonNull IndicateurSearchDto indicateurSearchDto) {

        List<IndicateurDto> indicateurs = new ArrayList<>();
        List<Affectation> affectationAffiliation = emptyList();
        List<Affectation> affectationsRenforts = emptyList();
        IndicateurActiviteDto indicateurActiviteDto = IndicateurActiviteDto.builder().indicateurs(indicateurs).build();

        List<Affiliation> affiliations = affiliationService.findByListEquipe(indicateurSearchDto);
        if (!affiliations.isEmpty()) {
            affectationAffiliation = affectationService
                    .findByAffiliationsAndDates(affiliations, indicateurSearchDto.getDateDebut(), indicateurSearchDto
                            .getDateFin());
        }
        List<Renfort> renfortsEntrant = renfortService
                .findRenfortEntrant(indicateurSearchDto.getListCodeServiceTraitement(), indicateurSearchDto
                        .getDateDebut(), indicateurSearchDto.getDateFin());

        if (!renfortsEntrant.isEmpty()) {
            affectationsRenforts = affectationService
                    .findByRenfortsAndDates(renfortsEntrant, indicateurSearchDto.getDateDebut(), indicateurSearchDto
                            .getDateFin());

        }

        List<Affectation> affectations = concat(affectationAffiliation, affectationsRenforts);

        Map<String, List<Affectation>> affectationByActivite = affectations.stream()
                .collect(Collectors.groupingBy(affec -> affec.getActivite().getCode()));

        affectationByActivite.entrySet()
                .forEach(entryAffecByActivite -> buildIndicateurs(indicateurs, entryAffecByActivite));

        return indicateurActiviteDto;
    }

    private void buildIndicateurs(List<IndicateurDto> indicateurs, Map.Entry<String, List<Affectation>> entryAffecByActivite) {

        Map<Long, List<Affectation>> affectationsBySt =
                entryAffecByActivite.getValue().stream().collect(Collectors
                        .groupingBy(affec -> affec.getAffiliation() != null ? affec.getAffiliation().getEquipe().getCode() : affec
                                .getRenfort().getEquipe().getCode()));

        affectationsBySt.entrySet()
                .forEach(entryAffecBySt -> buildIndicateursBySt(indicateurs, entryAffecByActivite, entryAffecBySt));
    }

    private void buildIndicateursBySt(List<IndicateurDto> indicateurs, Map.Entry<String, List<Affectation>> entryAffecByActivite, Map.Entry<Long, List<Affectation>> entryAffecBySt) {

        Map<LocalDate, List<Affectation>> affectationsByDay = entryAffecBySt.getValue().stream()
                .collect(Collectors.groupingBy(Affectation::getDate));

        affectationsByDay.entrySet().forEach(entryAffecByDay -> indicateurs
                .add(createIndicateur(entryAffecByActivite.getKey(), entryAffecBySt, entryAffecByDay)));

    }

    private IndicateurDto createIndicateur(String codeActivite, Map.Entry<Long, List<Affectation>> entryAffecBySt, Map.Entry<LocalDate, List<Affectation>> entryAffecByDay) {
        return IndicateurDto.builder().codeActivite(codeActivite).serviceTraitementId(entryAffecBySt.getKey())
                .date(entryAffecByDay.getKey()).etp(computeEtp(entryAffecByDay))
                .codeFamille(!CollectionUtils.isEmpty(entryAffecByDay.getValue()) ? entryAffecByDay.getValue().get(0).getActivite().getCodeFamille() : "")
                .unite(!CollectionUtils.isEmpty(entryAffecByDay.getValue()) ? entryAffecByDay.getValue().get(0).getActivite().getUnite() : Unite.NA)
                .contributors(getContributor(entryAffecByDay.getValue()))
                .capacite(computeCapaciteTheorique(entryAffecByDay)).build();
    }

    /**
     * Récupérations de la liste des collaborateurs qui ont travaillés sur chaque activité
     * @param affectations
     * @return
     */
    private List<ContributorDto> getContributor(List<Affectation> affectations) {
        return affectations.stream()
                .map(affectation -> {
                    Collaborateur collaborateur = affectation.getAffiliation() != null
                            ? affectation.getAffiliation().getCollaborateur() : affectation.getRenfort().getCollaborateur();
                    String affectationColor = (affectation.getParametresCarte() != null && affectation.getParametresCarte().getCouleur() != null ) ? affectation.getParametresCarte().getCouleur().getCode() : null;
                    return ContributorDto.builder()
                            .loginWindows(collaborateur.getLoginWindows())
                            .nom(collaborateur.getNom())
                            .prenom(collaborateur.getPrenom())
                            .renfort(affectation.getRenfort() != null ? RenfortDto.fromDomain(affectation.getRenfort()) : null)
                            .pourcentContribution(affectation.getPourcentage())
                            .commentPrameteres(
                                    ParametresCarteDTO.builder()
                                            .commentPrincipale(affectation.getParametresCarte() != null ? affectation.getParametresCarte().getTitre() : null)
                                            .commentSecondaire(affectation.getParametresCarte() != null ? affectation.getParametresCarte().getCommentaire() : null)
                                            .customStyle(affectationColor).build()
                            )
                            .build();
                })
                .collect(Collectors.toList());
    }

    private BigDecimal computeEtp(Map.Entry<LocalDate, List<Affectation>> entryAffecByDay) {
        Long totalPourcent = entryAffecByDay.getValue().stream().map(Affectation::getPourcentage).reduce(0L, Long::sum);
        return new BigDecimal(totalPourcent).divide(new BigDecimal(100));
    }

    private BigDecimal computeCapaciteTheorique(Map.Entry<LocalDate, List<Affectation>> entryAffecByDay) {

        Double totalNbrDossier = entryAffecByDay.getValue().stream()
                .filter(aff -> aff.getNombreDossier() != null).map(Affectation::getNombreDossier)
                .reduce(0D, Double::sum);

        return BigDecimal.valueOf(totalNbrDossier);
    }

    private <T> List<T> concat(List<T> list, List<T> list2) {
        return Stream.concat(list.stream(), list2.stream()).collect(Collectors.toList());
    }
}
