package com.socgen.eqc.application.exception;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Getter
@Slf4j
public class BusinessException extends RuntimeException {

    private final HttpStatus httpStatus;
    private final String messageFonctionnel;

    public BusinessException(String message) {
    	super(message);
        this.messageFonctionnel = message;
        this.httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
    }

    public BusinessException(String messageFonctionnel, Exception e) {
        log.error("Exception", e);
        this.messageFonctionnel = messageFonctionnel;
        this.httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
    }
}
