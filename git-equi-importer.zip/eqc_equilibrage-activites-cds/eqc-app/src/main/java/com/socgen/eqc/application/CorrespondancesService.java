package com.socgen.eqc.application;

import com.socgen.eqc.infrastructure.smbo.dto.CorrespondanceActiviteDto;
import com.socgen.eqc.infrastructure.smbo.dto.ReferentielProcessusDto;
import com.socgen.eqc.infrastructure.smbo.dto.Source;

import java.util.List;

public interface CorrespondancesService {

    List<ReferentielProcessusDto> getProcessusByTetePerimetre(List<Long> codeTetePerimetres, Source source);

    List<CorrespondanceActiviteDto> getAllCorrespondanceByTetePerimetre(List<Long> codeTetePerimetres);

    void saveCorrespondances(CorrespondanceActiviteDto correspondanceActiviteDto);
}
