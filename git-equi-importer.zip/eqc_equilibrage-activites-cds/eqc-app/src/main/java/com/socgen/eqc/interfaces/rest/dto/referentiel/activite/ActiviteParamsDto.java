package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.socgen.eqc.domain.model.TypeActivite;
import com.socgen.eqc.domain.model.Unite;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ActiviteParamsDto implements Serializable {

    private static final long serialVersionUID = -2650299435296794303L;

    private String code;
    private String codeFamille;
    private int ordre;
    private ActiviteRatioDto activiteRatio;
    private TypeActivite type;
    private  Unite unite;
    private LocalDate maskDate;
    private LocalDate maskDatePilotage;
    private LocalDate maskDateCompetence;
    private Set<ExpertiseDto> expertises = new HashSet<>();
    private Set<DefaultExpertiseDto> defaultExpertises = new HashSet<>();
}
