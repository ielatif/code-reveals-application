package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPlanningCollabDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
@Repository
@RequiredArgsConstructor
@Slf4j
public class ExtractPlanningCollabRepository {

    private final NamedParameterJdbcTemplate namedJdbcTemplate;

    //NOSONAR
    String EXTRACT_PLANNING_COLLAB_SQL_QUERY = "SELECT *\n" +
            "FROM (\n" +
            "       SELECT\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           renfort.code_cds_aide\n" +
            "         ELSE\n" +
            "           equipe.code_cds\n" +
            "         END AS \"codeFiliere\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "                get_es_name_by_code(renfort.code_cds_aide::text)\n" +
            "              ELSE\n" +
            "                get_es_name_by_code(equipe.code_cds::text)\n" +
            "           END AS \"filiere\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           renfort.code_ug_aide\n" +
            "         ELSE\n" +
            "           equipe.code_ug\n" +
            "         END AS \"codeUg\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "                get_es_name_by_code(renfort.code_ug_aide::text)\n" +
            "              ELSE\n" +
            "                get_es_name_by_code(equipe.code_ug::text)\n" +
            "           END AS \"ug\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "                renfort.code_st_aide\n" +
            "              ELSE\n" +
            "                equipe.id\n" +
            "           END AS \"codeSt\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "              get_es_name_by_code(renfort.code_st_aide::text)\n" +
            "           else\n" +
            "             get_es_name_by_code(equipe.id::text)\n" +
            "           end\n" +
            "           as \"st\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           UPPER(renfort.matricule_collaborateur)\n" +
            "         ELSE\n" +
            "           UPPER(affiliation.collaborateur_id)\n" +
            "         END AS \"matricule\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           get_collaborator_name_by_matricule(renfort.matricule_collaborateur)\n" +
            "         ELSE\n" +
            "           get_collaborator_name_by_matricule(affiliation.collaborateur_id)\n" +
            "         END AS \"nomCollaborateur\",\n" +
            "\n" +
            "         affectation.date AS \"dateAffectation\",\n" +
            "\n" +
            "         activite_params.code_famille AS \"familleCode\",\n" +
            "\n" +
            "         code_activite AS \"activiteCode\",\n" +
            "\n" +
            "         null AS \"activite\",\n" +
            "         null AS \"famille\",\n" +
            "\n" +
            "         (affectation.pourcentage::float / 100) AS \"etp\",\n" +
            "\n" +
            "         titre AS CommentairePrincipal,\n" +
            "\n" +
            "         CASE\n" +
            "         WHEN renfort_id IS NULL THEN ''\n" +
            "         ELSE 'Entrant' END\n" +
            "           AS \"renfort\",\n" +
            "\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NULL THEN\n" +
            "           null\n" +
            "         else renfort.code_cds_rattachement\n" +
            "         end as \"codeFiliereAidante\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           get_es_name_by_code(renfort.code_cds_rattachement::text)\n" +
            "         else ''\n" +
            "         end as \"filiereAidante\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NULL THEN\n" +
            "           null\n" +
            "         else renfort.code_ug_rattachement\n" +
            "         end as \"codeUgAidante\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           get_es_name_by_code(renfort.code_ug_rattachement::text)\n" +
            "         else ''\n" +
            "         end as \"ugAidante\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NULL THEN\n" +
            "           null\n" +
            "         else renfort.code_st_rattachement\n" +
            "         end as \"codeStAidant\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           get_es_name_by_code(renfort.code_st_rattachement::text)\n" +
            "         else ''\n" +
            "         end as \"stAidant\",\n" +
            "\n" +
            "\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NULL THEN\n" +
            "           null\n" +
            "         else renfort.code_cds_aide\n" +
            "         end as \"codeFiliereAidee\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           get_es_name_by_code(renfort.code_cds_aide::text)\n" +
            "         else ''\n" +
            "         end as \"filiereAidee\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NULL THEN\n" +
            "           null\n" +
            "         else renfort.code_ug_aide\n" +
            "         end as \"codeUgAidee\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "           get_es_name_by_code(renfort.code_ug_aide::text)\n" +
            "         else ''\n" +
            "         end as \"ugAidee\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NULL THEN\n" +
            "           null\n" +
            "         else renfort.code_st_aide\n" +
            "         end as \"codeStAide\",\n" +
            "\n" +
            "         CASE WHEN renfort_id IS NOT NULL THEN\n" +
            "              get_es_name_by_code(renfort.code_st_aide::text)\n" +
            "           else ''\n" +
            "           end as \"stAide\",\n" +
            "array_to_string(array_agg(distinct sous_equipe.libelle),',') AS sousEquipe, " +
            "affectation.id as affectationId\n" +
            "       FROM affectation\n" +
            "         Left JOIN affiliation ON affectation.affiliation_id = affiliation.id " +
            "Left JOIN affiliation_sous_equipe ON affectation.affiliation_id = affiliation_sous_equipe.affiliation_id " +
            "Left JOIN sous_equipe ON sous_equipe.id = affiliation_sous_equipe.sous_equipe_id\n" +
            "         Left JOIN collaborateur ON affiliation.collaborateur_id = collaborateur.matricule\n" +
            "         Left JOIN equipe ON affiliation.equipe_id = equipe.id\n" +
            "         Left JOIN ref_data_libelle_es ON equipe.id::text = ref_data_libelle_es.code\n" +
            "         Left JOIN renfort ON affectation.renfort_id = renfort.id\n" +
            "         Left JOIN activite_params ON affectation.code_activite = activite_params.code\n" +
            "         Left JOIN parametres_carte ON affectation.parametres_carte_id = parametres_carte.id\n" +
            "       WHERE affectation.date BETWEEN :from AND :to\n" +
            "         And (cast(equipe.id as varchar)  in (:codeSt) or cast(renfort.code_st_aide as varchar) in (:codeSt)) " +
            " group by affectation.id, code_cds_aide, equipe.code_cds, renfort.code_ug_aide, equipe.code_ug, renfort.code_st_aide,\n" +
            "           equipe.id, renfort.matricule_collaborateur, affiliation.collaborateur_id, activite_params.code_famille,\n" +
            "           parametres_carte.titre, renfort.code_cds_rattachement, renfort.code_ug_rattachement, renfort.code_st_rattachement\n" +
            "\n" +
            "       UNION\n" +
            "\n" +
            "       SELECT\n" +
            "\n" +
            "         renfort.code_cds_rattachement AS codeFiliere,\n" +
            "         get_es_name_by_code(renfort.code_cds_rattachement::text) AS filiere,\n" +
            "\n" +
            "         renfort.code_ug_rattachement AS codeUg,\n" +
            "         get_es_name_by_code(renfort.code_ug_rattachement::text) AS ug,\n" +
            "\n" +
            "         renfort.code_st_rattachement AS codeSt,\n" +
            "         get_es_name_by_code(renfort.code_st_rattachement::text) as st,\n" +
            "\n" +
            "         UPPER(renfort.matricule_collaborateur) AS matricule,\n" +
            "         get_collaborator_name_by_matricule(renfort.matricule_collaborateur) AS nomCollaborateur,\n" +
            "         renfort.date AS dateAffectation,\n" +
            "         null AS familleCode,\n" +
            "         null AS activiteCode,\n" +
            "         'renfort' AS activite,\n" +
            "         null AS famille,\n" +
            "\n" +
            "         CASE\n" +
            "         WHEN renfort.intervalle = 2 THEN 1\n" +
            "         ELSE 0.5 END\n" +
            "           AS etp,\n" +
            "         titre as CommentairePrincipal,\n" +
            "         'Sortant' AS renfort,\n" +
            "\n" +
            "         renfort.code_cds_rattachement as codeFiliereAidante,\n" +
            "         get_es_name_by_code(renfort.code_cds_rattachement::text) as filiereAidante,\n" +
            "\n" +
            "         renfort.code_ug_rattachement as codeUgAidante,\n" +
            "         get_es_name_by_code(renfort.code_ug_rattachement::text) as ugAidante,\n" +
            "\n" +
            "         renfort.code_st_rattachement as codeStAidant,\n" +
            "         get_es_name_by_code(renfort.code_st_rattachement::text) as stAidant,\n" +
            "\n" +
            "\n" +
            "         renfort.code_cds_aide as codeFiliereAidee,\n" +
            "         get_es_name_by_code(renfort.code_cds_aide::text) as filiereAidee,\n" +
            "\n" +
            "         renfort.code_ug_aide as codeUgAidee,\n" +
            "         get_es_name_by_code(renfort.code_ug_aide::text) as ugAidee,\n" +
            "\n" +
            "         renfort.code_st_aide as codeStAide,\n" +
            "         get_es_name_by_code(renfort.code_st_aide::text) as stAide, " +
            "null AS sousEquipe, " +
            "null as affectationId\n" +
            "\n" +
            "\n" +
            "       FROM renfort\n" +
            "         inner JOIN collaborateur ON renfort.matricule_collaborateur = collaborateur.matricule " +
            "Left JOIN parametres_carte ON renfort.parametres_carte_id = parametres_carte.id\n" +
            "       WHERE renfort.date BETWEEN :from AND :to\n" +
            "             And cast(renfort.code_st_rattachement as varchar) in (:codeSt) \n" +
            "     ) AS \"Activity\"\n" +
            "\n";

    public List<ExtractPlanningCollabDto> findPlanningCollab(final List<String> listCodeSt, final LocalDate from, final LocalDate to) {
        try {
            log.info("extract planning collab from {} to {} ", from, to);
            SqlParameterSource parameters = new MapSqlParameterSource("codeSt", listCodeSt)
                    .addValue("from", from).addValue("to", to);

            return this.namedJdbcTemplate.query(
                    EXTRACT_PLANNING_COLLAB_SQL_QUERY, parameters, new ExtractPlanningCollabRowMapper());
        } catch (final DataAccessException ex) {
            log.error("An error occurred while getting planning collab extract from DB", ex);
            return Collections.emptyList();
        }
    }

    static class ExtractPlanningCollabRowMapper implements RowMapper<ExtractPlanningCollabDto> {
        @Override
        public ExtractPlanningCollabDto mapRow(ResultSet rs, int rowNum) throws SQLException {

            return ExtractPlanningCollabDto.builder()
                    .codeFiliere(rs.getString("codeFiliere"))
                    .filiere(rs.getString("filiere"))
                    .codeUg(rs.getString("codeUg"))
                    .ug(rs.getString("ug"))
                    .codeSt(rs.getString("codeSt"))
                    .st(rs.getString("st"))
                    .matricule(rs.getString("matricule"))
                    .nomCollaborateur(rs.getString("nomCollaborateur"))
                    .sousEquipe(rs.getString("sousEquipe"))
                    .dateAffectation(rs.getString("dateAffectation"))
                    .familleCode(rs.getString("familleCode"))
                    .famille(rs.getString("famille"))
                    .activiteCode(rs.getString("activiteCode"))
                    .activite(rs.getString("activite"))
                    .etp(rs.getBigDecimal("etp") != null ?
                            rs.getBigDecimal("etp").setScale(2, RoundingMode.HALF_EVEN).toString() :
                            "")
                    .commentairePrincipal(rs.getString("CommentairePrincipal"))
                    .renfort(rs.getString("renfort"))
                    .codeFiliereAidante(rs.getString("codeFiliereAidante"))
                    .filiereAidante(rs.getString("filiereAidante"))
                    .codeUgAidante(rs.getString("codeUgAidante"))
                    .ugAidante(rs.getString("ugAidante"))
                    .codeStAidant(rs.getString("codeStAidant"))
                    .stAidant(rs.getString("stAidant"))
                    .codeFiliereAidee(rs.getString("codeFiliereAidee"))
                    .filiereAidee(rs.getString("filiereAidee"))
                    .codeUgAidee(rs.getString("codeUgAidee"))
                    .ugAidee(rs.getString("ugAidee"))
                    .codeStAide(rs.getString("codeStAide"))
                    .stAide(rs.getString("stAide"))
                    .build();
        }
    }
}
