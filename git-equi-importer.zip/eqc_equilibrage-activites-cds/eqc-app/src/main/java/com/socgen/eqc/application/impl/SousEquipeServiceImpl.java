package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.SousEquipeService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.AffiliationSousEquipe;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.domain.model.SousEquipe;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import com.socgen.eqc.infrastructure.persistance.AffiliationSousEquipeRepository;
import com.socgen.eqc.infrastructure.persistance.EquipeRepository;
import com.socgen.eqc.infrastructure.persistance.SousEquipeRepository;
import com.socgen.eqc.interfaces.rest.dto.AffiliationSousEquipeDto;
import com.socgen.eqc.interfaces.rest.dto.SousEquipeDto;
import com.socgen.eqc.mapper.AffiliationSousEquipeMapper;
import com.socgen.eqc.mapper.SousEquipeMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class SousEquipeServiceImpl implements SousEquipeService {

    private final SousEquipeRepository sousEquipeRepository;
    private final EquipeRepository equipeRepository;
    private final SousEquipeMapper sousEquipeMapper;
    private final AffiliationSousEquipeRepository affiliationSousEquipeRepository;
    private final AffiliationRepository affiliationRepository;
    private final AffiliationSousEquipeMapper affiliationSousEquipeMapper;

    @Override
    @Transactional(readOnly = true)
    public List<SousEquipeDto> getByCodeEquipe(Long codeEquipe) {
        return sousEquipeMapper.toDtoList(sousEquipeRepository.findByEquipeCode(codeEquipe));
    }

    @Override
    @Transactional
    public SousEquipeDto create(SousEquipeDto sousEquipeDto) {
        Optional<Equipe> optionalEquipe = equipeRepository.findById(sousEquipeDto.getEquipeId());
        SousEquipe sousEquipe = SousEquipe.builder()
                .libelle(sousEquipeDto.getLibelle())
                .description(sousEquipeDto.getDescription())
                .equipe(optionalEquipe.orElseThrow(() -> new BusinessException("L'équipe n'existe pas")))
                .build();
        return sousEquipeMapper.toDto(sousEquipeRepository.save(sousEquipe));
    }

    @Override
    @Transactional
    public SousEquipeDto update(SousEquipeDto sousEquipeDto) {
        Optional<SousEquipe> sousEquipeOptional = sousEquipeRepository.findById(sousEquipeDto.getId());
        SousEquipe sousEquipe = sousEquipeOptional.orElseThrow(() -> new BusinessException("La sous équipe n'existe pas"));
        sousEquipe.setLibelle(sousEquipeDto.getLibelle());
        sousEquipe.setDescription(sousEquipeDto.getDescription());
        return sousEquipeMapper.toDto(sousEquipeRepository.save(sousEquipe));
    }

    @Override
    @Transactional
    public void delete(Long idSousEquipe) {
        sousEquipeRepository.deleteById(idSousEquipe);
    }

    @Override
    @Transactional
    public void delete(List<Long> idSousEquipes) {
        List<AffiliationSousEquipe> affiliationSousEquipe = affiliationSousEquipeRepository.findAllBySousEquipeIdIn(idSousEquipes);
        affiliationSousEquipeRepository.deleteAll(affiliationSousEquipe);
        sousEquipeRepository.deleteAllById(idSousEquipes);
    }

    @Override
    @Transactional
    public void addMembres(Long idSousEquipe, List<Long> idAffiliations) {
        Optional<SousEquipe> sousEquipeOptional = sousEquipeRepository.findById(idSousEquipe);
        SousEquipe sousEquipe = sousEquipeOptional.orElseThrow();
        List<Long> idAffiliationsBd = affiliationSousEquipeRepository.findAllBySousEquipeIdIn(Collections.singletonList(idSousEquipe)).stream()
                .map(AffiliationSousEquipe::getAffiliation).map(Affiliation::getId).collect(Collectors.toList());
        idAffiliations.stream()
                .filter(idAffiliation -> !idAffiliationsBd.contains(idAffiliation))
                .map(idAffiliation ->
                        AffiliationSousEquipe.builder()
                                .sousEquipe(sousEquipe)
                                .affiliation(affiliationRepository.findById(idAffiliation).orElseThrow())
                                .build()
                ).forEach(affiliationSousEquipeRepository::save);
    }

    @Override
    @Transactional
    public void deleteMembres(List<Long> idMemebres) {
        affiliationSousEquipeRepository.deleteAllById(idMemebres);
    }

    @Override
    public List<AffiliationSousEquipeDto> getMembreByCodeEquipe(Long codeServiceTraitement) {
        List<SousEquipe> sousEquipeList = sousEquipeRepository.findByEquipeCode(codeServiceTraitement);
        List<AffiliationSousEquipe> bySousEquipeId = affiliationSousEquipeRepository.
                findAllBySousEquipeIdIn(sousEquipeList.stream()
                        .map(SousEquipe::getId)
                        .collect(Collectors.toList()));
        return affiliationSousEquipeMapper.toDtos(bySousEquipeId);
    }
}
