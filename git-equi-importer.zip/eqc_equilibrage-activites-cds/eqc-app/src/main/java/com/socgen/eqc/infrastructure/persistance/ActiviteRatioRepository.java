package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.ActiviteRatio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ActiviteRatioRepository extends JpaRepository<ActiviteRatio, String> {

    ActiviteRatio findByCode(String codeActiviteRatio);
    List<ActiviteRatio> findByratioTypeCode(Long ratioType);
    List<ActiviteRatio> findByTetePerimetre(String codeActiviteRatio);
}
