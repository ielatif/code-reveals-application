package com.socgen.eqc.application.impl;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.socgen.eqc.application.ExtractService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.infrastructure.extraction.ExtractionFactory;
import com.socgen.eqc.interfaces.rest.dto.ExtractionTypes;
import com.socgen.eqc.utils.ExtractUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExtractServiceImpl implements ExtractService {


    @Override
    @Transactional
    public byte[] buildExtraction(String extractionType, List<String> listCodeSt, List<String> tetePerimetre, String from, String to) {

        try {
            return createExtraction(extractionType, listCodeSt, tetePerimetre, from, to).get();
        } catch (Exception e) {
            log.error("An error occured while creating extractione for planning collab ", e);
            // Sonar : Either re-interrupt this method or rethrow the "InterruptedException" that can be caught here.
            Thread.currentThread().interrupt();
            throw new BusinessException("An error occured while creating CSV File for planning collab", e);
        }
    }

    @Async("taskExecutor")
    public CompletableFuture<byte[]> createExtraction(String extractionType, List<String> listCodeSt, List<String> tetePerimetre, String from, String to) {
        Object dataToWrite = ExtractionFactory.buildExtractionData(ExtractionTypes.instanceByKey(extractionType), listCodeSt, tetePerimetre, from, to);
        byte[] csvData = createGenericDataExtraction(ExtractionTypes.instanceByKey(extractionType).getDtoClass(), dataToWrite);
        return CompletableFuture.completedFuture(csvData);
    }

    private byte[] createGenericDataExtraction(Class dtoClazz, Object dataToWrite) {
        try {
            ObjectWriter objectWriter = ExtractUtils.createObjectWriter(dtoClazz);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            objectWriter.writeValue(outputStream, dataToWrite);

            return outputStream.toString("UTF-8").getBytes("UTF-8");

        } catch (Exception e) {
            log.error("An error occured while creating extraction ", e);
            throw new BusinessException("An error occured while creating CSV Data", e);
        }
    }

}
