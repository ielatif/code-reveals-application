package com.socgen.eqc.infrastructure.entite.structure.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "PARAMETRES_TETE_PERIMETRE")
@Builder
@Getter
@Setter
public class TetePerimetre implements Serializable {

    private static final long serialVersionUID = -6348362750105950506L;

    @JsonProperty("id")
    @Id
    @Column(name = "id", nullable = false, unique = true)
    private String id;

    @JsonProperty("libelle")
    @Column(name = "libelle")
    private String libelle;

    @Column(name = "is_active")
    private Boolean active;
}
