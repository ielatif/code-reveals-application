package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class TetePerimetreDto implements Serializable {

    private static final long serialVersionUID = -1942653506476464198L;

    @JsonProperty("id")
    private String id;

    @JsonProperty("libelle")
    private String libelle;

    private Boolean active;

}
