package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;

import java.util.List;

public interface CollaborateurService {

    List<CollaborateurDto> findByMatricules(String... matricules);

    List<CollaborateurDto> findNewCollaborateurs(Long idEquipe);

    List<Collaborateur> findByPlanningSearchDto(PlanningSearchDto planningSearchDto);

    Collaborateur save(CollaborateurDto dto);

    List<CollaborateurDto> getCollaborateursByMatriculeFromEqc(List<String> matricules);

    void remove(String matricule);

    List<CollaborateurDto> findCollaborateurs(Long codeServiceTraitement);
}
