package com.socgen.eqc.mapper;

import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.RenfortService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.CouleurCarte;
import com.socgen.eqc.domain.model.ParametresCarte;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.infrastructure.persistance.ExtensionPerimetreRepository;
import com.socgen.eqc.interfaces.rest.dto.ActionAbsenceDto;
import com.socgen.eqc.interfaces.rest.dto.ActionAffectationDto;
import com.socgen.eqc.interfaces.rest.dto.ActionDto;
import com.socgen.eqc.interfaces.rest.dto.ActionRenfortDto;
import lombok.Setter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.util.StringUtils;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;

@Mapper(componentModel = "spring")
@Setter
public abstract class ActionMapper {

    @Autowired
    @Lazy
    private RenfortService renfortService;

    @Autowired
    private AffiliationService affiliationService;

    @Autowired
    private ExtensionPerimetreRepository extensionPerimetreRepository;

    @Mapping(target = "matriculeCollaborateur", source = "matricule")
    public abstract Absence toAbsence(ActionAbsenceDto dto);

    public abstract List<Absence> toAbsences(List<ActionAbsenceDto> dtos);

    @Mapping(target = "affiliation", source = "actionAffectationDto", qualifiedByName = "buildAffiliation")
    @Mapping(target = "renfort", source = "actionAffectationDto", qualifiedByName = "buildRenfort")
    @Mapping(target = "activite.code", source = "codeActivite")
    @Mapping(target = "expertise.id", source = "idExpertise")
    @Mapping(target = "parametresCarte", source = "actionAffectationDto", qualifiedByName = "buildParametresCarte")
    public abstract Affectation toAffectation(ActionAffectationDto actionAffectationDto);

    public abstract List<Affectation> toAffectations(List<ActionAffectationDto> dtos);

    @Mapping(target = "equipe.code", source = "codeStAide")
    @Mapping(target = "equipe.codeCds", source = "codeCdsAide")
    @Mapping(target = "equipe.codeUg", source = "codeUgAide")
    @Mapping(target = "collaborateur.matricule", source = "matricule")
    @Mapping(target= "equipe.formatSemainier", source="formatSemainier")
    @Mapping(target = "parametresCarte", source = "actionRenfortDto", qualifiedByName = "buildParametresCarte")
    public abstract Renfort toRenfort(ActionRenfortDto actionRenfortDto);

    public abstract List<Renfort> toListRenforts(List<ActionRenfortDto> actionRenfortDtos);

    @Named("buildRenfort")
    public Renfort buildRenfort(ActionAffectationDto actionAffectationDto) {
        if (actionAffectationDto.isForRenfort()) {
            return renfortService.searchRenfortByMatriculeAndCodeStAideAndDate(actionAffectationDto
                    .getMatricule(), actionAffectationDto.getCodeServiceTraitement(), actionAffectationDto.getDate());
        }
        return null;
    }

    @Named("buildAffiliation")
    public Affiliation buildAffiliation(ActionAffectationDto actionAffectationDto) {
        if (!actionAffectationDto.isForRenfort()) {
            return affiliationService
                    .findByMatriculeAndDate(actionAffectationDto.getMatricule(),
                            actionAffectationDto.getDate().with(DayOfWeek.MONDAY), actionAffectationDto.getDate())
                    .orElseThrow(() -> new BusinessException(String
                            .format("Une erreur est produite lors de la recuperation de l'affiliation du collaborateur: %s", actionAffectationDto
                                    .getMatricule())));
        }
        return null;
    }

    @Named("buildParametresCarte")
    public ParametresCarte buildParametresCarte(ActionDto actionDto) {

        if (StringUtils.hasText(actionDto.getCommentPrincipale())
                || StringUtils.hasText(actionDto.getCommentSecondaire())
                || StringUtils.hasText(actionDto.getCustomStyle())) {
            return ParametresCarte.builder()
                    .couleur(actionDto.getCustomStyle() != null && !actionDto.getCustomStyle().isEmpty() ? CouleurCarte.of(actionDto.getCustomStyle()) : null)
                    .commentaire(actionDto.getCommentSecondaire())
                    .titre(actionDto.getCommentPrincipale())
                    .updatedAt(LocalDateTime.now())
                    .build();
        }
        return null;
    }
}
