package com.socgen.eqc.interfaces.rest.planning.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContributorDto {

    private String loginWindows;
    private String nom;
    private String prenom;
    private RenfortDto renfort;
    private Long pourcentContribution;
   private ParametresCarteDTO commentPrameteres;
}
