package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.TetePerimetreService;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.infrastructure.persistance.TetePerimetreRepository;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.TetePerimetreDto;
import com.socgen.eqc.mapper.TetePerimetreMapper;
import lombok.AllArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class TetePerimetreServiceImpl implements TetePerimetreService {

    private final TetePerimetreRepository tetePerimetreRepository;
    private final TetePerimetreMapper tetePerimetreMapper;
    private final SmboClient smboClient;

    @Override
    @Cacheable(value = EqcCacheConfig.CACHE_TETE_PERIMETRES)
    public List<TetePerimetreDto> getAllTetePerimetres() {
        List<TetePerimetreDto> allTetePerimetres = smboClient.getAllTetePerimetres(); 
        final List<TetePerimetre> smboTetePerimetres = tetePerimetreMapper.listTetePerimetreDtoToTetePerimetreList(allTetePerimetres);

        final List<TetePerimetre> dbTetePerimetres = tetePerimetreRepository.findAll();


        // We create a stream of elements from the first list.
        final List<TetePerimetre> tetePerimetres = smboTetePerimetres.stream()
                // We select any elements such that in the stream of elements from the second list
                .filter(two -> dbTetePerimetres.stream()
                        // there is an element that does not have the ID as this element,
                        .noneMatch(one -> one.getId().equals(two.getId())))
                // and collect all matching elements from the first list into a new list.
                .collect(Collectors.toList());

        // Par defaut les tetes de perimetres rajoutes depuis le RES sont desactives
        tetePerimetres.forEach(tetePerimetre -> tetePerimetre.setActive(false));

        this.tetePerimetreRepository.saveAll(tetePerimetres);

        return this.tetePerimetreMapper.listTetePerimetreToTetePerimetreDtoList(this.tetePerimetreRepository.findAll());
    }

    @Override
    public TetePerimetre findTetePerimetreById(String idTetePerimetre) {
        return tetePerimetreRepository.findFirstById(idTetePerimetre);
    }
}
