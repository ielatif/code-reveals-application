package com.socgen.eqc.application;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;

import java.util.List;

public interface PerimetreService {
    List<CentreService> getPerimetre(String codeEntiteRattachement, SgUserPrincipal sgUserPrincipal);

}
