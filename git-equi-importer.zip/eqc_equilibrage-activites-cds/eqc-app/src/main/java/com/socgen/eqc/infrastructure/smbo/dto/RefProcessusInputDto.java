package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class RefProcessusInputDto implements Serializable {

    private static final long serialVersionUID = 619988598821149081L;

    private String code;

    @NotBlank
    private String libelle;

    @NotNull
    @Enumerated(EnumType.STRING)
    private Source source;

    @NotBlank
    private String codeTetePerimetre;

    private String informations;

    private LocalDate dateDesactivation;

}
