package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AbsenceService;
import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Intervalle;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.infrastructure.gershwin.service.GershwinService;
import com.socgen.eqc.infrastructure.persistance.AbsenceRepository;
import com.socgen.eqc.interfaces.rest.dto.Action;
import com.socgen.eqc.interfaces.rest.dto.ActionAbsenceDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.interfaces.rest.planning.dto.AbsenceGershwinDto;
import com.socgen.eqc.mapper.ActionMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;

@Service
@AllArgsConstructor
public class AbsenceServiceImpl implements AbsenceService {

    private final GershwinService gershwinService;
    private final AbsenceRepository absenceRepository;
    private final ActionMapper actionMapper;
    private final AffiliationService affiliationService;

    @Override
    public List<Absence> updateOrDelete(List<ActionAbsenceDto> actionAbsences) {
        Map<Action, List<ActionAbsenceDto>> actionListMap = actionAbsences.stream().collect(Collectors.groupingBy(ActionAbsenceDto::getAction));
        List<ActionAbsenceDto> actionAbsenceDtoToSave = actionListMap.getOrDefault(Action.CREATE, new ArrayList<>());
        actionAbsenceDtoToSave.addAll(actionListMap.getOrDefault(Action.UPDATE, new ArrayList<>()));
        List<Absence> absenceToSave = actionMapper.toAbsences(actionAbsenceDtoToSave).stream().peek(absence -> {
            Optional<Absence> absenceFromDb = absenceRepository
                .findByMatriculeCollaborateurAndDate(absence.getMatriculeCollaborateur(), absence.getDate());
            absence.setId(absenceFromDb.map(Absence::getId).orElse(null));
        }).collect(toList());
        List<ActionAbsenceDto> actionAbsenceDtoToDelete = actionListMap.getOrDefault(Action.DELETE, new ArrayList<>());
        absenceRepository.deleteAll(actionMapper.toAbsences(actionAbsenceDtoToDelete));
        return absenceRepository.saveAll(absenceToSave);
    }

    @Override
    public List<Absence> findAbsences(Long idEquipe, List<Collaborateur>  collaborateurs, LocalDate dateDebut, LocalDate dateFin) {
        List<Absence> absences = new ArrayList<>();
        List<String> matricules = collaborateurs.stream().map(Collaborateur::getMatricule)
            .collect(toList());
        List<Absence> absencesEqc = absenceRepository.findByMatriculeCollaborateurInAndDateBetween(matricules, dateDebut, dateFin);
        List<Absence> absencesGershwin = gershwinService.findAbsence(idEquipe, collaborateurs, dateDebut, dateFin);
        //Merge absences
        handleDuplicates(absencesEqc, absencesGershwin);
        handleSameDayDifferentPeriod(absencesEqc, absencesGershwin);
        absences.addAll(absencesEqc);
        absences.addAll(absencesGershwin);

        return absences;
    }

    private void handleSameDayDifferentPeriod(List<Absence> absencesEqc, List<Absence> absencesGershwin) {
        List<Absence> absencesToRemove = new ArrayList<>();
    	absencesEqc.forEach(absence -> {
            Optional<Absence> absenceGershwin = getAbsence(absencesGershwin, absence.getMatriculeCollaborateur(), absence.getDate());
	        absenceGershwin.ifPresent(ag -> {
		        Intervalle intervalle = ag.getIntervalle();
		        // Absence GERSHWIN toute la journée -> supprimer l'absence EQC
		        if (intervalle == Intervalle.TOUTE_JOURNEE) {
			        absencesToRemove.add(absence);
			        absenceRepository.delete(absence);
		        }
		        // Gérer les demi-journées
		        else if (absence.getIntervalle() == Intervalle.TOUTE_JOURNEE) {
		        	Intervalle newIntervalle = (intervalle == Intervalle.MATIN) ? Intervalle.APRES_MIDI : Intervalle.MATIN;
		        	absence.setIntervalle(newIntervalle);
			        absenceRepository.save(absence);
		        }
	        });
        });
	    absencesEqc.removeAll(absencesToRemove);
    }

    private void handleDuplicates(List<Absence> absencesEqc, List<Absence> absencesGershwin) {
        List<Absence> duplicateAbsences = absencesEqc.stream()
            .filter(absencesGershwin::contains)
            .collect(toList());
        duplicateAbsences.forEach(absenceRepository::delete);
        absencesEqc.removeAll(duplicateAbsences);
    }

    private Optional<Absence> getAbsence(List<Absence> absences, String matricule, LocalDate date) {
        return absences.stream()
		        .filter(absence -> absence.getMatriculeCollaborateur().equals(matricule) && absence.getDate().equals(date))
		        .findFirst();
    }

    @Override
    public void removeAll(String matricule) {
        absenceRepository.deleteAllByMatriculeCollaborateurAndDateAfter(matricule, LocalDate.now().minusDays(1));
    }

    @Override
    public AbsenceGershwinDto findAbsence(PlanningSearchDto planningSearch) {
        List<Affiliation> affiliations = affiliationService.findByPlanningSearchDto(planningSearch);
        if (!affiliations.isEmpty()) {
            List<Collaborateur> collaborateurs = affiliations.stream().map(Affiliation::getCollaborateur).distinct().collect(toList());
            List<Absence> absences = findAbsences(planningSearch.getCodeServiceTraitement(), collaborateurs, planningSearch.getDateDebut(), planningSearch.getDateFin());
            return AbsenceGershwinDto.fromDomain(absences);
        }
        return new AbsenceGershwinDto();
    }

    @Override
    public void supprimerSemaine(SuppressionSemaineDto dto) {
        if (!dto.getMatricules().isEmpty()) {
            absenceRepository.deleteAllByMatriculeCollaborateurInAndDateBetween(dto.getMatricules(),
                dto.getDateDebut().minusDays(1), dto.getDateFin().plusDays(1));
        }
    }
}
