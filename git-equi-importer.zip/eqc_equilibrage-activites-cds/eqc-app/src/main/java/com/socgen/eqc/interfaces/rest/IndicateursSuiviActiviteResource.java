package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.IndicateursSuiviActiviteService;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Path("/indicateurs-suivi-activite")
@Api(value = "indicateurs-suivi-activite")
public class IndicateursSuiviActiviteResource {
    @Autowired
    private IndicateursSuiviActiviteService indicateursSuiviActiviteService;

    @GET
    @ApiOperation(value = "Récupération des indicateurs suivi activite", notes = "Récupération des indicateurs suivi activite")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les indicateurs suivi activite sont bien récupérées")
    })
    public Response getStockTrait(@BeanParam IndicateurInputDto indicateurInputDto) {

        return Response.ok(indicateursSuiviActiviteService.getIndicateurSuiviActivite(indicateurInputDto).toString()).build();
    }
}
