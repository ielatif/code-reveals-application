package com.socgen.eqc.domain.model;

import com.socgen.eqc.application.exception.BusinessException;

import java.util.stream.Stream;

public enum CouleurCarte {

    MAGENTA("Magenta"),
    VOLCANO("Volcano"),
    ORANGE("Orange"),
    GOLD("Gold"),
    LIME("Lime"),
    GREEN("Green"),
    BLUE("Blue"),
    GREEKBLUE("GreekBlue"),
    RED("Red");

    private String code;

    CouleurCarte(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static CouleurCarte of(String code) {
        return Stream.of(CouleurCarte.values())
                .filter(p -> p.getCode().equals(code))
                .findFirst()
                .orElseThrow(() -> new BusinessException(String
                        .format("Le code couleur %s n'est pas reconnu pour cette affectation.", code)));
    }
}
