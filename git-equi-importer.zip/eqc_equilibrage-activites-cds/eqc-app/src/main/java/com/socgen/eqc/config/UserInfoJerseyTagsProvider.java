package com.socgen.eqc.config;

import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.binder.jersey.server.JerseyTags;
import io.micrometer.core.instrument.binder.jersey.server.JerseyTagsProvider;
import lombok.RequiredArgsConstructor;
import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.ContainerResponse;
import org.glassfish.jersey.server.monitoring.RequestEvent;

import java.util.List;

@RequiredArgsConstructor
public class UserInfoJerseyTagsProvider implements JerseyTagsProvider {

    private final UserInfoCustomTagsExtractor userInfoCustomTagsExtractor;

    @Override
    public Iterable<Tag> httpRequestTags(RequestEvent event) {

        ContainerRequest request = event.getContainerRequest();
        ContainerResponse response = event.getContainerResponse();

        Tags tags = Tags.of(JerseyTags.method(request), JerseyTags.uri(event),
                JerseyTags.exception(event), JerseyTags.status(response), JerseyTags.outcome(response));

        List<String> authorizationHeader = request.getRequestHeader("Authorization");
        final String authorization = authorizationHeader != null ? authorizationHeader.get(0) : "";

        return tags.and(this.userInfoCustomTagsExtractor.extractTagsFromAuthHeader(authorization));
    }

    @Override
    public Iterable<Tag> httpLongRequestTags(RequestEvent event) {
        return httpRequestTags(event);
    }
}
