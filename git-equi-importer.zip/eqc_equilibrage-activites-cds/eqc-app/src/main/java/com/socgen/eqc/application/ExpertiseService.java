package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.DefaultExpertise;
import com.socgen.eqc.domain.model.Expertise;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ExpertiseDto;

import javax.persistence.Tuple;
import java.util.List;
import java.util.Set;

public interface ExpertiseService {

    List<Expertise> getCommonExpertise();
    List<Expertise> findByCodesActivites(List<String> codesActivites);
    Expertise getExpertiseByActiviteAndNiveau(String codeActivite, Long idNiveau);
    Set<Expertise> getExpertiseByActivite(String codeActivite);
    List<Tuple> getExpertiseByActivites(Set<String> codeActivite);

    List<Expertise> findByCodeTetePerimetre(String codeTetePerimetre);

    Set<DefaultExpertise> updateDefaultExpertise(String codeActivite, List<ExpertiseDto> expertiseDto);
}
