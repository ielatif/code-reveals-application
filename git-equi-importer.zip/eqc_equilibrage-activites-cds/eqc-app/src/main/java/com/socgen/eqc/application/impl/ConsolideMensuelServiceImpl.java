package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.CollaborateurService;
import com.socgen.eqc.application.ConsolideMensuelService;
import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import com.socgen.eqc.infrastructure.persistance.ConsolideMensuelRepository;
import com.socgen.eqc.interfaces.rest.dto.ConsolideMensSearch;
import com.socgen.eqc.interfaces.rest.dto.ConsolideMensuelDto;
import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;
import com.socgen.eqc.mapper.ConsolideMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class ConsolideMensuelServiceImpl implements ConsolideMensuelService {


    private final ConsolideMensuelRepository consolideMensuelRepository;
    private final ConsolideMapper consolideMapper;
    private final CollaborateurService collaborateurService;

    @Override
    public List<ConsolideMensuelDto> getConsolideMensuel(ConsolideMensSearch consolideMensSearch) {

        List<ConsolideMensuel> consolideMensuels = consolideMensuelRepository
                .findAllByStActifAndMonthYearConsolide(consolideMensSearch
                        .getIdServiceTraitement(), consolideMensSearch.getDateDebut());

        List<ConsolideMensuelDto> consolideEqpAndRenfortIntraUg =  getConsolideEqpAndIntraUg(consolideMensuels);

        List<ConsolideMensuelDto> consolideRenfortInterUg =  getConsolideForRenfortInterUg(consolideMensuels);
        return Stream.concat(consolideEqpAndRenfortIntraUg.stream(), consolideRenfortInterUg.stream())
                .collect(Collectors.toList());
    }

    private ConsolideMensuelDto buildConsolideMensuel(Map.Entry<String, List<ConsolideMensuel>> consolideEntry,
                                                      CollaborateurDto collaborateur, Boolean isRenfortInterUg) {
        return ConsolideMensuelDto.builder().collaborateurMatricule(collaborateur.getMatricule())
                .collaborateurNom(collaborateur.getNom()).collaborateurPrenom(collaborateur.getPrenom())
                .isRenfortInterUg(isRenfortInterUg)
                .consolides(consolideMapper.consolideMensuelListToConsolideMensTauxList(consolideEntry.getValue()))
                .build();
    }

    private List<ConsolideMensuelDto> getConsolideForRenfortInterUg(List<ConsolideMensuel> consolideMensuels) {

        return buildCommonConsolide(consolideMensuels, true);
    }

    private List<ConsolideMensuelDto> getConsolideEqpAndIntraUg(List<ConsolideMensuel> consolideMensuels) {

       return buildCommonConsolide(consolideMensuels, false);
    }

    private  List<ConsolideMensuelDto> buildCommonConsolide(List<ConsolideMensuel> consolideMensuels, Boolean isRenfortInterUg) {

        Map<String, List<ConsolideMensuel>> consolideGroupedByMatricules = consolideMensuels.stream()
                .filter(consolideMensuel -> isRenfortInterUg.equals(consolideMensuel.getIsRenfortInterUg()))
                .collect(Collectors.groupingBy(ConsolideMensuel::getMatriculeCollaborateur));

        return consolideGroupedByMatricules.entrySet().stream().map(consolideEntry -> {
            CollaborateurDto collaborateur = collaborateurService.getCollaborateursByMatriculeFromEqc(Collections.singletonList(consolideEntry.getKey())).get(0);

            return buildConsolideMensuel(consolideEntry, collaborateur, isRenfortInterUg);
        }).collect(Collectors.toList());
    }
}
