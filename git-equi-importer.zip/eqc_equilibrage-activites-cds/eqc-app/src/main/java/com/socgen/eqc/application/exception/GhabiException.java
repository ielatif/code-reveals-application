package com.socgen.eqc.application.exception;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Getter
@Slf4j
public class GhabiException extends Exception {

    private final HttpStatus httpStatus;

    public GhabiException(String message) {
        super(message);
        this.httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
    }

    public GhabiException(String message, Exception e) {
        super(message, e);
        this.httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
    }
}
