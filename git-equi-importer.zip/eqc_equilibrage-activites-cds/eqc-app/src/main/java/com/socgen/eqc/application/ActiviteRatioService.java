package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.RatioType;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteRatioDto;

import java.util.List;

public interface ActiviteRatioService {

    List<ActiviteRatioDto> getAllActiviteRatio();
    List<ActiviteRatioDto> getActiviteRatioByType(Long ratioType);
    List<RatioType> getRatioTypes();

    List<ActiviteRatioDto> getAllActiviteRatioByTetePerimetre(String tetePerimetre);
}
