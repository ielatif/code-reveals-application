package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.AffiliationSousEquipe;
import com.socgen.eqc.interfaces.rest.dto.AffiliationSousEquipeDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AffiliationSousEquipeMapper {

    @Mapping(target = "idAffiliation", source = "affiliation.id")
    @Mapping(target = "idSousEquipe", source = "sousEquipe.id")
    AffiliationSousEquipeDto toDto(AffiliationSousEquipe affiliationSousEquipe);

    List<AffiliationSousEquipeDto> toDtos(List<AffiliationSousEquipe> affiliationSousEquipes);
}
