package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.SousEquipe;
import com.socgen.eqc.interfaces.rest.dto.SousEquipeDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SousEquipeMapper {

    @Mapping(target = "equipeId", source = "equipe.code")
    SousEquipeDto toDto(SousEquipe sousEquipe);

    List<SousEquipeDto> toDtoList(List<SousEquipe> sousEquipes);
}
