package com.socgen.eqc.config;

import com.socgen.digital.agence.metric.contributor.ContributorMetricsService;
import com.socgen.digital.agence.metric.contributor.ContributorMetricsService.TypeContributor;
import org.apache.commons.lang3.time.StopWatch;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.client.ClientResponseFilter;
import java.time.Duration;
import java.util.Optional;

@Priority(Priorities.USER)
public class EqcContributorMetricsClientFilter implements ClientRequestFilter, ClientResponseFilter {

	private static final String METRIC_TIMER = "metric.timer";

	private Optional<ContributorMetricsService> contributorsMetrics;

	public EqcContributorMetricsClientFilter(final Optional<ContributorMetricsService> contributorsMetrics) {
		this.contributorsMetrics = contributorsMetrics;
	}

	@Override
	public void filter(final ClientRequestContext requestContext) {

		this.contributorsMetrics.ifPresent((final ContributorMetricsService cm) -> requestContext.setProperty(METRIC_TIMER, StopWatch.createStarted()));
	}

	@Override
	public void filter(final ClientRequestContext requestContext, final ClientResponseContext responseContext) {

		this.contributorsMetrics.ifPresent((final ContributorMetricsService cm) -> {

			final StopWatch timer = (StopWatch) requestContext.getProperty(METRIC_TIMER);
			timer.stop();

			cm.updateContributor(
					TypeContributor.REST,
					requestContext.getMethod(),
					responseContext.getStatus(),
					requestContext.getUri().getPath(),
					Duration.ofMillis(timer.getTime())
			);
		});
	}
}

