package com.socgen.eqc.infrastructure.batch.exception;

public class EqcBatchException extends RuntimeException {

    public EqcBatchException(String message) {
        super(message);
    }
}
