package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.ActiviteRatioService;
import com.socgen.eqc.domain.model.RatioType;
import com.socgen.eqc.infrastructure.persistance.ActiviteRatioRepository;
import com.socgen.eqc.infrastructure.persistance.RatioTypeRepository;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteRatioDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ActiviteRatioServiceImpl implements ActiviteRatioService {

    private final ActiviteRatioRepository activiteRatioRepository;
    private final RatioTypeRepository ratioTypeRepository;

    @Override
    public List<ActiviteRatioDto> getAllActiviteRatio() {
        return ActiviteRatioDto.toListDto(activiteRatioRepository.findAll());
    }

    @Override
    public List<ActiviteRatioDto> getActiviteRatioByType(Long ratioType) {
        return ActiviteRatioDto.toListDto(activiteRatioRepository.findByratioTypeCode(ratioType));
    }

    @Override
    public List<RatioType> getRatioTypes() {
        return ratioTypeRepository.findAll();
    }

    @Override
    public List<ActiviteRatioDto> getAllActiviteRatioByTetePerimetre(String tetePerimetre) {
        return ActiviteRatioDto.toListDto(activiteRatioRepository.findByTetePerimetre(tetePerimetre));
    }
}
