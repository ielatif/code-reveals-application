package com.socgen.eqc.infrastructure.ghabi.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class AccessSgConnectTokenResponse  implements Serializable {
  @JsonProperty("access_token")
  private String accessToken = null;

  @JsonProperty("scope")
  private String scope = null;

  @JsonProperty("expires_in")
  private String expiresIn = null;

  @JsonProperty("token_type")
  private String tokenType = null;

  public AccessSgConnectTokenResponse accessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }
}