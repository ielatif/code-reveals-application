package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SaisieGlobaleOutputDto implements Serializable {

    private Long processusId;

    private String processusCode;

    private String matricule;

    private String codeST;

    private Long stockRecus;

    private Long stockTermines;

    private LocalDate dateSaisie;

}
