package com.socgen.eqc.infrastructure.batch.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ExceptionBatchMessage {

    CSM_ERROR_GENERATION_CONSOLIDE("CSM_ERR_001", "Une erreur est produite lors de la génération du consolide mensuel du Mois/Année => %s / %s, Error [%s] "),
    CSM_ERROR_WHEN_GET_HOLIDAY_DAY("CSM_ERR_002", "Une erreur est produite lors de la récupération des jours fériés");

    @Getter
    private String code;

    private String message;

    public String formatErrorMessage(String... args) {
        return String.format(message, (Object[]) args);
    }

}
