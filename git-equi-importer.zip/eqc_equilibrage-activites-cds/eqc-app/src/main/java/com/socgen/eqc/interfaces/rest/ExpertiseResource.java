package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.ExpertiseService;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ExpertiseDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/expertises")
@Api(value = "expertises")
public class ExpertiseResource {

    @Autowired
    private ExpertiseService expertiseService;

    @GET
    @ApiOperation(value = "Récupération des expertises", notes = "Récupération des expertises")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les expertises sont bien récupérées")
    })
    @Path("/tete-perimetre/{codeTetePerimetre}")
    public Response getAllExpertises(@PathParam("codeTetePerimetre") String codeTetePerimetre) {
        return Response.ok(ExpertiseDto.fromDomain(expertiseService.findByCodeTetePerimetre(codeTetePerimetre)))
            .build();
    }


    @PUT
    @ApiOperation(value = "Mettre à jour d'une expertise", notes = "Mettre à jour d'une expertise")
    @ApiResponses({
            @ApiResponse(code = 201, message = "L'expertise est bien mise à jour"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    @Path("/{codeActivite}")
    public Response updateDefaultExpertise(@PathParam("codeActivite") String codeActivite, List<ExpertiseDto> expertiseDto) {
        expertiseService.updateDefaultExpertise(codeActivite, expertiseDto);
        return Response.noContent().build();
    }
}
