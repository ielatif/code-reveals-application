package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Collaborateur;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CollaborateurRepository extends JpaRepository<Collaborateur, Long> {

    List<Collaborateur> findByMatriculeIn(List<String> matricules);
}
