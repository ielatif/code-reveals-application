package com.socgen.eqc.interfaces.rest.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@ToString
@SuperBuilder
public class ActionAffectationDto extends ActionDto {

    private String codeActivite;

    private Long pourcentage;

    private Long codeServiceTraitement;

    private boolean forRenfort;

    private Double nombreDossier;

    private int ordre;

    private long idExpertise;
}
