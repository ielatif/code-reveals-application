package com.socgen.eqc.domain.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@EqualsAndHashCode
@Entity(name = "SOUS_EQUIPE")
@Table(name = "SOUS_EQUIPE")
public class SousEquipe implements Serializable {

    private static final long serialVersionUID = 2873150734153585955L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;


    @Column(name = "libelle", nullable = false, unique = true)
    private String libelle;

    @Column(name = "description")
    private String description;

    @ManyToOne
    @JoinColumn(name = "equipe_id", nullable = false)
    private Equipe equipe;

    @OneToMany(mappedBy = "sousEquipe", fetch = FetchType.LAZY)
    private Set<AffiliationSousEquipe> affiliationSousEquipes;
}
