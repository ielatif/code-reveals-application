package com.socgen.eqc.config;

import com.socgen.dga.idp.jaxrs.SgSignInFeature;
import com.socgen.dga.idp.jaxrs.filter.SgSignInConfigProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.core.type.filter.AssignableTypeFilter;
import org.springframework.util.ClassUtils;

import javax.annotation.PostConstruct;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Path;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.logging.Level;
import java.util.stream.Collectors;
import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;
import io.swagger.models.Contact;
import io.swagger.models.Info;
import io.swagger.models.License;
import io.swagger.models.Swagger;
import io.swagger.parser.SwaggerParser;

@Configuration
@RequiredArgsConstructor
@ApplicationPath("/api")
@Slf4j
public class ApiJerseyConfig extends ResourceConfig {

	private static final String REST_PACKAGE = "com.socgen.eqc.interfaces.rest";

	public static final String PATH_SWAGGER_DEF_YAML = "swagger/swagger-def.yaml";

	@Value("${spring.jersey.application-path:/}")
	private String apiPath;

	private final ApplicationProperties properties;

	@Autowired
	private Environment env;

	@PostConstruct
	public void init() {
		register(NoCacheFilter.class);
		registerSgSignIn();
		registerEndPoints();
		// configuration pour avoir les fllux WS console + jerseyXxx.log
		register(new LoggingFeature(java.util.logging.Logger.getLogger("jerseyEqc"), Level.INFO,
				LoggingFeature.Verbosity.PAYLOAD_TEXT, LoggingFeature.DEFAULT_MAX_ENTITY_SIZE));
		configureSwagger();
	}

	private void registerEndPoints() {
		scanPackage4JerseyAndSpringboot(REST_PACKAGE);
	}

	private void registerSgSignIn() {
		if (properties.getSgSignIn().isEnabled()) {
			register(SgSignInFeature.class);
			register(SgSignInConfigProvider.class);
			register(CustomUserInfoFilter.class);
		}
	}

	/**
	 * Jersey 2 ne peut pas scanner un package avec Springboot (dans un fat jar), on le fait pour lui
	 * Voir https://github.com/spring-projects/spring-boot/issues/1468
	 */
	private void scanPackage4JerseyAndSpringboot(final String packageName) {
		final ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
		scanner.addIncludeFilter(new AnnotationTypeFilter(Provider.class));
		scanner.addIncludeFilter(new AnnotationTypeFilter(Path.class));
		scanner.addIncludeFilter(new AssignableTypeFilter(ExceptionMapper.class));
		// add more annotation filters if you need
		registerClasses(scanner.findCandidateComponents(packageName).stream()
				.map(beanDefinition -> ClassUtils.resolveClassName(beanDefinition.getBeanClassName(), ApiJerseyConfig.class.getClassLoader()))
				.collect(Collectors.toSet()));
	}

	private void configureSwagger() {
		if (!env.acceptsProfiles(Profiles.of("swagger"))) {
			log.info("Swagger is disabled");
		} else {
			register(SwaggerSerializers.class);
			// On va configurer une config de base swagger utilisable dans swagger-ui sur poste local
			// et une configuration pour ssop
			// Pour avoir la configuration ssop, il suffit d'ajouter le paramètre

			BeanConfig config = new BeanConfig();

			Info info = new Info()
					.title(StringUtils.trimToNull(properties.getSwagger().getTitle()))
					.version(StringUtils.trimToNull(properties.getSwagger().getVersion()))
					.description(StringUtils.trimToNull(properties.getSwagger().getDescription()))
					.termsOfService(StringUtils.trimToNull(properties.getSwagger().getTermsOfServiceUrl()));

			if (StringUtils.isNotBlank(properties.getSwagger().getContactName())
					|| StringUtils.isNotBlank(properties.getSwagger().getContactEmail())
					|| StringUtils.isNotBlank(properties.getSwagger().getContactUrl())) {
				info.setContact(new Contact().name(StringUtils.trimToEmpty(properties.getSwagger().getContactName()))
						.email(StringUtils.trimToNull(properties.getSwagger().getContactEmail()))
						.url(StringUtils.trimToNull(properties.getSwagger().getContactUrl())));
			}

			if (StringUtils.isNotBlank(properties.getSwagger().getLicense())
					|| StringUtils.isNotBlank(properties.getSwagger().getLicenseUrl())
					|| StringUtils.isNotBlank(properties.getSwagger().getTermsOfServiceUrl())) {
				info.setLicense(new License()
						.name(StringUtils.trimToEmpty(properties.getSwagger().getLicense()))
						.url(StringUtils.trimToNull(properties.getSwagger().getLicenseUrl())));
			}

			// On met volontairement le x-ibm-name à vide dans la configuration de base
			// Car cela provoquera une erreur à l'importation dans le IBM API Connect
			// Ce qui évitera d'importer par erreur la config swagger de base et non pas celle
			// pour ssop (cad avec le bon basepath et config de securite)
			info.getVendorExtensions().put("x-ibm-name", "");

			// Le consumes est important car la plateforme SSOP rejettera les requêtes (avec 404) qui ne sont pas de
			// content-type compatible
			config.getSwagger().info(info)
					.produces("application/json")
					.consumes("application/json");
			config.setSchemes(properties.getSwagger().getSchemes());

			// En local, pour swagger-ui ou autre, le basepath des points d'entrée Jersey
			// Pour la config ssop, il sera surchargé par le basepath au niveau de la passerelle
			// Note : pour avoir la version ssop du swagger.yaml : https://localhost:8444/api/swagger.yaml?ssop
			config.setBasePath(this.apiPath);

			config.setHost(StringUtils.trimToNull(properties.getSwagger().getHost()));

			config.setResourcePackage(REST_PACKAGE);

			// On scan pour récuperer les infos des annotations
			config.setScan();

			// On obtient une configuration ssop (securité, basepath ssop, etc.)
			final Swagger swaggerSsop = obtenirSwaggerWithIbmConfiguration(config.getSwagger());

			// Permet de renvoyer la version ssop si ssop est passé en paramètre
			register(new ApiListingResource() {
				@Override
				protected Swagger process(Application app, ServletContext servletContext, ServletConfig sc,
										  HttpHeaders headers, UriInfo uriInfo) {
					if (uriInfo != null && uriInfo.getQueryParameters().containsKey("ssop")) {
						if (swaggerSsop == null) {
							throw new RuntimeException(String.format("Configuration SSOP non disponible " +
									"(vérifiez le fichier '%s')", PATH_SWAGGER_DEF_YAML));
						}
						return swaggerSsop;
					} else {
						return super.process(app, servletContext, sc, headers, uriInfo);
					}
				}
			});
		}

	}

	private Swagger obtenirSwaggerWithIbmConfiguration(Swagger swaggerToMerge) {
		Swagger swaggerSsop = new SwaggerParser().read(PATH_SWAGGER_DEF_YAML);
		if (swaggerSsop == null || swaggerSsop.getInfo() == null) {
			log.error("Le fichier '{}' n'a pas permis de charger une définition swagger ssop correcte",
					PATH_SWAGGER_DEF_YAML);
			return null;
		}
		swaggerSsop.getInfo().mergeWith(swaggerToMerge.getInfo());
		if (StringUtils.isBlank(swaggerSsop.getBasePath())) {
			swaggerSsop.setBasePath(swaggerToMerge.getBasePath());
		}
		if (swaggerToMerge.getTags() != null && !swaggerToMerge.getTags().isEmpty()) {
			if (swaggerSsop.getTags() == null) {
				swaggerSsop.setTags(swaggerToMerge.getTags());
			} else {
				swaggerSsop.getTags().addAll(swaggerToMerge.getTags());
			}
		}
		swaggerSsop.paths(swaggerToMerge.getPaths());
		// On récupère les définitions
		swaggerSsop.setDefinitions(swaggerToMerge.getDefinitions());
		if (swaggerSsop.getExternalDocs() == null) {
			swaggerSsop.setExternalDocs(swaggerToMerge.getExternalDocs());
		}
		swaggerSsop.setParameters(swaggerToMerge.getParameters());
		swaggerSsop.setResponses(swaggerToMerge.getResponses());

		return swaggerSsop;
	}
}