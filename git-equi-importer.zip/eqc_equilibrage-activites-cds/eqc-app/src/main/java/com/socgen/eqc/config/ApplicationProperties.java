package com.socgen.eqc.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("app")
@Getter
@Setter
public class ApplicationProperties {

    private String trigram;
    private String codeIrt;
    private final SgSignIn sgSignIn = new SgSignIn();
    private final Metrics metrics = new Metrics();
    private final People people = new People();
    private final Rbv rbv = new Rbv();
    private final Gershwin gershwin = new Gershwin();
    private final Smbo smbo = new Smbo();
    private final SgConnect sgConnect = new SgConnect();
    private final Ghabi ghabi = new Ghabi();
    private final Async async = new Async();
    private final Swagger swagger = new Swagger();

    @Getter
    public static class Metrics {
        private final Logs logs = new Logs();

        @Getter
        @Setter
        public static class Logs {
            private boolean enabled = false;
            private boolean jvmEnabled = false;
            private boolean consoleEnabled = false;
            private long reportFrequency = 60;
        }
    }

    @Getter
    @Setter
    public static class SgSignIn {
        private boolean enabled = true;
        private String clientId;
        private String clientSecret;
        private String redirectUrl;
        private String serverUrl;
        private boolean acceptOnlyRequestsFromSSOP = true;
    }

    @Getter
    @Setter
    public static class People {
        private String serverUrl;
    }

    @Getter
    @Setter
    public static class Rbv {
        private String redirectUrl;
    }

    @Getter
    @Setter
    public static class Gershwin {
        private String clientId;
        private String clientSecret;
        private String grantType;
        private String scope;
        private String serverUrl;
        private String authorizationPath;
        private String calendarPath;
        private String approversPath;
    }

    @Getter
    @Setter
    public static class Smbo {
        private String serverUrl;
        private String referentielActivitePath;
        private String referentielTetePerimetrePath;
        private String saisieGlobalePath;
    }

    @Getter
    @Setter
    public static class SgConnect {
        private String serverUrl;
        private String username;
        private String password;
        private String scope;
    }

    @Getter
    @Setter
    public static class Ghabi {
        private String serverUrl;
        private String extensionPerimetrePath;
    }

    @Getter
    @Setter
    public static class Async {

        private int corePoolSize = 2;
        private int maxPoolSize = 50;
        private int queueCapacity = 10000;
    }

    @Getter
    @Setter
    public static class Swagger {

        private String title;

        private String description;

        private String version;

        private String host;

        private String termsOfServiceUrl;

        private String contactName;

        private String contactUrl;

        private String contactEmail;

        private String license;

        private String licenseUrl;

        private String[] schemes;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public String getTermsOfServiceUrl() {
            return termsOfServiceUrl;
        }

        public void setTermsOfServiceUrl(String termsOfServiceUrl) {
            this.termsOfServiceUrl = termsOfServiceUrl;
        }

        public String getContactName() {
            return contactName;
        }

        public void setContactName(String contactName) {
            this.contactName = contactName;
        }

        public String getContactUrl() {
            return contactUrl;
        }

        public void setContactUrl(String contactUrl) {
            this.contactUrl = contactUrl;
        }

        public String getContactEmail() {
            return contactEmail;
        }

        public void setContactEmail(String contactEmail) {
            this.contactEmail = contactEmail;
        }

        public String getLicense() {
            return license;
        }

        public void setLicense(String license) {
            this.license = license;
        }

        public String getLicenseUrl() {
            return licenseUrl;
        }

        public void setLicenseUrl(String licenseUrl) {
            this.licenseUrl = licenseUrl;
        }

        public String[] getSchemes() {
            return schemes;
        }

        public void setSchemes(String[] schemes) {
            this.schemes = schemes;
        }
    }

    public Swagger getSwagger() {
        return swagger;
    }
}
