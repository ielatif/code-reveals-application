package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.ExportEtpService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Path("/etps")
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Api(value = "etps")
public class ExportEtpResource {
    @Autowired
    private ExportEtpService exportEtpService;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Récupération des ETP sous le format JSON", notes = "Récupération des ETP sous le format JSON")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les ETP sont bien récupérés")
    })
    public Response exportEtpJson(@QueryParam("from") String from,
                                     @QueryParam("to") String to) {

        LocalDate fromDate = LocalDate.parse(from, DateTimeFormatter.ISO_DATE);
        LocalDate toDate = LocalDate.parse(to, DateTimeFormatter.ISO_DATE);
        return Response.ok(this.exportEtpService.getEtps(fromDate, toDate))
                .build();
    }

    @GET
    @Produces({MediaType.APPLICATION_OCTET_STREAM})
    @ApiOperation(value = "Récupération des ETP sous le format CSV", notes = "Récupération des ETP sous le format CSV")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les ETP sont bien récupérés")
    })
    public Response exportEtpCsv(@QueryParam("from") String from,
                                     @QueryParam("to") String to) {

        File etpsCsv = this.exportEtpService.getEtpsCsv(from, to);
        return Response.ok(etpsCsv, MediaType.APPLICATION_OCTET_STREAM_TYPE)
                .header("Content-Disposition", "attachment; filename=" + etpsCsv.getName())
                .build();
    }
}

