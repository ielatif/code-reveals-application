package com.socgen.eqc.domain.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "ACTIVITE_PARAMS")
@Builder
@Getter
@Setter
public class ActiviteParams implements Serializable {

    private static final long serialVersionUID = 2873150734153588722L;

    @Id
    @Column(name = "CODE", nullable = false, unique = true)
    private String code;

    @Column(name = "CODE_FAMILLE")
    private String codeFamille;

    @Column(name = "ORDRE")
    private int ordre;

    @ManyToOne
    @JoinColumn(name = "ACTIVITE_RATIO_ID")
    private ActiviteRatio activiteRatio;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "CODE_ACTIVITE")
    private Set<Expertise> expertises = new HashSet<>();

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "CODE_ACTIVITE")
    private Set<DefaultExpertise> defaultExpertises = new HashSet<>();

    @Column(name = "unite", nullable = false)
    private Unite unite;

    @Column(name = "type")
    private TypeActivite type;

    @Column(name = "MASK_DATE")
    private LocalDate maskDate;

    @Column(name = "mask_date_pilotage")
    private LocalDate maskDatePilotage;

    @Column(name = "mask_date_competence")
    private LocalDate maskDateCompetence;
}
