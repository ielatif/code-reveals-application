package com.socgen.eqc.domain.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode
@Builder
@Entity(name = "RENFORT")
@Table(name = "RENFORT", uniqueConstraints = {@UniqueConstraint(columnNames = {"matricule_collaborateur", "date", "intervalle", "code_st_rattachement", "code_st_aide"})})
public class Renfort implements Serializable {

    private static final long serialVersionUID = 2873150734153585911L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @Column(name = "date", nullable = false)
    private LocalDate date;

    @Column(name = "intervalle", nullable = false)
    private Intervalle intervalle;

    @Column(name = "code_st_rattachement", nullable = false)
    private Long codeStRattachement;

    @Column(name = "code_cds_rattachement", nullable = false)
    private Long codeCdsRattachement;

    @Column(name = "code_ug_rattachement", nullable = false)
    private Long codeUgRattachement;

    @Column(name = "code_cds_aide", nullable = false)
    private Long codeCdsAide;

    @Column(name = "code_ug_aide", nullable = false)
    private Long codeUgAide;

    @OneToMany(mappedBy = "renfort", fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    private Set<Affectation> affectations;

    @ManyToOne
    @JoinColumn(name = "matricule_collaborateur", nullable = false)
    private Collaborateur collaborateur;

    @ManyToOne
    @JoinColumn(name = "code_st_aide", nullable = false)
    private Equipe equipe;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_extension_perimetre")
    private ExtensionPerimetre extensionPerimetre;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "parametres_carte_id", referencedColumnName = "id")
    private ParametresCarte parametresCarte;

    public boolean isRenfortIntraFiliere(List<Long> filieres) {
        return filieres.containsAll(Arrays.asList(codeCdsRattachement, codeCdsAide))
                && codeCdsRattachement.equals(codeCdsAide);
    }

    public boolean isRenfortInterUG() {
        return !codeUgRattachement.equals(codeUgAide);
    }

    public boolean isAllowedGhabiExtension(List<Long> filieres) {
        return isRenfortIntraFiliere(filieres) && isRenfortInterUG();
    }

    public boolean isRenfortIntraDay() {
        return this.date.isEqual(LocalDate.now());
    }
}
