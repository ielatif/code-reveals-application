package com.socgen.eqc.infrastructure.batch.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AffectationEqcTotal {

    private String matriculeCollaborateur;

    private String codeActivite;

    private Long cumulTauxAffectationByActivite;

    private BigDecimal tauxActiviteSumeau;

    private String idActiviteSumeau;

    private String sumeauLibelleActivite;

    private Long stActif;

    private Long cdsRattachement;

    private Long ugRattachement;

    private Long stRattachement;
}
