package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.AffiliationSousEquipe;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AffiliationSousEquipeRepository extends JpaRepository<AffiliationSousEquipe, Long> {

    List<AffiliationSousEquipe> findAllBySousEquipeIdIn(List<Long> idsSousEquipe);
    List<AffiliationSousEquipe> findAllByAffiliationId(Long AffiliationId);
}
