package com.socgen.eqc.interfaces.rest.dto;

import com.socgen.eqc.domain.model.Intervalle;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@ToString
@SuperBuilder
public class ActionAbsenceDto extends ActionDto {

    private Intervalle intervalle;
}
