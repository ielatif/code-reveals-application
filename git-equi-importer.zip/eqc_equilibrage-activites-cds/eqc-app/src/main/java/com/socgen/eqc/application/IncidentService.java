package com.socgen.eqc.application;

import com.socgen.eqc.interfaces.rest.dto.IncidentDto;

public interface IncidentService {
    IncidentDto getIncident();
}
