package com.socgen.eqc.config;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public interface GenericGenerator extends IdentifierGenerator {

    default Long getNextSequence(SharedSessionContractImplementor session, Object obj) {
        String query = String.format("select count(%s) from %s",
                session.getEntityPersister(obj.getClass().getName(), obj)
                        .getIdentifierPropertyName(),
                obj.getClass().getSimpleName());
        return (Long)session.createQuery(query).uniqueResult();
    }
}
