package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.TetePerimetreService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/tete-perimetres")
@Api(value = "tete-perimetres")
public class TetePerimetresResource {

    @Autowired
    private TetePerimetreService tetePerimetreService;

    @GET
    @ApiOperation(value = "Récupération des tête de périmetre", notes = "Récupération des tête de périmetre")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les tete périmetre sont bien récupérés")
    })
    public Response getAllTetePerimetres() {
        return Response.ok(tetePerimetreService.getAllTetePerimetres()).build();
    }

}
