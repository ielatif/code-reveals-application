package com.socgen.eqc.application.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.socgen.eqc.application.IndicateurService;
import com.socgen.eqc.infrastructure.persistance.IndicateurEtpRepository;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurEtpInputDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;

@Service
@AllArgsConstructor
public class IndicateurServiceImpl implements IndicateurService {

    public static final String CODE_FAMILLE = "codeFamille";
    public static final String CODE_ACTIVITE = "codeActivite";
    public static final String EQUIPE_ID = "equipeId";
    public static final String ETP_TOTAL_MOYEN = "etpTotalMoyen";
    public static final String ETP_RENFORT_MOYEN = "etpRenfortMoyen";
    private final SmboClient smboClient;

    private final IndicateurEtpRepository indicateurEtpRepository;

    private static final Gson gson = new GsonBuilder().create();

    @Override
    public List<IndicateurActiviteDto> getStockTraiter(IndicateurInputDto indicateurInputDto, Boolean isStockForExtraction) {

        LocalDate dateDebut = LocalDate.parse(indicateurInputDto.getDateDebut());
        LocalDate dateFin = LocalDate.parse(indicateurInputDto.getDateFin());

        Period period = Period.between(dateDebut, LocalDate.now());


        if (dateDebut.isAfter(dateFin) || dateDebut.isAfter(LocalDate.now())) {
            return Collections.emptyList();
        }
        return (
                !isStockForExtraction ||
                        (isStockForExtraction && (
                                (dateFin.isAfter(LocalDate.now()) || dateFin.isEqual(LocalDate.now())) &&
                                                (period.getYears() == 0 && period.getMonths() == 0 && period.getDays() < 7)
                        ))
        ) ?
                smboClient.getIndicateurBrut(indicateurInputDto.getListCodeServiceTraitement(),
                        buildDateDebut(dateDebut, dateFin), buildDateFin(dateFin), indicateurInputDto.getTetePerimetre())
                :
                smboClient.getIndicateurBrut(indicateurInputDto.getListCodeServiceTraitement(),
                dateDebut, dateFin, indicateurInputDto.getTetePerimetre());
    }

    @Override
    public JsonObject getEtps(IndicateurEtpInputDto indicateurEtpInputDto) {
        String[] arrayResult = indicateurEtpInputDto.getListCodeServiceTraitement().split(",");

        List<BigInteger> stCodes = new ArrayList<>();

        Arrays.asList(arrayResult).forEach(code -> stCodes.add(new BigInteger(code)));

        List<JsonObject> etpsBrut = this.indicateurEtpRepository.getEtps(indicateurEtpInputDto.getDateDebut(), indicateurEtpInputDto.getDateFin(), stCodes)
                .stream().filter(item -> !item.get(CODE_FAMILLE).isJsonNull() && !item.get(CODE_ACTIVITE).isJsonNull()).collect(Collectors.toList());

        List<JsonObject> etpRenfort = this.indicateurEtpRepository.getEtpsRenfort(indicateurEtpInputDto.getDateDebut(), indicateurEtpInputDto.getDateFin(), stCodes)
                .stream().filter(item -> !item.get(CODE_FAMILLE).isJsonNull() && !item.get(CODE_ACTIVITE).isJsonNull()).collect(Collectors.toList());

        List<JsonObject> etpsBrutEtRenfort = mergeEtp(etpsBrut, etpRenfort);

        JsonObject payload = new JsonObject();

        payload.add("sts", gson.toJsonTree(stCodes));
        payload.addProperty("dateDebut", indicateurEtpInputDto.getDateDebut());
        payload.addProperty("dateFin", indicateurEtpInputDto.getDateFin());


        final Map<String, List<JsonObject>> etpsPerFamille = etpsBrutEtRenfort.stream().collect(groupingBy(item -> item.get(CODE_FAMILLE).getAsString()));

        final Map<String, Map<String, List<JsonObject>>> etps = etpsBrutEtRenfort.stream().collect(groupingBy(item -> item.get(EQUIPE_ID).getAsString(), groupingBy(item -> item.get(CODE_FAMILLE).getAsString())));

        final Map<String, Map<String, JsonObject>> etpsBySt = new HashMap<>();

        final Map<String, JsonObject> etpsByUg = new HashMap<>();


        etps.forEach((k,v) -> {

            Map<String, JsonObject> etpMap = new HashMap<>();

            v.forEach((key, value) -> etpMap.put(key, this.computeEtpByFamille(value)));

            etpsBySt.put(k, etpMap);
        });


        etpsPerFamille.forEach((k,v) -> etpsByUg.put(k, this.computeEtpUgByFamille(v)));

        payload.add("etpsBySt", gson.toJsonTree(etpsBySt));

        payload.add("etpsByUg", gson.toJsonTree(etpsByUg));

        return payload;
    }


    private LocalDate buildDateDebut(LocalDate dateDebut, LocalDate dateFin) {
        LocalDate dateNow = LocalDate.now();
        if (dateFin.isBefore(dateNow)) {
            return dateDebut;
        }
        return dateNow.minusDays(7);
    }

    private LocalDate buildDateFin(LocalDate dateFin) {
        LocalDate dateNow = LocalDate.now();
        if (dateNow.isBefore(dateFin)) {
            return dateNow;
        }
        return dateFin;
    }


    private JsonObject computeEtpByFamille (List<JsonObject> activities) {

        final JsonObject etpPayload = new JsonObject();

            double etpTotalMoyen = 0;
            double etpRenfortMoyen = 0;

            for (JsonObject etp : activities) {
                etpTotalMoyen+=  etp.get(ETP_TOTAL_MOYEN).getAsDouble();
                etpRenfortMoyen+= etp.get(ETP_RENFORT_MOYEN).getAsDouble();
            }

        etpPayload.addProperty(ETP_TOTAL_MOYEN, etpTotalMoyen);
        etpPayload.addProperty(ETP_RENFORT_MOYEN, etpRenfortMoyen);

        etpPayload.add("activities", toJsonObject(activities));


        return etpPayload;

    }

    private JsonObject computeEtpUgByFamille (List<JsonObject> activities) {


        JsonObject etpsPayload = this.computeEtpByFamille(activities);

        JsonObject etpActivity = new JsonObject();

        Map<String, List<JsonObject>> etpByActivity = activities.stream().collect(groupingBy(item -> item.get(CODE_ACTIVITE).getAsString()));

        etpByActivity.forEach((code, etps) -> {
            double etpTotalMoyen = 0;
            double etpRenfortMoyen = 0;

            JsonObject etpPayload = new JsonObject();

            for (JsonObject etp : etps) {
                etpTotalMoyen+=  etp.get(ETP_TOTAL_MOYEN).getAsDouble();
                etpRenfortMoyen+= etp.get(ETP_RENFORT_MOYEN).getAsDouble();
            }

            etpPayload.addProperty(CODE_ACTIVITE,code);
            etpPayload.addProperty(ETP_TOTAL_MOYEN, etpTotalMoyen);
            etpPayload.addProperty(ETP_RENFORT_MOYEN, etpRenfortMoyen);

            etpActivity.add(code, etpPayload);

        });

        etpsPayload.add("activities", etpActivity);

        return etpsPayload;

    }

    private JsonObject toJsonObject(List<JsonObject> list) {
        JsonObject payload = new JsonObject();
        list.stream().forEach(item -> payload.add(item.get(CODE_ACTIVITE).getAsString(), item));
        return payload;
    }

    private List<JsonObject> mergeEtp(List<JsonObject> listEtp, List<JsonObject> listEtpRenfort) {
        List<JsonObject> keyEtpList = listEtp.stream()
                .map(item ->  {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty(CODE_FAMILLE,String.valueOf(item.get(CODE_FAMILLE)).replace("\"",""));
                    jsonObject.addProperty(CODE_ACTIVITE,String.valueOf(item.get(CODE_ACTIVITE)).replace("\"",""));
                    jsonObject.addProperty(EQUIPE_ID, item.get(EQUIPE_ID).getAsBigDecimal());
                    return jsonObject;
                })
                .collect(Collectors.toList());
        List<JsonObject> listEtpRenfortFiltred = listEtpRenfort.stream()
                .filter(item -> {
                    for (JsonObject keyEtp: keyEtpList) {
                        if(keyEtp.get(CODE_FAMILLE).toString().equals(item.get(CODE_FAMILLE).toString()) && keyEtp.get(CODE_ACTIVITE).toString().equals(item.get(CODE_ACTIVITE).toString()) && keyEtp.get(EQUIPE_ID).toString().equals(item.get(EQUIPE_ID).toString()))  {
                            return false;
                        }
                    }
                    return true;
                }).collect(Collectors.toList());
        listEtp.addAll(listEtpRenfortFiltred);
        return listEtp;
    }
}
