package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.infrastructure.people.client.PeopleClient;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import com.socgen.eqc.infrastructure.persistance.EquipeRepository;
import com.socgen.eqc.interfaces.rest.dto.EquipeDto;
import com.socgen.eqc.mapper.EquipeMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

import static java.util.Collections.singletonList;
import static java.util.function.Predicate.not;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

@Service
@RequiredArgsConstructor
public class EquipeServiceImpl implements EquipeService {

	protected static final List<String> CODE_EMPLOI_MANAGERS = Arrays.asList("1123", "3001", "6173");

	private final AffiliationRepository affiliationRepository;
    private final EquipeRepository equipeRepository;
	private final PeopleClient peopleClient;
	private final EquipeMapper equipeMapper;
    @Override
    public Equipe findById(Long code) {
        return equipeRepository.findById(code).orElseThrow(() -> new BusinessException("Equipe not found"));
    }

	@Override
	public Optional<Equipe> findByCode(Long code) {
		return equipeRepository.findByCode(code);
	}

	@Override
    public Equipe saveDto(EquipeDto dto) {
        return equipeRepository.save(dto.toDomain());
    }

	@Override
	public Equipe save(Equipe equipe) {
		return equipeRepository.save(equipe);
	}

	@Override
	public Set<String> findManagersIdRh(Long code) {
		// Dirty fix : mock HML pour Molière CRE CLIPRI 1 code=3000324055
		if(code.equals(3000324055L)) {
			return new HashSet<>(List.of("GL001026400"));
		} else {
			return Optional.of(
							peopleClient.findPeopleByListCodeSt(singletonList(code))
									.getDatas()
									.stream()
									.filter(peopleDto -> CODE_EMPLOI_MANAGERS.contains(peopleDto.getCodeEmploi()))
									.map(peopleDto -> peopleDto.getIdRhLocal().isBlank() ? "GL" + peopleDto.getIdCnxRtfe() : peopleDto.getIdRhLocal())
									.collect(toSet()))
					.filter(not(Set::isEmpty))
					.orElseThrow(() -> new BusinessException("Le responsable de l'équipe " + code + " n'a pas été trouvé. Les absences programmées ne seront pas affichées"));
		}
	}

	@Override
	public List<Collaborateur> getCollaborateurs(Long code, LocalDate dateDebut, LocalDate dateFin) {
		return affiliationRepository.findByEquipeIdAndDates(code, dateDebut, dateFin)
				.stream()
				.map(Affiliation::getCollaborateur)
				.collect(toList());
	}

	@Override
	public List<EquipeDto> findAll() {
		return equipeMapper.equipeListToEquipeDtoList(equipeRepository.findAll());
	}

}