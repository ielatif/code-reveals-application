package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SaisieGlobaleInputDto implements Serializable {

    private Long processusId;

    private String matricule;

    private String codeST;

    private Long stockRecus;

    private Long stockTermines;

}
