package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity(name = "Competence")
@Table(name = " COMPETENCE", uniqueConstraints = {@UniqueConstraint(columnNames = {"matricule", "id_expertise"})})
public class Competence  implements Serializable {

    private static final long serialVersionUID = 2873150734153585988L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "matricule", nullable = false)
    private Collaborateur collaborateur;

    @ManyToOne
    @JoinColumn(name = "id_expertise", nullable = false)
    private Expertise expertise;

    @LastModifiedDate
    @Column(name = "last_modified_date", nullable = false)
    private LocalDate lastModifiedDate;
}
