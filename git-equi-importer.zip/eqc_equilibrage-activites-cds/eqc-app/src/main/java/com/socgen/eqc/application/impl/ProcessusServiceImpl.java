package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.ProcessusService;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.RefProcessusInputDto;
import com.socgen.eqc.infrastructure.smbo.dto.RefProcessusOutputDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ProcessusServiceImpl implements ProcessusService {

    private final SmboClient smboClient;

    @Override
    public RefProcessusOutputDto saveOrUpdateProcessus(RefProcessusInputDto processus) {
        return smboClient.saveOrUpdateProcessus(processus);
    }
}
