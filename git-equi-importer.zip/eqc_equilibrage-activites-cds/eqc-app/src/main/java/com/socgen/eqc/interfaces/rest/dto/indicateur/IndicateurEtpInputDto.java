package com.socgen.eqc.interfaces.rest.dto.indicateur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class IndicateurEtpInputDto {

    @QueryParam("stCodes")
    @NotNull
    private String listCodeServiceTraitement;

    @QueryParam("dateDebut")
    @NotNull
    private String dateDebut;

    @QueryParam("dateFin")
    @NotNull
    private String dateFin;
}
