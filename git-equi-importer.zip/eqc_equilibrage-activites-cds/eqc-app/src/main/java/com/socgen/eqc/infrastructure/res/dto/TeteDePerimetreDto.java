package com.socgen.eqc.infrastructure.res.dto;

import com.socgen.eqc.infrastructure.entite.structure.domain.ServiceTraitement;
import com.socgen.eqc.infrastructure.entite.structure.domain.UniteGestion;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TeteDePerimetreDto {

    private String id;

    private String libelle;

    private Boolean active;

    private UniteGestion ug;

    private ServiceTraitement st;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TeteDePerimetreDto that = (TeteDePerimetreDto) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, libelle);
    }
}
