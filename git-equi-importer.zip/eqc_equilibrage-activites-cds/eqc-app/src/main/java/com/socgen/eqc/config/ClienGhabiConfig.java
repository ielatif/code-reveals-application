package com.socgen.eqc.config;

import com.socgen.eqc.application.exception.TechnicalException;
import com.socgen.eqc.infrastructure.gershwin.model.AccessTokenErrorResponse;
import com.socgen.eqc.infrastructure.ghabi.dto.AccessSgConnectTokenResponse;
import com.socgen.eqc.infrastructure.sgconnect.SgConnectService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.logging.LoggingFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.util.logging.Level;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class ClienGhabiConfig {


    private final SgConnectService sgConnectService;

    @Bean(name = "ghabiClient")
    public Client sgConnectClient() {

        ClientBuilder clientBuilder = ClientBuilder.newBuilder()
                .register(new LoggingFeature(java.util.logging.Logger
                        .getLogger("ghabiClient"), Level.INFO, LoggingFeature.Verbosity.PAYLOAD_TEXT, LoggingFeature.DEFAULT_MAX_ENTITY_SIZE))
                .register(getAuthorizationFilter());
        clientBuilder.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true);
        clientBuilder.property(ClientProperties.CONNECT_TIMEOUT, 2000);
        clientBuilder.property(ClientProperties.READ_TIMEOUT, 25000);

        return clientBuilder.build();
    }

    private String getAccessToken() {
        Response response = sgConnectService.getBasicAuthentication();

        if (Response.Status.Family.SUCCESSFUL != response.getStatusInfo().getFamily()) {
            AccessTokenErrorResponse error = response.readEntity(AccessTokenErrorResponse.class);
            log.error("Problème Ghabi : {} {}", error.getError(), error.getErrorDescription());
            throw new TechnicalException("Une erreur est survenue lors de la récupération du Token sgConnect");
        }

        log.info("SG connect access token récupérer avec success");

        AccessSgConnectTokenResponse accessTokenResponse = response.readEntity(AccessSgConnectTokenResponse.class);

        return "Bearer " + accessTokenResponse.getAccessToken();
    }

    private ClientRequestFilter getAuthorizationFilter() {
        return requestContext -> requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, getAccessToken());
    }
}
