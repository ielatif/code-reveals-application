package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.domain.model.Renfort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface RenfortRepository extends JpaRepository<Renfort, Long> {

    List<Renfort> findByCodeStRattachementAndCollaborateurMatriculeAndDateBetween(Long codeServiceTraitement, String matriculeCollaborateur, LocalDate dateDebut, LocalDate dateFin);

    Optional<List<Renfort>> findByEquipeCodeInAndDateBetween(List<Long> codeSTAide, LocalDate dateDebut, LocalDate dateFin);

    Optional<Renfort> findByCollaborateurMatriculeAndEquipeCodeAndDate(String matricule, Long codeSTAide, LocalDate date);

    void deleteByCollaborateurMatriculeAndDateAfter(String matricule, LocalDate now);

    List<Renfort> findByCodeStRattachementAndDateBetween(Long codeServiceTraitement, LocalDate dateDebut, LocalDate dateFin);

    List<Renfort> findByCollaborateurMatriculeAndDateAfter(String matricule, LocalDate now);

    List<Renfort> findByDateBetween(LocalDate dateDebut, LocalDate dateFin);

    List<Renfort> findByCollaborateurMatriculeInAndDateBetween(List<String> matricules, LocalDate dateDebut, LocalDate dateFin);

    List<Renfort> findByCollaborateurMatriculeAndDate(String matricule, LocalDate now);

    Optional<Renfort> findByCollaborateurMatriculeAndDateAndExtensionPerimetreNotNull(String matricule, LocalDate date);

    Optional<Renfort> findByCollaborateurMatriculeAndDateAndExtensionPerimetreNull(String matricule, LocalDate date);

    @Query("SELECT r FROM RENFORT r WHERE r.date=:date and  r.codeStRattachement=:codeStRattachement and r.equipe =:equipe and r.collaborateur =:collaborateur")
    Optional<Renfort> findByUniqueKey(@Param("date") LocalDate date, @Param("codeStRattachement") Long codeStRattachement, @Param("equipe") Equipe equipe, @Param("collaborateur") Collaborateur collaborateur);

    List<Renfort> findByExtensionPerimetreId(Long id);

    @Modifying
    @Query("DELETE FROM RENFORT r where r in (select r FROM RENFORT r LEFT JOIN r.collaborateur WHERE (r.collaborateur.matricule in :matricules and r.codeStRattachement=:codeSt) and r.date>=:dateDebut and r.date<=:dateFin)")
    void deleteByCollaborateurs(@Param("matricules") List<String> matricules, @Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin, @Param("codeSt") Long codeSt);

    List<Renfort> findByCodeStRattachementAndDateBetweenAndCollaborateurMatriculeIn(Long codeServiceTraitement, LocalDate dateDebut, LocalDate dateFin, List<String> matricules);

    @Query(nativeQuery = true, value = "select count(*) from renfort where extract(year from date) = extract(year from now()) and id_extension_perimetre is not null")
    Long fetchRenfortCount();
}
