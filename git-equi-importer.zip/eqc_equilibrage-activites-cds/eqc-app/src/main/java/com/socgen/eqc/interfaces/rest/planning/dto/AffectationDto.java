package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.domain.model.Affectation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AffectationDto {

    private Long id;
    private String matricule;
    private LocalDate date;
    private DayOfWeek day;
    private String codeActivite;
    private String libelle;
    private Long pourcentage;
    private Double nombreDossier;
    private boolean forRenfort;
    private int ordre;
    private long idExpertise;
    private String commentPrincipale;
    private String commentSecondaire;
    private String customStyle;

    public static AffectationDto fromDomain(Affectation affectation) {
        String matricule = affectation.getAffiliation() == null ? affectation.getRenfort().getCollaborateur()
                .getMatricule() : affectation.getAffiliation().getCollaborateur().getMatricule();

        String affectationColor = (affectation.getParametresCarte() != null && affectation.getParametresCarte().getCouleur() != null ) ? affectation.getParametresCarte().getCouleur().getCode() : null;

        return AffectationDto.builder().pourcentage(affectation.getPourcentage()).id(affectation.getId())
                .nombreDossier(affectation.getNombreDossier())
                .forRenfort(affectation.getRenfort() != null).matricule(matricule)
                .day(affectation.getDate().getDayOfWeek())
                .codeActivite(affectation.getActivite().getCode()).date(affectation.getDate())
                .ordre(affectation.getOrdre())
                .idExpertise(affectation.getExpertise().getId())
                .commentPrincipale(affectation.getParametresCarte() != null ? affectation.getParametresCarte().getTitre() : null)
                .commentSecondaire(affectation.getParametresCarte() != null ? affectation.getParametresCarte().getCommentaire() : null)
                .customStyle(affectationColor)
                .build();
    }

    public static List<AffectationDto> fromDomain(List<Affectation> affectations) {
        if (affectations == null) {
            return Collections.emptyList();
        }
        return affectations.stream().map(AffectationDto::fromDomain).collect(Collectors.toList());
    }
}
