package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.CompetenceService;
import com.socgen.eqc.interfaces.rest.dto.CompetenceDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})

@Path("/competences")
@Slf4j
@Api(value = "competences")
public class CompetenceResource {

    @Autowired
    private CompetenceService competenceService;

    @GET
    @ApiOperation(value = "Récupération du profil d'un collaborateur", notes = "Récupération du profil d'un collaborateur")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Le profil a été bien récupéré")
    })
    public Response getProfilByCollaborateur(@QueryParam("matricule") @NotNull String matricule,
                                             @QueryParam("codeStRattachement") @NotNull Long codeStRattachement) {
        log.info("Récupération du profil de la matrciule {} ", matricule);
        return Response.ok(competenceService.getProfilByServiceTraitementAndMatricule(codeStRattachement, matricule)).build();
    }

    @GET
    @ApiOperation(value = "Récupération des profils par ST", notes = "Récupération des profils par ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les profils sont bien récupérés")
    })
    @Path("/services-traitements/{codeServiceTraitement}")
    public Response getProfilByServiceTraitement(@PathParam("codeServiceTraitement") Long codeServiceTraitement) {
        log.info("Récupération des profils du service de traitement {} ", codeServiceTraitement);

        return Response.ok(competenceService.getProfilByServiceTraitement(codeServiceTraitement)).build();
    }


    @PUT
    @ApiOperation(value = "Mettre à jour d'une compétence", notes = "Mettre à jour d'une compétence")
    @ApiResponses({
            @ApiResponse(code = 201, message = "La compétence est bien mise à jour"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response updateCompetence(@QueryParam("matricule") String matricule, List<CompetenceDto> competenceDtos) {
        log.info("update competence pour le collaborateur {}", matricule);
        competenceService.updateProfilCollaborateur(matricule, competenceDtos);
        return Response.noContent().build();
    }

}
