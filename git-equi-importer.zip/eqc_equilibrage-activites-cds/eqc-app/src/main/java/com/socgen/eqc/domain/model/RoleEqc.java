package com.socgen.eqc.domain.model;

public class RoleEqc {
    public static final String CONSULTER_VUE_COLLAB = "CONSULTER_VUE_COLLAB";
    public static final String CONSULTER_PLANNING = "CONSULTER_PLANNING";
    public static final String GERER_PLANNING = "GERER_PLANNING";
    public static final String CONSULTER_MOIS = "CONSULTER_MOIS";

    private RoleEqc(){}
}
