package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum Source {
    HARMONIE("HARMONIE"),
    ISIS("ISIS"),
    SAISIE_GLOBALE("SAISIE GLOBALE"),
    ALL("ALL");

    @Getter
    private String name;

    public static Source valueOfByEtat(final String source) {
        for (final Source type : values()) {
            if (type.name.equals(source)) {
                return type;
            }
        }
        throw new IllegalArgumentException("The specified result type code is illegal: " + source);
    }
}
