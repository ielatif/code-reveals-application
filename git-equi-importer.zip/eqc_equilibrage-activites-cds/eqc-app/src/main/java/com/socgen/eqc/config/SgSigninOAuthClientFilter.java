package com.socgen.eqc.config;

import com.socgen.dga.idp.client.SgSignInClient;
import com.socgen.dga.idp.client.SgSignInClientException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import java.io.IOException;


@Component
@Priority(Priorities.AUTHENTICATION)
public class SgSigninOAuthClientFilter implements ClientRequestFilter {

    private SgSignInClient sgSignInClient;

    @Autowired
    private ApplicationProperties applicationProperties;

    @PostConstruct
    public void initFilter() {
        // Create an instance of SgSignInClient
        sgSignInClient = new SgSignInClient(applicationProperties.getSgSignIn().getClientId(), applicationProperties
                .getSgSignIn().getClientSecret(), applicationProperties.getSgSignIn().getServerUrl());
    }

    @Override
    public void filter(ClientRequestContext clientRequestContext) throws IOException {
        String myToken;
        try {
            myToken = sgSignInClient.getAccessToken();
        } catch (SgSignInClientException e) {
            throw new IOException("Erreur durant le temps de couverture du token", e);
        }
        clientRequestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, myToken);
        clientRequestContext.getHeaders().add("x-ibm-client-id", applicationProperties.getSgSignIn().getClientId());
    }
}
