package com.socgen.eqc.interfaces.rest.dto.indicateur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class StockATraiterStDto {

    private String codeServiceTraitement;
    private List<StockOutputDto> stocksATraiter;
}
