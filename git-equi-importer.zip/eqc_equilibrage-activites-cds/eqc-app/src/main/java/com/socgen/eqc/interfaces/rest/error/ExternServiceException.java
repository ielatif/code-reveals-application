package com.socgen.eqc.interfaces.rest.error;


public class ExternServiceException extends RuntimeException {

    public ExternServiceException(String message) {
        super(message);
    }

}
