package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ConsolideMensuelRepository extends JpaRepository<ConsolideMensuel, Long> {

   List<ConsolideMensuel> findAllByStActifAndMonthYearConsolide(long serviceTraitementId, String monthYearConsolide);

   void deleteAllByMonthYearConsolide(String monthYearConsolide);
}
