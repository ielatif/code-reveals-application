package com.socgen.eqc.application;

import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.TetePerimetreDto;

import java.util.List;

public interface TetePerimetreService {


    List<TetePerimetreDto> getAllTetePerimetres();

    TetePerimetre findTetePerimetreById(String idTetePerimetre);
}
