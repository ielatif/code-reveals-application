package com.socgen.eqc.interfaces.rest.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConsolideMensTaux {

    private String idActiviteSumeau;
    private Long stActif;
    private String monthYearConsolide;
    private String sumeauLibelleActivite;
    private BigDecimal tauxHorsUg;
    private BigDecimal tauxActiviteSumeau;
    private String joursPresence;
    private Long stRattachement;

}
