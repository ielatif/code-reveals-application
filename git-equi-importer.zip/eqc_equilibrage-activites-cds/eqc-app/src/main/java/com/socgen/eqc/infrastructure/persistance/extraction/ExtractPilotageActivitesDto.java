package com.socgen.eqc.infrastructure.persistance.extraction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
@JsonPropertyOrder({ "codeFiliere", "filiere", "codeUg", "ug","codeSt","st","dateDebut", "dateFin","niveau"," codeActivite","famille","activite","typeActivite","source","libelleProcessus","libelleNature","codeTache","libelleTache","nombreDossierVeille","nombreDossierRecus","nombreDossiersTermines","nombreDossiersAbandonees","dossiersRestant","nombreTachesVeilles","nombreTachesRecus","nombreTachesTermines","nombreTachesSupprimees","nombreTachesRestantes","nombreEtpPlanifies","nombreEtpRenfort" })
public class ExtractPilotageActivitesDto implements Serializable {


    @JsonProperty(value = "NB DE TACHES VEILLE")
    private String nombreTachesVeilles;


    @JsonProperty(value = "FILIERE")
    private String filiere;

    @JsonProperty(value = "CODE UG")
    private String codeUg;

    @JsonProperty(value = "UG")
    private String ug;

    @JsonProperty(value = "CODE ST")
    private String codeSt;

    @JsonProperty(value = "ST")
    private String st;

    @JsonProperty(value = "DATE DE DEBUT PERIODE")
    private String dateDebut;

    @JsonProperty(value = "DATE DE FIN PERIODE")
    private String dateFin;

    @JsonIgnore
    private String codeFamille;

    @JsonProperty(value = "NIVEAU")
    private String niveau;

    @JsonIgnore
    private String codeActivite;

    @JsonProperty(value = "FAMILLE D'ACTIVITE")
    private String famille;

    @JsonProperty(value = "ACTIVITE")
    private String activite;

    @JsonIgnore
    private String typeActivite;

    @JsonProperty(value = "SOURCE")
    private String source;

    @JsonProperty(value = "LIBELLE PROCESSUS")
    private String libelleProcessus;

    @JsonProperty(value = "LIBELLE NATURE")
    private String libelleNature;

    @JsonProperty(value = "CODE TACHE")
    private String codeTache;

    @JsonProperty(value = "LIBELLE TACHE")
    private String libelleTache;

    @JsonProperty(value = "NB DE DOSSIERS VEILLE")
    private String nombreDossierVeille;

    @JsonProperty(value = "NB DE DOSSIERS RECUS")
    private String nombreDossierRecus;

    @JsonProperty(value = "NB DE DOSSIERS TERMINES")
    private String nombreDossiersTermines;

    @JsonProperty(value = "DONT DOSSIERS ABANDONNES")
    private String nombreDossiersAbandonees;

    @JsonProperty(value = "NB DE DOSSIERS RESTANTS")
    private String dossiersRestant;

    @JsonProperty(value = "NB DE TACHES RECUES")
    private String nombreTachesRecus;

    @JsonProperty(value = "NB DE TACHES TERMINEES")
    private String nombreTachesTermines;

    @JsonProperty(value = "DONT TACHES SUPPRIMEES")
    private String nombreTachesSupprimees;

    @JsonProperty(value = "NB DE TACHES RESTANTES")
    private String nombreTachesRestantes;

    @JsonProperty(value = "NB ETP PLANIFIES")
    private String nombreEtpPlanifies;

    @JsonProperty(value = "DONT ETP EN RENFORT")
    private String nombreEtpRenfort;


    @JsonProperty(value = "CODE FILIERE")
    private String codeFiliere;

}
