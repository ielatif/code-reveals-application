package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.interfaces.rest.dto.EquipeDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface EquipeMapper {

     EquipeDto toDto(Equipe equipe);

     List<EquipeDto> equipeListToEquipeDtoList(List<Equipe> equipes);

}
