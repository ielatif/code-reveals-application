package com.socgen.eqc.application;

import com.socgen.eqc.interfaces.rest.dto.ConsolideMensSearch;
import com.socgen.eqc.interfaces.rest.dto.ConsolideMensuelDto;

import java.util.List;

public interface ConsolideMensuelService {

    List<ConsolideMensuelDto> getConsolideMensuel(ConsolideMensSearch consolideMensSearch);

}
