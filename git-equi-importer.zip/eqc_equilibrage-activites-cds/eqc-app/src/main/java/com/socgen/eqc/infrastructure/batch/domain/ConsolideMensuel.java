package com.socgen.eqc.infrastructure.batch.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Consolide_mensuel")
public class ConsolideMensuel {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "ID", nullable = false, unique = true)
    private Long id;

    private String monthYearConsolide;

    private String matriculeCollaborateur;

    @Digits(integer=19, fraction=0)
    private BigDecimal tauxActiviteSumeau;

    private String idActiviteSumeau;

    private String sumeauLibelleActivite;

    private Long stActif;

    private Long cdsRattachement;

    private Long ugRattachement;

    private Long stRattachement;

    private Double joursPresence;

    private Boolean isRenfortInterUg;

    private BigDecimal tauxHorsUg;


}
