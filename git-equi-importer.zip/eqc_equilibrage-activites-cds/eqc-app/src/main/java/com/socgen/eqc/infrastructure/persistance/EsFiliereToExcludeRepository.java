package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.EsFiliereToExclude;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EsFiliereToExcludeRepository extends JpaRepository<EsFiliereToExclude, Long> {

}
