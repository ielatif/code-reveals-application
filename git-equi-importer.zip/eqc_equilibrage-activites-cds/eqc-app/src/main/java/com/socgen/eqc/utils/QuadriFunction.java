package com.socgen.eqc.utils;

@FunctionalInterface
public interface QuadriFunction<A, B, C, D, R> {

    R apply(A var1, B var2, C var3, D var4);
}
