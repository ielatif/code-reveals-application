package com.socgen.eqc.infrastructure.ghabi.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@NoArgsConstructor
@SuperBuilder
public abstract class GhabiExtensionAbstractDto {

    private Long id;

    private String utilisateurId;

    private String utilisateurStId;

    private String createurId;

    private String dateDebut;

    private String dateFin;

    private List<String> perimStIds;

}
