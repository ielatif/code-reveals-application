package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.domain.model.Competence;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompetenceDto {

    private Long id;

    private String matricule;

    private String codeFamille;

    private String codeActivite;

    private String libelleActivite;

    private int ordreActivite;

    private Long idNiveau;

    private String libelleNiveau;

    private Float nombreDossier;

    private Boolean isUpdated;

    private Map<Long, Float> mapNombreDossiers;

    private Long idExpertise;

    private LocalDate lastModifiedDate;

    public static CompetenceDto fromDomain(Competence competence) {
        return CompetenceDto.builder().id(competence.getId()).matricule(competence.getCollaborateur().getMatricule())
                .codeActivite(competence.getExpertise().getActivite().getCode())
                .ordreActivite(competence.getExpertise().getActivite().getOrdre())
                .idNiveau(competence.getExpertise().getNiveau().getId())
                .libelleNiveau(competence.getExpertise().getNiveau().getLibelle())
                .idExpertise(competence.getExpertise().getId())
                .lastModifiedDate(competence.getLastModifiedDate())
                .nombreDossier(competence.getExpertise().getNombreDossier()).build();
    }

    public static List<CompetenceDto> fromDomain(List<Competence> competences) {
        return competences.stream().map(CompetenceDto::fromDomain).collect(Collectors.toList());
    }
}
