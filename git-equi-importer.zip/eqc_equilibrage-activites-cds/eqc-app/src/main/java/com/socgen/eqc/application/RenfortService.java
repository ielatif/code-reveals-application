package com.socgen.eqc.application;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.interfaces.rest.dto.ActionRenfortDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;

import java.time.LocalDate;
import java.util.List;

public interface RenfortService {

    Renfort searchRenfortByMatriculeAndCodeStAideAndDate(String matricule, Long codeSTAide, LocalDate dateRenfort);

    void removeAll(String matricule, List<Renfort> renfortList);

    List<Renfort> findByMatricule(String matricule);

    List<Renfort> findRenfortEntrant(List<Long> codeSTAide, LocalDate dateDebut, LocalDate dateFin);

    List<Renfort> findRenfortSortant(PlanningSearchDto planningSearch);

    List<Renfort> updateOrDelete(List<ActionRenfortDto> actionRenforts, SgUserPrincipal sgUserPrincipal);

    void supprimerSemaine(SuppressionSemaineDto suppressionSemaineDto);

    List<Renfort> findRenfortsInterUGFromToday(String matricule);

    void dupliquerSemaine(LocalDate dateDebutSemaineSource, LocalDate dateDebutSemaineCible, List<String> matricules, SgUserPrincipal sgUserPrincipal);
}
