package com.socgen.eqc.config;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@ConfigurationProperties(prefix="eqc")
@Configuration
public class EqcProperties {

    private Config config;
    private Batch batch = new Batch();
    private Contributeur contributeur = new Contributeur();

    @Data
    public static class Config {
        private Integer chunkSize;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Batch {
        private Config config;
        private String confTest;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Contributeur {
        private String resUrl;
        private String esWithTetePerimetrePath;
        private List<String> departementBddf;
        private List<String> codeType;
        private List<String> codeCdsExclus;
        private List<String> sigleExclus;
        private List<String> filieres;
    }
}

