package com.socgen.eqc.application.exception;

public class TechnicalException extends RuntimeException  {

    public TechnicalException(String message) {
        super(message);
    }
}
