package com.socgen.eqc.interfaces.rest.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class ConsolideMensuelDto {

    private String collaborateurMatricule;
    private String collaborateurNom;
    private String collaborateurPrenom;
    private Boolean isRenfortInterUg;
    private List<ConsolideMensTaux> consolides;
}
