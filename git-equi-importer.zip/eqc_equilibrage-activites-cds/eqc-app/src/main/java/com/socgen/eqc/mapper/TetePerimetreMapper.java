package com.socgen.eqc.mapper;

import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.TetePerimetreDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TetePerimetreMapper {

    List<TetePerimetreDto> listTetePerimetreToTetePerimetreDtoList (List<TetePerimetre> tetePerimetres);
    List<TetePerimetre> listTetePerimetreDtoToTetePerimetreList (List<TetePerimetreDto> tetePerimetreDtos);
    TetePerimetreDto tetePerimetreToTeteperimetreDto (TetePerimetre tetePerimetre);
    TetePerimetre tetePerimetreDtoToTetePerimetre(TetePerimetreDto tetePerimetreDto);

}
