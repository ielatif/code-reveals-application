package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.CompetenceService;
import com.socgen.eqc.application.ExpertiseService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.infrastructure.persistance.CompetenceRepository;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractCompetencesDto;
import com.socgen.eqc.interfaces.rest.dto.CompetenceDto;
import com.socgen.eqc.interfaces.rest.dto.ProfilDto;
import com.socgen.eqc.mapper.CompetenceMapper;
import com.socgen.eqc.mapper.ExpertiseMapper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.persistence.Tuple;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
@Transactional
public class CompetenceServiceImpl implements CompetenceService {

    private final CompetenceRepository competenceRepository;

    private final ExpertiseService expertiseService;

    private final ExpertiseMapper expertiseMapper;

    private final CompetenceMapper competenceMapper;

    private final AffiliationService affiliationService;

    private final AffectationService affectationService;


    @Override
    public ProfilDto getProfilByCollaborateur(String matricule, Long codeStRattachement, LocalDate dateDebut, LocalDate dateFin) {

        Affiliation affiliation = affiliationService.findByMatriculeAndDate(matricule, dateDebut, dateFin)
                .orElseThrow(() -> new BusinessException("Matricule non trovée !"));

        //récupérer les compétences qui ont été modifiées par le RST
        List<CompetenceDto> profilCompetences = getCurrentProfil(matricule);

        Set<String> listCurrentActiviteProfil = profilCompetences.stream()
                .map(CompetenceDto::getCodeActivite)
                .collect(Collectors.toSet());

        //récupérer des compétences communes
        List<Expertise> commonExpertises = expertiseService.getCommonExpertise();
        //Récupération des compétences par defaut
        List<Expertise> defaultExpertises = getDefaultExpertiseByCollab(commonExpertises, affiliation);

        Set<CompetenceDto> defaultCompetences = defaultExpertises
                .stream()
                .filter(expertise -> !listCurrentActiviteProfil.contains(expertise.getActivite().getCode()))
                .map(expertiseMapper::expertiseToCompetenceDto)
                .collect(Collectors.toSet());

        Set<CompetenceDto> competences = Stream.concat(profilCompetences.stream(), defaultCompetences.stream())
                .collect(Collectors.toSet());

        Map<String, Map<Long, Float>> nombresDossier = buildNombresDossier(competences.stream()
                .map(CompetenceDto::getCodeActivite)
                .collect(Collectors.toSet())
        );

        competences.forEach(competenceDto -> competenceDto.setMapNombreDossiers(nombresDossier.get(competenceDto.getCodeActivite())));

        return ProfilDto.builder()
                .matricule(matricule)
                .isUpdatable(isUpdatableProfil(matricule, codeStRattachement))
                .competences(competences).build();
    }

    @Override
    public List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> getProfilByServiceTraitement(Long codeServiceTraitement) {

        List<Affiliation> affiliations = affiliationService
                .findByEquipeAndDate(codeServiceTraitement, LocalDate.now()).stream()
                .filter(affiliation -> affiliation.getDateSortie() == null).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(affiliations)) {
            return Collections.emptyList();
        }
        List<Collaborateur>  collaborateursAffiliation = affiliations.stream().map(Affiliation::getCollaborateur).distinct().collect(Collectors.toList());
        Map<String, List<Affiliation>> affiliationByCollab = affiliations.stream()
                .collect(Collectors.groupingBy(affiliation -> affiliation.getCollaborateur().getMatricule()));

        List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> competenceDtos = com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto.fromDomain(getProfilByCollaborateurs(collaborateursAffiliation, affiliationByCollab));


        Map<String, Map<Long, Float>> nombresDossier = buildNombresDossier(competenceDtos.stream()
                .map(com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto::getCodeActivite)
                .collect(Collectors.toSet())
        );

        competenceDtos.forEach(competenceDto -> competenceDto.setMapNombreDossiers(nombresDossier.get(competenceDto.getCodeActivite())));

        return competenceDtos;

    }

    @Override
    public List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> getProfilByServiceTraitementAndMatricule(Long codeServiceTraitement, String matricule) {

        Optional<Affiliation> affiliation = affiliationService
                .findByEquipeAndActiveByMatricule(codeServiceTraitement, matricule);
        if (!affiliation.isPresent()) {
            return Collections.emptyList();
        }
        List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> competenceDtos = com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto.fromDomain(getProfilByCollaborateur(affiliation.get().getCollaborateur(), affiliation.get()));
        Map<String, Map<Long, Float>> nombresDossier = buildNombresDossier(competenceDtos.stream()
                .map(com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto::getCodeActivite)
                .collect(Collectors.toSet())
        );
        competenceDtos.forEach(competenceDto -> competenceDto.setMapNombreDossiers(nombresDossier.get(competenceDto.getCodeActivite())));
        return competenceDtos;

    }

    private List<Expertise> getDefaultExpertiseByCollab(List<Expertise> commonExpertises, Affiliation affiliation) {
        return commonExpertises.stream()
                .filter(expertise -> {
                    Optional<DefaultExpertise> defaultHistoriqueExpertise = expertise.getActivite().getDefaultExpertises()
                            .stream()
                            .filter(getDefaultExpertisePredicate(affiliation))
                            .filter(expert -> expert.getDateFin() != null)
                            .max(Comparator.comparing(DefaultExpertise::getDateFin));
                    if (defaultHistoriqueExpertise.isEmpty()) {
                        Optional<DefaultExpertise> lastDefaultExpertise = expertise.getActivite().getDefaultExpertises()
                                .stream()
                                .filter(expert -> expert.getDateFin() == null)
                                .findFirst();
                        return lastDefaultExpertise.filter(defaultExpertise -> expertise.getNiveau().getId().equals(defaultExpertise.getNiveau().getId())).isPresent();
                    }
                    return expertise.getNiveau().getId().equals(defaultHistoriqueExpertise.get().getNiveau().getId());
                }).collect(Collectors.toList());
    }

    /**
     * Récupérer les niveaux d'expertise par default pour lec collaborateurs
     * qui ont une date d'entrée > = date de debut de creation de niveau d'expertise
     * et la date de fin d'expertise est null ou bien  strictement supérieur a la date de d'entrée du colab
     *
     * @param affiliation
     * @return
     */
    private Predicate<DefaultExpertise> getDefaultExpertisePredicate(Affiliation affiliation) {
        return defExpertise ->
                (affiliation.getDateEntree().isEqual(defExpertise.getDateDebut()) ||
                        affiliation.getDateEntree().isAfter(defExpertise.getDateDebut())) &&
                        (defExpertise.getDateFin() == null ||
                                defExpertise.getDateFin().isAfter(affiliation.getDateEntree()));
    }

    /**
     * Récupérer le nombre de dossier pour chaque activité
     * Pour les activités qui n'ont pas de valorisation, on lui affecte -1
     * pour etre traiter en Front comme non disponible
     *
     * @param codeActivites
     * @return
     */
    public Map<String, Map<Long, Float>> buildNombresDossier(Set<String> codeActivites) {
        List<Tuple> expertises = expertiseService.getExpertiseByActivites(codeActivites);

        Map<String, List<Tuple>> expertiseByActivites = expertises.stream().collect(Collectors.groupingBy(tuple -> tuple.get("codeActivite").toString()));



         return expertiseByActivites.entrySet().stream().collect(
                Collectors.toMap(Map.Entry::getKey,
                        expertiseEntry -> expertiseEntry.getValue().stream()
                                .collect(Collectors.toMap(
                                        tuple -> Long.valueOf(tuple.get("idNiveau").toString()),
                                        (tuple -> tuple.get("nombreDossier") == null ? -1 : Float.parseFloat(tuple.get("nombreDossier").toString()))
                                ))));
    }


    private boolean isUpdatableProfil(String matricule, Long codeStRattachement) {
        Affiliation affiliation = affiliationService.findLastByMatricule(matricule)
                .orElseThrow(() -> new BusinessException("Aucune affiliation trouve pour ce matricule " + matricule));
        return affiliation.getEquipe().getCode().equals(codeStRattachement);
    }

    public List<CompetenceDto> getCurrentProfil(String matricule) {
        return competenceMapper.competenceListToCompetenceDtoList(competenceRepository.findByCollaborateurMatricule(matricule));
    }

    @Override
    public void updateProfilCollaborateur(String matricule, List<CompetenceDto> competenceInputDtos) {
        List<Competence> listUpdateCompetence = competenceInputDtos.stream().filter(CompetenceDto::getIsUpdated)
                .map(competenceInputDto -> {
                    Competence competence = competenceMapper.competenceDtoToCompetence(competenceInputDto, matricule);
                    Expertise expertise = expertiseService
                            .getExpertiseByActiviteAndNiveau(competence.getExpertise().getActivite()
                                    .getCode(), competence.getExpertise().getNiveau().getId());
                    competence.setExpertise(expertise);
                    competence.setLastModifiedDate(LocalDate.now());
                    return competenceRepository.save(competence);
                }).collect(Collectors.toList());
        affectationService.updateCapaciteTheorique(matricule, listUpdateCompetence);
    }

    @Override
    public List<Competence> getProfilByCollaborateurs(@NonNull List<Collaborateur> collaborateurs, Map<String, List<Affiliation>> affiliationByCollab) {
        //expertise par défaut
        List<Expertise> commonExpertise = expertiseService.getCommonExpertise();

        //profil modifiées par le RST
        Map<Collaborateur, List<Competence>> collaborateurCompetenceMap = competenceRepository
                .findByCollaborateurMatriculeIn(collaborateurs.stream().map(Collaborateur::getMatricule)
                        .collect(Collectors.toList())).stream()
                .collect(Collectors.groupingBy(Competence::getCollaborateur));
        return collaborateurs.stream().map(collaborateur -> {
            List<Competence> competencesByCollaborateur = collaborateurCompetenceMap.get(collaborateur);

            Affiliation affiliation = affiliationByCollab.get(collaborateur.getMatricule()).stream()
                    .max(Comparator.comparing(Affiliation::getDateEntree)).get();

            List<Competence> defaultCompetencesByCollaborateur = getDefaultExpertiseByCollab(commonExpertise, affiliation).stream()
                    .map(expertise -> Competence.builder().expertise(expertise).build()).collect(Collectors.toList());
            if (competencesByCollaborateur == null) {
                return getDefaultProfil(defaultCompetencesByCollaborateur, collaborateur);
            }
            return addDefaultCompetences(defaultCompetencesByCollaborateur, collaborateur, competencesByCollaborateur);
        }).flatMap(Collection::stream).collect(Collectors.toList());
    }


    private String getLastDateModifiedProfil(List<Competence> competences, String matricule){
        Optional<Competence> competenceLastUpdated = competences.stream()
                .filter(competence -> competence.getCollaborateur().getMatricule().equals(matricule) && competence.getLastModifiedDate() != null)
                .sorted(Comparator.comparing(Competence::getLastModifiedDate,Comparator.nullsLast(Comparator.reverseOrder()))).findFirst();
        if(competenceLastUpdated.isPresent()){
            return competenceLastUpdated.get().getLastModifiedDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        }
        return null;
    }

    @Override
    public List<Competence> getProfilByCollaborateur(@NonNull Collaborateur collaborateur, Affiliation affiliation) {
        //expertise par défaut
        List<Expertise> commonExpertise = expertiseService.getCommonExpertise();

        //profil modifiées par le RST
        List<Competence> competences = competenceRepository.findByCollaborateurMatricule(collaborateur.getMatricule());
        List<Competence> defaultCompetencesByCollaborateur = getDefaultExpertiseByCollab(commonExpertise, affiliation).stream()
                .map(expertise -> Competence.builder().expertise(expertise).build()).collect(Collectors.toList());
        if (competences == null) {
            return getDefaultProfil(defaultCompetencesByCollaborateur, collaborateur);
        }
        return addDefaultCompetences(defaultCompetencesByCollaborateur, collaborateur, competences);

    }

    private List<Competence> addDefaultCompetences(List<Competence> defaultCompetence, Collaborateur collaborateur, List<Competence> competences) {
        List<ActiviteParams> listActivite = competences.stream().map(competence -> competence.getExpertise().getActivite())
                .collect(Collectors.toList());
        List<Competence> filtredDefaultCompetence = defaultCompetence.stream()
                .filter(competence -> !listActivite.contains(competence.getExpertise().getActivite()))
                .map(competence -> {
                    competence.setCollaborateur(collaborateur);
                   return competence;
                }).collect(Collectors.toList());
        competences.addAll(filtredDefaultCompetence);
        return competences;
    }

    private List<Competence> getDefaultProfil(List<Competence> defaultCompetence, Collaborateur collaborateur) {
        return defaultCompetence.stream().map(competence -> Competence.builder().expertise(competence.getExpertise())
                .collaborateur(collaborateur).build()).collect(Collectors.toList());
    }

    @Override
    public List<ExtractCompetencesDto> getCompetencesExtractionByListServiceTraitement(List<Long> codesServiceTraitement,
                                                                                       List<String> codesActivites,
                                                                                       TetePerimetre tetePerimetre,
                                                                                       Map<String, String> libellesRESMap,
                                                                                       Map<String, String> libellesFamillesMap,
                                                                                       Map<String, String> libellesActivitesMap) {

        List<Affiliation> affiliations = affiliationService.findByListEquipeAndActive(codesServiceTraitement);
        if (CollectionUtils.isEmpty(affiliations)) {
            return Collections.emptyList();
        }

        List<ExtractCompetencesDto> extractCompetencesDtos = new ArrayList<>();
        //expertise par défaut
        List<Expertise> commonExpertise = expertiseService.findByCodesActivites(codesActivites);

        List<String> matricules = affiliations.stream()
                .map(affiliation -> affiliation.getCollaborateur().getMatricule()).collect(Collectors.toList());

        //profil modifiées par le RST
        Map<Collaborateur, List<Competence>> collaborateurCompetenceMap = competenceRepository
                .findByCollaborateurMatriculeInAndExpertiseActiviteCodeIn(matricules, codesActivites).stream()
                .collect(Collectors.groupingBy(Competence::getCollaborateur));

        affiliations.stream().forEach(affiliation -> {
            List<Competence> competencesByCollaborateur = collaborateurCompetenceMap.get(affiliation.getCollaborateur());

            String sousEquipeLibelle = affiliation.getAffiliationSousEquipes().stream()
                    .map(affil -> affil.getSousEquipe().getLibelle())
                    .collect(Collectors.joining(","));

            Map<String, String> entiteStructureLibelle = Map.of(
                    affiliation.getEquipe().getCodeCds().toString(), libellesRESMap.get(affiliation.getEquipe().getCodeCds().toString()),
                    affiliation.getEquipe().getCodeUg().toString(), libellesRESMap.get(affiliation.getEquipe().getCodeUg().toString()),
                    affiliation.getEquipe().getCode().toString(), libellesRESMap.get(affiliation.getEquipe().getCode().toString())
            );

            List<Competence> defaultCompetencesByCollaborateur = getDefaultExpertiseByCollab(commonExpertise, affiliation).stream()
                    .map(expertise -> Competence.builder().expertise(expertise).build()).collect(Collectors.toList());

            List<Competence> finalCompetences = competencesByCollaborateur == null ?
                    getDefaultProfil(defaultCompetencesByCollaborateur, affiliation.getCollaborateur()) :
                    addDefaultCompetences(defaultCompetencesByCollaborateur, affiliation.getCollaborateur(), competencesByCollaborateur);

            finalCompetences.stream().forEach(competence ->
                    buildExtractCompetenceDto(affiliation, entiteStructureLibelle, tetePerimetre, libellesFamillesMap, libellesActivitesMap,
                            extractCompetencesDtos, sousEquipeLibelle, finalCompetences, competence)
            );

        });
        return extractCompetencesDtos;

    }

    private void buildExtractCompetenceDto(Affiliation affiliation, Map<String, String> entiteStructureLibelle, TetePerimetre tetePerimetre, Map<String, String> libellesFamillesMap,
                                           Map<String, String> libellesActivitesMap, List<ExtractCompetencesDto> extractCompetencesDtos,
                                           String sousEquipeLibelle, List<Competence> finalCompetences, Competence competence) {
        extractCompetencesDtos.add(ExtractCompetencesDto.builder()
                .codeFiliere(affiliation.getEquipe().getCodeCds().toString())
                .filiere(entiteStructureLibelle.get(affiliation.getEquipe().getCodeCds().toString()))
                .codeUg(affiliation.getEquipe().getCodeUg().toString())
                .ug(entiteStructureLibelle.get(affiliation.getEquipe().getCodeUg().toString()))
                .codeSt(affiliation.getEquipe().getCode().toString())
                .st(entiteStructureLibelle.get(affiliation.getEquipe().getCode().toString()))
                .tetePerimetre(tetePerimetre.getLibelle())
                .matricule(competence.getCollaborateur().getMatricule().toUpperCase())
                .nomCollaborateur(competence.getCollaborateur().getNom() + ' ' + competence.getCollaborateur().getPrenom())
                .sousEquipe(sousEquipeLibelle)
                .activite(libellesActivitesMap.get(competence.getExpertise().getActivite().getCode()))
                .famille(libellesFamillesMap.get(competence.getExpertise().getActivite().getCodeFamille()))
                .typeActivite(competence.getExpertise().getActivite().getType())
                .niveauExpertise(NiveauExplicite.valueOfId(competence.getExpertise().getNiveau().getId()).label)
                .capaciteTheorique(competence.getExpertise().getNombreDossier() != null ?
                        String.format("%.2f", new BigDecimal(
                                competence.getExpertise().getNombreDossier().toString()).setScale(2, RoundingMode.HALF_UP)
                        ).replace(".", ",") : "0")
                .uniteMesure( Unite.of(competence.getExpertise().getActivite().getUnite().getCode()).getCode())
                .dateUpdateCompetence(competence.getLastModifiedDate() != null ?
                        competence.getLastModifiedDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) : null)
                .dateUpdateProfil(getLastDateModifiedProfil(finalCompetences, competence.getCollaborateur().getMatricule())).build()
        );
    }

}
