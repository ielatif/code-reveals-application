package com.socgen.eqc.interfaces.rest.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class IncidentDto implements Serializable {

    private static final long serialVersionUID = 8092151013082834583L;

    private LocalDateTime dateCreation;

    private LocalDate dateFichier;

    private String incidentLibelle;

    private int order;

    private int severity;
}
