package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import com.socgen.eqc.domain.model.Expertise;
import com.socgen.eqc.domain.model.Niveau;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ExpertiseDto implements Serializable {

    private static final long serialVersionUID = -4268685942895221391L;
    private Long id;
    private String codeActivite;
    private Niveau niveau;
    private Float nombreDossier;
    private Boolean isDefault;

    public static List<ExpertiseDto> fromDomain(List<Expertise> expertises) {
        return expertises.stream().map(ExpertiseDto::fromDomain).collect(Collectors.toList());
    }

    public static ExpertiseDto fromDomain(Expertise expertise) {
        ExpertiseDto dto = new ExpertiseDto();
        dto.codeActivite = expertise.getActivite().getCode();
        dto.id = expertise.getId();
        dto.niveau = expertise.getNiveau();
        dto.nombreDossier = expertise.getNombreDossier();
        return dto;
    }

}
