package com.socgen.eqc.interfaces.rest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ClientForwardController implements ErrorController {

    @SuppressWarnings("squid:S3752")
    @RequestMapping("/error")
    public String handleError() {
        return "forward:/";
    }
}
