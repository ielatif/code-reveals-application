package com.socgen.eqc.config;

import com.socgen.dga.idp.client.SgSignInClient;
import com.socgen.dga.idp.client.SgSignInClientException;
import com.socgen.dga.idp.jaxrs.commons.ConfigKey;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.SmboClientImpl;
import lombok.RequiredArgsConstructor;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.logging.LoggingFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import java.io.IOException;
import java.util.logging.Level;

@Configuration
@RequiredArgsConstructor
public class ClientSmboConfig {

    private final HttpServletRequest httpServletRequest;
    private final ApplicationProperties applicationProperties;

    @Bean(name = "smboClient")
    public SmboClient smboClient() {

        ClientBuilder clientBuilder = ClientBuilder.newBuilder()
            .register(new LoggingFeature(java.util.logging.Logger
                .getLogger("smboClient"), Level.INFO, LoggingFeature.Verbosity.PAYLOAD_TEXT, LoggingFeature.DEFAULT_MAX_ENTITY_SIZE))
                .register(getUserToAppAuthorizationFilter());
        //Todo : solution provisoire apres il faut Creer un client smbo pour l'extraction
        //clientBuilder.property(ClientProperties.CONNECT_TIMEOUT, 2000);
        //clientBuilder.property(ClientProperties.READ_TIMEOUT, 25000);

        return new SmboClientImpl(clientBuilder.build(), applicationProperties);
    }

    private ClientRequestFilter getUserToAppAuthorizationFilter() {
        return requestContext -> {
            requestContext.getHeaders().add(ConfigKey.X_IBM_CLIENT_ID, httpServletRequest.getAttribute(ConfigKey.X_IBM_CLIENT_ID));
            requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, httpServletRequest.getAttribute(HttpHeaders.AUTHORIZATION));
        };
    }

    @Bean
    public SgSignInClient sgSignInClient() {
        // Create an instance of SgSignInClient
        return new SgSignInClient(applicationProperties.getSgSignIn().getClientId(), applicationProperties
                .getSgSignIn().getClientSecret(), applicationProperties.getSgSignIn().getServerUrl());
    }

    //TODO remplacer ce dirty fix par une solution plus propre
    @Bean(name = "appToAppSmboClient")
    public SmboClient appToAppSmboClient(SgSignInClient sgSignInClient) {

        ClientBuilder clientBuilder = ClientBuilder.newBuilder()
                .register(new LoggingFeature(java.util.logging.Logger
                        .getLogger("appToAppSmboClient"), Level.INFO, LoggingFeature.Verbosity.PAYLOAD_TEXT, LoggingFeature.DEFAULT_MAX_ENTITY_SIZE))
                .register(getAppToAppAuthorizationFilter(sgSignInClient));
        clientBuilder.property(ClientProperties.CONNECT_TIMEOUT, 2000);
        clientBuilder.property(ClientProperties.READ_TIMEOUT, 25000);

        return new SmboClientImpl(clientBuilder.build(), applicationProperties);
    }

    private ClientRequestFilter getAppToAppAuthorizationFilter(SgSignInClient sgSignInClient) {
        return requestContext -> {
            String myToken;
            try {
                myToken = sgSignInClient.getAccessToken();
            } catch (SgSignInClientException e) {
                throw new IOException("Erreur durant le temps de couverture du token", e);
            }
            requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, myToken);
            requestContext.getHeaders().add("x-ibm-client-id", applicationProperties.getSgSignIn().getClientId());
        };
    }
}
