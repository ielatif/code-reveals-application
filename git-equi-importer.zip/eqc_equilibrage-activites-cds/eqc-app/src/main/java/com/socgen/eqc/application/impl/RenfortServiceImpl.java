package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.application.ExtensionPerimetreService;
import com.socgen.eqc.application.RenfortService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.config.EqcProperties;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.infrastructure.persistance.EquipeRepository;
import com.socgen.eqc.infrastructure.persistance.RenfortRepository;
import com.socgen.eqc.interfaces.rest.dto.Action;
import com.socgen.eqc.interfaces.rest.dto.ActionRenfortDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.interfaces.rest.error.ExternServiceException;
import com.socgen.eqc.mapper.ActionMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.time.temporal.ChronoUnit.DAYS;
import static java.util.stream.Collectors.groupingBy;

@Service
@AllArgsConstructor
@Slf4j
public class RenfortServiceImpl implements RenfortService {

    private final RenfortRepository renfortRepository;
    private final ActionMapper actionMapper;
    private final AffectationService affectationService;
    private final EquipeRepository equipeRepository;
    private final EquipeService equipeService;
    private final ExtensionPerimetreService extensionPerimetreService;
    private final EqcProperties eqcProperties;

    @Override
    @Transactional
    public List<Renfort> updateOrDelete(List<ActionRenfortDto> actionRenforts, SgUserPrincipal sgUserPrincipal) {
        log.info("Mise a jour des renforts ");
        try {
            List<Renfort> renforts = new ArrayList<>();
            Map<Action, List<ActionRenfortDto>> actionListMap = actionRenforts.stream()
                    .collect(groupingBy(ActionRenfortDto::getAction));
            List<ActionRenfortDto> actionRenfortDtoToSave = new ArrayList<>();
            List<ActionRenfortDto> actionRenfortDtoToDelete = new ArrayList<>();
            String createurId = sgUserPrincipal.getCurrentUser().getUserId();
            List<Long> filieres = eqcProperties.getContributeur().getFilieres()
                    .stream().map(Long::valueOf).collect(Collectors.toList());

            Stream.of(Action.values()).forEach(actionType -> buildListActions(actionListMap, actionRenfortDtoToSave, actionRenfortDtoToDelete, actionType));

            manageDeletingRenfort(actionRenfortDtoToDelete, createurId, filieres);

            return manageUpdatingAndSavingRenfort(renforts, actionRenfortDtoToSave, createurId, filieres);
        } catch (Exception e) {
        	log.error("Une erreur est produite lors de la mise à jours des renforts", e);
        	throw new BusinessException("Une erreur s'est produite lors de la mise en place d'un ou de plusieurs renforts");
        }
    }

    private List<Renfort> manageUpdatingAndSavingRenfort(List<Renfort> renforts, List<ActionRenfortDto> actionRenfortDtoToSave, String createurId, List<Long> filieres) {
        if (!CollectionUtils.isEmpty(actionRenfortDtoToSave)) {
            List<Renfort> renfortList = actionMapper.toListRenforts(actionRenfortDtoToSave).stream().peek(renfort -> {

                Optional<Renfort> renfortFromDbOpt = renfortRepository
                        .findByUniqueKey(renfort.getDate(), renfort.getCodeStRattachement(), renfort
                                .getEquipe(), renfort.getCollaborateur());
                if (renfortFromDbOpt.isPresent()) {
                    var renfortFromDb = renfortFromDbOpt.get();
                    renfort.setId(renfortFromDb.getId());
                    renfort.setExtensionPerimetre(renfortFromDb.getExtensionPerimetre());
                }
                //TODO : refactor add cascade equipe

                Equipe equipe = equipeService.save(renfort.getEquipe());
                renfort.setEquipe(equipe);
            }).collect(Collectors.toList());

            List<Renfort> renfortsToSave = createExtensionPerimetre(renfortList, createurId, filieres);
            renforts = renfortRepository.saveAll(renfortsToSave);
        }
        return renforts;
    }

    private void manageDeletingRenfort(List<ActionRenfortDto> actionRenfortDtoToDelete, String createurId, List<Long> filieres) {
        if (!CollectionUtils.isEmpty(actionRenfortDtoToDelete)) {

            List<Renfort> renfortsToDelete = actionRenfortDtoToDelete.stream()
                    .map(actionRenfortDto -> getRenfortById(actionRenfortDto.getId())).collect(Collectors.toList());

            List<Renfort> renfortsToDeleteWithExtensionPerimetre = renfortsToDelete.stream()
                    .filter(renfort -> renfort.getExtensionPerimetre() != null)
                    .collect(Collectors.toList());

            affectationService.removeAll(renfortsToDelete);
            renfortRepository.deleteAll(renfortsToDelete);

            if (!CollectionUtils.isEmpty(renfortsToDeleteWithExtensionPerimetre)) {
                extensionPerimetreService.deleteExtension(renfortsToDeleteWithExtensionPerimetre);

                Map<LocalDate, List<Renfort>> renfortsByDate = renfortsToDeleteWithExtensionPerimetre.stream()
                        .collect(groupingBy(Renfort::getDate));
                renfortsByDate.forEach(((date, renfortListDate) -> {
                    Map<String, List<Renfort>> renfortsByMatricule = renfortListDate.stream().collect(groupingBy(renfort -> renfort.getCollaborateur().getMatricule()));
                    renfortsByMatricule.forEach((matricule, renfortList1) -> {

                        Renfort renfortItem = renfortList1.get(0);

                        Optional<Renfort> renfortWithoutPerimFromDbOpt = renfortRepository
                                .findByCollaborateurMatriculeAndDateAndExtensionPerimetreNull(renfortItem.getCollaborateur().getMatricule(), renfortItem.getDate());

                        if (renfortWithoutPerimFromDbOpt.isPresent()
                                && renfortWithoutPerimFromDbOpt.get().isAllowedGhabiExtension(filieres)) {
                            Optional<ExtensionPerimetre> extensionPerimetre = extensionPerimetreService
                                    .createExtension(matricule, createurId, renfortWithoutPerimFromDbOpt.get());
	                        extensionPerimetre.ifPresent(perimetre -> renfortWithoutPerimFromDbOpt.get().setExtensionPerimetre(perimetre));
                            renfortRepository.save(renfortWithoutPerimFromDbOpt.get());
                        }
                    });

                }));
            }
        }
    }

    private Renfort getRenfortById(Long renfortId) {
        return renfortRepository.findById(renfortId)
                .orElseThrow(() -> new ExternServiceException("Aucun renfor trouvé avec l'identifiant " + renfortId));
    }

    private void buildListActions(Map<Action, List<ActionRenfortDto>> actionListMap, List<ActionRenfortDto> actionRenfortDtoToSave, List<ActionRenfortDto> actionRenfortDtoToDelete, Action actionType) {
        switch (actionType) {
            case CREATE:
            case UPDATE:
                actionRenfortDtoToSave.addAll(actionListMap.getOrDefault(actionType, new ArrayList<>()));
                break;
            case DELETE:
                actionRenfortDtoToDelete.addAll(actionListMap.getOrDefault(actionType, new ArrayList<>()));
                break;
        }
    }

    @Override
    public Renfort searchRenfortByMatriculeAndCodeStAideAndDate(String matricule, Long codeStAide, LocalDate dateRenfort) {
        return renfortRepository.findByCollaborateurMatriculeAndEquipeCodeAndDate(matricule, codeStAide, dateRenfort)
                .orElseThrow(() -> new BusinessException(String
                        .format("Erreur : Le collaborateur avec le matricule %s n'est plus affecté en renfort dans votre ST %s à cette date %s", matricule, codeStAide, dateRenfort)));
    }

    @Override
    public void removeAll(String matricule, List<Renfort> renfortList) {
        renfortRepository.deleteByCollaborateurMatriculeAndDateAfter(matricule, LocalDate.now().minusDays(1));
        //Suppression des extensions de périmetres pour les renforts supprimés
        extensionPerimetreService.deleteExtensionAsync(
                renfortList.stream()
                        .filter(renfort -> renfort.getExtensionPerimetre() != null)
                        .collect(Collectors.toList())
        );
    }

    @Override
    public List<Renfort> findByMatricule(String matricule) {
        return renfortRepository.findByCollaborateurMatriculeAndDateAfter(matricule, LocalDate.now().minusDays(1));
    }

    @Override
    public List<Renfort> findRenfortEntrant(List<Long> codeSTAide, LocalDate dateDebut, LocalDate dateFin) {

        return renfortRepository
                .findByEquipeCodeInAndDateBetween(codeSTAide, dateDebut, dateFin).orElse(new ArrayList<>());
    }

    @Override
    @Transactional
    public List<Renfort> findRenfortSortant(PlanningSearchDto planningSearch) {
        return renfortRepository
                .findByCodeStRattachementAndDateBetween(planningSearch.getCodeServiceTraitement(), planningSearch
                        .getDateDebut(), planningSearch.getDateFin());
    }

    private List<Renfort> createExtensionPerimetre(List<Renfort> renfortList, String createurId, List<Long> filieres) {

        //L'extension Ghabi n'est faite que si on est dans la même filière (isRenfortIntraFiliere) et dans deux Ug deifférente (isRenfortInterUG)
        Map<LocalDate, List<Renfort>> renfortsByDate = renfortList.stream()
                .filter(renfort -> renfort.isAllowedGhabiExtension(filieres))
                .collect(groupingBy(Renfort::getDate));

        renfortsByDate.forEach(((date, renfortListDate) -> {
            Map<String, List<Renfort>> renfortsByMatricule = renfortListDate.stream().collect(groupingBy(renfort -> renfort.getCollaborateur().getMatricule()));
            renfortsByMatricule.forEach((matricule, renfortList1) -> {
                    if (renfortList1.size() == 1) {
                        var renfortItem = renfortList1.get(0);

                        Optional<Renfort> renfortFromDbOpt = renfortRepository
                                .findByCollaborateurMatriculeAndDateAndExtensionPerimetreNotNull(renfortItem.getCollaborateur().getMatricule(), renfortItem.getDate());

                        if (renfortFromDbOpt.isEmpty()) {//Nouveau renfort : création dans GHABI et dans EQC
                            Optional<ExtensionPerimetre> extensionPerimetre = extensionPerimetreService.createExtension(matricule, createurId, renfortItem);
                            extensionPerimetre.ifPresent(renfortItem::setExtensionPerimetre);
                        } else {
                            handleGhabiForOneRenfort(renfortList1, renfortFromDbOpt.get(), renfortItem, createurId);
                        }
                    } else if (renfortList1.size() > 1) {
                        handleGhabiForTwoSimultanyRenfort(renfortList1, createurId);
                    }
            });
        }));

        return renfortList;
    }


    /**
     * Création des extensions Ghabi pour le renfort avec un intervalle le matin
     *
     * @param renfortList
     * @param createurId
     */
    private void createRenfortMatin(List<Renfort> renfortList, String createurId) {
        renfortList.stream()
                .filter(renfort -> renfort.getIntervalle() == Intervalle.MATIN && renfort.getExtensionPerimetre() == null)
                .findFirst()
                .ifPresent(renfortMatin -> {
                    Optional<ExtensionPerimetre> extensionPerimetre = extensionPerimetreService
                            .createExtension(renfortMatin.getCollaborateur().getMatricule(), createurId, renfortMatin);
                    extensionPerimetre.ifPresent(renfortMatin::setExtensionPerimetre);
                });
    }

    /**
     * Gérer le cas ou on a deux renfort
     * 1- soit pour une création pour les deux renforts
     * 2- soit pour un update et create pour un nouveau
     * (dans le cas ou on change l'intervalle d'un renfort existant suivi d'une création d'un nouveau renfort)
     */
    private void handleGhabiForTwoSimultanyRenfort(List<Renfort> renfortList, String createurId) {

        Renfort renfortItem1 = renfortList.get(0);
        Renfort renfortItem2 = renfortList.get(1);

	    if (renfortItem1.getId() != null || renfortItem2.getId() != null) {
		    renfortList.stream()
                    .filter(renfort -> renfort.getIntervalle() == Intervalle.APRES_MIDI && renfort.getExtensionPerimetre() != null)
                    .forEach(renfort -> {
			    extensionPerimetreService.deleteExtension(Collections.singletonList(renfort));
			    renfort.setExtensionPerimetre(null);
		    });
	    }
	    createRenfortMatin(renfortList, createurId);
    }

    /**
     * Gérer le cas d'un seul renfort en modif ou création
     * //Si le nouveau renfort a créer est différent du renfort existant (autre st aidé) et si le rnefort existant dans la BD possede un intervalle dans l'apres midi
     * //3 scénario qui se présentent :
     * // 1 --> Suppression de l'extension de perim existante dans GHABI  ,
     * // 2-->  Setter la valeur de perim extension du renfort existant a null et suppresion de l'ancien peim dans EQC
     * //3 -->  Créer une nouvelle demande Ghabi pour le nouveau renfort
     *
     * @param renfortList
     * @param renfortFromDb
     * @param renfortItem
     * @param createurId
     */
    private void handleGhabiForOneRenfort(List<Renfort> renfortList, Renfort renfortFromDb, Renfort renfortItem, String createurId) {

        ExtensionPerimetre extensionPerimetreDB = renfortFromDb.getExtensionPerimetre();

        if (renfortFromDb.getIntervalle() != Intervalle.MATIN &&
		        !renfortFromDb.getEquipe().getCode().equals(renfortItem.getEquipe().getCode()) && extensionPerimetreDB != null) {

            extensionPerimetreService.deleteExtension(Collections.singletonList(renfortFromDb));

            renfortFromDb.setExtensionPerimetre(null);
            renfortList.add(renfortFromDb);

            Optional<ExtensionPerimetre> extensionPerimetre = extensionPerimetreService.createExtension(renfortItem.getCollaborateur().getMatricule(), createurId, renfortItem);
	        extensionPerimetre.ifPresent(renfortItem::setExtensionPerimetre);
        }
    }

    @Override
    public void supprimerSemaine(SuppressionSemaineDto dto) {
        if (!dto.getMatricules().isEmpty()) {
            List<Renfort> renfortList = renfortRepository.findByCodeStRattachementAndDateBetweenAndCollaborateurMatriculeIn(dto.getCodeServiceTraitement(), dto.getDateDebut().minusDays(1), dto.getDateFin().plusDays(1), dto.getMatricules());
            extensionPerimetreService.deleteExtensionAsync(renfortList.stream().filter(renfort -> renfort.getExtensionPerimetre() != null).collect(Collectors.toList()));
            renfortRepository.deleteByCollaborateurs(dto.getMatricules(), dto.getDateDebut().minusDays(1), dto.getDateFin().plusDays(1), dto.getCodeServiceTraitement());
        }
    }

    @Override
    public List<Renfort> findRenfortsInterUGFromToday(String matricule){
        List<Renfort> renfortList = renfortRepository.findByCollaborateurMatriculeAndDate(matricule, LocalDate.now());
        return renfortList.stream().filter(renfort ->  !renfort.getCodeUgRattachement().equals(renfort.getCodeUgAide())).collect(Collectors.toList());
    }

    @Override
    public void dupliquerSemaine(LocalDate dateDebutSemaineSource, LocalDate dateDebutSemaineCible, List<String> matricules, SgUserPrincipal sgUserPrincipal) {
        List<Renfort> listRenfort = new ArrayList<>();
        List<Renfort> listRenfortSource = renfortRepository.findByCollaborateurMatriculeInAndDateBetween(matricules, dateDebutSemaineSource, dateDebutSemaineSource.plusDays(6)).stream().collect(Collectors.toList());
        List<Renfort> listRenfortCible = renfortRepository.findByCollaborateurMatriculeInAndDateBetween(matricules, dateDebutSemaineCible, dateDebutSemaineCible.plusDays(6)).stream().collect(Collectors.toList());
        String createurId = sgUserPrincipal.getCurrentUser().getUserId();
        List<Long> filieres = eqcProperties.getContributeur().getFilieres()
                .stream().map(Long::valueOf).collect(Collectors.toList());
        listRenfortSource.stream().forEach(renfort -> {
                Optional<Renfort> renfortOptional = listRenfortCible.stream()
                        .filter(renfortCible ->
                                renfortCible.getDate().isEqual(renfort.getDate().plusDays(DAYS.between(dateDebutSemaineSource, dateDebutSemaineCible)))
                                        && renfortCible.getCollaborateur().getMatricule().equals(renfort.getCollaborateur().getMatricule())
                ).findFirst();
            if (!renfortOptional.isPresent()) {
                Renfort renfortToSave = Renfort.builder()
                        .collaborateur(renfort.getCollaborateur())
                        .codeCdsAide(renfort.getCodeCdsAide())
                        .codeUgAide(renfort.getCodeUgAide())
                        .equipe(renfort.getEquipe())
                        .codeCdsRattachement(renfort.getCodeCdsRattachement())
                        .codeUgRattachement(renfort.getCodeUgRattachement())
                        .codeStRattachement(renfort.getCodeStRattachement())
                        .intervalle(renfort.getIntervalle())
                        .date(renfort.getDate().plusDays(DAYS.between(dateDebutSemaineSource, dateDebutSemaineCible)))
                        .affectations(null)
                        .build();
                if(renfort.getParametresCarte() != null){
                    renfortToSave.setParametresCarte(ParametresCarte.builder()
                            .commentaire(renfort.getParametresCarte().getCommentaire())
                            .titre(renfort.getParametresCarte().getTitre())
                            .build());
                }
                listRenfort.add(renfortToSave);
            }
        });

        if(!listRenfort.isEmpty()){
            List<Renfort> listRenfortToSave = createExtensionPerimetre(listRenfort, createurId, filieres);
            renfortRepository.saveAll(listRenfortToSave);
        }

    }

}
