package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.RatioType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RatioTypeRepository extends JpaRepository<RatioType, String> {
}