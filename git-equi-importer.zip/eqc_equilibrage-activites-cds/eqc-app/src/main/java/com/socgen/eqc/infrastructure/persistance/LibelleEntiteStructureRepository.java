package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.LibelleEntiteStructure;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public interface LibelleEntiteStructureRepository extends JpaRepository<LibelleEntiteStructure, String> {

	default Map<String, String> getAll() {
		List<LibelleEntiteStructure> libellesEntiteStructure = findAll();
		return libellesEntiteStructure.stream()
				.collect(Collectors.toMap(LibelleEntiteStructure::getCode, LibelleEntiteStructure::getLibelle));
	}
}
