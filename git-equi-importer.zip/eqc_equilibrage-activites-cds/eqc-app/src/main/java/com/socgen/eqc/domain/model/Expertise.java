package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity(name = "Expertise")
@Table(name = " EXPERTISE", uniqueConstraints = {@UniqueConstraint(columnNames = {"code_activite", "id_niveau"})})
public class Expertise implements Serializable {

    private static final long serialVersionUID = 2873150734213588722L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceExpertGenerator")
    @GenericGenerator(
            name = "sequenceExpertGenerator",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "sequence_name", value = "expertise_id_seq"),
                    @org.hibernate.annotations.Parameter(name = "initial_value", value = "1000"),
                    @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
            }
    )
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "code_activite", nullable = false)
    private ActiviteParams activite;

    @ManyToOne
    @JoinColumn(name = "id_niveau", nullable = false)
    private Niveau niveau;

    private Float nombreDossier;
}
