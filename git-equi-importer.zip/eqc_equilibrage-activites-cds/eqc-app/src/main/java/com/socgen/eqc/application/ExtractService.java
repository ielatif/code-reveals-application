package com.socgen.eqc.application;

import java.util.List;

public interface ExtractService {

    byte[] buildExtraction(String extractionType, List<String> listCodeSt, List<String> tetePerimetre, String from , String to);
}
