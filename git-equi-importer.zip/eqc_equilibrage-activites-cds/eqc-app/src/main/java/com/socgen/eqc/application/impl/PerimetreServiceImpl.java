package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.Role;
import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.PerimetreService;
import com.socgen.eqc.application.RenfortService;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.infrastructure.entite.structure.EntiteStructureService;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.ServiceTraitement;
import com.socgen.eqc.infrastructure.entite.structure.domain.UniteGestion;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PerimetreServiceImpl implements PerimetreService {

    private final EntiteStructureService entiteStructureService;
    private final RenfortService renfortService;

    @Override
    public List<CentreService> getPerimetre(String codeEntiteRattachement, SgUserPrincipal sgUserPrincipal) {
        List<CentreService> entiteStructureFromRes = entiteStructureService.getEntiteStructureFromRes();
        return StringUtils
                .isEmpty(codeEntiteRattachement) ? entiteStructureFromRes : findPerimetreFromProfilAndRenfort(codeEntiteRattachement, entiteStructureFromRes, sgUserPrincipal);
    }

    private List<CentreService> findPerimetreFromProfilAndRenfort(String codeEntiteRattachement, List<CentreService> entiteStructureFromRes, SgUserPrincipal sgUserPrincipal) {
        List<CentreService> centresService = new ArrayList<>();

        // codeEntiteRattachement est un CDS
        Optional<CentreService> centreService = findCds(codeEntiteRattachement, entiteStructureFromRes);
        centreService.ifPresent(centresService::add);

        // codeEntiteRattachement est une UG
        // Inclure les UGs du périmètre de pilotage pour les RST/RDO
        List<String> codesUgToInclude = new ArrayList<>();
        codesUgToInclude.add(codeEntiteRattachement);
        codesUgToInclude.addAll(getEntiteStructureFromPerimetrePilotage(sgUserPrincipal));
        List<UniteGestion> unitesGestion = findUg(codesUgToInclude, entiteStructureFromRes);
        centresService.addAll(getCentreServices(entiteStructureFromRes, unitesGestion));

        // codeEntiteRattachement est un ST
        // Inclure tous les st du périmètre : profil, périmètre de pilotage, renfort et serviceCodeGeo
        List<Renfort> renfortList = renfortService.findRenfortsInterUGFromToday(sgUserPrincipal.getCurrentUser().getUserId().toLowerCase());
        List<String> codesStFromRenfort = renfortList.stream().map(renfort -> renfort.getEquipe().getCode().toString()).collect(Collectors.toList());
        List<String> codesStToInclude = new ArrayList<>();
        codesStToInclude.addAll(getEntiteStructureFromProfile(sgUserPrincipal));
        codesStToInclude.addAll(getEntiteStructureFromPerimetrePilotage(sgUserPrincipal));
        codesStToInclude.addAll(codesStFromRenfort);
        List<ServiceTraitement> servicesTraitement = findSt(codeEntiteRattachement, entiteStructureFromRes, codesStToInclude);
        if (!servicesTraitement.isEmpty()) {
            List<String> codesSt = servicesTraitement.stream().map(ServiceTraitement::getId).collect(Collectors.toList());
            List<UniteGestion> uniteGestionsByCodeSt = findUgsByCodesSt(codesSt, entiteStructureFromRes);
            if (!uniteGestionsByCodeSt.isEmpty()) {
                centresService.addAll(getCentreServices(entiteStructureFromRes, uniteGestionsByCodeSt));
            }
        }

        if (centresService.isEmpty()) {
            return entiteStructureFromRes;
        }

        return centresService;
    }

    private List<CentreService> getCentreServices(List<CentreService> entiteStructureFromRes, List<UniteGestion> unitesGestion) {

        List<CentreService> centreServicesByCodesUniteGestion = new ArrayList<>();
        unitesGestion.forEach(uniteGestion -> {
            Optional<CentreService> centreServiceByCodesUniteGestionOpt = findCdsByCodeUg(uniteGestion.getId(), entiteStructureFromRes);
            if (centreServiceByCodesUniteGestionOpt.isPresent()) {
                CentreService centreServiceByCodesUniteGestion = centreServiceByCodesUniteGestionOpt.get();
                centreServicesByCodesUniteGestion.add(
                        CentreService.builder()
                                .id(centreServiceByCodesUniteGestion.getId())
                                .libelle(centreServiceByCodesUniteGestion.getLibelle())
                                .uniteGestions(List.of(uniteGestion))
                                .teteDePerimetres(centreServiceByCodesUniteGestion.getTeteDePerimetres())
                                .build()
                );
            }
        });
        if (!centreServicesByCodesUniteGestion.isEmpty()) {
            return centreServicesByCodesUniteGestion;
        }
        return Collections.emptyList();
    }

    private List<UniteGestion> findUgsByCodesSt(List<String> codesST, List<CentreService> entiteStructureFromRes) {
        return entiteStructureFromRes.stream()
                .map(CentreService::getUniteGestions)
                .flatMap(List::stream)
                .filter(uniteGestion ->
                        uniteGestion.getServiceTraitements().stream()
                                .anyMatch(serviceTraitement -> codesST.contains(serviceTraitement.getId())))
                .collect(Collectors.toList());
    }

    private Optional<CentreService> findCdsByCodeUg(String id, List<CentreService> entiteStructureFromRes) {
        return entiteStructureFromRes.stream().filter(centreService -> centreService.getUniteGestions().stream()
            .anyMatch(uniteGestion -> uniteGestion.getId().equalsIgnoreCase(id))).findFirst();
    }

    private List<ServiceTraitement> findSt(String codeEntiteRattachement, List<CentreService> entiteStructureFromRes, List<String> codesStToInclude) {
        return entiteStructureFromRes.stream()
                .map(CentreService::getUniteGestions)
                .flatMap(List::stream)
                .map(UniteGestion::getServiceTraitements).flatMap(List::stream)
                .filter(serviceTraitement ->
                        serviceTraitement.getId().equalsIgnoreCase(codeEntiteRattachement) || codesStToInclude.contains(serviceTraitement.getId()))
                .collect(Collectors.toList());
    }

    private List<UniteGestion> findUg(List<String> codesUgToInclude, List<CentreService> entiteStructureFromRes) {
        return entiteStructureFromRes.stream()
                .map(CentreService::getUniteGestions)
                .flatMap(List::stream)
                .filter(uniteGestion -> codesUgToInclude.contains(uniteGestion.getId()))
                .collect(Collectors.toList());
    }

    private Optional<CentreService> findCds(String codeEntiteRattachement, List<CentreService> entiteStructureFromRes) {
        return entiteStructureFromRes.stream()
            .filter(centreService -> centreService.getId().equalsIgnoreCase(codeEntiteRattachement)).findFirst();
    }

    private List<String> getEntiteStructureFromProfile(SgUserPrincipal sgUserPrincipal) {
        Map<String, String> customParams = sgUserPrincipal.getCurrentUser().getCustomParams();
        if (customParams.isEmpty()) {
            return Collections.emptyList();
        }
        String sgstructureatt = customParams.get("sgstructureatt");
        String[] codeSts = StringUtils.substringsBetween(sgstructureatt, "IdEs=", ":");
        return Arrays.asList(Optional.ofNullable(codeSts).orElse(new String[0]));
    }

    private List<String> getEntiteStructureFromPerimetrePilotage(SgUserPrincipal sgUserPrincipal) {
        Map<String, List<Role>> roles = sgUserPrincipal.getCurrentUser().getRoles();
        if (roles.isEmpty()) {
            return Collections.emptyList();
        }
        return roles.get("EQC").stream()
                .flatMap(role -> role.getParameters().stream())
                .filter(parameter -> parameter.getName().equals("Perimetre"))
                .map(parameter -> parameter.getValue().split(","))
                .map(Arrays::asList)
                .flatMap(Collection::stream)
                .distinct()
                .collect(Collectors.toList());
    }
}
