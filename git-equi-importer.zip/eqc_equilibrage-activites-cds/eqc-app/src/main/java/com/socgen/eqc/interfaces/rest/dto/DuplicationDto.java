package com.socgen.eqc.interfaces.rest.dto;

import lombok.*;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DuplicationDto {

    @NotNull
    private List<String> matricules;
    @NotNull
    private LocalDate dateSource;
    @NotNull
    private LocalDate dateCible;

}
