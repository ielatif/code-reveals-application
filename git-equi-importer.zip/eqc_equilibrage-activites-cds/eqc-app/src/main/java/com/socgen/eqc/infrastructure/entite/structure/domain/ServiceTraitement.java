package com.socgen.eqc.infrastructure.entite.structure.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ServiceTraitement extends EntiteStructure implements Serializable {

    private static final long serialVersionUID = 7510256966666950528L;

    @JsonProperty("id")
    private String id;

    @JsonProperty("libelle")
    private String libelle;

    private String ville;

    @JsonProperty("listeTetePerimetre")
    private List<TetePerimetre> listeTetePerimetre;
}
