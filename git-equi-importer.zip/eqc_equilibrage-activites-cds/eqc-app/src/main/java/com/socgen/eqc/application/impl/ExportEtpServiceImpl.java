package com.socgen.eqc.application.impl;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.socgen.eqc.application.ExportEtpService;
import com.socgen.eqc.domain.model.ExportEtp;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.ServiceTraitement;
import com.socgen.eqc.infrastructure.entite.structure.domain.UniteGestion;
import com.socgen.eqc.infrastructure.persistance.ExportEtpRepository;
import com.socgen.eqc.infrastructure.res.ResClient;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.RefActiviteDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static java.util.stream.Collectors.toMap;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExportEtpServiceImpl implements ExportEtpService {

    private final ExportEtpRepository exportEtpRepository;
    @Qualifier("appToAppSmboClient")
    private final SmboClient appToAppSmboClient;
    private final ResClient resClient;

    @Override
    public List<ExportEtp> getEtps(LocalDate from, LocalDate to) {
        List<ExportEtp> etps = this.exportEtpRepository.getEtps(from, to);
        ajouterLibellesActivites(etps);
        ajouterDonneesRes(etps);

        return etps;
    }

    @Override
    public File getEtpsCsv(String from, String to) {

        try {
            LocalDate fromDate = LocalDate.parse(from, DateTimeFormatter.ISO_DATE);
            LocalDate toDate = LocalDate.parse(to, DateTimeFormatter.ISO_DATE);

            ObjectWriter objectWriter = createObjectWriter();
            FileAttribute<Set<PosixFilePermission>> attr = PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwxr-----"));
            String filename = "etp_export_" + fromDate.toString() + "_" + toDate.toString();
            File tempFile = Files.createTempFile(filename, ".csv", attr).toFile();
            try (FileOutputStream tempFileOutputStream = new FileOutputStream(tempFile);
                 BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(tempFileOutputStream, 1024)) {
                OutputStreamWriter writerOutputStream = new OutputStreamWriter(bufferedOutputStream, StandardCharsets.UTF_8);
                objectWriter.writeValue(writerOutputStream, getEtps(fromDate, toDate));
            }
            tempFile.deleteOnExit();
            return tempFile;

        } catch (IOException e) {
            log.error("An error occured while creating CSV File to export ", e);
        }

        return null;
    }

    private ObjectWriter createObjectWriter() {
        CsvMapper csvMapper = new CsvMapper();
        CsvSchema csvSchema = csvMapper
                .schemaFor(ExportEtp.class)
                .sortedBy("cdsCode", "cdsLabel", "ugCode", "ugLabel", "stCode", "stLabel", "activiteCode", "activiteLabel",
                        "collaboratorMatricule", "day", "etp", "renfort", "stRattachementCollabCode",
                        "stRattachementCollabLabel")
                .withHeader();

        return csvMapper.writer(csvSchema);
    }

    private void ajouterLibellesActivites(List<ExportEtp> etps) {
        final Map<String, String> activityReferential= appToAppSmboClient.getAllFamilles().stream().flatMap(refFamilleDto -> refFamilleDto.getActivites().stream())
                .collect(toMap(RefActiviteDto::getCode, RefActiviteDto::getLibelle));
        etps.stream()
                .filter(etp -> etp.getActiviteCode() != null)
                .forEach(etp -> etp.setActiviteLabel(activityReferential.get(etp.getActiviteCode())));
    }

    private void ajouterDonneesRes(List<ExportEtp> etps) {
        List<CentreService> centreServices = resClient.getEntiteStructure();

        Map<String, String> filiereLibelleByCode = centreServices.stream()
                .collect(toMap(CentreService::getId, CentreService::getLibelle));

        Map<String, String> ugLibelleByCode = centreServices.stream()
                .flatMap(centreService -> centreService.getUniteGestions().stream())
                .collect(toMap(UniteGestion::getId, UniteGestion::getLibelle));

        Map<String, String> stLibelleByCode = centreServices.stream()
                .flatMap(centreService -> centreService.getUniteGestions().stream())
                .flatMap(uniteGestion -> uniteGestion.getServiceTraitements().stream())
                .collect(toMap(ServiceTraitement::getId, ServiceTraitement::getLibelle));

        Map<String, String> codeCdsByCodeSt = new HashMap<>();
        Map<String, String> codeUgByCodeSt = new HashMap<>();
        for (CentreService cds : centreServices) {
            for (UniteGestion ug : cds.getUniteGestions()) {
                for (ServiceTraitement st : ug.getServiceTraitements()) {
                    codeCdsByCodeSt.put(st.getId(), cds.getId());
                    codeUgByCodeSt.put(st.getId(), ug.getId());
                }
            }
        }

        etps.forEach(etp -> {
            etp.setCdsCode(codeCdsByCodeSt.get(etp.getStCode()));
            etp.setCdsLabel(filiereLibelleByCode.getOrDefault(etp.getCdsCode(), etp.getCdsLabel()));
            etp.setUgCode(codeUgByCodeSt.get(etp.getStCode()));
            etp.setUgLabel(ugLibelleByCode.getOrDefault(etp.getUgCode(), etp.getUgLabel()));
            etp.setStLabel(stLibelleByCode.getOrDefault(etp.getStCode(), etp.getStLabel()));
            etp.setStAideLabel(stLibelleByCode.getOrDefault(etp.getStAideCode(), etp.getStAideLabel()));
            etp.setStRattachementCollabLabel(stLibelleByCode.getOrDefault(etp.getStRattachementCollabCode(), etp.getStRattachementCollabLabel()));
        });
    }
}
