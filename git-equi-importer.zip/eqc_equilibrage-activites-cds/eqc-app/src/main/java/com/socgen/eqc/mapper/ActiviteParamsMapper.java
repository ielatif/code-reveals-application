package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteParamsDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring", uses = {ExpertiseMapper.class, DefaultExpertiseMapper.class, ActiviteRatioMapper.class, ActiviteRatioMapper.class})
public interface ActiviteParamsMapper {

    ActiviteParamsDto toDto(ActiviteParams activite);

    List<ActiviteParamsDto> toDto(List<ActiviteParams> activite);

    ActiviteParams toDomain(ActiviteParamsDto activiteParamsDto);
}
