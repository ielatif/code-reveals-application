package com.socgen.eqc.infrastructure.gershwin.client;

import com.socgen.eqc.application.exception.TechnicalException;
import com.socgen.eqc.config.ApplicationProperties.Gershwin;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.infrastructure.gershwin.model.AccessTokenErrorResponse;
import com.socgen.eqc.infrastructure.gershwin.model.AccessTokenResponse;
import com.socgen.eqc.infrastructure.gershwin.model.Approver;
import com.socgen.eqc.infrastructure.gershwin.model.ApproverDataListResponse;
import com.socgen.eqc.infrastructure.gershwin.model.UserDataCalendar;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.glassfish.jersey.internal.util.collection.MultivaluedStringMap;
import org.springframework.cache.annotation.Cacheable;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import java.util.Optional;

import static javax.ws.rs.core.HttpHeaders.AUTHORIZATION;
import static javax.ws.rs.core.HttpHeaders.CACHE_CONTROL;

@RequiredArgsConstructor
@Slf4j
public class GershwinClientImpl implements GershwinClient {

	private static final String X_BSC_SOA_CONSUMER_NAME = "X-BSC-SOA-CONSUMER-NAME";
	private static final String X_BSC_SOA_CONSUMER_CODE = "X-BSC-SOA-CONSUMER-CODE";
	private static final String X_BSC_SOA_CONSUMER_ORG = "X-BSC-SOA-CONSUMER-ORG";
	private static final String X_BSC_SOA_CONSUMER_APP_NAME = "X-BSC-SOA-CONSUMER-APP-NAME";
	private static final String X_BSC_SOA_CONSUMER_APP_CODE = "X-BSC-SOA-CONSUMER-APP-CODE";
	private static final String X_BSC_SOA_USER_ID = "X-BSC-SOA-USER-ID";

	private final WebTarget ooormTarget;
	private final Gershwin gershwin;

	@Override
    @Cacheable(EqcCacheConfig.CACHE_GERSHWIN_NAME)
	public UserDataCalendar getTeamCalendar(String idRhManager, String mois) {
		log.info("Récupérer le calendrier Gershwin du manager={} pour le mois={}", idRhManager, mois);
		Response response = ooormTarget.path(gershwin.getCalendarPath())
				.queryParam("userId", idRhManager)
				.queryParam("month", mois)
				.request("*/*")
				.headers(bscConsumerHeaders())
				.header(AUTHORIZATION, getAccessToken())
				.header(X_BSC_SOA_USER_ID, idRhManager)
				.header(CACHE_CONTROL, "no-cache")
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.get();

		if (Response.Status.Family.SUCCESSFUL != response.getStatusInfo().getFamily()) {
			log.error("Problème Gershwin {}", response.getEntity());
			throw new ClientErrorException(response.getStatus());
		}

		UserDataCalendar userDataCalendar = response.readEntity(UserDataCalendar.class);
		log.info("Le calendrier Gershwin pour le manager={} pour le mois={} sont récupérées avec success", idRhManager, mois);
		return userDataCalendar;
	}

	@Override
	@Cacheable(EqcCacheConfig.CACHE_GERSHWIN_NAME)
	public Optional<Approver> getApprover(String idRhUser) {
		log.info("Récupérer l'approver Gershwin du user={}", idRhUser);
		Response response = ooormTarget.path(gershwin.getApproversPath())
				.queryParam("userId", idRhUser)
				.queryParam("all", false)
				.request("*/*")
				.headers(bscConsumerHeaders())
				.header(AUTHORIZATION, getAccessToken())
				.header(X_BSC_SOA_USER_ID, idRhUser)
				.header(CACHE_CONTROL, "no-cache")
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.get();

		if (Response.Status.Family.SUCCESSFUL != response.getStatusInfo().getFamily()) {
			log.error("Problème Gershwin {}", response.getEntity());
			throw new ClientErrorException(response.getStatus());
		}

		ApproverDataListResponse approverDataListResponse = response.readEntity(ApproverDataListResponse.class);

		if (approverDataListResponse.getData().isEmpty()) {
			log.info("L'approver Gershwin du user {} n'est pas trouvé", idRhUser);
			return Optional.empty();
		}
		log.info("L'approver Gershwin du user {} est récupéré avec success", idRhUser);
		return Optional.ofNullable(approverDataListResponse.getData().get(0));
	}

	private String getAccessToken() {
		Response response = ooormTarget.path(gershwin.getAuthorizationPath())
				.request(MediaType.APPLICATION_JSON)
				.headers(bscConsumerHeaders())
				.post(Entity.form(accessData()));

		if (Response.Status.Family.SUCCESSFUL != response.getStatusInfo().getFamily()) {
			AccessTokenErrorResponse error = response.readEntity(AccessTokenErrorResponse.class);
			log.error("Problème Gershwin : {} {}", error.getError(), error.getErrorDescription());
			throw new TechnicalException("Une erreur est survenue lors de la récupération des absences Gershwin");
		}

		log.info("Gershwin access token récupérer avec success");

		AccessTokenResponse accessTokenResponse = response.readEntity(AccessTokenResponse.class);

		return "Bearer " + accessTokenResponse.getAccessToken();
	}

	private MultivaluedMap<String, Object> bscConsumerHeaders() {
		MultivaluedMap<String, Object> headers = new MultivaluedHashMap<>();
		headers.add(X_BSC_SOA_CONSUMER_NAME, "EQC");
		headers.add(X_BSC_SOA_CONSUMER_CODE, "A5340");
		headers.add(X_BSC_SOA_CONSUMER_ORG, "ITIM");
		headers.add(X_BSC_SOA_CONSUMER_APP_NAME, "EQC");
		headers.add(X_BSC_SOA_CONSUMER_APP_CODE, "A5340");
		return headers;
	}

	private MultivaluedMap<String, String> accessData() {
		MultivaluedMap<String, String> accessData = new MultivaluedStringMap();
		accessData.add("client_id", gershwin.getClientId());
		accessData.add("client_secret", gershwin.getClientSecret());
		accessData.add("grant_type", gershwin.getGrantType());
		accessData.add("scope", gershwin.getScope());
		return accessData;
	}
}
