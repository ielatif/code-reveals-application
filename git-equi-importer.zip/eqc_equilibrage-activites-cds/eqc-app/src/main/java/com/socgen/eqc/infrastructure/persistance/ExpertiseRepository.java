package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Expertise;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.Tuple;
import java.util.List;
import java.util.Set;

public interface ExpertiseRepository extends JpaRepository<Expertise, Long> {

    Expertise findByActiviteCodeAndNiveauId(String codeActivite, Long idNiveau);
    Set<Expertise> findByActiviteCode(String codeActivite);

    @Query(value = "SELECT exp.nombre_dossier as nombreDossier, exp.code_activite as codeActivite, " +
            "exp.id_niveau as idNiveau FROM expertise exp WHERE code_activite in (:activites)", nativeQuery = true)
    List<Tuple> findExpertiseByActivites(@Param("activites") Set<String> activites);

    List<Expertise> findByActiviteCodeIn(List<String> codesActivites);
}
