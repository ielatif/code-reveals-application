package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class RatioTypeDto implements Serializable {

    private static final long serialVersionUID = 5573605281812881374L;

    private String code;

    private String libelle;
}
