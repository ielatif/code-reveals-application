package com.socgen.eqc.interfaces.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompetenceDto {

    private Long id;

    private String matricule;

    private String codeFamille;

    private String codeActivite;

    private String libelleActivite;

    private int ordreActivite;

    private Long idNiveau;

    private String libelleNiveau;

    private Map<Long, Float> mapNombreDossiers;

    private Boolean isUpdated;

    private LocalDate lastModifiedDate;
}
