package com.socgen.eqc.infrastructure.gershwin.client;

import com.socgen.eqc.infrastructure.gershwin.model.Approver;
import com.socgen.eqc.infrastructure.gershwin.model.UserDataCalendar;

import java.util.Optional;

public interface GershwinClient {

	UserDataCalendar getTeamCalendar(String idRhManager, String mois);

	Optional<Approver> getApprover(String idRhUser);
}
