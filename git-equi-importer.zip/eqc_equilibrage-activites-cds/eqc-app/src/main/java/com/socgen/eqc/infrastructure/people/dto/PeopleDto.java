package com.socgen.eqc.infrastructure.people.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class PeopleDto implements Serializable {

    private static final long serialVersionUID = 7130328073037314078L;

    @JsonProperty("codeActiviteMaia")
    public String codeActiviteMaia;

    @JsonProperty("codeCentreActivite")
    public String codeCentreActivite;

    @JsonProperty("codeEmploi")
    public String codeEmploi;

    @JsonProperty("codeFilialePyr")
    public String codeFilialePyr;

    @JsonProperty("codeGeo")
    public String codeGeo;

    @JsonProperty("codeService")
    public String codeService;

    @JsonProperty("dateEntreePoste")
    public String dateEntreePoste;

    @JsonProperty("etatCivilEn")
    public String etatCivilEn;

    @JsonProperty("etatCivilFr")
    public String etatCivilFr;

    @JsonProperty("id")
    public Integer id;

    @JsonProperty("idCnxRtfe")
    public String idCnxRtfe;

    @JsonProperty("idGG")
    public String idGG;

    @JsonProperty("idRhLocal")
    public String idRhLocal;

    @JsonProperty("indSiegeReseau")
    public String indSiegeReseau;

    @JsonProperty("libActiviteMaia")
    public String libActiviteMaia;

    @JsonProperty("libEmploi")
    public String libEmploi;

    @JsonProperty("libFiliale")
    public String libFiliale;

    @JsonProperty("libGeo")
    public String libGeo;

    @JsonProperty("libService")
    public String libService;

    @JsonProperty("mailPresentation")
    public String mailPresentation;

    @JsonProperty("nom")
    public String nom;

    @JsonProperty("prenom")
    public String prenom;

    @JsonProperty("presPersonne")
    public String presPersonne;

    @JsonProperty("zoneRtfe")
    public String zoneRtfe;
}
