package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.annotations.SgSignInRolesAllowed;
import com.socgen.eqc.application.AbsenceService;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.socgen.eqc.domain.model.RoleEqc.*;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/absences")
@Slf4j
@Api(value = "absences")
public class AbsenceResource {

    @Autowired
    private AbsenceService absenceService;

    @GET
    @ApiOperation(value = "Récupération des absences par ST", notes = "Récupération de toutes les familles du référentiel")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les absences sont bien récupérées")
    })
    @Path("/services-traitements/{codeServiceTraitement}")
    @SgSignInRolesAllowed({CONSULTER_VUE_COLLAB, CONSULTER_PLANNING, GERER_PLANNING})
    public Response getAbsencesByServiceTraitement(@BeanParam PlanningSearchDto planningSearchDto) {
        return Response.ok(absenceService.findAbsence(planningSearchDto)).build();
    }
}
