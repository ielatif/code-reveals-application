package com.socgen.eqc.domain.model;


import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@EqualsAndHashCode(exclude = {"affiliation", "sousEquipe"})
@Entity(name = "AFFILIATION_SOUS_EQUIPE")
@Table(name = "AFFILIATION_SOUS_EQUIPE",
        uniqueConstraints = {@UniqueConstraint(columnNames = {"affiliation_id", "sous_equipe_id"})})
public class AffiliationSousEquipe implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "affiliation_id", nullable = false)
    private Affiliation affiliation;

    @ManyToOne
    @JoinColumn(name = "sous_equipe_id", nullable = false)
    private SousEquipe sousEquipe;
}
