package com.socgen.eqc.domain.model;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class ExportEtp {

    private String cdsLabel;
    private String cdsCode;
    private String ugLabel;
    private String ugCode;
    private String stRattachementCollabLabel;
    private String stRattachementCollabCode;
    private String stAideLabel;
    private String stAideCode;
    private String stLabel;
    private String stCode;
    private String day;
    private String collaboratorName;
    private String collaboratorMatricule;
    private String renfort;
    private String activiteLabel;
    private String activiteCode;
    private BigDecimal etp;
}
