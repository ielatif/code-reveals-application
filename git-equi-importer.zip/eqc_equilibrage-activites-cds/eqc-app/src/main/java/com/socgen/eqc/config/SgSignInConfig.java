package com.socgen.eqc.config;

import com.socgen.dga.idp.jaxrs.DefaultSgSignIn;
import com.socgen.dga.idp.jaxrs.SgSignIn;
import com.socgen.dga.idp.jaxrs.commons.ConfigKey;
import com.socgen.dga.idp.jaxrs.commons.utils.CacheProvider;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PreDestroy;
import javax.cache.Cache;

@Configuration
@AllArgsConstructor
public class SgSignInConfig {

	private final ApplicationProperties applicationProperties;

	private final CacheProvider cacheProviderSgSigin = new CacheProvider();
	private final Cache<String, String> sgSignInCache = cacheProviderSgSigin.createCache();

	@Bean(name = ConfigKey.SG_SIGNIN_BEAN_NAME)
	public SgSignIn getSgSignInInstance() {
		//============================
		// Mandatory config
		//===========================
		final SgSignIn sgSignIn = new DefaultSgSignIn();
		sgSignIn.setClientId(applicationProperties.getSgSignIn().getClientId());
		sgSignIn.setClientSecret(applicationProperties.getSgSignIn().getClientSecret());
		sgSignIn.setServerURL(applicationProperties.getSgSignIn().getServerUrl());
		sgSignIn.enableCORS("*");
		sgSignIn.setTrigram(applicationProperties.getTrigram());
		sgSignIn.setOAuth2RedirectUrl(applicationProperties.getSgSignIn().getRedirectUrl().trim());
        sgSignIn.setCustomParams("sgstructureatt");

		if (applicationProperties.getSgSignIn().isAcceptOnlyRequestsFromSSOP()) {
			sgSignIn.acceptOnlyRequestsFromSSOP();
		}

		return sgSignIn;
	}

	@Bean(name = ConfigKey.SG_SIGNIN_CACHE_BEAN_NAME)
	public Cache<String, String> getSgSignInCacheInstance() {
		return sgSignInCache;
	}

	@PreDestroy
	public void destroyCache() {
			cacheProviderSgSigin.clearCache();
	}
}
