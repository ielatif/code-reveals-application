package com.socgen.eqc.infrastructure.res.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Cette Classe est un DTO d''entrée qui contient les parametres de recherche pour une entité de Strcture
 * listeDepartements : Permet de definir la liste des departements des entites de structure à récupérer
 * listeCodeTypes : Permet de definir la liste des code type (022: CDS, 023: UG, 024: ST) des entites de structure à récupérer
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EsInputDTO {

    private List<String> listeDepartements;
    private List<String> listeCodeTypes;
}
