package com.socgen.eqc.interfaces.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@SuperBuilder
public class ExtensionPerimetreDto {

    private Long id;

    private Long idGhabi;

    private Integer etat;
}
