package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.ActiviteRatioService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Path("/ratio")
@Api(value = "ratio")
public class RatioReource {


    @Autowired
    private ActiviteRatioService ratioService;

    @GET
    @ApiOperation(value = "Récupération des activités ratio par tête de périmetre", notes = "Récupération des activités ratio par tête de périmetre")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Le planning est bien récupéré")
    })
    public Response getActiviteRatio(@QueryParam("tetePerimetre") @NotNull String tetePerimetre) {
        return Response.ok(ratioService.getAllActiviteRatioByTetePerimetre(tetePerimetre)).build();
    }

    @GET
    @Path(("/type"))
    public Response getRatioTypes() {
        return Response.ok(ratioService.getRatioTypes()).build();
    }



}
