package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.ActiviteService;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.constraints.NotBlank;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Api(tags = {"activites"})
public class ActiviteResource {

    @PathParam("code")
    private String codeFamille;

    @Autowired
    private ActiviteService activiteService;


    @POST
    @ApiOperation(value = "Créer une Activité", notes = "Création d'une activité")
    @ApiResponses({
            @ApiResponse(code = 201, message = "L activité est bien créé"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response createRefActivite(ActiviteDto activiteDto) {
        log.info("Création de l'activité {} ", activiteDto.getRefActiviteDto().getLibelle());
        activiteDto.getRefActiviteDto().setCodeFamille(codeFamille);
        return Response.status(Response.Status.CREATED)
                .entity(activiteService.create(activiteDto))
                .build();
    }

    @PUT
    @Path("{codeActivite}")
    @ApiOperation(value = "MAJ une Activité", notes = "Mise a jour d'une activité")
    @ApiResponses({
            @ApiResponse(code = 201, message = "L'activité a bien été mise à jour"),
            @ApiResponse(code = 405, message = "Mauvaises données en entrée")
    })
    public Response updateActivite(ActiviteDto activiteDto, @NotBlank @PathParam("codeActivite") String codeActivite) {
        activiteDto.getRefActiviteDto().setCode(codeActivite);
        activiteDto.getRefActiviteDto().setCodeFamille(codeFamille);
        return Response.status(Response.Status.OK)
                .entity(activiteService.update(activiteDto))
                .build();
    }

}
