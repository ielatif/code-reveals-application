package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.ActiviteParamsService;
import com.socgen.eqc.interfaces.rest.dto.ActiviteOrdreDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Path("/activites-params")
@Api(value = "activites-params")
public class ActiviteParamsResource {


    @Autowired
    private ActiviteParamsService activiteParamsService;

    @GET
    @ApiOperation(value = "Récupération des activités", notes = "Récupération des activités")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les activités sont bien récupérées")
    })
    public Response getAllActiviteParams() {
        return Response.ok(activiteParamsService.findAll()).build();
    }

    @PUT
    @Path("/update-ordre")
    @ApiOperation(value = "Mettre à jour d'une liste d'activité", notes = "Mettre à jour d'une liste d'activité")
    @ApiResponses({
            @ApiResponse(code = 201, message = "La famille est bien mise à jour"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response updateOrdreActivites(List<ActiviteOrdreDto> activiteOrdreDtos) {
        activiteParamsService.updateOrdreActivites(activiteOrdreDtos);
        return Response.noContent().build();
    }

}
