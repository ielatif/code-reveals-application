package com.socgen.eqc.application;

import com.socgen.eqc.infrastructure.smbo.dto.RefFamilleDto;

import java.util.List;

public interface FamilleService {
    List<RefFamilleDto> getAll();

    RefFamilleDto saveFamille(RefFamilleDto famille);

    void updateFamilles(RefFamilleDto famille);

    List<RefFamilleDto> saveFamille(List<RefFamilleDto> familleDto);
}
