package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Niveau;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NiveauRepository extends JpaRepository<Niveau, Long> {

}
