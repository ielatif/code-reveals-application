package com.socgen.eqc.infrastructure.smbo;

import com.socgen.eqc.infrastructure.smbo.dto.*;
import com.socgen.eqc.interfaces.rest.dto.IncidentDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.TetePerimetreDto;

import java.time.LocalDate;
import java.util.List;

public interface SmboClient {

    RefActiviteDto saveActivite(RefActiviteDto refActiviteDto);

    List<TetePerimetreDto> getAllTetePerimetres();

    List<ReferentielProcessusDto> getAllProcessusByTetePerimetre(List<Long> codeTetePerimetres, Source source);

    List<RefFamilleDto> getAllFamilles();

    RefFamilleDto saveFamilles(RefFamilleDto refFamilleDto);

    List<IndicateurActiviteDto> getIndicateurBrut(List<String> listCodeServiceTraitement, LocalDate dateDebut, LocalDate dateFin, List<String> tetePerimetres);

    List<CorrespondanceActiviteDto> getAllCorrespondanceByTetePerimetre(List<Long> tetePerimetres);

    void saveCorrespondances(CorrespondanceActiviteDto correspondanceActiviteDto);

    List<RefFamilleDto> updateListFamille(List<RefFamilleDto> famillesDto);

    List<IncidentDto> getIncident();

    RefProcessusOutputDto saveOrUpdateProcessus(RefProcessusInputDto processus);

    String getIndicateurSuivieActivite(String dateDebut, String dateFin, List<String> tetePerimetre, List<String> listCodeServiceTraitement);

    SaisieGlobaleOutputDto addStockSaisieGlobale(SaisieGlobaleInputDto saisieGlobaleInputDto);

    List<SaisieGlobaleStockOutputDto> getSaisieGlobaleIndicateurs(List<Long> tetePerimtres, String codeSt, String userId);
}
