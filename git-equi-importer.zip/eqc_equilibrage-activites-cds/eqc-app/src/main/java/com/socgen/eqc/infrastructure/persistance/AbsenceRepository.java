package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Absence;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface AbsenceRepository extends JpaRepository<Absence, Long> {

    List<Absence> findByMatriculeCollaborateurIn(List<String> matricules);

    void deleteAllByMatriculeCollaborateurAndDateAfter(String matricule, LocalDate date);

    List<Absence> findByMatriculeCollaborateurInAndDateBetween(Collection<String> matricules, LocalDate dateDebut,
                                                               LocalDate dateFin);

    Optional<Absence> findByMatriculeCollaborateurAndDate(String matricule, LocalDate date);

    void deleteAllByMatriculeCollaborateurInAndDateBetween(List<String> matricule, LocalDate dateDebut, LocalDate dateFin);

}
