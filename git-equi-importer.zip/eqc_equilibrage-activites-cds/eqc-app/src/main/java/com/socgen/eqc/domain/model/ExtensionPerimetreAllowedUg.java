package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity(name = "ExtensionPerimetreAllowedUg")
@Table(name = " EXTENSION_PERIMETRE_ALLOWED_UG")
public class ExtensionPerimetreAllowedUg implements Serializable {

    @Id
    @Column(name = "code", nullable = false, unique = true)
    private String code;

    private String libelle;
}
