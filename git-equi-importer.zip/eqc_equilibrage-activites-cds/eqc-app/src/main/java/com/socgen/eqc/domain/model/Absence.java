package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode
@Builder
@Entity(name = "ABSENCE")
@Table(name = " ABSENCE", uniqueConstraints = {@UniqueConstraint(columnNames = {"matricule_collaborateur", "date"})})
public class Absence {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
	@EqualsAndHashCode.Exclude
    private Long id;

    @Column(name = "matricule_collaborateur", nullable = false)
    private String matriculeCollaborateur;

    @Column(name = "date", nullable = false)
    private LocalDate date;

    @Column(name = "intervalle", nullable = false)
    private Intervalle intervalle;
}
