package com.socgen.eqc.config;

import com.socgen.digital.agence.boot.metric.autoconfigure.MetricContributorRestAutoConfiguration;
import com.socgen.digital.agence.metric.contributor.ContributorMetricsService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.ws.rs.client.Client;
import java.util.Collection;
import java.util.Optional;

@Configuration
@AutoConfigureAfter({MetricContributorRestAutoConfiguration.class, ClientRestConfig.class})
@ConditionalOnProperty(
		name = {"metrics.contributor.enabled"},
		havingValue = "true"
)
@RequiredArgsConstructor
public class EqcContributorMetricsClientFilterConfig {

	private final ContributorMetricsService contributorsMetricsService;
	private final Collection<Client> restClients;

	@PostConstruct
	private void registerContributorMetricsClientFilter() {
		for (Client client : restClients) {
			client.register(new EqcContributorMetricsClientFilter(Optional.of(contributorsMetricsService)));
		}
	}
}
