package com.socgen.eqc.infrastructure.batch.repository;

import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

public interface ConsolideRepository extends JpaRepository<ConsolideMensuel, Long> {

    @Transactional
    void deleteAllByMonthYearConsolide(String monthYearConsolide);
}
