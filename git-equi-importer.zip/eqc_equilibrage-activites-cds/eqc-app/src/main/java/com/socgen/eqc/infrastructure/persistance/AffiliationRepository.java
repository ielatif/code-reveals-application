package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Affiliation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AffiliationRepository extends JpaRepository<Affiliation, Long> {

    @Query("SELECT a FROM AFFILIATION a WHERE a.equipe.id=:equipeId and ( a.dateSortie = null Or a.dateSortie>:dateDebut   ) and a.dateEntree<=:dateFin  ")
    List<Affiliation> findByEquipeIdAndDates(@Param("equipeId") Long equipeId, @Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin);

    @Query("SELECT a FROM AFFILIATION a WHERE a.equipe.id=:equipeId and ( (a.dateSortie = null and a.dateEntree<=:date) Or (a.dateSortie>:date and a.dateEntree<=:date ))")
    List<Affiliation> findByEquipeIdAndDate(@Param("equipeId") Long equipeId, @Param("date") LocalDate date);

    @Query("SELECT a FROM AFFILIATION a WHERE a.collaborateur.matricule=:matricule and a.dateSortie = null")
    Affiliation findActiveByMatricule(@Param("matricule") String matricule);

    @Query("SELECT a FROM AFFILIATION a WHERE a.equipe.id=:equipeId and a.collaborateur.matricule = :matricule and ((a.dateSortie = null and a.dateEntree<=:date) Or (a.dateSortie>:date and a.dateEntree<=:date ))")
    Optional<Affiliation> findByEquipeIdAndMatriculeAndDate(@Param("equipeId") Long equipeId, @Param("date") LocalDate date,  @Param("matricule") String matricule);

    Optional<Affiliation> findByEquipeCodeAndCollaborateurMatriculeAndDateSortieIsNull(Long codeEquipe, String matricule);

    @Query("SELECT a FROM AFFILIATION a WHERE a.collaborateur.matricule in (:matricules) and a.dateSortie = null")
    List<Affiliation> findActiveByMatricules(@Param("matricules") List<String> matricules);

    @Query("SELECT a FROM AFFILIATION a WHERE a.equipe.id=:equipeId and (a.collaborateur.matricule=:matricule)and ( a.dateSortie = null Or a.dateSortie>=:dateDebut   ) and a.dateEntree<=:dateFin  ")
    Affiliation findByEquipeIdAndDatesAndMatricule(@Param("equipeId") Long equipeId, @Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin, @Param("matricule") String matricule);

    Affiliation findTopByCollaborateurMatriculeOrderByDateSortieDesc(String matricule);

    @Query("SELECT a FROM AFFILIATION a WHERE a.equipe.id in (:equipeIds) and ( a.dateSortie = null Or a.dateSortie>=:dateDebut   ) and a.dateEntree<=:dateFin  ")
    List<Affiliation> findByEquipeIdInAndDates(@Param("equipeIds") List<Long> equipeIds, @Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin);

    @Query("SELECT a FROM AFFILIATION a WHERE a.collaborateur.matricule=:matricule and ( a.dateSortie = null Or a.dateSortie>:dateDebut   ) and a.dateEntree<=:LocalDate")
    List<Affiliation> findByMatriculeAndDate(@Param("matricule") String matricule, @Param("dateDebut") LocalDate dateDebut, @Param("LocalDate") LocalDate dateFin);

    @Query("SELECT a FROM AFFILIATION a WHERE a.collaborateur.matricule=:matricule and ( a.dateSortie = null Or a.dateSortie>:dateDebut   ) and a.dateEntree<=:dateFin")
    List<Affiliation>  findByMatriculeAndDateDebutAndDateFin(@Param("matricule") String matricule, @Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin);

    @Query(nativeQuery = true, value = "select count(*) from affiliation where date_sortie is null")
    Long fetchAffiliationCount();

    @Query("SELECT a FROM AFFILIATION a WHERE a.equipe.id in (:idsEquipes) and a.dateSortie = null ")
    List<Affiliation> findbyListEquipeAndActive(List<Long> idsEquipes);
}
