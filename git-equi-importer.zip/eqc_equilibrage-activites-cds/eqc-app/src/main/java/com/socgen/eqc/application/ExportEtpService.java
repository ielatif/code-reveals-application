package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.ExportEtp;

import java.io.File;
import java.time.LocalDate;
import java.util.List;

public interface ExportEtpService {

    List<ExportEtp> getEtps(LocalDate from , LocalDate to);

    File getEtpsCsv(String from , String to);
}
