package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Competence;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractCompetencesDto;
import com.socgen.eqc.interfaces.rest.dto.CompetenceDto;
import com.socgen.eqc.interfaces.rest.dto.ProfilDto;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface CompetenceService {

   ProfilDto getProfilByCollaborateur(String matricule, Long codeStRattachement, LocalDate dateDebut, LocalDate dateFin);

   List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> getProfilByServiceTraitement(Long codeServiceTraitement);

   List<com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto> getProfilByServiceTraitementAndMatricule(Long codeServiceTraitement, String matricule);

   void updateProfilCollaborateur(String matricule, List<CompetenceDto> actionCompetenceDto);

   List<Competence> getProfilByCollaborateurs(List<Collaborateur> collaborateurs, Map<String, List<Affiliation>> affiliationByCollab);

   List<Competence> getProfilByCollaborateur(Collaborateur collaborateur, Affiliation affiliation);

   List<ExtractCompetencesDto> getCompetencesExtractionByListServiceTraitement(List<Long> codesServiceTraitements, List<String> codesActivites, TetePerimetre tetePerimetre,
                                                                               Map<String, String> libellesRESMap,
                                                                               Map<String, String> libellesFamillesMap,
                                                                               Map<String, String> libellesActivites);
}
