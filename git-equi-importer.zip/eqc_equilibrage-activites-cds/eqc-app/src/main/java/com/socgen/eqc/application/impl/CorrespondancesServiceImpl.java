package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.CorrespondancesService;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.CorrespondanceActiviteDto;
import com.socgen.eqc.infrastructure.smbo.dto.ReferentielProcessusDto;
import com.socgen.eqc.infrastructure.smbo.dto.Source;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class CorrespondancesServiceImpl implements CorrespondancesService {

    private final SmboClient smboClient;

    @Override
    public List<ReferentielProcessusDto> getProcessusByTetePerimetre(List<Long> codeTetePerimetres, Source source) {
        return smboClient.getAllProcessusByTetePerimetre(codeTetePerimetres, source);
    }

    @Override
    public List<CorrespondanceActiviteDto> getAllCorrespondanceByTetePerimetre(List<Long> codeTetePerimetres) {
        return smboClient.getAllCorrespondanceByTetePerimetre(codeTetePerimetres);
    }

    @Override
    @CacheEvict(value = EqcCacheConfig.CACHE_FAMILLE_NAME, allEntries = true)
    public void saveCorrespondances(CorrespondanceActiviteDto correspondanceActiviteDto) {
        smboClient.saveCorrespondances(correspondanceActiviteDto);
    }
}
