package com.socgen.eqc.infrastructure.extraction;

import com.socgen.eqc.interfaces.rest.dto.ExtractionTypes;
import com.socgen.eqc.utils.QuadriFunction;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExtractionFactory {


    private static final Map<ExtractionTypes, QuadriFunction<List<String>, List<String>, String, String, Object>> EXTRACTIONS = new HashMap<>();

    static {
        EXTRACTIONS.put(ExtractionTypes.PLANNING_COLLABORATEUR, ExtractionBuilder::buildExtractPlanningCollab);
        EXTRACTIONS.put(ExtractionTypes.PLANNING_ACTIVITES, ExtractionBuilder::buildExtractPlanningActivite);
        EXTRACTIONS.put(ExtractionTypes.PILOTAGE_ACTIVITES, ExtractionBuilder::buildExtractPilotageActivite);
        EXTRACTIONS.put(ExtractionTypes.COMPETENCES, ExtractionBuilder::buildExtractCompetences);

    }

    public static Object buildExtractionData(ExtractionTypes extractionType, List<String> listCodeSt, List<String> tetePerimetre, String from, String to) {
        QuadriFunction<
                List<String>, List<String>, String, String, Object>
                extraction = EXTRACTIONS.get(extractionType);

        return extraction.apply(listCodeSt, tetePerimetre, from, to);
    }

}
