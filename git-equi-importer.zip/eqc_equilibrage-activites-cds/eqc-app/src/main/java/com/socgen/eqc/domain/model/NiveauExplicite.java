package com.socgen.eqc.domain.model;

import java.util.HashMap;
import java.util.Map;

public enum NiveauExplicite {
    DEBUTANT(0L, "0 - Débutant"),
    BASES_ELEMENTAIRES(1L,"1 - Bases élémentaires"),
    BONNES_CONNAISSANCES(2L,"2 - Bonnes connaissances"),
    MAITRISE_PROCEDURE(3L,"3 - Maîtrise la procédure"),
    EXPERT(4L,"4 - Expert"),
    NE_MONTE_PAS_COMPETENCE(5L,"X - Ne monte pas en compétence");

    private static final Map<Long, NiveauExplicite> BY_ID = new HashMap<>();
    private static final Map<String, NiveauExplicite> BY_LABEL = new HashMap<>();
    static {
        for (NiveauExplicite niveauExplicite : values()) {
            BY_ID.put(niveauExplicite.id, niveauExplicite);
            BY_LABEL.put(niveauExplicite.label, niveauExplicite);
        }
    }
    public final Long id;
    public final String label;

    private NiveauExplicite(Long id, String label) {
        this.id = id;
        this.label = label;
    }

    public static NiveauExplicite valueOfId(Long id) {
        return BY_ID.get(id);
    }

    public static NiveauExplicite valueOfLabel(String label) {
        return BY_LABEL.get(label);
    }
}
