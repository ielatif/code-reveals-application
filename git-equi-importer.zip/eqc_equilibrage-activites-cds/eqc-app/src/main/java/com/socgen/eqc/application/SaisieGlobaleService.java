package com.socgen.eqc.application;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleInputDto;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleOutputDto;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleStockOutputDto;

import java.util.List;

public interface SaisieGlobaleService {

    List<SaisieGlobaleStockOutputDto> getIndicateurs(List<Long> tetePerimetres, String codeSt,SgUserPrincipal sgUserPrincipal);
    SaisieGlobaleOutputDto addStock(SaisieGlobaleInputDto saisieGlobaleInputDto);
}
