package com.socgen.eqc.infrastructure.ghabi.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class GhabiExtensionResponseDto extends GhabiExtensionAbstractDto {

    private String dateCreation;

    private Integer status;
}