package com.socgen.eqc.domain.model;

public enum TypeActivite {
    SIMPLE, REGROUPEMENT, SEQUENCE, FAMILLE, COMPETENCE
}
