package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.ExtensionPerimetreService;
import com.socgen.eqc.application.exception.GhabiException;
import com.socgen.eqc.domain.model.ExtensionPerimetre;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.infrastructure.ghabi.GhabiClient;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionDto;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionResponseDto;
import com.socgen.eqc.infrastructure.persistance.ExtensionPerimetreAllowedUgRepository;
import com.socgen.eqc.infrastructure.persistance.ExtensionPerimetreRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@AllArgsConstructor
public class ExtensionPerimetreServiceImpl implements ExtensionPerimetreService {

    private final GhabiClient ghabiClient;
	private final ExtensionPerimetreRepository extensionPerimetreRepository;
    private final ExtensionPerimetreAllowedUgRepository extensionPerimetreAllowedUgRepository;

    @Override
    public Optional<ExtensionPerimetre> createExtension(String matricule, String createurId, Renfort renfort) {
	    final GhabiExtensionResponseDto newExtensionPerimetreDto;
        final GhabiExtensionDto ghabiExtensionDto;
	    try {
		    log.info("Create de l'extension Ghabi pour le matricule {} sur l'intervalle {} ", matricule, renfort.getIntervalle());

            //  EQCH-2367 : Prévoir un paramétrage au niveau de l'UG pour autoriser ou non la génération d'extension de périmètre en intra day.
            if (renfort.isRenfortIntraDay() ) {
                if (extensionPerimetreAllowedUgRepository.existsById(renfort.getCodeUgRattachement().toString())) {
                    ghabiExtensionDto = buildIntraDayExtensionPerimetreDto(createurId, renfort);
                } else {
                    return Optional.empty();
                }

            } else {
                ghabiExtensionDto = buildExtensionPerimetreDto(createurId, renfort);
            }

		    newExtensionPerimetreDto = ghabiClient.createExtension(ghabiExtensionDto);
		    return Optional.of(ExtensionPerimetre.builder()
				    .idGhabi(newExtensionPerimetreDto.getId()).
						    etat(newExtensionPerimetreDto.getStatus())
				    .dateCreation(LocalDateTime.now())
				    .build());
	    } catch (GhabiException e) {
		    log.error(e.getMessage(), e);
		    return Optional.empty();
	    }
    }

    @Override
    public void deleteExtension(List<Renfort> renfortsToDeleteWithExtensionPerimetre) {
        renfortsToDeleteWithExtensionPerimetre.forEach(renfort -> {

            GhabiExtensionResponseDto ghabiExtensionDetail = ghabiClient.getExtensionDetail(renfort.getExtensionPerimetre().getIdGhabi());

            if (ghabiExtensionDetail.getStatus() == 2) {
                log.info("suppression de l'extension Ghabi {} pour le matricule {} ",
                        renfort.getExtensionPerimetre().getIdGhabi(), renfort.getCollaborateur().getMatricule());
                ghabiClient.deleteExtension(renfort.getExtensionPerimetre().getIdGhabi());
                extensionPerimetreRepository.delete(renfort.getExtensionPerimetre());
            } else if( ghabiExtensionDetail.getStatus() == 1) {
                //Mise à jour la date de fin
                GhabiExtensionDto ghabiExtensionDto = GhabiExtensionDto.builder()
                        .id(ghabiExtensionDetail.getId())
                        .createurId(ghabiExtensionDetail.getCreateurId())
                        .dateDebut(ghabiExtensionDetail.getDateDebut())
                        .dateFin(LocalDateTime.of(LocalDate.now(), LocalTime.now().plusMinutes(1)).toString())
                        .utilisateurId(ghabiExtensionDetail.getUtilisateurId())
                        .utilisateurStId(ghabiExtensionDetail.getUtilisateurStId())
                        .perimStIds(ghabiExtensionDetail.getPerimStIds()).build();

                ghabiClient.updateExtension(ghabiExtensionDto);
            }

        });
    }

    @Async("taskExecutor")
    @Override
    public void deleteExtensionAsync(List<Renfort> renfortsToDeleteWithExtensionPerimetre) {
        deleteExtension(renfortsToDeleteWithExtensionPerimetre);
    }

    private GhabiExtensionDto buildExtensionPerimetreDto(String createurId, Renfort renfort) {
        return GhabiExtensionDto.builder()
                .createurId(createurId)
                .dateDebut(LocalDateTime.of(renfort.getDate().minusDays(1), renfort.getIntervalle().getHeureDebut()).toString())
                .dateFin(LocalDateTime.of(renfort.getDate(), renfort.getIntervalle().getHeureFin()).toString())
                .utilisateurId(renfort.getCollaborateur().getMatricule())
                .utilisateurStId(renfort.getCodeStRattachement().toString())
                .perimStIds(List.of(renfort.getEquipe().getCode().toString())).build();
    }

    private GhabiExtensionDto buildIntraDayExtensionPerimetreDto(String createurId, Renfort renfort) {
        return GhabiExtensionDto.builder()
                .createurId(createurId)
                .dateDebut(LocalDateTime.of(renfort.getDate(), LocalTime.now().plusMinutes(5)).toString())
                .dateFin(LocalDateTime.of(renfort.getDate(), renfort.getIntervalle().getHeureFin()).toString())
                .utilisateurId(renfort.getCollaborateur().getMatricule())
                .utilisateurStId(renfort.getCodeStRattachement().toString())
                .perimStIds(List.of(renfort.getEquipe().getCode().toString())).build();
    }
}
