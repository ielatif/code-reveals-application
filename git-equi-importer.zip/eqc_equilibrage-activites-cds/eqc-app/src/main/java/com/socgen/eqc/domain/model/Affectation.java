package com.socgen.eqc.domain.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@ToString(exclude = {"renfort", "affiliation"})
@EqualsAndHashCode(exclude = {"renfort", "affiliation"})
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity(name = "AFFECTATION")
@Table(name = " AFFECTATION", uniqueConstraints = {@UniqueConstraint(columnNames = {"affiliation_id", "code_activite", "date"})})
public class Affectation implements Serializable {

    private static final long serialVersionUID = 2873150734153585922L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @Column(name = "date", nullable = false)
    private LocalDate date;

    @Column(name = "pourcentage")
    private Long pourcentage;

    @ManyToOne
    @JoinColumn(name = "affiliation_id")
    private Affiliation affiliation;

    @ManyToOne
    @JoinColumn(name = "renfort_id")
    private Renfort renfort;

    @ManyToOne
    @JoinColumn(name = "code_activite", nullable = false)
    private ActiviteParams activite;

    @Column(name = "nombre_dossier")
    private Double nombreDossier;

    @Column(name = "ordre")
    private int ordre;

    @OneToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "expertise_id", referencedColumnName = "id")
    private Expertise expertise;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "parametres_carte_id", referencedColumnName = "id")
    private ParametresCarte parametresCarte;
}
