package com.socgen.eqc.infrastructure.batch.config;

import com.socgen.eqc.config.EqcProperties;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.infrastructure.batch.dto.AffectationDto;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@EnableBatchProcessing
@RequiredArgsConstructor
@Configuration
public class ConsolideBatchConfiguration {

    @Bean
    protected Step step(EqcProperties eqcProperties,StepBuilderFactory steps, ItemReader<Affectation> reader, ItemProcessor<Affectation, AffectationDto> cmItemProcessor, ItemWriter<AffectationDto> writer) {
        return steps.get("consolideStep").<Affectation, AffectationDto>chunk(eqcProperties.getBatch().getConfig()
            .getChunkSize()).reader(reader).processor(cmItemProcessor).writer(writer).build();
    }

    @Bean
    public JobConsolideListener jobConsolideListener() {
        return new JobConsolideListener();
    }

    @Bean
    public Job job(JobBuilderFactory jobs, Step step) {
        return jobs.get("consolideJob").start(step).listener(jobConsolideListener()).preventRestart().build();
    }

    @Bean
    public JobLauncher getJobLauncher(JobRepository jobRepository) {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        return jobLauncher;
    }

}
