package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Affectation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface AffectationRepository extends JpaRepository<Affectation, Long> {

    /**
     * This method is Used for Consolid Mensuel Batch
     *
     * @param startDate
     * @param endDate
     * @param pageable
     * @return
     */
    Page<Affectation> findAllByDateBetween(LocalDate startDate, LocalDate endDate, Pageable pageable);

    List<Affectation> findAllByDateBetweenAndAffiliationEquipeCodeIn(LocalDate startDate, LocalDate endDate, List<Long> listStCodes);

    List<Affectation> findByAffiliationIdAndDateBetween(Long idAffiliation, LocalDate dateDebut, LocalDate dateFin);

    Set<Affectation> findByRenfortId(Long renfortId);

    void deleteByAffiliationIdAndDateAfter(Long idAffiliation, LocalDate now);

    List<Affectation> findByRenfortEquipeCodeAndDateBetween(Long idEquipe, LocalDate dateDebut, LocalDate dateFin);

    List<Affectation> findByAffiliationIdInAndDateBetween(List<Long> affiliationsIds, LocalDate dateDebut, LocalDate dateFin);

    List<Affectation> findByRenfortIdInAndDateBetween(List<Long> idRenforts, LocalDate dateDebut, LocalDate dateFin);

    void deleteAllByIdIn(List<Long> ids);

    void deleteByRenfortIdInAndDateAfter(List<Long> renfortIds, LocalDate date);

    @Query("SELECT a FROM AFFECTATION a LEFT JOIN a.affiliation LEFT JOIN a.renfort WHERE ( a.affiliation.collaborateur.matricule=:matricule or a.renfort.collaborateur.matricule=:matricule) and a.date>=:date")
    List<Affectation> findAllByMatricule(@Param("matricule") String matricule, @Param("date") LocalDate date);

    List<Affectation> findByExpertiseIdInAndDateAfter(List<Long> idsExpertise, LocalDate date);

    Optional<Affectation> findByDateAndAffiliationIdAndActiviteCode(LocalDate date, Long affiliationId, String codeActivite);

    Optional<Affectation> findByDateAndRenfortIdAndActiviteCode(LocalDate date, Long affiliationId, String codeActivite);

    @Modifying
    @Query("DELETE FROM AFFECTATION a where a in (select a FROM AFFECTATION a  LEFT JOIN a.affiliation LEFT JOIN a.renfort WHERE ((a.affiliation.collaborateur.matricule in :matricules and a.affiliation.equipe.code=:codeSt) or (a.renfort.collaborateur.matricule in :matricules and a.renfort.codeStRattachement=:codeSt)) and a.date>=:dateDebut and a.date<=:dateFin)")
    void deleteByMatricules(@Param("matricules") List<String> matricules, @Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin, @Param("codeSt") long codeSt);

    @Modifying
    @Query("DELETE FROM AFFECTATION a where a in (select a FROM AFFECTATION a LEFT JOIN a.renfort WHERE (a.renfort.collaborateur.matricule in :matricules and a.renfort.equipe.code=:codeSt) and a.date>=:dateDebut and a.date<=:dateFin)")
    void deleteRenfortEntrant(@Param("matricules") List<String> matricules, @Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin, @Param("codeSt") long codeStAide);

    @Query(nativeQuery = true, value = "select count(*) from affectation where extract(year from date) = extract(year from now())")
    Long fetchAffectationCount();
}
