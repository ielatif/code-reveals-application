package com.socgen.eqc.infrastructure.res;

import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;

import java.util.List;

public interface ResClient {

    List<CentreService> getEntiteStructure();
}
