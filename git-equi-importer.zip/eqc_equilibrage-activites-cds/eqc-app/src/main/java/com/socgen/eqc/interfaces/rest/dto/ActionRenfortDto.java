package com.socgen.eqc.interfaces.rest.dto;

import com.socgen.eqc.domain.model.Intervalle;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@SuperBuilder
public class ActionRenfortDto extends ActionDto {

    private String libelleRenfort;

    private Intervalle intervalle;

    private Long codeCdsAide;

    private Long codeUgAide;

    private Long codeCdsRattachement;

    private Long codeStRattachement;

    private Long codeUgRattachement;

    private Long codeStAide;

    private Long extensionPerimetreId;

    private Byte formatSemainier;
}
