package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.domain.model.Intervalle;
import com.socgen.eqc.domain.model.Renfort;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class RenfortDto {

    private Long id;
    private String matricule;
    private LocalDate date;
    private DayOfWeek day;
    private Intervalle intervalle;
    private String keyRenfortEs;
    private Long codeCdsAide;
    private Long codeUgAide;
    private Long codeStAide;
    private Long codeCdsRattachement;
    private Long codeStRattachement;
    private Long codeUgRattachement;
    private Long extensionPerimetreId;
    private String commentPrincipale;
    private String commentSecondaire;
    private String customStyle;
    private Byte formatSemainier;

    public static RenfortDto fromDomain(Renfort renfort) {
        String affectationColor = (renfort.getParametresCarte() != null && renfort.getParametresCarte().getCouleur() != null ) ? renfort.getParametresCarte().getCouleur().getCode() : null;

        return RenfortDto.builder().id(renfort.getId()).matricule(renfort.getCollaborateur().getMatricule())
                .codeStAide(renfort.getEquipe().getCode()).intervalle(renfort.getIntervalle())
                .keyRenfortEs(new StringBuilder().append(renfort.getCodeCdsAide()).append("-")
                        .append(renfort.getCodeUgAide()).append("-").append(renfort.getEquipe().getCode()).toString())
                .codeStRattachement(renfort.getCodeStRattachement()).codeUgAide(renfort.getCodeUgAide())
                .codeCdsAide(renfort.getCodeCdsAide()).date(renfort.getDate()).day(renfort.getDate().getDayOfWeek())
                .codeCdsRattachement(renfort.getCodeCdsRattachement())
                .codeUgRattachement(renfort.getCodeUgRattachement())
                .extensionPerimetreId(renfort.getExtensionPerimetre() != null ? renfort.getExtensionPerimetre().getId() : null)
                .commentPrincipale(renfort.getParametresCarte() != null ? renfort.getParametresCarte().getTitre() : null)
                .commentSecondaire(renfort.getParametresCarte() != null ? renfort.getParametresCarte().getCommentaire() : null)
                .customStyle(affectationColor)
                .formatSemainier(renfort.getEquipe().getFormatSemainier())
                .build();
    }

    public static List<RenfortDto> fromDomain(List<Renfort> renforts) {
        return renforts.stream().map(RenfortDto::fromDomain).collect(Collectors.toList());
    }

    public boolean isRenfortIntraUg() {
        return codeUgRattachement.equals(codeUgAide);
    }
}
