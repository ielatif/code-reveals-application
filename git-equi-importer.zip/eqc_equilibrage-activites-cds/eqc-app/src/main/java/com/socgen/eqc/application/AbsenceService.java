package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.interfaces.rest.dto.ActionAbsenceDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.interfaces.rest.planning.dto.AbsenceGershwinDto;

import java.time.LocalDate;
import java.util.List;

public interface AbsenceService {

    List<Absence> updateOrDelete(List<ActionAbsenceDto> actionAbsences);

    List<Absence> findAbsences(Long idEquipe, List<Collaborateur> collaborateurs, LocalDate dateDebut, LocalDate dateFin);

    AbsenceGershwinDto findAbsence(PlanningSearchDto planningSearchDto);

    void removeAll(String matricule);

    void supprimerSemaine(SuppressionSemaineDto suppressionSemaineDto);
}
