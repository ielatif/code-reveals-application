package com.socgen.eqc.domain.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@EqualsAndHashCode(exclude = "affiliationSousEquipes")
@Entity(name = "AFFILIATION")
@Table(name = "AFFILIATION", indexes = {@Index(columnList = "equipe_id", name = "idx_affiliation_equipe_id")}, uniqueConstraints = {@UniqueConstraint(columnNames = {"date_entree", "collaborateur_id", "equipe_id"})})
public class Affiliation implements Serializable {

    private static final long serialVersionUID = 2873150734153585955L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @Column(name = "date_entree", nullable = false)
    private LocalDate dateEntree;

    @Column(name = "date_sortie")
    private LocalDate dateSortie;

    @ManyToOne
    @JoinColumn(name = "collaborateur_id", nullable = false)
    private Collaborateur collaborateur;

    @ManyToOne
    @JoinColumn(name = "equipe_id", nullable = false)
    private Equipe equipe;

    @OneToMany(mappedBy = "affiliation", fetch = FetchType.LAZY)
    private Set<Affectation> affectations;

    @OneToMany(mappedBy = "affiliation", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<AffiliationSousEquipe> affiliationSousEquipes;
}