package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.SousEquipe;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SousEquipeRepository extends JpaRepository<SousEquipe, Long> {

    List<SousEquipe> findByEquipeCode(Long code);
}
