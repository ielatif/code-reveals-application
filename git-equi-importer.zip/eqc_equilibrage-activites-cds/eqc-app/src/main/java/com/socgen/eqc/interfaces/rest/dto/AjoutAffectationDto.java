package com.socgen.eqc.interfaces.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AjoutAffectationDto {

    @NotNull
    private Long collaborateurId;
    @NotNull
    private List<String> activiteCodes;
    @NotNull
    private LocalDate date;

    private Long serviceTraitementId;
}
