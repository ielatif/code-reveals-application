package com.socgen.eqc.infrastructure.batch.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class ValidationBatchDto {

    private List<String> errorMessages;
}
