package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.interfaces.rest.dto.EquipeDto;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface EquipeService {

    Equipe findById(Long code);

    Optional<Equipe> findByCode(Long code);

    Equipe saveDto(EquipeDto dto);

    Equipe save(Equipe equipe);

	Set<String> findManagersIdRh(Long code);

	List<Collaborateur> getCollaborateurs(Long code, LocalDate dateDebut, LocalDate dateFin);

	List<EquipeDto> findAll();

}
