package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.socgen.eqc.domain.model.TypeActivite;
import com.socgen.eqc.domain.model.Unite;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ActiviteInputDto {

    private String code;

    private String libelle;

    private String libelleLong;

    private String tetePerimetre;

    private String famille;

    private String activiteRatio;

    private int ordre;

    private boolean active;

    private LocalDate maskDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate dateActivation;

    private List<ExpertiseInputDto> expertises;

    private List<Long> activity = new ArrayList<>();

    private Unite unite;

    private TypeActivite type;

    private LocalDate maskDatePilotage;

    private LocalDate maskDateCompetence;
}
