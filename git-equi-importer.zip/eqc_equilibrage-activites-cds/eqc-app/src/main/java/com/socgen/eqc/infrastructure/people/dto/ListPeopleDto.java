package com.socgen.eqc.infrastructure.people.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ListPeopleDto implements Serializable {

    private static final long serialVersionUID = -1240196956746387125L;

    @JsonProperty("datas")
    private List<PeopleDto> datas;
}
