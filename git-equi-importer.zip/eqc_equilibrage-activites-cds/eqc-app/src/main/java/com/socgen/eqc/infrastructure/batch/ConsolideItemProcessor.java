package com.socgen.eqc.infrastructure.batch;

import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.infrastructure.batch.dto.AffectationDto;
import com.socgen.eqc.interfaces.rest.planning.dto.RenfortDto;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class ConsolideItemProcessor implements ItemProcessor<Affectation, AffectationDto> {

    @Override
    public AffectationDto process(Affectation affectation) {
        return AffectationDto.builder().id(affectation.getId()).codeActivite(affectation.getActivite().getCode())
                .matricule(getMatricule(affectation))
                .cdsRattachement(getCds(affectation))
                .ugRattachement(getUg(affectation))
                .idServiceTraitement(getSt(affectation))
                .date(affectation.getDate())
                .renfort(affectation.getRenfort() != null ? RenfortDto.fromDomain(affectation.getRenfort()) : null)
                .pourcentage(affectation.getPourcentage()).build();
    }

    private String getMatricule(Affectation affectation) {
        return affectation.getAffiliation() != null ?
                affectation.getAffiliation().getCollaborateur().getMatricule() : affectation.getRenfort().getCollaborateur().getMatricule();
    }

    private Long getSt(Affectation affectation) {
        return affectation.getAffiliation() != null ?
                affectation.getAffiliation().getEquipe().getCode() : affectation.getRenfort().getCodeStRattachement();
    }

    private Long getCds(Affectation affectation) {
        return affectation.getAffiliation() != null ?
                affectation.getAffiliation().getEquipe().getCodeCds() : affectation.getRenfort().getCodeCdsRattachement();
    }

    private Long getUg(Affectation affectation) {
        return affectation.getAffiliation() != null ?
                affectation.getAffiliation().getEquipe().getCodeUg() : affectation.getRenfort().getCodeUgRattachement();
    }

}