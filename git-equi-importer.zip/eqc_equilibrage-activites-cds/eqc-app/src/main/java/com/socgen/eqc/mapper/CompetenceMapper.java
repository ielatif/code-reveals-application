package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.Competence;
import com.socgen.eqc.interfaces.rest.dto.CompetenceDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CompetenceMapper {

    @Mapping(target = "codeActivite", source = "expertise.activite.code")
    @Mapping(target = "ordreActivite", source = "expertise.activite.ordre")
    @Mapping(target = "idNiveau", source = "expertise.niveau.id")
    @Mapping(target = "libelleNiveau", source = "expertise.niveau.libelle")
    @Mapping(target = "matricule", source = "collaborateur.matricule")
    CompetenceDto competenceToCompetenceDto (Competence competence);

    List<CompetenceDto> competenceListToCompetenceDtoList (List<Competence> competences);

    @Mapping(target = "collaborateur.matricule", source = "matricule")
    @Mapping(target = "expertise.activite.code", source = "competenceDto.codeActivite")
    @Mapping(target = "expertise.niveau.id", source = "competenceDto.idNiveau")
    Competence competenceDtoToCompetence (CompetenceDto competenceDto, String matricule);
}
