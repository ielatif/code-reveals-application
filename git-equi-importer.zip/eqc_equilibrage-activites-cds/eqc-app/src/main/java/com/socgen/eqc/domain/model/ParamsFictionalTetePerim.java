package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity(name = "ParamsFictionalTetePerim")
@Table(name = "params_fictional_tete_perim")
public class ParamsFictionalTetePerim {

    private static final long serialVersionUID = -2088595025397744877L;

    @EmbeddedId
   private ParamsFictionalTetePerimId paramsFictionalTetePerimId;

    @Column(name = "fictional_tete_perim", nullable = false)
    private Long fictionalTetePerim;
}
