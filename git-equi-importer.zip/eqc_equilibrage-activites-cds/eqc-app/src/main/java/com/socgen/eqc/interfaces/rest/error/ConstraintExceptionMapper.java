package com.socgen.eqc.interfaces.rest.error;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;

import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
@Slf4j
public class ConstraintExceptionMapper
               implements ExceptionMapper<ConstraintViolationException> {

    @Override
    public Response toResponse(final ConstraintViolationException exception) {
        log.error("Exception : {}", exception.getMessage(), exception);
        return Response.status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .entity(ErrorDto.internalServerError(ExceptionUtils.getStackTrace(exception))).build();
    }
}