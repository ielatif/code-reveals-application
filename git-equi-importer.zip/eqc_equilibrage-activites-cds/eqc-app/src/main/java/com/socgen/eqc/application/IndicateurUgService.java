package com.socgen.eqc.application;

import com.socgen.eqc.interfaces.rest.dto.IndicateurSearchDto;
import com.socgen.eqc.interfaces.rest.planning.dto.IndicateurActiviteDto;

public interface IndicateurUgService {

    IndicateurActiviteDto computeIndicateur(IndicateurSearchDto indicateurSearchDto);
}
