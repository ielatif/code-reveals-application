package com.socgen.eqc.interfaces.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlanningSearchDto {

    @PathParam("codeServiceTraitement")
    @NotNull
    private Long codeServiceTraitement;

    @QueryParam("dateDebut")
    @NotNull
    private LocalDate dateDebut;

    @QueryParam("dateFin")
    @NotNull
    private LocalDate dateFin;

}
