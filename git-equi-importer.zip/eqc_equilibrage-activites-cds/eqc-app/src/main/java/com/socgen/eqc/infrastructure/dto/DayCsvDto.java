package com.socgen.eqc.infrastructure.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DayCsvDto {

    private String date;
    private String isHolidayDay;
    private String holidayName;
}
