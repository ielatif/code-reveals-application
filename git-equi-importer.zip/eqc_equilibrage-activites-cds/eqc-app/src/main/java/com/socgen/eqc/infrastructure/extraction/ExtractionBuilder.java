package com.socgen.eqc.infrastructure.extraction;


import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.socgen.eqc.application.*;
import com.socgen.eqc.application.impl.ActiviteParamsServiceImpl;
import com.socgen.eqc.application.impl.CompetenceServiceImpl;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import com.socgen.eqc.infrastructure.persistance.*;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractCompetencesDto;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPilotageActivitesDto;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPlanningActivitesDto;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPlanningCollabDto;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.*;
import com.socgen.eqc.interfaces.rest.dto.IndicateurSearchDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.*;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteParamsDto;
import com.socgen.eqc.interfaces.rest.planning.dto.IndicateurDto;
import com.socgen.eqc.utils.TriPredicate;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toMap;

@Component
class ExtractionBuilder {


    private static ExtractPlanningCollabRepository extractPlanningCollabRepository;
    private static SmboClient smboClient;
    private static IndicateurService indicateurService;
    private static LibelleEntiteStructureRepository libelleEntiteStructureRepository;
    private static ActiviteRepository activiteRepository;
    private static IndicateurUgService indicateurUgService;
    private static EquipeRepository equipeRepository;
    private static CompetenceServiceImpl competenceService;
    private static IndicateursSuiviActiviteService indicateursSuiviActiviteService;
    private static CorrespondancesService correspondancesService;
    private static AffiliationService affiliationService;
    private static AffiliationSousEquipeRepository affiliationSousEquipeRepository;
    private static ActiviteParamsService activiteParamsService;
    private static TetePerimetreService tetePerimetreService;


    @Autowired
    private ExtractPlanningCollabRepository autowiredExtractPlanningCollabRepository;
    @Autowired
    @Qualifier("smboClient")
    private SmboClient autowiredSmboClient;
    @Autowired
    private IndicateurService autowiredIndicateurService;
    @Autowired
    private LibelleEntiteStructureRepository autowiredLibelleEntiteStructureRepository;
    @Autowired
    private ActiviteRepository autowiredActiviteRepository;
    @Autowired
    private IndicateurUgService autowiredIndicateurUgService;
    @Autowired
    private EquipeRepository autowiredEquipeRepository;
    @Autowired
    private CompetenceServiceImpl autowiredCompetenceService;
    @Autowired
    private IndicateursSuiviActiviteService autowiredIndicateursSuiviActiviteService;
    @Autowired
    private CorrespondancesService autowiredCorrespondancesService;
    @Autowired
    private AffiliationService autowiredAffiliationService;
    @Autowired
    private AffiliationSousEquipeRepository autowiredAffiliationSousEquipeRepository;
    @Autowired
    private ActiviteParamsServiceImpl autowiredActiviteParamsService;
    @Autowired
    private TetePerimetreService autowiredTetePerimetreService;

    List<CentreService> centreServices;

    private static BiPredicate<BigInteger, String> applyManagementRuleForJourJ =
            (stockTraite, day) -> (LocalDate.parse(day, DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now()) &&
                    stockTraite != null
            );
    //Pas de création des extractions pour les jours Futures
    private static Predicate<String> applyManagementRuleForFutureDays =
            (day) -> !LocalDate.parse(day, DateTimeFormatter.ISO_DATE).isAfter(LocalDate.now());
    private static BiPredicate<String, LocalDate>   isPlannableActivite =
            (day, maskDate) -> maskDate == null || maskDate.isAfter(LocalDate.parse(day, DateTimeFormatter.ISO_DATE));


    private static Predicate<ExtractPlanningActivitesDto> applyFiltersRulesForPlanActivites =
            (extract) -> {
            if(
                    //RG03 : Pour les jours échus, On n'affiche pas les enregistrements qui ont le triplet
                    // {ETP ET stock réellement traité ET stock réel} égale à 0 OU à blanc
                    (LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE).isBefore(LocalDate.now()) &&
                            (
                                    (StringUtils.isEmpty(extract.getEtp()) || extract.getEtp().equals("0,0") || extract.getEtp().equals("0")) &&
                                    (extract.getStockReelementTraite() == BigInteger.ZERO || extract.getStockReelementTraite() == null) &&
                                    (extract.getStockReel() == BigInteger.ZERO || extract.getStockReel() == null)

                            )
                    ) ||
                            (LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now()) &&
                                    (
                                            (StringUtils.isEmpty(extract.getEtp()) || extract.getEtp().equals("0,0") || extract.getEtp().equals("0")) &&
                                            (extract.getStockATraiterEstime() == BigInteger.ZERO || extract.getStockATraiterEstime() == null)
                                    )
                            ) ||
                    //RG05: Pour les jours dans le futur, on n'affiche pas les enregistrements qui ont le doublet {ETP ET CTT} égale à 0
                            (LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE).isAfter(LocalDate.now()) &&
                                    (
                                            (StringUtils.isEmpty(extract.getEtp()) || extract.getEtp().equals("0,0") || extract.getEtp().equals("0")) &&
                                            StringUtils.isEmpty(extract.getCapaciteTheoriqueATraiter())
                                    )
                            )
            ) {
                return false;
            } else {
                return true;
            }
            };

    @SuppressWarnings("squid:S2696")
    @PostConstruct
    private void init() {
        extractPlanningCollabRepository = this.autowiredExtractPlanningCollabRepository;
        smboClient = this.autowiredSmboClient;
        indicateurService = this.autowiredIndicateurService;
        libelleEntiteStructureRepository = this.autowiredLibelleEntiteStructureRepository;
        activiteRepository = this.autowiredActiviteRepository;
        indicateurUgService = this.autowiredIndicateurUgService;
        equipeRepository = this.autowiredEquipeRepository;
        competenceService = this.autowiredCompetenceService;
        indicateursSuiviActiviteService = this.autowiredIndicateursSuiviActiviteService;
        correspondancesService = this.autowiredCorrespondancesService;
        affiliationService = this.autowiredAffiliationService;
        affiliationSousEquipeRepository = this.autowiredAffiliationSousEquipeRepository;
        activiteParamsService = this.autowiredActiviteParamsService;
        tetePerimetreService = this.autowiredTetePerimetreService;

    }

    /***
     * Génération de l'extraction Planning Collaborateur
     * @param listCodeSt
     * @param tetePerimetre
     * @param from
     * @param to
     * @return
     */
    static List<ExtractPlanningCollabDto> buildExtractPlanningCollab(List<String> listCodeSt, List<String> tetePerimetre, String from, String to) {

        List<ExtractPlanningCollabDto> extractPlanningCollab = extractPlanningCollabRepository
                .findPlanningCollab(listCodeSt, LocalDate.parse(from, DateTimeFormatter.ISO_DATE),
                        LocalDate.parse(to, DateTimeFormatter.ISO_DATE));

        completeSousEquipeforRenfort(extractPlanningCollab);
        formatDecimalValueForPlanCollab(extractPlanningCollab);

        List<RefFamilleDto> familleFromSmbo = smboClient.getAllFamilles();
        ajouterLibellesFamilleAndActivitesForPlanningCollab(extractPlanningCollab, familleFromSmbo);

        return extractPlanningCollab;
    }

    private static void formatDecimalValueForPlanCollab(List<ExtractPlanningCollabDto> extractPlanningCollab){
        extractPlanningCollab.stream()
                .forEach(extract -> extract.setEtp(StringUtils.isEmpty(extract.getEtp()) ? "" : extract.getEtp().replace(".", ",") ));
    }

    private static void completeSousEquipeforRenfort(List<ExtractPlanningCollabDto> extractPlanningCollab) {
        extractPlanningCollab.stream()
                .filter(exract -> exract.getRenfort() != null)
                .forEach(extractRenfort -> {

                    Optional<Affiliation> affiliationRenfort = affiliationService.findLastByMatricule(extractRenfort.getMatricule().toLowerCase());
                    if (affiliationRenfort.isPresent()) {
                        Long affiliationId = affiliationRenfort.get().getId();
                        List<AffiliationSousEquipe> affiliationSousEquipe = affiliationSousEquipeRepository.findAllByAffiliationId(affiliationId);
                        String sousEquipeLibelle = affiliationSousEquipe.stream()
                                .map(affil -> affil.getSousEquipe().getLibelle())
                                .collect(Collectors.joining(","));
                        extractRenfort.setSousEquipe(sousEquipeLibelle);
                    }

                });
    }

    private static Map<String, String> getFamilleReferential(List<RefFamilleDto> familleFromSmbo) {
        return familleFromSmbo.stream()
                .collect(toMap(RefFamilleDto::getCode, RefFamilleDto::getLibelle));
    }

    private static Map<String, String> getActiviteReferential(List<RefFamilleDto> familleFromSmbo) {
        return familleFromSmbo.stream()
                .flatMap(refFamilleDto -> refFamilleDto.getActivites().stream())
                .collect(toMap(RefActiviteDto::getCode, RefActiviteDto::getLibelle));
    }

    private static Map<String, Boolean> getActiviteCorrespondace(List<RefFamilleDto> familleFromSmbo) {
        return familleFromSmbo.stream()
                .flatMap(refFamilleDto -> refFamilleDto.getActivites().stream())
                .collect(toMap(RefActiviteDto::getCode, RefActiviteDto::isHasCorrespondances));
    }

    static void ajouterLibellesFamilleAndActivitesForPlanningCollab(List<ExtractPlanningCollabDto> extractPlanningCollab, List<RefFamilleDto> familleFromSmbo) {

        Map<String, String> familleReferential = getFamilleReferential(familleFromSmbo);

        final Map<String, String> activityReferential = getActiviteReferential(familleFromSmbo);

        extractPlanningCollab.stream()
                .filter(extractPlan -> extractPlan.getActiviteCode() != null)
                .forEach(extractPlan -> {
                    extractPlan.setFamille(familleReferential.get(extractPlan.getFamilleCode()));
                    extractPlan.setActivite(activityReferential.get(extractPlan.getActiviteCode()));
                });
    }

    static void ajouterLibellesFamilleAndActivitesForPlanningActivite(List<ExtractPlanningActivitesDto> extractPlanningActivite, List<RefFamilleDto> familleFromSmbo) {

        final Map<String, String> familleReferential = getFamilleReferential(familleFromSmbo);

        final Map<String, String> activityReferential = getActiviteReferential(familleFromSmbo);

        extractPlanningActivite.stream()
                .filter(extractPlan -> extractPlan.getCodeActivite() != null)
                .forEach(extractPlan -> {
                    extractPlan.setFamille(familleReferential.get(extractPlan.getCodeFamille()));
                    extractPlan.setActivite(activityReferential.get(extractPlan.getCodeActivite()));
                });
    }

    /***
     * Génération de l'extraction du planning Activité
     * @param listCodeSt
     * @param tetePerimetre
     * @param from
     * @param to
     * @return
     */
    static List<ExtractPlanningActivitesDto> buildExtractPlanningActivite(List<String> listCodeSt, List<String> tetePerimetre, String from, String to) {

        List<ExtractPlanningActivitesDto> resultExtraction = new ArrayList<>();

        //Récupération des libelles d'Entité de Structure
        Map<String, String> libellesEntiteStructureMap = libelleEntiteStructureRepository.getAll();
        List<RefFamilleDto> familleFromSmbo = smboClient.getAllFamilles();
        Map<Long, List<Equipe>> equipesBySt = getEquipeBySt(listCodeSt);

        //Si la date du debut de l'extraction il faut calculer les indicateur par rapport à la date J-1 afin de calculer la moyenne arithmetique
        String dateDebutExtraction = LocalDate.parse(from).isEqual(LocalDate.now()) ? LocalDate.parse(from).minusDays(1).toString() : from;

        List<IndicateurActiviteDto> indicateursSmboBrut = indicateurService.getStockTraiter(IndicateurInputDto.builder()
                .listCodeServiceTraitement(listCodeSt)
                .tetePerimetre(tetePerimetre)
                .dateDebut(dateDebutExtraction)
                .dateFin(to)
                .build(), true);

        Set<String> activiteCodesWithSmboIndic = indicateursSmboBrut.stream()
                .map(indicateur -> indicateur.getCodeActivite())
                .collect(Collectors.toSet());


        List<IndicateurDto> indicateursFromEqc = indicateurUgService.computeIndicateur(IndicateurSearchDto.builder()
                .listCodeServiceTraitement(listCodeSt.stream().map(Long::valueOf).collect(Collectors.toList()))
                .dateDebut(LocalDate.parse(from))
                .dateFin(LocalDate.parse(to))
                .build()
        ).getIndicateurs();

        Set<String> activiteCodesWithAffectations = indicateursFromEqc.stream().map(indicateurDto -> indicateurDto.getCodeActivite()).distinct().collect(Collectors.toSet());

        Map<String, ActiviteParams> activiteParamsByActivite = activiteRepository.findByCodeIn(new ArrayList<>(concat(activiteCodesWithAffectations, activiteCodesWithSmboIndic)))
                .stream()
                .collect(Collectors.toMap(ActiviteParams::getCode, Function.identity()));

        Map<String , Boolean> activiteCorrespondances = getActiviteCorrespondace(familleFromSmbo);

        //Génération des extrations pour les activités plannifiables (qui ont des affectations pendant la date en question)
        buildExtractPlanningActiviteForPlanninfiedActivite(resultExtraction, libellesEntiteStructureMap, equipesBySt, indicateursFromEqc,
                activiteParamsByActivite);

        //récupération des expertises
        Map<String, Map<Long, Float>> expertiseByActivite = competenceService.buildNombresDossier(
                new HashSet<>(concat(activiteCodesWithAffectations, activiteCodesWithSmboIndic)));


        //génération des extractions pour les activites qui ont des indicateurs dans SMBO
        buildExtractPlanningActiviteForActiviteWithIndicateur(from, to, resultExtraction, libellesEntiteStructureMap, equipesBySt, indicateursSmboBrut,
                activiteParamsByActivite, expertiseByActivite, activiteCorrespondances);

        //Compléter les Libelles des familles et activités
        ajouterLibellesFamilleAndActivitesForPlanningActivite(resultExtraction, familleFromSmbo);


        /*
         * Traitement pour calculer la charge en ETP pour chaque famille dans chaque ST
         * */

        Map<String, Map<String, BigDecimal>> chargeEnEtpByStByFamille =  new HashMap<>();
        listCodeSt.forEach(codeSt -> chargeEnEtpByStByFamille.put(codeSt, computeChargeEnEtpForFamille(resultExtraction, codeSt)));

        setArroundCapaciteTheorique(resultExtraction);


        resultExtraction.stream()
                .filter(extract -> activiteCorrespondances.get(extract.getCodeActivite()) == null ? false : activiteCorrespondances.get(extract.getCodeActivite()))
                .filter(extract -> LocalDate.now().isEqual(LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE)))
                .filter(extract -> extract.getChargeEnEtp() == null && extract.getChargeEnVolume() == null)
                .forEach(extract -> {
                    StockOutputDto stockOutputDto = StockOutputDto.builder().stockDossierTraiter(BigInteger.ZERO)
                            .stockTacheTraiter(BigInteger.ZERO).build();

                    BigInteger stockTraiter = computeStockTraite(stockOutputDto, Unite.of(extract.getUniteDeMesure()));
                    BigDecimal capacite = !StringUtils.isEmpty(extract.getCapaciteTheoriqueATraiter()) ?
                            new BigDecimal(extract.getCapaciteTheoriqueATraiter().replace(",", ".")) : BigDecimal.ZERO;
                    BigDecimal chargeEnVolume = new BigDecimal((stockTraiter.toString()))
                            .subtract(capacite).setScale(0, RoundingMode.HALF_EVEN);

                    BigDecimal chargeEnEtp = computeChargeEtp(stockOutputDto, capacite,
                            extract.getCodeActivite(), Unite.of(extract.getUniteDeMesure()), expertiseByActivite);

                    extract.setChargeEnEtp(chargeEnEtp !=  null ? chargeEnEtp.toString() : null);
                    extract.setChargeEnVolume(chargeEnVolume != null ? new BigInteger(chargeEnVolume.toString()) : null);
                });


        //Setter la charge en ETP pour les activités de Type Famille
        resultExtraction.stream()
                .filter(extractResult -> extractResult.getTypeActivite() == null
                        ? false : extractResult.getTypeActivite().equals(TypeActivite.FAMILLE.name()) &&
                        LocalDate.now().isEqual(LocalDate.parse(extractResult.getDate(), DateTimeFormatter.ISO_DATE)))
                .forEach(extractResult -> {
                    BigDecimal sumChareEnEtpFamille = chargeEnEtpByStByFamille.get(extractResult.getCodeSt()).get(extractResult.getCodeFamille());
                    if (sumChareEnEtpFamille != null) {
                        extractResult.setChargeEnEtp(sumChareEnEtpFamille
                                .subtract(
                                        new BigDecimal(extractResult.getEtp().replace(",", "."))
                                ).toString().replace(".", ","));
                    }
                });


        return filterExtraction(resultExtraction);
    }

    private static void setArroundCapaciteTheorique(List<ExtractPlanningActivitesDto> resultExtraction) {
        resultExtraction.stream()
                .forEach(extract -> {

            extract.setCapaciteTheoriqueATraiter(
                    extract.getCapaciteTheoriqueATraiter() != null &&
                            (
                                    LocalDate.now().isEqual(LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE)) ||
                                            (LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE)).isAfter(LocalDate.now())
                            ) ?
                            round2decimal(new BigDecimal(extract.getCapaciteTheoriqueATraiter())).toString().replace(".", ",") :
                            null
            );
            extract.setEtp(extract.getEtp().replace(".", ","));
            extract.setChargeEnEtp(extract.getChargeEnEtp() != null &&
                    LocalDate.now().isEqual(LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE)) ?
                    extract.getChargeEnEtp().replace(".", ",") :
                    null);
                }
        );
    }

    private static List<ExtractPlanningActivitesDto> filterExtraction(List<ExtractPlanningActivitesDto> resultExtraction) {
        return resultExtraction.stream()
                .filter(extract -> applyFiltersRulesForPlanActivites.test(extract))
                .collect(Collectors.toList());
    }

    private static Map<String, BigDecimal> computeChargeEnEtpForFamille(List<ExtractPlanningActivitesDto> resultExtraction, String codeSt) {
        return resultExtraction.stream()
                .filter(extract -> !StringUtils.isEmpty(extract.getCodeFamille()))
                .filter(extract -> extract.getCodeSt().equals(codeSt))
                .collect(Collectors.groupingBy(ExtractPlanningActivitesDto::getCodeFamille))
                .entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entryByFamille ->
                        entryByFamille.getValue().stream()
                                .filter(extractPlan -> !extractPlan.getTypeActivite().equals(TypeActivite.FAMILLE) &&
                                        extractPlan.getChargeEnEtp() != null &&
                                        new BigDecimal(extractPlan.getChargeEnEtp()).compareTo(BigDecimal.ZERO) > 0
                                )
                                .map(extractPlan -> extractPlan.getChargeEnEtp() == null ?
                                        BigDecimal.ZERO : new BigDecimal(extractPlan.getChargeEnEtp()))
                                .reduce(BigDecimal.ZERO, BigDecimal::add)
                ));
    }

    /**
     * Génération des extraction pour les activités qui ont des Indicateurs
     */

    private static void buildExtractPlanningActiviteForActiviteWithIndicateur(String from, String to, List<ExtractPlanningActivitesDto> resultExtraction,
                                                                              Map<String, String> libellesEntiteStructureMap, Map<Long, List<Equipe>> equipesBySt,
                                                                              List<IndicateurActiviteDto> indicateursSmboBrut, Map<String, ActiviteParams> activiteParamsByActivite,
                                                                              Map<String, Map<Long, Float>> expertiseByActivite,
                                                                              Map<String , Boolean> activiteCorrespondances) {
        indicateursSmboBrut.stream().forEach(indicateur -> {


            indicateur.getStocks().stream().forEach(indicBySt -> {

                Equipe equipe = equipesBySt.get(Long.valueOf(indicBySt.getCodeServiceTraitement())) != null ? equipesBySt.get(Long.valueOf(indicBySt.getCodeServiceTraitement())).get(0) : Equipe.builder().code(Long.valueOf(indicBySt.getCodeServiceTraitement())).build();
                Unite unite = activiteParamsByActivite.get(indicateur.getCodeActivite()).getUnite();
                TypeActivite activiteType = activiteParamsByActivite.get(indicateur.getCodeActivite()).getType() == null ?
                        TypeActivite.SIMPLE : activiteParamsByActivite.get(indicateur.getCodeActivite()).getType();

                //Traitement pour les activités qui ne possèdent pas d'affectation sur le ST en question
                buildExtractionForActiviteWithIndic(from, to, resultExtraction, libellesEntiteStructureMap, activiteParamsByActivite,
                        expertiseByActivite, indicateur, indicBySt, equipe, unite, activiteType, activiteCorrespondances);

            });


        });
    }

    /**
     * Setter les donneés d'indicateurs pour les extractions des activités plannifiées
     */
    private static void completeIndicDataForPlannedActivite(Map<String, ActiviteParams> activiteParamsByActivite, Map<String, Map<Long, Float>> expertiseByActivite,
                                                            IndicateurActiviteDto indicateur, Map<String, List<ExtractPlanningActivitesDto>> extractBySt, StockATraiterStDto indicBySt,
                                                            TypeActivite activiteType) {

        List<ExtractPlanningActivitesDto> listExtractPlanActForSt = extractBySt.get(indicBySt.getCodeServiceTraitement());
        Map<String, ExtractPlanningActivitesDto> listExtractPlanActForStByDate = listExtractPlanActForSt.stream().collect(Collectors.toMap(ExtractPlanningActivitesDto::getDate, Function.identity()));
        indicBySt.getStocksATraiter().stream().forEach(indicByDay -> {
            BigInteger stockTraite = computeStockTraite(indicByDay, activiteParamsByActivite.get(indicateur.getCodeActivite()).getUnite());
            BigInteger stockTerminer = computeStockTerminer(indicByDay, activiteParamsByActivite.get(indicateur.getCodeActivite()).getUnite());

            ExtractPlanningActivitesDto extractionByDate = listExtractPlanActForStByDate.get(indicByDay.getDay());
            if (extractionByDate != null) {
                extractionByDate.setActivite(indicateur.getLibelleActivite());
                extractionByDate.setFamille(indicateur.getLibelleFamille());
                extractionByDate.setStockReelementTraite(LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isBefore(LocalDate.now()) ? stockTerminer : null);
                extractionByDate.setTypeActivite(activiteType.name());
                extractionByDate.setStockReel(
                        LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isBefore(LocalDate.now()) ? stockTraite : null);
                extractionByDate.setStockATraiterEstime(
                        LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now()) ? stockTraite : null);

                if (!extractionByDate.getTypeActivite().equals(TypeActivite.FAMILLE) &&
                        (
                                LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now()) ||
                                        (LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE)).isAfter(LocalDate.now())
                        )
                ) {

                    if (!activiteType.equals(TypeActivite.FAMILLE)) {
                        BigDecimal chargeEnEtp = computeChargeEtp(indicByDay, new BigDecimal(extractionByDate.getCapaciteTheoriqueATraiter()),
                                extractionByDate.getCodeActivite(), Unite.of(extractionByDate.getUniteDeMesure()), expertiseByActivite);
                        extractionByDate.setChargeEnEtp(chargeEnEtp != null &&
                                LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now())  ?
                                chargeEnEtp.toString() :
                                null);
                    }

                    BigInteger chargeEnVolume = computeChargeVolume(indicByDay, new BigDecimal(extractionByDate.getCapaciteTheoriqueATraiter()), Unite.of(extractionByDate.getUniteDeMesure()));
                    extractionByDate.setChargeEnVolume(
                            LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now())  ? chargeEnVolume : null);
                    extractionByDate.setCapaciteTheoriqueATraiter(

                                    LocalDate.now().isEqual(LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE)) ||
                                            (LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE)).isAfter(LocalDate.now())
                            ?
                            extractionByDate.getCapaciteTheoriqueATraiter()
                            : null);

                }
            }

        });
    }

    /**
     * Générer les donnes d'extraction ExtractPlanningActivitesDto pour les activités qui ne sont pas planifiées
     * pendant la période solliciter (from, to)
     * <p>
     * Les regles de Gestion pour les Jours échus, J, et Future sont applicable seuelemnt sur les activités qui ne sont pas plannifiées
     * (pas d'affectation sur cette période donc ETP, et CTT sont égale à Zero)
     */
    private static void buildExtractionForActiviteWithIndic(String from, String to, List<ExtractPlanningActivitesDto> resultExtraction,
                                                            Map<String, String> libellesEntiteStructureMap, Map<String, ActiviteParams> activiteParamsByActivite,
                                                            Map<String, Map<Long, Float>> expertiseByActivite, IndicateurActiviteDto indicateur, StockATraiterStDto indicBySt,
                                                            Equipe equipe, Unite unite, TypeActivite activiteType, Map<String, Boolean> activiteCorrespondances) {

        if(indicBySt.getStocksATraiter().isEmpty()){

            resultExtraction.stream()
                    .filter(extract -> extract.getCodeActivite().equals(indicateur.getCodeActivite()))
                    .filter(extract -> activiteCorrespondances.get(extract.getCodeActivite()))
                    .filter((extract -> extract.getSt().equals(indicBySt.getCodeServiceTraitement())))
                    .forEach(extract -> {
                        StockOutputDto stockOutputDto = StockOutputDto.builder().stockDossierTraiter(BigInteger.ZERO)
                                .stockTacheTraiter(BigInteger.ZERO).build();

                        BigInteger stockTraiter = computeStockTraite(stockOutputDto, unite);

                        BigDecimal capacite = !StringUtils.isEmpty(extract.getCapaciteTheoriqueATraiter()) ? new BigDecimal(extract.getCapaciteTheoriqueATraiter()) : BigDecimal.ZERO;
                        BigDecimal chargeEnVolume = new BigDecimal((stockTraiter.toString()))
                                .subtract(capacite).setScale(0, RoundingMode.HALF_EVEN);

                        BigDecimal chargeEnEtp = computeChargeEtp(stockOutputDto, capacite,
                                extract.getCodeActivite(), Unite.of(extract.getUniteDeMesure()), expertiseByActivite);

                        extract.setChargeEnEtp(chargeEnEtp != null ? chargeEnEtp.toString() : null);
                        extract.setChargeEnVolume(
                                LocalDate.now().isEqual(LocalDate.parse(extract.getDate(), DateTimeFormatter.ISO_DATE)) &&
                                        chargeEnVolume != null ? new BigInteger(chargeEnVolume.toString()) : null);
                    });
        }
        indicBySt.getStocksATraiter().stream()
                //On ne prend que les indicateurs entre date début et fin (parce que dans indicateursSmboBrut on récupère
                //les indicateur de J-6 de date debut jusqu' la date de fin pour un besoin de calcul de la moyenne Arithemetique dans le planning
                .filter(indic -> isIndicateurBetweenDateDebutAndFin.test(indic, from, to))
                .filter(indic ->
                        isPlannableActivite.test(indic.getDay(), activiteParamsByActivite.get(indicateur.getCodeActivite()).getMaskDate()))
                .forEach(indicByDay -> {

                    Map<String, Map<String, List<ExtractPlanningActivitesDto>>> extractByActAndSt = resultExtraction.stream()
                            .collect(Collectors.groupingBy(ExtractPlanningActivitesDto::getCodeActivite)).entrySet().stream().collect(
                                    Collectors.toMap(Map.Entry::getKey, extractEntry -> extractEntry.getValue().stream().collect(Collectors.groupingBy(
                                            ExtractPlanningActivitesDto::getCodeSt
                                    )))
                            );
                    Map<String, List<ExtractPlanningActivitesDto>> extractBySt = extractByActAndSt.get(indicateur.getCodeActivite());

                    BigInteger stockTraite = computeStockTraite(indicByDay, unite);
                    BigInteger stockTerminer = computeStockTerminer(indicByDay, unite);

                    if (extractBySt == null) {
                        //On Applique les regles de Gestion
                        //Création des extractions pour les activités qui n'ont pas d'affectations, donc ETP égale à Zero, et CTT égale à Zero
                        if (
                            //Pas besoin de créer des extractions pour les jours futures(ETP 0, et CTT égale à 0)
                                applyManagementRuleForFutureDays.test(indicByDay.getDay()) &&
                                        applyManagementRuleForJourJ.test(stockTraite, indicByDay.getDay()) ||
                                        applyMnagementRuleForPassedDays(stockTraite, stockTerminer, indicByDay.getDay()).get()

                        ) {
                            createNewPlanningactiviteExtract(resultExtraction, libellesEntiteStructureMap, expertiseByActivite, indicateur,
                                    indicBySt, equipe, unite, activiteType, indicByDay, stockTraite, stockTerminer, activiteCorrespondances);
                        }
                    } else {
                        Optional<ExtractPlanningActivitesDto> optionalExtractPlanningActivite = extractBySt.get(indicBySt.getCodeServiceTraitement()) == null ? Optional.empty() :
                                extractBySt.get(indicBySt.getCodeServiceTraitement()).stream()
                                        .filter(indic -> !StringUtils.isEmpty(indic.getDate()) && indic.getDate().equals(indicByDay.getDay()))
                                        .findFirst();

                        if (optionalExtractPlanningActivite.isPresent()) {
                            //Traitement pour les activités qui possèdent d'affectation sur le ST en question
                            //Les enrichir avec les données des indicateurs Brut calculé pour chaque activités
                            completeIndicDataForPlannedActivite(activiteParamsByActivite, expertiseByActivite, indicateur, extractBySt, indicBySt, activiteType);
                        } else {
                            if (
                                //Pas besoin de créer des extractions pour les jours futures(ETP 0, et CTT égale à 0)
                                    applyManagementRuleForFutureDays.test(indicByDay.getDay()) &&
                                            applyManagementRuleForJourJ.test(stockTraite, indicByDay.getDay()) ||
                                            applyMnagementRuleForPassedDays(stockTraite, stockTerminer, indicByDay.getDay()).get()

                            ) {
                                //On Applique les regles de Gestion
                                //Création des extractions pour les activités qui n'ont pas d'affectations, donc ETP égale à Zero, et CTT égale à Zero
                                createNewPlanningactiviteExtract(resultExtraction, libellesEntiteStructureMap, expertiseByActivite, indicateur, indicBySt, equipe,
                                        unite, activiteType, indicByDay, stockTraite, stockTerminer, activiteCorrespondances);
                            }
                        }
                    }
                });
    }

    private static void createNewPlanningactiviteExtract(List<ExtractPlanningActivitesDto> resultExtraction, Map<String, String> libellesEntiteStructureMap,
                                                         Map<String, Map<Long, Float>> expertiseByActivite, IndicateurActiviteDto indicateur,
                                                         StockATraiterStDto indicBySt, Equipe equipe, Unite unite, TypeActivite activiteType,
                                                         StockOutputDto indicByDay, BigInteger stockTraite, BigInteger stockTerminer,
                                                         Map<String , Boolean> activiteCorrespondances) {
        BigDecimal chareEnEtp = computeChargeEtp(indicByDay, BigDecimal.ZERO,
                indicateur.getCodeActivite(), unite, expertiseByActivite);
        ExtractPlanningActivitesDto extractionDto = ExtractPlanningActivitesDto.builder()
                .codeFiliere(equipe.getCodeCds().toString())
                .filiere(libellesEntiteStructureMap.get(equipe.getCodeCds().toString()))
                .codeUg(equipe.getCodeUg().toString())
                .ug(libellesEntiteStructureMap.get(equipe.getCodeUg().toString()))
                .codeSt(indicBySt.getCodeServiceTraitement())
                .st(libellesEntiteStructureMap.get(indicBySt.getCodeServiceTraitement()))
                .codeActivite(indicateur.getCodeActivite())
                .activite(indicateur.getLibelleActivite())
                .typeActivite(activiteType.name())
                .codeFamille(indicateur.getCodeFamille())
                .famille(indicateur.getLibelleFamille())
                .uniteDeMesure(unite.getCode())
                .etp("0")
                .date(indicByDay.getDay())
                .capaciteTheoriqueATraiter(
                        LocalDate.now().isEqual(LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE)) ||
                                (LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE)).isAfter(LocalDate.now()) ?
                                "0" :
                        null)
                .stockReelementTraite(LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isBefore(LocalDate.now()) ? stockTerminer : null)
                //Stock réel (Pour le jours échus), Stock à traiter estimé (Jour J), Stock à traiter(Jour future)
                // c'ets le stockTacheTraiter ou stockDossierTraiter selon l'unité
                .stockReel(LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isBefore(LocalDate.now()) ? stockTraite : null)
                .stockATraiterEstime(LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now()) ? stockTraite : null)
                .chargeEnVolume(
                        activiteCorrespondances.get(indicateur.getCodeActivite()) && LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE).isEqual(LocalDate.now()) ?
                                computeChargeVolume(indicByDay, BigDecimal.ZERO, unite) : null)
                .chargeEnEtp(
                        activiteCorrespondances.get(indicateur.getCodeActivite()) && !activiteType.equals(TypeActivite.FAMILLE) && LocalDate.parse(indicByDay.getDay(), DateTimeFormatter.ISO_DATE)
                                .isEqual(LocalDate.now()) ?
                                chareEnEtp != null ? chareEnEtp.toString() : null
                        : null)
                .build();

        resultExtraction.add(extractionDto);
    }

    private static TriPredicate<StockOutputDto, String, String> isIndicateurBetweenDateDebutAndFin =
            (indic, from, to) -> (LocalDate.parse(indic.getDay(), DateTimeFormatter.ISO_DATE)
                    .isEqual(LocalDate.parse(from, DateTimeFormatter.ISO_DATE)) ||
                    LocalDate.parse(indic.getDay(), DateTimeFormatter.ISO_DATE)
                            .isAfter(LocalDate.parse(from, DateTimeFormatter.ISO_DATE))) &&
                    (
                            LocalDate.parse(indic.getDay(), DateTimeFormatter.ISO_DATE)
                                    .isEqual(LocalDate.parse(to, DateTimeFormatter.ISO_DATE)) ||
                                    LocalDate.parse(indic.getDay(), DateTimeFormatter.ISO_DATE)
                                            .isBefore(LocalDate.parse(to, DateTimeFormatter.ISO_DATE))
                    );


    /**
     * Générer les donnes d'extraction ExtractPlanningActivitesDto pour les activités qui sont planifiées
     * pendant la période solliciter (from, to)
     */
    private static void buildExtractPlanningActiviteForPlanninfiedActivite(List<ExtractPlanningActivitesDto> resultExtraction, Map<String, String> libellesEntiteStructureMap,
                                                                           Map<Long, List<Equipe>> equipesBySt, List<IndicateurDto> indicateursFromEqc,
                                                                           Map<String, ActiviteParams> activiteParamsByActivite) {

        indicateursFromEqc.stream()
                .forEach(indicEqc -> {
                    Equipe equipe = equipesBySt.get(indicEqc.getServiceTraitementId()) != null ? equipesBySt.get(indicEqc.getServiceTraitementId()).get(0) : Equipe.builder().code(indicEqc.getServiceTraitementId()).build();

                    TypeActivite activiteType = activiteParamsByActivite.get(indicEqc.getCodeActivite()).getType() == null ?
                            TypeActivite.SIMPLE : activiteParamsByActivite.get(indicEqc.getCodeActivite()).getType();

                    ExtractPlanningActivitesDto extractionDto = ExtractPlanningActivitesDto.builder()
                            .codeFiliere(equipe.getCodeCds().toString())
                            .filiere(libellesEntiteStructureMap.get(equipe.getCodeCds().toString()))
                            .codeUg(equipe.getCodeUg().toString())
                            .ug(libellesEntiteStructureMap.get(equipe.getCodeUg().toString()))
                            .codeSt(equipe.getCode().toString())
                            .st(libellesEntiteStructureMap.get(equipe.getCode().toString()))
                            .codeActivite(indicEqc.getCodeActivite())
                            .codeFamille(indicEqc.getCodeFamille())
                            .typeActivite(activiteType.name())
                            .uniteDeMesure(indicEqc.getUnite().getCode())
                            .etp(indicEqc.getEtp().setScale(1, RoundingMode.HALF_UP).toString())
                            .capaciteTheoriqueATraiter(
                                    LocalDate.now().isEqual(indicEqc.getDate()) ||
                                            indicEqc.getDate().isAfter(LocalDate.now()) ?
                                            indicEqc.getCapacite().toString() : null
                            )
                            .date(indicEqc.getDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
                            .build();

                    resultExtraction.add(extractionDto);

                });
    }

    private static BigDecimal round2decimal(BigDecimal value) {
        return new BigDecimal(Math.round((value)
                .multiply(new BigDecimal(10)).floatValue()))
                .divide(new BigDecimal(10));
    }

    private static BigInteger computeStockTraite(StockOutputDto stock, Unite unite) {
        if (unite.equals(Unite.TACHES)) {
            return stock.getStockTacheTraiter();
        }
        if (unite.equals(Unite.DOSSIERS)) {
            return stock.getStockDossierTraiter();
        }
        return BigInteger.ZERO;
    }

    private static BigInteger computeStockTerminer(StockOutputDto stock, Unite unite) {
        if (unite.equals(Unite.TACHES)) {
            return stock.getStockTacheTermine();
        }
        if (unite.equals(Unite.DOSSIERS)) {
            return stock.getStockDossierTermine();
        }
        return BigInteger.ZERO;
    }

    private static BigInteger computeChargeVolume(StockOutputDto stock, BigDecimal capacite, Unite unite) {
        BigInteger stockTraiter = computeStockTraite(stock, unite);
        BigDecimal chargeVolume = new BigDecimal((stockTraiter.toString())).subtract(new BigDecimal(round2decimal(capacite).toString()));

        return new BigInteger(chargeVolume.compareTo(BigDecimal.ZERO) > 0 ?
                chargeVolume.setScale(0, RoundingMode.HALF_UP).toString()
                : chargeVolume.setScale(0, RoundingMode.HALF_EVEN).toString());
    }

    private static BigDecimal computeChargeEtp(StockOutputDto stock, BigDecimal capacite, String codeActivite, Unite unite,
                                               Map<String, Map<Long, Float>> expertiseByActivite) {

        BigInteger stockTraiter = computeStockTraite(stock, unite);

        BigDecimal chargeVolume = new BigDecimal((stockTraiter.toString()))
                .subtract(new BigDecimal(capacite.toString())).setScale(3, RoundingMode.UP);

        Float nombreDossier = expertiseByActivite.get(codeActivite).get(3L);

        if (
                nombreDossier == null || nombreDossier == -1
                        ||
                        nombreDossier == 0 ||
                        chargeVolume == BigDecimal.ZERO
        ) {
            return null;
        }
        return new BigDecimal(Math.round((chargeVolume
                .multiply(new BigDecimal(100)))
                .divide(new BigDecimal(nombreDossier), 2, RoundingMode.HALF_UP)
                .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP)
                .multiply(new BigDecimal(10)).floatValue()))
                .divide(new BigDecimal(10));

    }

    private static <T> Set<T> concat(Set<T> set1, Set<T> set2) {
        return Stream.concat(set1.stream(), set2.stream()).collect(Collectors.toSet());
    }

    private static Supplier<Boolean> applyMnagementRuleForPassedDays(BigInteger stockTraite, BigInteger stockTerminer, String day) {
        return () -> (LocalDate.parse(day, DateTimeFormatter.ISO_DATE).isBefore(LocalDate.now()) &&
                (stockTraite != null && stockTraite != BigInteger.ZERO || stockTerminer != null && stockTerminer != BigInteger.ZERO)
        );
    }

    private static Map<Long, List<Equipe>> getEquipeBySt(List<String> listCodeSt) {
        Map<Long, List<Equipe>> equipesBySt = equipeRepository.findAllByCodeIn(listCodeSt.stream()
                        .map(Long::new).collect(Collectors.toList()))
                .stream().collect(Collectors.groupingBy(Equipe::getCode));
        return equipesBySt;
    }

    /***
     * Génération de l'extraction Pilotage Activités
     * @param listCodeSt
     * @param tetePerimetre
     * @param from
     * @param to
     * @return
     */
    static List<ExtractPilotageActivitesDto> buildExtractPilotageActivite(List<String> listCodeSt, List<String> tetePerimetre, String from, String to) {

        List<ExtractPilotageActivitesDto> result = new ArrayList<>();
        List<RefFamilleDto> familleFromSmbo = smboClient.getAllFamilles();
        Map<String, List<String>> familleUniteMesure = familleFromSmbo.stream()
                .collect(toMap(RefFamilleDto::getCode,
                        famille -> CollectionUtils.isEmpty(famille.getUniteMesure()) ? new ArrayList<>() : famille.getUniteMesure()));

        Map<String,   Map<String, List<String>>> activiteUniteMesure = familleFromSmbo.stream()
                .collect(toMap(RefFamilleDto::getCode,
                        famille -> famille.getActivites().stream().collect(toMap(RefActiviteDto::getCode, RefActiviteDto::getUniteMesure))));

        Map<String, Unite> activitesParamps = activiteParamsService.findAll()
                .stream().collect(toMap(ActiviteParamsDto::getCode, ActiviteParamsDto::getUnite));

        JsonObject etpInfos = indicateurService.getEtps(
                IndicateurEtpInputDto.builder()
                        .dateDebut(from)
                        .dateFin(to)
                        .listCodeServiceTraitement(StringUtils.join(listCodeSt, ","))
                        .build()
        );


        JsonObject indicateurSuiviActivites = indicateursSuiviActiviteService.getIndicateurSuiviActivite(
                IndicateurInputDto.builder()
                        .listCodeServiceTraitement(listCodeSt)
                        .tetePerimetre(tetePerimetre)
                        .dateDebut(from)
                        .dateFin(to)
                        .build()
        );

        Map<Long, ReferentielProcessusDto> referentielProcessusById = correspondancesService.getProcessusByTetePerimetre(
                        tetePerimetre.stream().map(Long::valueOf).collect(Collectors.toList()), Source.ALL)
                .stream()
                .distinct()
                .collect(Collectors.toMap(ReferentielProcessusDto::getId, Function.identity()));

        //Récupération des libelles d'Entité de Structure
        Map<String, String> libellesEntiteStructureMap = libelleEntiteStructureRepository.getAll();


        Map<Long, List<Equipe>> equipesBySt = getEquipeBySt(listCodeSt);
        indicateurSuiviActivites.get("indicateurBySt").getAsJsonObject().entrySet()
                .stream().forEach(indicBySt -> {

                    Equipe equipe = equipesBySt.get(Long.valueOf(indicBySt.getKey())) != null ? equipesBySt.get(Long.valueOf(indicBySt.getKey())).get(0) : Equipe.builder().code(Long.valueOf(indicBySt.getKey())).build();

                    JsonObject etpBySt = etpInfos.get("etpsBySt").getAsJsonObject().get(indicBySt.getKey()) != null ? etpInfos.get("etpsBySt").getAsJsonObject().get(indicBySt.getKey()).getAsJsonObject() : null;
                    JsonElement indicateurValueSt = indicBySt.getValue();

                    indicateurValueSt.getAsJsonObject().entrySet()
                            .stream().forEach(indicByFamille -> {


                                JsonObject etpFamille = etpBySt != null && etpBySt.get(indicByFamille.getKey()) != null ?
                                        etpBySt.get(indicByFamille.getKey()).getAsJsonObject() : null;


                                ExtractPilotageActivitesDto extractionDto = buildPilotageFamilleLine(libellesEntiteStructureMap, familleUniteMesure.get(indicByFamille.getKey()), indicBySt, equipe, indicByFamille, etpFamille, from, to);

                                //Ajout d'une ligne représentant la Famille
                                result.add(extractionDto);

                                indicByFamille.getValue().getAsJsonObject().get("Activites").getAsJsonObject()
                                        .entrySet().forEach(indicByActivite -> {

                                            JsonObject etpActivite = etpFamille != null && etpFamille.get("activities").getAsJsonObject()
                                                    .get(indicByActivite.getKey()) != null ?
                                                    etpFamille.get("activities").getAsJsonObject()
                                                            .get(indicByActivite.getKey()).getAsJsonObject()
                                                    : null;


                                            ExtractPilotageActivitesDto extractionActiviteClone = SerializationUtils.clone(extractionDto);

                                            buildPilotageActiviteLine(indicByActivite,
                                                    activiteUniteMesure.get(indicByFamille.getKey()).get(indicByActivite.getKey()),
                                                    extractionActiviteClone, etpActivite, from, to);

                                            //Ajout d'une ligne représentant l'activité
                                            result.add(extractionActiviteClone);

                                            //Parcourir les processus
                                            indicByActivite.getValue().getAsJsonObject().get("Processus").getAsJsonObject()
                                                    .entrySet().forEach(indicByProcessus -> {

                                                        ExtractPilotageActivitesDto extractionProcessusClone = SerializationUtils.clone(extractionActiviteClone);
                                                        ReferentielProcessusDto processus = buildPilotageProcessusLine(referentielProcessusById, indicByProcessus, extractionProcessusClone, from, to);
                                                        //Ajout d'une ligne représentant le processus lié à l'activité
                                                if(
                                                        (processus.getSource().equals(Source.HARMONIE) &&
                                                                (
                                                                        (CollectionUtils.isEmpty(processus.getNatures()) &&
                                                                                CollectionUtils.isEmpty(processus.getTaches())) ||
                                                                                (CollectionUtils.isEmpty(processus.getNatures()) &&
                                                                                        !CollectionUtils.isEmpty(processus.getTaches()))
                                                                )
                                                        ) || processus.getSource().equals(Source.SAISIE_GLOBALE)
                                                ) {
                                                    result.add(extractionProcessusClone);
                                                }

                                                        if (processus.getSource().equals(Source.HARMONIE)) {

                                                            indicByProcessus.getValue().getAsJsonObject().get("Nature").getAsJsonObject()
                                                                    .entrySet().forEach(indicByNature -> {

                                                                        ExtractPilotageActivitesDto extractionNatureClone = SerializationUtils.clone(extractionProcessusClone);

                                                                        if (!indicByNature.getKey().equals("null")) {
                                                                            buildPilotageNatureLine(processus, indicByNature, extractionNatureClone);
                                                                            //Ajout d'une ligne représentant la nature liée à l'activité
                                                                            result.add(extractionNatureClone);
                                                                        }

                                                                        indicByNature.getValue().getAsJsonObject().get("Taches").getAsJsonArray()
                                                                                .forEach(indicBytache -> {

                                                                                    ExtractPilotageActivitesDto extractTacheClone = SerializationUtils.clone(extractionNatureClone);
                                                                                    Optional<ReferentielTacheDto> tache = processus.getTaches().stream()
                                                                                            .filter(task -> task.getId()
                                                                                                    .equals(indicBytache.getAsJsonObject()
                                                                                                            .get("tacheId") == null ? null : Long.valueOf(indicBytache.getAsJsonObject()
                                                                                                            .get("tacheId").getAsString())))
                                                                                            .findFirst();

                                                                                    if(tache.isPresent()) {
                                                                                        buildPilotageTacheLine(processus, tache.get(), indicBytache, extractTacheClone, from , to);

                                                                                        //Ajout d'une ligne représentant les taches liées à l'activité
                                                                                        result.add(extractTacheClone);
                                                                                    }
                                                                                });
                                                                    });
                                                        }

                                                    });
                                        });

                            });

                });

        List<ExtractPlanningCollabDto> extractPlanningCollab = extractPlanningCollabRepository
                .findPlanningCollab(listCodeSt, LocalDate.parse(from, DateTimeFormatter.ISO_DATE),
                        LocalDate.parse(to, DateTimeFormatter.ISO_DATE));

        ajouterLibellesFamilleAndActivitesForPlanningCollab(extractPlanningCollab, familleFromSmbo);


        return result;
    }


    private static void buildPilotageNatureLine(ReferentielProcessusDto processus, Map.Entry<String, JsonElement> indicByNature, ExtractPilotageActivitesDto extractNatureClone) {

        Optional<NatureDto> optNature = processus.getNatures().stream()
                .filter(nat -> nat.getId().equals(Long.valueOf(indicByNature.getKey())))
                .findFirst();

        extractNatureClone.setLibelleNature(
                optNature.isPresent() ? optNature.get().getLibelle() : ""
        );
        extractNatureClone.setNiveau("Processus /Nature");
        extractNatureClone.setCodeTache("-");
        extractNatureClone.setLibelleTache("-");

        extractNatureClone.setNombreDossierVeille(indicByNature.getValue()
                .getAsJsonObject().get("stockVeille").getAsBigDecimal().toString());
        extractNatureClone.setNombreDossierRecus(indicByNature.getValue()
                .getAsJsonObject().get("stockRecu").getAsBigDecimal().toString());
        extractNatureClone.setNombreDossiersTermines(indicByNature.getValue().getAsJsonObject()
                .get("stockTermine").getAsBigDecimal().toString());
        extractNatureClone.setNombreDossiersAbandonees(indicByNature.getValue().getAsJsonObject()
                .get("stockSupprime").getAsBigDecimal().toString());

        extractNatureClone.setNombreTachesVeilles(indicByNature.getValue().getAsJsonObject()
                .get("stockTacheVeille").getAsBigDecimal().toString());
        extractNatureClone.setNombreTachesSupprimees(indicByNature.getValue().getAsJsonObject()
                .get("stockTacheSupprime").getAsBigDecimal().toString());
        extractNatureClone.setNombreTachesTermines(indicByNature.getValue().getAsJsonObject()
                .get("stockTacheTermine").getAsBigDecimal().toString());
        extractNatureClone.setNombreTachesRecus(indicByNature.getValue().getAsJsonObject()
                .get("stockTacheRecu").getAsBigDecimal().toString());

        extractNatureClone.setNombreTachesRestantes(
                String.valueOf(
                        Integer.valueOf(extractNatureClone.getNombreTachesVeilles()) +
                                Integer.valueOf(extractNatureClone.getNombreTachesRecus())
                                -
                                Integer.valueOf(extractNatureClone.getNombreTachesTermines())
                ));

        extractNatureClone.setDossiersRestant(
                String.valueOf(
                        Integer.valueOf(extractNatureClone.getNombreDossierVeille()) +
                                Integer.valueOf(extractNatureClone.getNombreDossierRecus())
                                -
                                Integer.valueOf(extractNatureClone.getNombreDossiersTermines())
                ));

        extractNatureClone.setNombreEtpPlanifies(null);
        extractNatureClone.setNombreEtpRenfort(null);
    }

    private static void buildPilotageTacheLine(ReferentielProcessusDto processus, ReferentielTacheDto tache, JsonElement indicBytache, ExtractPilotageActivitesDto extractTacheClone, String from, String to) {
        //List<ReferentielTacheDto> taches = processus.getTaches();

        extractTacheClone.setDateDebut(from);
        extractTacheClone.setDateFin(to);

            extractTacheClone.setCodeTache(tache.getCode());
            extractTacheClone.setLibelleTache(tache.getLibelle());
            extractTacheClone.setNiveau("Tâche");

        extractTacheClone.setNombreDossierVeille(null);
        extractTacheClone.setNombreDossierRecus(null);
        extractTacheClone.setNombreDossiersTermines(null);
        extractTacheClone.setNombreDossiersAbandonees(null);
        extractTacheClone.setDossiersRestant(null);

        extractTacheClone.setNombreTachesVeilles(indicBytache.getAsJsonObject()
                .get("stockTacheVeille").getAsBigDecimal().toString());
        extractTacheClone.setNombreTachesSupprimees(indicBytache.getAsJsonObject()
                .get("stockTacheSupprime").getAsBigDecimal().toString());
        extractTacheClone.setNombreTachesTermines(indicBytache.getAsJsonObject()
                .get("stockTacheTermine").getAsBigDecimal().toString());
        extractTacheClone.setNombreTachesRecus(indicBytache.getAsJsonObject()
                .get("stockTacheRecu").getAsBigDecimal().toString());

        extractTacheClone.setNombreTachesRestantes(
                String.valueOf(
                        Integer.valueOf(extractTacheClone.getNombreTachesVeilles()) +
                                Integer.valueOf(extractTacheClone.getNombreTachesRecus())
                                -
                                Integer.valueOf(extractTacheClone.getNombreTachesTermines())
                ));
    }

    private static ReferentielProcessusDto buildPilotageProcessusLine(Map<Long, ReferentielProcessusDto> referentielProcessusById, Map.Entry<String, JsonElement> indicByProcessus, ExtractPilotageActivitesDto extractionProcessusClone, String from, String to) {
        extractionProcessusClone.setDateDebut(from);
        extractionProcessusClone.setDateFin(to);
        ReferentielProcessusDto processus = referentielProcessusById.get(Long.valueOf(indicByProcessus.getKey()));
        extractionProcessusClone.setLibelleProcessus(processus.getLibelle());
        extractionProcessusClone.setSource(processus.getSource().getName());
        extractionProcessusClone.setNiveau("Processus /Nature");

        extractionProcessusClone.setNombreDossierVeille(indicByProcessus.getValue()
                .getAsJsonObject().get("stockVeille").getAsBigDecimal().toString());
        extractionProcessusClone.setNombreDossierRecus(indicByProcessus.getValue()
                .getAsJsonObject().get("stockRecu").getAsBigDecimal().toString());
        extractionProcessusClone.setNombreDossiersTermines(indicByProcessus.getValue().getAsJsonObject()
                .get("stockTermine").getAsBigDecimal().toString());
        extractionProcessusClone.setNombreDossiersAbandonees(indicByProcessus.getValue().getAsJsonObject()
                .get("stockSupprime").getAsBigDecimal().toString());

        if(processus.getSource().equals(Source.HARMONIE)) {
            extractionProcessusClone.setNombreTachesVeilles(indicByProcessus.getValue().getAsJsonObject()
                    .get("stockTacheVeille").getAsBigDecimal().toString());
            extractionProcessusClone.setNombreTachesSupprimees(indicByProcessus.getValue().getAsJsonObject()
                    .get("stockTacheSupprime").getAsBigDecimal().toString());
            extractionProcessusClone.setNombreTachesTermines(indicByProcessus.getValue().getAsJsonObject()
                    .get("stockTacheTermine").getAsBigDecimal().toString());
            extractionProcessusClone.setNombreTachesRecus(indicByProcessus.getValue().getAsJsonObject()
                    .get("stockTacheRecu").getAsBigDecimal().toString());
            extractionProcessusClone.setNombreTachesRestantes(
                    String.valueOf(
                            Integer.valueOf(extractionProcessusClone.getNombreTachesVeilles()) +
                                    Integer.valueOf(extractionProcessusClone.getNombreTachesRecus())
                                    -
                                    Integer.valueOf(extractionProcessusClone.getNombreTachesTermines())
                    ));
        } else {
            extractionProcessusClone.setNombreTachesVeilles(null);
            extractionProcessusClone.setNombreTachesSupprimees(null);
            extractionProcessusClone.setNombreTachesTermines(null);
            extractionProcessusClone.setNombreTachesRecus(null);
            extractionProcessusClone.setNombreTachesRestantes(null);
        }

        extractionProcessusClone.setDossiersRestant(
                String.valueOf(
                        Integer.valueOf(extractionProcessusClone.getNombreDossierVeille()) +
                                Integer.valueOf(extractionProcessusClone.getNombreDossierRecus())
                                -
                                Integer.valueOf(extractionProcessusClone.getNombreDossiersTermines())
                ));

        extractionProcessusClone.setCodeTache("-");
        extractionProcessusClone.setLibelleTache("-");
        extractionProcessusClone.setLibelleNature("-");
        extractionProcessusClone.setNombreEtpPlanifies(null);
        extractionProcessusClone.setNombreEtpRenfort(null);
        return processus;
    }

    private static ExtractPilotageActivitesDto buildPilotageFamilleLine(Map<String, String> libellesEntiteStructureMap, List<String> uniteFamilles, Map.Entry<String, JsonElement> indicBySt, Equipe equipe, Map.Entry<String, JsonElement> indicByFamille, JsonObject etpFamille, String from, String to) {
        Boolean isFamilleWithTacheUnite = uniteFamilles.contains("TACHE");
        return ExtractPilotageActivitesDto.builder()
                .dateDebut(from)
                .dateFin(to)
                .codeFiliere(equipe.getCodeCds().toString())
                .filiere(libellesEntiteStructureMap.get(equipe.getCodeCds().toString()))
                .codeUg(equipe.getCodeUg().toString())
                .ug(libellesEntiteStructureMap.get(equipe.getCodeUg().toString()))
                .codeSt(indicBySt.getKey())
                .st(libellesEntiteStructureMap.get(indicBySt.getKey()))
                .codeFamille(indicByFamille.getKey())
                .famille(!indicByFamille.getValue().getAsJsonObject().get("libelleFamille").isJsonNull()?
                        indicByFamille.getValue().getAsJsonObject().get("libelleFamille").getAsString() : "")
                .niveau("Famille")
                .activite("-")
                .source("-")
                .libelleProcessus("-")
                .libelleNature("-")
                .codeTache("-")
                .libelleTache("-")
                .nombreTachesVeilles(isFamilleWithTacheUnite ? indicByFamille.getValue()
                        .getAsJsonObject().get("stockTacheVeille").getAsBigDecimal().toString() : null)
                .nombreTachesRecus(isFamilleWithTacheUnite ? indicByFamille.getValue()
                        .getAsJsonObject().get("stockTacheRecu").getAsBigDecimal().toString() : null)
                .nombreTachesTermines(isFamilleWithTacheUnite ? indicByFamille.getValue()
                        .getAsJsonObject().get("stockTacheTermine").getAsBigDecimal().toString() : null)
                .nombreTachesSupprimees(isFamilleWithTacheUnite ? indicByFamille.getValue()
                        .getAsJsonObject().get("stockTacheSupprime").getAsBigDecimal().toString() : null)
                .nombreTachesRestantes(isFamilleWithTacheUnite ? indicByFamille.getValue()
                        .getAsJsonObject().get("stockTacheVeille").getAsBigDecimal()
                        .add(indicByFamille.getValue()
                                .getAsJsonObject().get("stockTacheRecu").getAsBigDecimal())
                        .subtract(indicByFamille.getValue()
                                .getAsJsonObject().get("stockTacheTermine").getAsBigDecimal()).toString() : null)
                .nombreDossierVeille(indicByFamille.getValue()
                        .getAsJsonObject().get("stockVeille").getAsBigDecimal().toString())
                .nombreDossierRecus(indicByFamille.getValue()
                        .getAsJsonObject().get("stockRecu").getAsBigDecimal().toString())
                .nombreDossiersTermines(indicByFamille.getValue().getAsJsonObject()
                        .get("stockTermine").getAsBigDecimal().toString())
                .nombreDossiersAbandonees(indicByFamille.getValue().getAsJsonObject()
                        .get("stockSupprime").getAsBigDecimal().toString())
                .dossiersRestant(indicByFamille.getValue()
                        .getAsJsonObject().get("stockVeille").getAsBigDecimal()
                        .add(indicByFamille.getValue()
                                .getAsJsonObject().get("stockRecu").getAsBigDecimal())
                        .subtract(indicByFamille.getValue()
                                .getAsJsonObject().get("stockTermine").getAsBigDecimal()).toString()
                )
                .nombreEtpPlanifies(etpFamille != null &&
                        !new BigDecimal(etpFamille.get("etpTotalMoyen").toString()).setScale(1, RoundingMode.HALF_UP).equals(new BigDecimal("0.0"))?
                        String.format("%.1f", new BigDecimal(etpFamille.get("etpTotalMoyen").toString()).setScale(1, RoundingMode.HALF_UP))
                                .replace(".", ",") :
                        "0"
                )
                .nombreEtpRenfort(
                        etpFamille != null &&
                                !new BigDecimal(etpFamille.get("etpRenfortMoyen").toString()).setScale(1, RoundingMode.HALF_UP).equals(new BigDecimal("0.0")) ?
                                String.format("%.1f", new BigDecimal(etpFamille.get("etpRenfortMoyen").toString()).setScale(1, RoundingMode.HALF_UP))
                                        .replace(".", ",") :
                            "0"
                )
                .build();
    }

    private static void buildPilotageActiviteLine(Map.Entry<String, JsonElement> indicByActivite, List<String> uniteActivite, ExtractPilotageActivitesDto extractionActiviteClone, JsonObject etpActivite, String from, String to) {
        Boolean isActiviteWithTacheUnite = uniteActivite.contains("TACHE");
        extractionActiviteClone.setDateDebut(from);
        extractionActiviteClone.setDateFin(to);
        extractionActiviteClone.setCodeActivite(indicByActivite.getKey());
        extractionActiviteClone.setActivite(
                !indicByActivite.getValue().getAsJsonObject().get("libelleActivite").isJsonNull() ?
                indicByActivite.getValue().getAsJsonObject().get("libelleActivite").getAsString() : "");
        extractionActiviteClone.setNiveau("Activité");
        extractionActiviteClone.setSource("-");
        extractionActiviteClone.setLibelleProcessus("-");
        extractionActiviteClone.setLibelleNature("-");
        extractionActiviteClone.setCodeTache("-");
        extractionActiviteClone.setLibelleTache("-");

        extractionActiviteClone.setNombreDossierVeille(indicByActivite.getValue()
                .getAsJsonObject().get("stockVeille").getAsBigDecimal().toString());
        extractionActiviteClone.setNombreDossierRecus(indicByActivite.getValue()
                .getAsJsonObject().get("stockRecu").getAsBigDecimal().toString());
        extractionActiviteClone.setNombreDossiersTermines(indicByActivite.getValue().getAsJsonObject()
                .get("stockTermine").getAsBigDecimal().toString());
        extractionActiviteClone.setNombreDossiersAbandonees(indicByActivite.getValue().getAsJsonObject()
                .get("stockSupprime").getAsBigDecimal().toString());

        extractionActiviteClone.setDossiersRestant(
                String.valueOf(
                        Integer.valueOf(extractionActiviteClone.getNombreDossierVeille()) +
                                Integer.valueOf(extractionActiviteClone.getNombreDossierRecus())
                                -
                                Integer.valueOf(extractionActiviteClone.getNombreDossiersTermines())
                ));

        extractionActiviteClone.setNombreTachesVeilles(isActiviteWithTacheUnite ? indicByActivite.getValue().getAsJsonObject()
                .get("stockTacheVeille").getAsBigDecimal().toString() : null);
        extractionActiviteClone.setNombreTachesSupprimees(isActiviteWithTacheUnite ? indicByActivite.getValue().getAsJsonObject()
                .get("stockTacheSupprime").getAsBigDecimal().toString() : null);
        extractionActiviteClone.setNombreTachesTermines(isActiviteWithTacheUnite ? indicByActivite.getValue().getAsJsonObject()
                .get("stockTacheTermine").getAsBigDecimal().toString() : null);
        extractionActiviteClone.setNombreTachesRecus(isActiviteWithTacheUnite ? indicByActivite.getValue().getAsJsonObject()
                .get("stockTacheRecu").getAsBigDecimal().toString() : null);

        extractionActiviteClone.setNombreTachesRestantes(isActiviteWithTacheUnite ?
                String.valueOf(
                        Integer.valueOf(extractionActiviteClone.getNombreTachesVeilles()) +
                                Integer.valueOf(extractionActiviteClone.getNombreTachesRecus())
                                -
                                Integer.valueOf(extractionActiviteClone.getNombreTachesTermines())
                ) : null);

        extractionActiviteClone.setNombreEtpPlanifies(etpActivite != null &&
                        !new BigDecimal(etpActivite.get("etpTotalMoyen").toString()).setScale(1, RoundingMode.HALF_UP).equals(new BigDecimal("0.0")) ?
                String.format("%.2f", new BigDecimal(etpActivite.get("etpTotalMoyen").toString()).setScale(1, RoundingMode.HALF_UP))
                .toString().replace(".", ",") :
                "0"
        );
        extractionActiviteClone.setNombreEtpRenfort(etpActivite != null &&
                !new BigDecimal(etpActivite.get("etpRenfortMoyen").toString()).setScale(1, RoundingMode.HALF_UP).equals(new BigDecimal("0.0")) ?
                        String.format("%.2f", new BigDecimal(etpActivite.get("etpRenfortMoyen").toString()).setScale(1, RoundingMode.HALF_UP))
                        .toString().replace(".", ",") :
                "0");
    }

    /***
     * Génération de l'extraction des compétences
     * @param listCodeSt
     * @param tetePerimetres
     * @return
     */
    static List<ExtractCompetencesDto> buildExtractCompetences(List<String> listCodeSt, List<String> tetePerimetres, String from, String to) {

        //Récupération des libelles d'Entité de Structure
        Map<String, String> libellesEntiteStructureMap = libelleEntiteStructureRepository.getAll();
        List<RefFamilleDto> familleFromSmbo = smboClient.getAllFamilles().stream()
                .filter(refFamilleDto -> tetePerimetres.contains(refFamilleDto.getCodeTetePerimetre()) && refFamilleDto.getMaskDateCompetence() == null)
                .collect(Collectors.toList());
        Map<String, String> libellesFamilles = getFamilleReferential(familleFromSmbo);
        Map<String, String> libellesActivites = getActiviteReferential(familleFromSmbo);
        TetePerimetre tetePerimetre = tetePerimetreService.findTetePerimetreById(tetePerimetres.get(0));

        List<ActiviteParams> listActiviteParams = activiteRepository.findByCodeFamilleInAndMaskDateCompetenceIsNull(familleFromSmbo.
                stream().map(RefFamilleDto::getCode).collect(Collectors.toList()));

        return competenceService.getCompetencesExtractionByListServiceTraitement(
                listCodeSt.stream().map(Long::valueOf).collect(Collectors.toList()),
                listActiviteParams.stream().map(ActiviteParams::getCode).collect(Collectors.toList()),
                tetePerimetre,
                libellesEntiteStructureMap,
                libellesFamilles,
                libellesActivites
        );
    }


}