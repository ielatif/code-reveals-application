package com.socgen.eqc.infrastructure.batch;

import com.socgen.eqc.application.ActiviteService;
import com.socgen.eqc.application.impl.AbsenceServiceImpl;
import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import com.socgen.eqc.infrastructure.batch.dto.ActiviteSumeauDto;
import com.socgen.eqc.infrastructure.batch.dto.AffectationDto;
import com.socgen.eqc.infrastructure.batch.dto.AffectationEqcTotal;
import com.socgen.eqc.infrastructure.batch.exception.EqcBatchException;
import com.socgen.eqc.infrastructure.batch.exception.ExceptionBatchMessage;
import com.socgen.eqc.infrastructure.batch.mapper.AbsenceMapper;
import com.socgen.eqc.infrastructure.batch.repository.ConsolideRepository;
import com.socgen.eqc.infrastructure.batch.service.ConsolideInterUgService;
import com.socgen.eqc.infrastructure.batch.service.ConsolideIntraUgService;
import com.socgen.eqc.infrastructure.batch.utils.CalculatorConsolideUtils;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import com.socgen.eqc.infrastructure.persistance.EquipeRepository;
import com.socgen.eqc.infrastructure.persistance.RenfortRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Component
@StepScope
public class ConsolideItemWriter implements ItemWriter<AffectationDto> {


    @Autowired
    private ActiviteService activiteService;
    @Autowired
    private ConsolideInterUgService consolideInterUgService;
    @Autowired
    private ConsolideIntraUgService consolideIntraUgService;
    private ConsolideRepository repositoryWriter;
    private AbsenceMapper absenceMapper;
    private RenfortRepository renfortRepository;
    private EquipeRepository equipeRepository;
    private AffiliationRepository affiliationRepository;
    private AbsenceServiceImpl absenceService;
    private Long date;


    @PostConstruct
    public void init() {
        CalculatorConsolideUtils.setAbsenceMapper(absenceMapper);
        CalculatorConsolideUtils.setRenfortRepository(renfortRepository);
        CalculatorConsolideUtils.setEquipeRepository(equipeRepository);
        CalculatorConsolideUtils.setAffiliationRepository(affiliationRepository);
        CalculatorConsolideUtils.setAbsenceService(absenceService);
    }

    public ConsolideItemWriter(ConsolideRepository repositoryWriter, AbsenceMapper absenceMapper,
                               RenfortRepository renfortRepository, EquipeRepository equipeRepository,
                               AffiliationRepository affiliationRepository, AbsenceServiceImpl absenceService,
                               @Value("#{jobParameters['date']}") Long date) {
        this.repositoryWriter = repositoryWriter;
        this.absenceMapper = absenceMapper;
        this.renfortRepository = renfortRepository;
        this.equipeRepository = equipeRepository;
        this.affiliationRepository = affiliationRepository;
        this.absenceService  = absenceService;
        this.date = date;
    }

    @Override
    public void write(List<? extends AffectationDto> affectationDtos) {

        try {

            //Calculer les jours de présence pour chaque collaborateur
            Map<String, Double> listPresenceByMatricule = CalculatorConsolideUtils.computePrenseceDays(affectationDtos, date);

            filterAffectWithSumeauActivite(affectationDtos);

            Map<Long, Map<String, Map<String, List<AffectationEqcTotal>>>> mapAffecRenfortInterUgByStAide = consolideInterUgService
                    .buildTotalAffectationRenfortEntrantsInterUg(affectationDtos);

            Map<String, Long> mapCumulMensRenfortInterUg = getCumulMensuelRenfortInterUg(mapAffecRenfortInterUgByStAide);

            Map<Long, List<ConsolideMensuel>> consolideEquipe = consolideIntraUgService.builConsolideForEquipeAndIntraUg(affectationDtos, mapCumulMensRenfortInterUg, listPresenceByMatricule, date);

            Map<Long, List<ConsolideMensuel>> consolideRenfortInterUg = consolideInterUgService
                    .buildConsolideRenfortEntrantsInterUg(mapAffecRenfortInterUgByStAide, mapCumulMensRenfortInterUg, date);

            //Sauvegarde des consolideMensuel
            Map<Long, List<ConsolideMensuel>> consolideMensuels = consolideInterUgService.flatMapWithSameKey(consolideEquipe, consolideRenfortInterUg);

            //ajustement du pourcentage le plus elevé
            adjustHigherPourcent(consolideMensuels);

            consolideMensuels.forEach((key, value) -> repositoryWriter.saveAll(value));

        } catch (Exception e) {
            LocalDate dateLastMonth = LocalDate.now().minusMonths(1);
            String exceptionBatchMessage = ExceptionBatchMessage.CSM_ERROR_GENERATION_CONSOLIDE
                    .formatErrorMessage(String.valueOf(dateLastMonth.getMonthValue()), String
                            .valueOf(dateLastMonth.getYear()), e.getMessage());
            log.error(exceptionBatchMessage);
            log.error("Exception", e);
            throw new EqcBatchException(exceptionBatchMessage);
        }

    }

    /**
     * Calculer le cumul mensuel pour les renforts entrants pour chaque matrciule
     * dans tous les ST Aide
     *
     * @param mapAffecRenfortInterUgByStAide
     * @return
     */
    private Map<String, Long> getCumulMensuelRenfortInterUg(Map<Long, Map<String, Map<String, List<AffectationEqcTotal>>>> mapAffecRenfortInterUgByStAide) {

        Map<Long, Map<String, Long>> result = mapAffecRenfortInterUgByStAide.entrySet()
                .stream().collect(Collectors.toMap(Map.Entry::getKey, entryRenfortByStAide -> entryRenfortByStAide.getValue().entrySet()
                        .stream()
                        .collect(Collectors.toMap(Map.Entry::getKey,
                                entryByMatricule -> consolideInterUgService.computeCumulMensuelForAllActivite(entryByMatricule.getValue().values())))));

        HashMap<String, Long> mapCumulMensByMatricule = new HashMap<>();
        for (Map<String, Long> entryTotal : result.values()) {
            entryTotal.forEach((key, value) -> mapCumulMensByMatricule.merge(key, value, Long::sum));
        }

        return mapCumulMensByMatricule;
    }


    /**
     * Récupérer que les affectations dont leurs activités ont une correspondance dans Sumeau
     *
     * @param affectationDtos
     */
    private void filterAffectWithSumeauActivite(List<? extends AffectationDto> affectationDtos) {
        List<String> activiteCodes = affectationDtos.stream().map(AffectationDto::getCodeActivite)
                .distinct()
                .collect(Collectors.toList());

        Map<String, ActiviteSumeauDto> sumeauActivites = getCorrespondanceActiviteSumeau(activiteCodes);

        for (AffectationDto affectDto : affectationDtos) {
            ActiviteSumeauDto activiteSumeau = sumeauActivites.get(affectDto.getCodeActivite());
            if (activiteSumeau != null && activiteSumeau.getSumeauId() != null) {
                affectDto.setIdActiviteSumeau(activiteSumeau.getSumeauId());
                affectDto.setLibelleActiviteSumeau(activiteSumeau.getLibelleSumeau());
            }
        }
    }

    /**
     * La fonction permet d'éviter de faire appel à chaque activité afin de chercher
     * l'activité Sumeau correspodante
     *filtrer les activites par type Ratio, récupérer que les activites Sumeau qui ont type == SUM
     * @param activiteCodes
     * @return
     */
    private Map<String, ActiviteSumeauDto> getCorrespondanceActiviteSumeau(List<String> activiteCodes) {
        return activiteService.findByIdIn(activiteCodes).stream()
                .filter(activite -> activite.getActiviteRatio() != null
                        && "SUM".equals(activite.getActiviteRatio().getRatioType().getCode()))
                .map(this::buildActiviteSumeauDto)
                .collect(Collectors.toMap(ActiviteSumeauDto::getActiviteCode, Function.identity()));
    }

    private ActiviteSumeauDto buildActiviteSumeauDto(ActiviteParams activite) {
        return ActiviteSumeauDto.builder()
                .sumeauId(activite.getActiviteRatio().getCode())
                .activiteCode(activite.getCode())
                .libelleSumeau(activite.getActiviteRatio().getLibelle())
                .build();
    }

    /**
     * Ajustement du % le plus élevé  pour obtenir un cumul à 100
     * Si la somme des taux mensuel d'affectation du collaborateur n'est pas égale à 100%,
     * alors il faut ajouter ou soustraire la différence à 100 au taux d'affectation le plus élevé.
     *
     * @return
     */
    private void adjustHigherPourcent(Map<Long, List<ConsolideMensuel>> consolideMensuel) {

        Map<Long, List<ConsolideMensuel>> mapConsolideByStRattachement = consolideMensuel.values().stream()
                .flatMap(Collection::stream)
                .collect(Collectors.groupingBy(ConsolideMensuel::getStRattachement));

        mapConsolideByStRattachement.forEach((key, value) -> {

            Map<String, List<ConsolideMensuel>> mapConsolideByMatricule = value
                .stream().collect(Collectors.groupingBy(ConsolideMensuel::getMatriculeCollaborateur));

            updateTaux(mapConsolideByMatricule);
        });
    }


    /**
     * Mise a jour de taux de l'activité sumeau
     * @param mapConsolideByMatricule
     */
    private void updateTaux( Map<String, List<ConsolideMensuel>> mapConsolideByMatricule) {

        mapConsolideByMatricule.forEach((key, consolides) -> {
            updateTauxHorsUg(consolides);
            updateTauxSumeau(consolides);
        });
    }

    /**
     * Lissage du Taux sumeau pour avoir à la fin un calcul égale a 100%
     * @param consolides
     */
    private void updateTauxSumeau(List<ConsolideMensuel> consolides) {
        Optional<ConsolideMensuel> consolideMensuelMax = consolides.stream()
                .filter(consolide -> consolide.getTauxActiviteSumeau() != BigDecimal.ZERO)
                .max(Comparator.comparing(ConsolideMensuel::getTauxActiviteSumeau));

        consolideMensuelMax.ifPresent(consolideMensuel -> consolideMensuel
            .setTauxActiviteSumeau(
                consolideMensuel.getTauxActiviteSumeau().subtract(computeDiffTotalTaux(consolides))
            ));
    }

    /**
     * Calcul du cumul des taux de renforts hors UG
     * @param consolides
     */
    private void updateTauxHorsUg(List<ConsolideMensuel> consolides) {
        BigDecimal tauxHorsUg = consolides.stream()
                .filter(ConsolideMensuel::getIsRenfortInterUg)
                .map(ConsolideMensuel::getTauxActiviteSumeau)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        consolides.stream()
                .filter(cons -> !cons.getIsRenfortInterUg())
                .forEach(cons -> cons.setTauxHorsUg(tauxHorsUg == null ? BigDecimal.ZERO : tauxHorsUg));
    }

    /**
     * Calculer l'ecrat entre le total des planiifications d'un collaborateur et 100%
     *
     * @param consolideByMatricule
     * @return
     */
    private BigDecimal computeDiffTotalTaux(List<ConsolideMensuel> consolideByMatricule) {
        BigDecimal totalPlannification = consolideByMatricule.stream()
                .map(cons -> cons.getTauxActiviteSumeau() != null ? cons.getTauxActiviteSumeau() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return totalPlannification.subtract(BigDecimal.valueOf(100));
    }
}
