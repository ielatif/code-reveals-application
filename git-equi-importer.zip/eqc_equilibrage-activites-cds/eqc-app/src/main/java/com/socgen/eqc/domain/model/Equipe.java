package com.socgen.eqc.domain.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = {"renforts", "affiliations", "sousEquipes"})
@Builder
@Entity(name = "EQUIPE")
@Getter
@Setter
public class Equipe implements Serializable {

    private static final long serialVersionUID = -2088595025397744894L;

    @Id
    @Column(name = "ID", nullable = false, unique = true)
    private Long code;

    @Column(name = "LIBELLE")
    private String libelle;

    @Column(name = "code_cds", nullable = false)
    private Long codeCds;

    @Column(name = "code_ug", nullable = false)
    private Long codeUg;

    @Column(name = "format_semainier", nullable = false)
    private Byte formatSemainier;

    @OneToMany(mappedBy = "equipe", fetch = FetchType.LAZY)
    private Set<Affiliation> affiliations;

    @OneToMany(mappedBy = "equipe", fetch = FetchType.LAZY)
    private Set<Renfort> renforts;

    @OneToMany(mappedBy = "equipe", fetch = FetchType.LAZY)
    private Set<SousEquipe> sousEquipes;
}
