package com.socgen.eqc.infrastructure.people.client;


import com.socgen.eqc.infrastructure.people.dto.ListPeopleDto;
import lombok.NonNull;

import java.util.List;

public interface PeopleClient {

    ListPeopleDto findPeopleByListMatricule(@NonNull List<String> matricules);

    ListPeopleDto findPeopleByListCodeSt(@NonNull List<Long> codesSt);

    ListPeopleDto findPeople(@NonNull List<Long> codesSt, @NonNull List<String> matricules);

}
