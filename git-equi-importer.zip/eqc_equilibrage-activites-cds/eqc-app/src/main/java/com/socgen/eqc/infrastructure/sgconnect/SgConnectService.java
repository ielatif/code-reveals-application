package com.socgen.eqc.infrastructure.sgconnect;

import javax.ws.rs.core.Response;

public interface SgConnectService {
    Response getBasicAuthentication();
}
