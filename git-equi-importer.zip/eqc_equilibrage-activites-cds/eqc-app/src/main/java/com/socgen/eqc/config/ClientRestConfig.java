package com.socgen.eqc.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import lombok.RequiredArgsConstructor;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.glassfish.jersey.logging.LoggingFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.util.logging.Level;

@Configuration
@RequiredArgsConstructor
public class ClientRestConfig {

	private final SgSigninOAuthClientFilter sgSigninOAuthClientFilter;

	@Bean(name = "restClient")
	public Client restClient() {
		ClientBuilder clientBuilder = ClientBuilder.newBuilder().register(new LoggingFeature(java.util.logging.Logger
				.getLogger("restClient"), Level.INFO, LoggingFeature.Verbosity.PAYLOAD_TEXT, LoggingFeature.DEFAULT_MAX_ENTITY_SIZE))
				.register(new JacksonJaxbJsonProvider()
						.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false))
				.register(sgSigninOAuthClientFilter);
		clientBuilder.property(ClientProperties.CONNECT_TIMEOUT, 2000);
		clientBuilder.property(ClientProperties.READ_TIMEOUT, 25000);

		return clientBuilder.build();
	}
}
