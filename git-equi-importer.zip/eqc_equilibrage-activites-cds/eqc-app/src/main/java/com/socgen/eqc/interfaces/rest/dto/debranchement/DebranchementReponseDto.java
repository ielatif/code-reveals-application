package com.socgen.eqc.interfaces.rest.dto.debranchement;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DebranchementReponseDto {

    private String url;

    public DebranchementReponseDto(String url) {
        this.url = url;
    }
}