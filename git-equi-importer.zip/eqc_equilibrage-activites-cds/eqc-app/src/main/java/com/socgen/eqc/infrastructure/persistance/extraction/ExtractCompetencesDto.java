package com.socgen.eqc.infrastructure.persistance.extraction;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.socgen.eqc.domain.model.TypeActivite;
import com.socgen.eqc.domain.model.Unite;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
@JsonPropertyOrder({ "codeFiliere","filiere","codeUg","ug","codeSt","st","matricule",
        "nomCollaborateur","sousEquipe","dateUpdateProfil","tetePerimetre","famille",
        "activite","typeActivite","niveauExpertise","capaciteTheorique","uniteMesure","dateUpdateCompetence"})
public class ExtractCompetencesDto implements Serializable {


    @JsonProperty("CODE FILIERE")
    private String codeFiliere;

    @JsonProperty("FILIERE")
    private String filiere;

    @JsonProperty("CODE UG")
    private String codeUg;

    @JsonProperty("UG")
    private String ug;

    @JsonProperty("CODE ST")
    private String codeSt;

    @JsonProperty("ST")
    private String st;

    @JsonProperty("MATRICULE")
    private String matricule;

    @JsonProperty("NOM COLLABORATEUR")
    private String nomCollaborateur;

    @JsonProperty("SOUS EQUIPE")
    private String sousEquipe;

    @JsonProperty("DATE MISE A JOUR PROFIL")
    private String dateUpdateProfil;

    @JsonProperty("TETE DE PERIMETRE")
    private String tetePerimetre;

    @JsonProperty("FAMILLE D'ACTIVITE")
    private String famille;

    @JsonProperty("ACTIVITE")
    private String activite;

    @JsonProperty("TYPE D'ACTIVITE")
    private TypeActivite typeActivite;

    @JsonProperty("NIVEAU EXPERTISE")
    private String niveauExpertise;

    @JsonProperty("CAPACITE THEORIQUE")
    private String capaciteTheorique;

    @JsonProperty("UNITE MESURE")
    private String uniteMesure;

    @JsonProperty("DATE DE MISE A JOUR DE LA COMPETENCE")
    private String dateUpdateCompetence;



}
