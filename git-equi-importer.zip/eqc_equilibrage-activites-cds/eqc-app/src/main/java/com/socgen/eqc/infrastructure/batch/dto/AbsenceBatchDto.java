package com.socgen.eqc.infrastructure.batch.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AbsenceBatchDto {

    private String matriculeCollaborateur;

    private LocalDate date;

    private Long pourcentage;

}
