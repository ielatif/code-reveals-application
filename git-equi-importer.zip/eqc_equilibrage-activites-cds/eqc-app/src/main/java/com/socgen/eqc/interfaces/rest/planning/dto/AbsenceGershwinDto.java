package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.domain.model.Renfort;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AbsenceGershwinDto {

    List<AbsenceDto> absences;

    public static AbsenceGershwinDto fromDomain(List<Absence> absences) {
        return AbsenceGershwinDto
            .builder()
            .absences(AbsenceDto.fromDomain(absences))
            .build();
    }

}
