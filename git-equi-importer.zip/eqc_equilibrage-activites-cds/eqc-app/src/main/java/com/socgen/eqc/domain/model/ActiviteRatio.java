package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "ACTIVITE_RATIO")
@Builder
@Data
public class ActiviteRatio implements Serializable {

    private static final long serialVersionUID = 2873150731413526722L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "CODE", nullable = false, unique = true)
    private String code;

    @Column(name = "LIBELLE")
    private String libelle;

    @OneToMany(mappedBy = "activiteRatio", fetch = FetchType.LAZY)
    private Set<ActiviteParams> activites;

    @ManyToOne
    @JoinColumn(name = "ratio_type", nullable = false)
    private RatioType ratioType;

    @Column(name = "CODE_TETE_PERIMETRE", nullable = false)
    private String tetePerimetre;

}
