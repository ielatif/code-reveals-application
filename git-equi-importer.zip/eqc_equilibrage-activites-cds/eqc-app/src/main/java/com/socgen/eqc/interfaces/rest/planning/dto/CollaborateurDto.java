package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.domain.model.Collaborateur;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class CollaborateurDto {

    @NotBlank
    private String prenom;

    @NotBlank
    private String nom;

    @NotBlank
    private String matricule;

    @NotBlank
    private String loginWindows;

    @NotBlank
    private String idRhLocal;

    @Builder.Default
    private Boolean isRenfort = false;

    private LocalDate dateEntree;

    private String lastModifiedProfilDate;

    private Long idAffiliation;

    public static CollaborateurDto fromDomain(Collaborateur collaborateur, boolean renfort) {
        return CollaborateurDto.builder()
                .loginWindows(collaborateur.getLoginWindows())
                .isRenfort(renfort)
                .matricule(collaborateur.getMatricule())
                .nom(collaborateur.getNom())
                .prenom(collaborateur.getPrenom())
                .idRhLocal(collaborateur.getIdRhLocal().isBlank() ? "GL" + collaborateur.getMatricule() : collaborateur.getIdRhLocal())
                .build();
    }

    public static List<CollaborateurDto> fromDomain(List<Collaborateur> collaborateurs, boolean renfort) {
        return collaborateurs.stream()
                .map(collaborateur -> CollaborateurDto.fromDomain(collaborateur, renfort))
                .collect(Collectors.toList());
    }

    public Collaborateur toDomain() {
        return Collaborateur.builder()
                .loginWindows(loginWindows)
                .matricule(matricule)
                .nom(nom)
                .prenom(prenom)
                .idRhLocal(idRhLocal)
                .build();
    }
}
