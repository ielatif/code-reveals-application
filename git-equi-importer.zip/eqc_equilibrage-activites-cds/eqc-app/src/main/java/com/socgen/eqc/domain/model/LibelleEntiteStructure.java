package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity(name = "REF_DATA_LIBELLE_ES")
@Table(name = " REF_DATA_LIBELLE_ES")
public class LibelleEntiteStructure {

	@Id
	@Column(name = "code", nullable = false, unique = true)
	private String code;

	private String libelle;

}
