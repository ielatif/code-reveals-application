package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity(name = "DefaultExpertise")
@Table(name = " default_expertise")
public class DefaultExpertise implements Serializable {

    private static final long serialVersionUID = 2873150734213588987L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "code_activite", nullable = false)
    private ActiviteParams activite;

    @ManyToOne
    @JoinColumn(name = "id_niveau", nullable = false)
    private Niveau niveau;

    @Column(name = "date_debut", nullable = false)
    private LocalDate dateDebut;

    private LocalDate dateFin;
}
