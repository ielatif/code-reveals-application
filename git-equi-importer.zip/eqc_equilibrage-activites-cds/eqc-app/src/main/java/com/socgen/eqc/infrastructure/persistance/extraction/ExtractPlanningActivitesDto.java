package com.socgen.eqc.infrastructure.persistance.extraction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

@Data
@Builder
@JsonPropertyOrder({ "codeFiliere","filiere","codeUg","ug","codeSt","st","date","codeFamille","famille","codeActivite","activite","typeActivite","uniteDeMesure","etp","stockReelementTraite","stockReel","capaciteTheoriqueATraiter","stockATraiterEstime","chargeEnVolume","chargeEnEtp" })
public class ExtractPlanningActivitesDto implements Serializable {


    @JsonProperty("CODE FILIERE")
    private String codeFiliere;

    @JsonProperty("FILIERE")
    private String filiere;

    @JsonProperty("CODE UG")
    private String codeUg;

    @JsonProperty("UG")
    private String ug;

    @JsonProperty("CODE ST")
    private String codeSt;

    @JsonProperty("ST")
    private String st;

    @JsonProperty("DATE")
    private String date;

    @JsonIgnore
    private String codeFamille;

    @JsonProperty("FAMILLE D'ACTIVITE")
    private String famille;

    @JsonIgnore
    private String codeActivite;

    @JsonProperty("ACTIVITE")
    private String activite;

    @JsonIgnore
    private String typeActivite;

    @JsonProperty("UNITE DE MESURE")
    private String uniteDeMesure;

    @JsonProperty("NOMBRE D'ETP")
    private String etp;

    @JsonProperty("STOCK REELLEMENT TRAITE")
    private BigInteger stockReelementTraite;

    @JsonProperty("STOCK REEL")
    private BigInteger stockReel;

    @JsonProperty("CAPACITE A TRAITER THEORIQUE")
    private String capaciteTheoriqueATraiter;

    @JsonProperty("STOCK A TRAITER ESTIME")
    private BigInteger stockATraiterEstime;

    @JsonProperty("CHARGE EN VOLUME")
    private BigInteger chargeEnVolume;

    @JsonProperty("CHARGE EN ETP")
    private String chargeEnEtp;

}
