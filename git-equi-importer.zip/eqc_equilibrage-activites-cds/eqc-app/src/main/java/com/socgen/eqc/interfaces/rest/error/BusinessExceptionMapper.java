package com.socgen.eqc.interfaces.rest.error;

import com.socgen.eqc.application.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
@Slf4j
public class BusinessExceptionMapper implements ExceptionMapper<BusinessException> {

    @Override
    public Response toResponse(BusinessException e) {
        log.error("Exception : {}", e.getMessage(), e);
        return Response.status(e.getHttpStatus().value())
            .entity(ErrorDto.builder().messageFonctionnel(e.getMessageFonctionnel())
                .messageTechnique(ExceptionUtils.getStackTrace(e)).build()).build();
    }
}
