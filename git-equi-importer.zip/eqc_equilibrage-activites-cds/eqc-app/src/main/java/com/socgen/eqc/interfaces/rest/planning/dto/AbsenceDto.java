package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Intervalle;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static com.socgen.eqc.interfaces.rest.planning.dto.AbsenceSource.EQC;
import static com.socgen.eqc.interfaces.rest.planning.dto.AbsenceSource.GERSHWIN;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AbsenceDto {

    private Long id;
    private Intervalle intervalle;
    private LocalDate date;
    private DayOfWeek day;
    private String matricule;
    private AbsenceSource source;

    public static AbsenceDto fromDomain(Absence absence) {
        return AbsenceDto.builder()
		        .id(absence.getId())
		        .intervalle(absence.getIntervalle())
		        .date(absence.getDate())
                .day(absence.getDate().getDayOfWeek())
		        .matricule(absence.getMatriculeCollaborateur())
		        .source(absence.getId() != null ? EQC : GERSHWIN)
		        .build();
    }

    public static List<AbsenceDto> fromDomain(List<Absence> absences) {
        return absences.stream()
		        .map(AbsenceDto::fromDomain)
		        .collect(Collectors.toList());
    }

}
