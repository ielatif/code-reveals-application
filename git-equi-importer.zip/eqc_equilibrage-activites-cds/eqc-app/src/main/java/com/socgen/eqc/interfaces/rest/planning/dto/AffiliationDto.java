package com.socgen.eqc.interfaces.rest.planning.dto;

import com.socgen.eqc.domain.model.Affiliation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AffiliationDto {

    private Long id;

    private String matricule;

    private LocalDate dateEntree;

    private LocalDate dateSortie;

    public static AffiliationDto fromDomain(Affiliation affiliation) {
        if (affiliation == null) {
            return AffiliationDto.builder().build();
        }
        return AffiliationDto.builder().id(affiliation.getId()).dateEntree(affiliation.getDateEntree())
                .matricule(affiliation.getCollaborateur().getMatricule()).dateSortie(affiliation.getDateSortie())
                .build();
    }

    public static List<AffiliationDto> fromDomain(List<Affiliation> affiliations) {
        return affiliations.stream().map(AffiliationDto::fromDomain).collect(Collectors.toList());
    }
}