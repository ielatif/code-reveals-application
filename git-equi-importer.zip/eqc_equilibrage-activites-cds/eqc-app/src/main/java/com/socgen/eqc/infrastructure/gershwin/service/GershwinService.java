package com.socgen.eqc.infrastructure.gershwin.service;

import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Collaborateur;

import java.time.LocalDate;
import java.util.List;

public interface GershwinService {
    List<Absence> findAbsence(Long idEquipe, List<Collaborateur> collaborateurs, LocalDate dateDebut, LocalDate dateFin);
}
