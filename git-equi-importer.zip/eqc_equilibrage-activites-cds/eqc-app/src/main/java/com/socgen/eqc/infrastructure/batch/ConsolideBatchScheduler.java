package com.socgen.eqc.infrastructure.batch;

import com.socgen.eqc.application.exception.BusinessException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

@Component
@AllArgsConstructor
@Slf4j
public class ConsolideBatchScheduler {

    private final JobLauncher jobLauncher;
    private final Job cmBatchJob;

    @Scheduled(cron = "${eqc.batch.config.cron}")
    void schedule() {
        Month currentMonth = LocalDate.now().getMonth();
        Month monthPreviousMonday = LocalDate.now().minusWeeks(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).getMonth();
        if (!currentMonth.equals(monthPreviousMonday)) {
            long epochDay = LocalDate.now().minusMonths(1).toEpochDay();
            JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
                .addLong("date", epochDay).toJobParameters();
            runJob(jobParameters);
        }
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
            .addLong("date", LocalDate.now().toEpochDay()).toJobParameters();
        runJob(jobParameters);
    }

    private void runJob(JobParameters jobParameters) {
        try {
            JobExecution run = jobLauncher.run(cmBatchJob, jobParameters);
            log.info("Launch BatchConsolide whith jobParameters date = {} , JobExecution : {}", jobParameters
                .getParameters().get("date"), run.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
            log.error("BatchConsolide fail jobParameters :{}", jobParameters.getParameters().get("date"));
            throw new BusinessException("Erreur lors du lancement du batch ", e);
        }
    }
}
