package com.socgen.eqc.infrastructure.smbo.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class StockNatureDto {

    private String id;
    @JsonIgnore
    private String codeProcesus;
    private String day;
    private BigInteger codeNature;
    private String libelle;
    private BigInteger stockVeille;
    private BigInteger stockRecu;
    private BigInteger stockTermine;
    private BigInteger stockSupprime;
    private List<StockTacheDto> taches;
}
