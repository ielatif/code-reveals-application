package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ReferentielTacheDto {

    private Long id;
    private String libelle;
    private String code;
}
