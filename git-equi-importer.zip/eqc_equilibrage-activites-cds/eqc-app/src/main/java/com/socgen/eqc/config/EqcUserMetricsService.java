package com.socgen.eqc.config;

import com.socgen.dga.idp.jaxrs.commons.SgUser;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.binder.MeterBinder;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class EqcUserMetricsService implements MeterBinder {

    private static final String UNIQUE_USERS_GAUGE = "users.uniques";
    private final Map<String, SgUser> users = new ConcurrentHashMap<>();
    private final Map<String, Gauge> gauges = new ConcurrentHashMap<>();
    private MeterRegistry registry;
    private final UserInfoCustomTagsExtractor userInfoCustomTagsExtractor;

    public EqcUserMetricsService(UserInfoCustomTagsExtractor userInfoCustomTagsExtractor) {
        this.userInfoCustomTagsExtractor = userInfoCustomTagsExtractor;
    }

    public void registerUser(final SgUser sgUser) {
        String userId = sgUser.getUserId();
        if (!this.users.containsKey(userId)) {
            Tags tags = this.userInfoCustomTagsExtractor.extractTags(sgUser.getServiceCodeGeo(), userId, sgUser.getJob());
            this.users.put(userId, sgUser);
            this.gauges.put(userId, Gauge.builder(UNIQUE_USERS_GAUGE, () -> 1)
                    .tags(tags)
                    .register(this.registry));
        }
    }

    @Override
    public void bindTo(final MeterRegistry registry) {
        this.registry = registry;
    }

    @Scheduled(cron = "${eqc.metrics.reset-cron}")
    public void clear() {
        this.users.clear();
        this.gauges.values().forEach(g -> this.registry.remove(g));
        this.gauges.clear();
    }
}