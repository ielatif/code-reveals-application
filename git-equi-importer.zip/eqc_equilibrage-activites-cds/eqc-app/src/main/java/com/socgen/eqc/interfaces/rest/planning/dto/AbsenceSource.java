package com.socgen.eqc.interfaces.rest.planning.dto;

public enum AbsenceSource {
	EQC, GERSHWIN
}
