package com.socgen.eqc.infrastructure.batch.service;

import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import com.socgen.eqc.infrastructure.batch.dto.AffectationDto;
import com.socgen.eqc.infrastructure.batch.dto.AffectationEqcTotal;
import com.socgen.eqc.infrastructure.batch.utils.UtilsDay;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


public interface CommonService {

    /**
     * Generation d'une liste d'objet AffectationEqcTotal permettant d'associer
     * chaque Activité EQC à une Activité Sumeau (Id et libelle) et calcul de la somme
     * des pourcentages des affectations pour la meme Activité EQC
     *
     * @param affectationByActiviteEqc : liste des affectations regroupés par Activite EQC
     * @param matricule
     * @param stActif
     * @return
     */
    default List<AffectationEqcTotal> buildListAffectationWithCalculTaux(Map<String, List<AffectationDto>> affectationByActiviteEqc, String matricule, Long stActif) {

        return affectationByActiviteEqc.entrySet().stream().map(affByActiv -> {

            Long cumelTauxAffectationByActivite = affByActiv.getValue().stream().filter(Objects::nonNull)
                    .mapToLong(aff -> aff.getPourcentage() != null ? aff.getPourcentage() : 0).reduce(0, Long::sum);

            return buildAffcetationEqcTotal(cumelTauxAffectationByActivite, matricule, affByActiv, stActif);
        }).collect(Collectors.toList());
    }

    /**
     * Build AffectationEqcTotal pour une etape intermédiaire du calcul de Taux
     * @param cumelTauxAffectationByActivite
     * @param matricule
     * @param entryAffec
     * @param stActif
     * @return
     */
    private AffectationEqcTotal buildAffcetationEqcTotal(Long cumelTauxAffectationByActivite, String matricule,
                                                         Map.Entry<String, List<AffectationDto>> entryAffec, Long stActif) {
        return AffectationEqcTotal.builder().cumulTauxAffectationByActivite(cumelTauxAffectationByActivite)
                .stActif(stActif).idActiviteSumeau(entryAffec.getValue().get(0).getIdActiviteSumeau())
                .cdsRattachement(entryAffec.getValue().get(0).getCdsRattachement())
                .ugRattachement(entryAffec.getValue().get(0).getUgRattachement())
                .stRattachement(entryAffec.getValue().get(0).getIdServiceTraitement())
                .sumeauLibelleActivite(entryAffec.getValue().get(0).getLibelleActiviteSumeau()).codeActivite(entryAffec.getKey())
                .matriculeCollaborateur(matricule).build();
    }

    /**
     * Générer la iste des consolideMensuel afin d'etre sauvegarder dans le Base
     *
     * @param listTauxActSumeau
     * @return
     */
    default List<ConsolideMensuel> buildListConsolideMensuel(Map<String, Map<String, List<AffectationEqcTotal>>> listTauxActSumeau,
                                                             Map<String, Double> listPresenceByMatricule, boolean isRenfortInterUg,
                                                             Map<String, Long> mapCumulMensRenfortInterUg, Long date) {

        return listTauxActSumeau.entrySet().stream().map(affByMatriculeAndSumeauAct -> {

            Map<String, List<AffectationEqcTotal>> affBySumeauId = affByMatriculeAndSumeauAct.getValue();
            Long cumulMensuelForAllActivites = getCumulForAllActivite(isRenfortInterUg, mapCumulMensRenfortInterUg, affByMatriculeAndSumeauAct, affBySumeauId);

            return getConsolide(listPresenceByMatricule, isRenfortInterUg, date, affBySumeauId, cumulMensuelForAllActivites);

        }).flatMap(Collection::stream).collect(Collectors.toList());
    }

    /**
     * Récupérer le cumul des taux pour les activités affectées à un collaborateur au sein de la meme equipe
     * et en Renfort Inter Ug
     * @param isRenfortInterUg
     * @param mapCumulMensRenfortInterUg
     * @param affByMatriculeAndSumeauAct
     * @param affBySumeauId
     * @return
     */
    default Long getCumulForAllActivite(boolean isRenfortInterUg, Map<String, Long> mapCumulMensRenfortInterUg,
                                               Map.Entry<String, Map<String, List<AffectationEqcTotal>>> affByMatriculeAndSumeauAct,
                                               Map<String, List<AffectationEqcTotal>> affBySumeauId) {
        Long cumulMensuelForAllActivite = 0L;

        if (!isRenfortInterUg) {
            cumulMensuelForAllActivite = computeCumulMensuelForAllActivite(affBySumeauId.values());
            cumulMensuelForAllActivite += mapCumulMensRenfortInterUg.getOrDefault(affByMatriculeAndSumeauAct.getKey(), 0L);
            mapCumulMensRenfortInterUg.put(affByMatriculeAndSumeauAct.getKey(), cumulMensuelForAllActivite);
        } else {
            cumulMensuelForAllActivite += mapCumulMensRenfortInterUg.getOrDefault(affByMatriculeAndSumeauAct.getKey(), 0L);
        }
        return cumulMensuelForAllActivite;
    }


    private List<ConsolideMensuel> getConsolide(Map<String, Double> listPresenceByMatricule, boolean isRenfortInterUg,
                                                Long date, Map<String, List<AffectationEqcTotal>> affBySumeauId,
                                                Long cumulMensuelForAllActivites) {
        return affBySumeauId.values().stream().map(listAffectationEqcTot -> {

            final Long cumulMensuelForSumeauActivite = listAffectationEqcTot.stream()
                    .mapToLong(affCumul -> affCumul.getCumulTauxAffectationByActivite() != null ? affCumul
                            .getCumulTauxAffectationByActivite() : 0).sum();

            return buildConsolideMensuel(listAffectationEqcTot, cumulMensuelForSumeauActivite,
                    cumulMensuelForAllActivites, listPresenceByMatricule, isRenfortInterUg, date);

        }).collect(Collectors.toList());
    }

    default Long computeCumulMensuelForAllActivite(Collection<List<AffectationEqcTotal>> affectationBySumeau) {
        return affectationBySumeau.stream().flatMap(Collection::stream).collect(Collectors.toList()).stream()
                .mapToLong(affCumul -> affCumul.getCumulTauxAffectationByActivite() != null ? affCumul
                        .getCumulTauxAffectationByActivite() : 0).sum();

    }

    private ConsolideMensuel buildConsolideMensuel(List<AffectationEqcTotal> listAffectationEqcTot,
                                                   Long cumulMensuelForSumeauActivite,
                                                   Long cumulMensuelForAllActivites,
                                                   Map<String, Double> listPresenceByMatricule, boolean isRenfortInterUg, Long date) {
        AffectationEqcTotal affectationEqcTotal = listAffectationEqcTot.get(0);
        return ConsolideMensuel.builder()
                .monthYearConsolide(UtilsDay.getMonthYearTwoDigitFormat(LocalDate.ofEpochDay(date)))
                .matriculeCollaborateur(affectationEqcTotal.getMatriculeCollaborateur())
                .cdsRattachement(affectationEqcTotal.getCdsRattachement())
                .ugRattachement(affectationEqcTotal.getUgRattachement())
                .stActif(affectationEqcTotal.getStActif())
                .stRattachement(affectationEqcTotal.getStRattachement())
                .idActiviteSumeau(affectationEqcTotal.getIdActiviteSumeau())
                .sumeauLibelleActivite(affectationEqcTotal.getSumeauLibelleActivite())
                .tauxActiviteSumeau(BigDecimal.valueOf(getTauxActiviteSumeau(cumulMensuelForSumeauActivite, cumulMensuelForAllActivites))
                        .setScale(0, RoundingMode.HALF_UP))
                .isRenfortInterUg(isRenfortInterUg)
                .joursPresence(listPresenceByMatricule.get(affectationEqcTotal.getMatriculeCollaborateur())).build();
    }

    /**
     * [Somme des taux mensuels des activités EQC correspondant à l’activité SUMEAU] x R
     *  Le coefficient de pondération R est obtenu en effectuant le calcul suivant :
     * R = 100/D
     * @param cumulMensuelForSumeauActivite
     * @param cumulMensuelActivitesInerAndIntraUg
     * @return
     */
    private Double getTauxActiviteSumeau(Long cumulMensuelForSumeauActivite, Long cumulMensuelActivitesInerAndIntraUg) {
        if (cumulMensuelForSumeauActivite == null || cumulMensuelActivitesInerAndIntraUg == null || cumulMensuelActivitesInerAndIntraUg == 0) {
            return 0d;
        }

        return (Double.valueOf(cumulMensuelForSumeauActivite) * 100) / (Double.valueOf(cumulMensuelActivitesInerAndIntraUg));
    }

    /**
     * Fusionner la list des valeurs du meme key dans mapAffectation11,
     * mapAffectation2
     * @param mapAffectation1
     * @param mapAffectation2
     * @param <T>
     * @param <U>
     * @return
     */
    default <T,U> Map<U, List<T>> flatMapWithSameKey(Map<U, List<T>> mapAffectation1,
                                                     Map<U, List<T>> mapAffectation2) {

        Map<U, List<T>> flattenMapAffectation = new HashMap<>(mapAffectation1);

        mapAffectation2.entrySet().stream()
                .forEach(entry -> {
                    List<T> value = entry.getValue();
                    U key = entry.getKey();
                    if (flattenMapAffectation.containsKey(key)) {
                        flattenMapAffectation.get(key).addAll(value);
                    } else {
                        flattenMapAffectation.put(key, value);
                    }
                });

        return flattenMapAffectation;
    }

    default Map<String, Map<String, List<AffectationEqcTotal>>> regroupAffectationByMatriculeAndSumeauActivite(Map<String, List<AffectationEqcTotal>> affecEqcTotByMatricule) {
        return affecEqcTotByMatricule.entrySet().stream().collect(Collectors
                .toMap(Map.Entry::getKey, affEqcTot -> affEqcTot.getValue().stream()
                        .filter(aff -> aff.getIdActiviteSumeau() != null)
                        .collect(Collectors.groupingBy(AffectationEqcTotal::getIdActiviteSumeau))));
    }

    default Map<String, List<AffectationEqcTotal>> buildAffecEqcTotal(Map<String, List<AffectationDto>> mapAffecByMatricule, Long stActif) {

       return mapAffecByMatricule.entrySet()
                .stream().collect(Collectors.toMap(Map.Entry::getKey, affectByMatricule -> {

            Map<String, List<AffectationDto>> affectationByActiviteEqc = affectByMatricule
                    .getValue().stream()
                    .collect(Collectors.groupingBy(AffectationDto::getCodeActivite));

            return buildListAffectationWithCalculTaux(affectationByActiviteEqc, affectByMatricule.getKey(), stActif);

        }));
    }
}
