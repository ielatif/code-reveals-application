package com.socgen.eqc.infrastructure.ghabi;

import com.socgen.eqc.application.exception.GhabiException;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionDto;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionResponseDto;

public interface GhabiClient {

    GhabiExtensionResponseDto createExtension(GhabiExtensionDto ghabiExtensionDto) throws GhabiException;

    void deleteExtension(Long idExtensionPerimetre);

    GhabiExtensionResponseDto updateExtension(GhabiExtensionDto ghabiExtensionDto);

    GhabiExtensionResponseDto getExtensionDetail(Long id);
}
