package com.socgen.eqc.infrastructure.entite.structure.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EntiteStructure {

    @JsonIgnore
    EntiteStructure parent;
}
