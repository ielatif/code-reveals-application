package com.socgen.eqc.config;

import io.micrometer.core.instrument.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.metrics.web.servlet.WebMvcTagsContributor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RequiredArgsConstructor
public class UserInfoWebMvcTagsContributor implements WebMvcTagsContributor {

    private final UserInfoCustomTagsExtractor userInfoCustomTagsExtractor;

    @Override
    public Iterable<Tag> getTags(HttpServletRequest request, HttpServletResponse response, Object handler,
                                 Throwable exception) {
        String authorization = request.getHeader("Authorization");
        return this.userInfoCustomTagsExtractor.extractTagsFromAuthHeader(authorization);
    }

    @Override
    public Iterable<Tag> getLongRequestTags(HttpServletRequest request, Object handler) {
        return getTags(request, null, handler, null);
    }
}
