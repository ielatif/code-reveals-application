package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AbsenceService;
import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.application.CollaborateurService;
import com.socgen.eqc.application.RenfortService;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.infrastructure.people.client.PeopleClient;
import com.socgen.eqc.infrastructure.people.dto.ListPeopleDto;
import com.socgen.eqc.infrastructure.people.dto.PeopleDto;
import com.socgen.eqc.infrastructure.persistance.CollaborateurRepository;
import com.socgen.eqc.infrastructure.persistance.CompetenceRepository;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.persistence.Tuple;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Collections.singletonList;
import static java.util.Objects.nonNull;
import static org.springframework.util.ObjectUtils.isEmpty;

@Service
@AllArgsConstructor
@Slf4j
public class CollaborateurServiceImpl implements CollaborateurService {

    private final PeopleClient peopleClient;
    private final AffiliationService affiliationService;
    private final CollaborateurRepository collaborateurRepository;
    private final AffectationService affectationService;
    private final RenfortService renfortService;
    private final AbsenceService absenceService;
    private final CompetenceRepository competenceRepository;

    @Override
    public List<CollaborateurDto> findByMatricules(@NonNull String... matricules) {
        var peopleByListMatricule = peopleClient.findPeopleByListMatricule(Arrays.asList(matricules));
        return buildCollaborateurDtosFromPeopleResponse(peopleByListMatricule);
    }

    @Override
    public List<CollaborateurDto> findNewCollaborateurs(@NonNull Long idEquipe) {
        var listeMatricule = affiliationService.findByEquipeAndDate(idEquipe, LocalDate.now()).stream()
                .map(affiliation -> affiliation.getCollaborateur().getMatricule()).collect(Collectors.toList());
        var peopleByListMatricule = peopleClient.findPeopleByListCodeSt(singletonList(idEquipe));
        var collaborateurs = buildCollaborateurDtosFromPeopleResponse(peopleByListMatricule);
        if (!isEmpty(listeMatricule)) {
            return collaborateurs.stream().filter(collaborateurDto -> listeMatricule.stream()
                    .noneMatch(collaborateurDto.getMatricule()::equalsIgnoreCase)).collect(Collectors.toList());
        }
        return collaborateurs;
    }

    @Override
    public List<Collaborateur> findByPlanningSearchDto(PlanningSearchDto planningSearchDto) {
        return affiliationService.findByPlanningSearchDto(planningSearchDto).stream().map(Affiliation::getCollaborateur)
                .collect(Collectors.toList());
    }

    @Override
    public Collaborateur save(CollaborateurDto dto) {
        return collaborateurRepository.save(dto.toDomain());
    }

    private String getIdRhLocal(PeopleDto peopleDto) {
        if (isEmpty(peopleDto.getIdRhLocal())) {
            return "GL".concat(peopleDto.getIdCnxRtfe().toUpperCase());
        }
        return peopleDto.getIdRhLocal().toUpperCase();
    }

    private List<CollaborateurDto> buildCollaborateurDtosFromPeopleResponse(ListPeopleDto peopleByListMatricule) {

        if (peopleByListMatricule != null && !isEmpty(peopleByListMatricule.getDatas())) {
            return peopleByListMatricule.getDatas().stream()
                    .filter(peopleDto -> nonNull(peopleDto.getIdCnxRtfe()))
                    .map(peopleDto -> CollaborateurDto.builder()
                            .matricule(peopleDto.getIdCnxRtfe().toLowerCase())
                            .loginWindows(peopleDto.getIdCnxRtfe().toLowerCase())
                            .nom(peopleDto.getNom())
                            .prenom(peopleDto.getPrenom())
                            .idRhLocal(getIdRhLocal(peopleDto))
                            .build())
                    .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    @Override
    public List<CollaborateurDto> getCollaborateursByMatriculeFromEqc(List<String> matricules) {
        return CollaborateurDto.fromDomain(collaborateurRepository.findByMatriculeIn(matricules), false);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void remove(String matricule) {
        Optional<Affiliation> optionalAffiliation = affiliationService.findLastByMatricule(matricule);
        if (optionalAffiliation.isPresent()) {
            List<Renfort> renfortList = renfortService.findByMatricule(matricule);
            affectationService.removeAll(optionalAffiliation.get());
            affectationService.removeAll(renfortList);
            renfortService.removeAll(matricule, renfortList);
            affiliationService.remove(matricule);
            absenceService.removeAll(matricule);
        }
    }

    @Override
    public List<CollaborateurDto> findCollaborateurs(Long codeServiceTraitement) {

        List<Affiliation> affiliations = affiliationService
                .findByEquipeAndDate(codeServiceTraitement, LocalDate.now()).stream()
                .filter(affiliation -> affiliation.getDateSortie() == null).collect(Collectors.toList());

        if (CollectionUtils.isEmpty(affiliations)) {
            return new ArrayList<>();
        }

        List<Tuple> tuples = competenceRepository.findLastModifiedDateByMatricules(affiliations.stream().map(affiliation -> affiliation.getCollaborateur().getMatricule()).collect(Collectors.toList()));

        Map<String, String> competencesTuple = tuples.stream().collect(
                Collectors.toMap(
                        tuple -> tuple.get("matricule") != null ? tuple.get("matricule").toString() : "",
                        tuple -> tuple.get("lastModifiedDate") != null ? tuple.get("lastModifiedDate").toString() : "")
        );
        return affiliations.stream().map(affiliation -> {
            CollaborateurDto collaborateurDto = CollaborateurDto
                    .fromDomain(affiliation.getCollaborateur(), false);
            collaborateurDto.setLastModifiedProfilDate(competencesTuple.get(affiliation.getCollaborateur().getMatricule()));
            collaborateurDto.setDateEntree(affiliation.getDateEntree());
            collaborateurDto.setIdAffiliation(affiliation.getId());
            return collaborateurDto;
        }).collect(Collectors.toList());
    }

}
