package com.socgen.eqc.infrastructure.persistance.extraction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder
@JsonPropertyOrder({ "codeFiliere","filiere","codeUg","ug","codeSt","st","matricule","nomCollaborateur","sousEquipe","dateAffectation","familleCode","famille","activite","activiteCode","etp","commentairePrincipal","renfort","codeFiliereAidante","filiereAidante","codeUgAidante","ugAidante","codeStAidant","stAidant","codeFiliereAidee","filiereAidee","codeUgAidee","ugAidee","codeStAide","stAide" })
public class ExtractPlanningCollabDto implements Serializable {

    @JsonProperty("CODE FILIERE")
    private String codeFiliere;

    @JsonProperty("FILIERE")
    private String filiere;

    @JsonProperty("CODE UG")
    private String codeUg;

    @JsonProperty("UG")
    private String ug;

    @JsonProperty("CODE ST")
    private String codeSt;

    @JsonProperty("ST")
    private String st;

    @JsonProperty("MATRICULE")
    private String matricule;

    @JsonProperty("NOM COLLABORATEUR")
    private String nomCollaborateur;

    @JsonProperty("SOUS EQUIPE")
    private String sousEquipe;

    @JsonProperty("DATE AFFECTATION")
    private String dateAffectation;

    @JsonIgnore
    private String familleCode;

    @JsonProperty("FAMILLE D'ACTIVITE")
    private String famille;

    @JsonProperty("ACTIVITE")
    private String activite;

    @JsonIgnore
    private String activiteCode;

    @JsonProperty("ETP")
    private String etp;

    @JsonProperty("COMMENTAIRE PRINCIPAL")
    private String commentairePrincipal;

    @JsonProperty("RENFORT")
    private String renfort;

    @JsonProperty("CODE FILIERE AIDANTE")
    private String codeFiliereAidante;

    @JsonProperty("FILIERE AIDANTE")
    private String filiereAidante;

    @JsonProperty("CODE UG AIDANTE")
    private String codeUgAidante;

    @JsonProperty("UG AIDANTE")
    private String ugAidante;

    @JsonProperty("CODE ST AIDANT")
    private String codeStAidant;

    @JsonProperty("ST AIDANT")
    private String stAidant;

    @JsonProperty("CODE FILIERE AIDEE")
    private String codeFiliereAidee;

    @JsonProperty("FILIERE AIDEE")
    private String filiereAidee;

    @JsonProperty("CODE UG AIDEE")
    private String codeUgAidee;

    @JsonProperty("UG AIDEE")
    private String ugAidee;

    @JsonProperty("CODE ST AIDE")
    private String codeStAide;

    @JsonProperty("ST AIDE")
    private String stAide;









}
