package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ExpertiseInputDto implements Serializable {

    private static final long serialVersionUID = 6777000151412466911L;

    private Long id;

    private long idNiveau;

    private Float nombreDossier;

    private Boolean isDefault;
}
