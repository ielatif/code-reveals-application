package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.Competence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.Tuple;
import java.util.List;


public interface CompetenceRepository extends JpaRepository<Competence, Long> {

    @Query(value = "SELECT c.matricule as matricule, max(c.last_modified_date) as lastModifiedDate FROM competence c WHERE matricule in (:matricules) group by matricule", nativeQuery = true)
    List<Tuple> findLastModifiedDateByMatricules(@Param("matricules") List<String> matricules);
    List<Competence> findByCollaborateurMatricule(String matricule);
    List<Competence> findByCollaborateurMatriculeIn(List<String> matricule);
    List<Competence> findByCollaborateurMatriculeInAndExpertiseActiviteCodeIn(List<String> matricule, List<String> codesActivtes);

}
