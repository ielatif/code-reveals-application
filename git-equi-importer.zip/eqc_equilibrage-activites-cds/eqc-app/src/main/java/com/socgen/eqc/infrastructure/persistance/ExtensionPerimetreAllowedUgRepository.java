package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.ExtensionPerimetreAllowedUg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExtensionPerimetreAllowedUgRepository extends JpaRepository<ExtensionPerimetreAllowedUg, String> {
}
