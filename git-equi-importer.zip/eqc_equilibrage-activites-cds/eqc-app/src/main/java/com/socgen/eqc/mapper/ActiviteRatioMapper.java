package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.ActiviteRatio;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteRatioDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring",
        uses = {RatioTypeMapper.class})
public interface ActiviteRatioMapper {

     ActiviteRatioDto activiteRatioToActiviteRatioDto(ActiviteRatio activiteRatio);

}
