package com.socgen.eqc.config;

import lombok.RequiredArgsConstructor;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.logging.LoggingFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.util.logging.Level;

@Configuration
@RequiredArgsConstructor
public class ClientSgConnectConfig {

    private final ApplicationProperties applicationProperties;

    @Bean(name = "sgConnect")
    public Client sgConnectClient() {

        ClientBuilder clientBuilder = ClientBuilder.newBuilder()
                .register(new LoggingFeature(java.util.logging.Logger
                        .getLogger("sgConnectClient"), Level.INFO, LoggingFeature.Verbosity.PAYLOAD_TEXT, LoggingFeature.DEFAULT_MAX_ENTITY_SIZE))
                .register(getBasicAuthorization());
        clientBuilder.property(ClientProperties.CONNECT_TIMEOUT, 2000);
        clientBuilder.property(ClientProperties.READ_TIMEOUT, 25000);

        return clientBuilder.build();
    }

    private HttpAuthenticationFeature getBasicAuthorization() {
        return HttpAuthenticationFeature.basic(applicationProperties.getSgConnect().getUsername(), applicationProperties.getSgConnect().getPassword());
    }
}
