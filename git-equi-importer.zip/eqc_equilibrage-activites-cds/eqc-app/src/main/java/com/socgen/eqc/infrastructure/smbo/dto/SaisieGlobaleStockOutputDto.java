package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SaisieGlobaleStockOutputDto implements Serializable {

    private Long processusId;

    private String processusLibelle;

    private String processusCode;

    private String processusInformations;

    private Long stockVeille;

    private Long totalStockRecus;

    private Long myStockRecus;

    private Long totalStockTermines;

    private Long myStockTermines;

    private Long stockRestant;

    private LocalDate dateSaisie;

}
