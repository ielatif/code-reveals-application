package com.socgen.eqc.infrastructure.debranchement;

import com.socgen.eqc.interfaces.rest.dto.debranchement.DebranchementDto;
import com.socgen.eqc.interfaces.rest.dto.debranchement.DebranchementReponseDto;

public interface DebranchementService {

    DebranchementReponseDto getRedirectUrl(DebranchementDto debranchementDto);
}
