package com.socgen.eqc.infrastructure.entite.structure.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.JsonObject;
import lombok.*;

import java.io.Serializable;
import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CentreService extends EntiteStructure implements Serializable {

    private static final long serialVersionUID = 1971930484239650828L;

    @JsonProperty("id")
    private String id;
    @JsonProperty("libelle")
    private String libelle;
    private String ville;
    @JsonProperty("ugs")
    private List<UniteGestion> uniteGestions;

    @JsonProperty("tprs")
    @Setter(AccessLevel.NONE)
    @Getter(AccessLevel.NONE)
    private Object teteDePerimetres;

    private boolean filiere;

    @JsonRawValue
    public String getTeteDePerimetres() {
        // default raw value: null or "[]"
        return teteDePerimetres == null ? null : teteDePerimetres.toString();
    }

    public void setTeteDePerimetres(JsonNode node) {
        this.teteDePerimetres = node;
    }
}
