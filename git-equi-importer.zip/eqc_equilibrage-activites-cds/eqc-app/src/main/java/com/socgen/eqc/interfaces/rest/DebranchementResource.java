package com.socgen.eqc.interfaces.rest;


import com.socgen.eqc.infrastructure.debranchement.DebranchementService;
import com.socgen.eqc.interfaces.rest.dto.debranchement.DebranchementDto;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/debranchement")
@Api(value = "debranchement")
public class DebranchementResource {
    @Autowired
    private DebranchementService debranchementService;

    @GET
    public Response getUrlRedirect(@BeanParam DebranchementDto debranchementDto){
        return Response.ok(debranchementService.getRedirectUrl(debranchementDto)).build();
    }
}
