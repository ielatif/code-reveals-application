package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.SaisieGlobaleService;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleInputDto;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleOutputDto;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleStockOutputDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
@Slf4j
public class SaisieGlobaleServiceImpl implements SaisieGlobaleService {

    private final SmboClient smboClient;

    @Override
    public List<SaisieGlobaleStockOutputDto> getIndicateurs(List<Long> tetePerimetres, String codeSt, SgUserPrincipal sgUserPrincipal) {
        return smboClient.getSaisieGlobaleIndicateurs(tetePerimetres, codeSt, sgUserPrincipal.getCurrentUser().getUserId());
    }

    @Override
    public SaisieGlobaleOutputDto addStock(SaisieGlobaleInputDto saisieGlobaleInputDto) {
        return smboClient.addStockSaisieGlobale(saisieGlobaleInputDto);

    }
}
