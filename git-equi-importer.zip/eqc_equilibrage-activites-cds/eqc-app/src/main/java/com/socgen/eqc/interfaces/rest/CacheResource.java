package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.config.CacheClearerScheduler;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Path("/cache")
@Api(value = "cache")
public class CacheResource {

    @Autowired
    private CacheClearerScheduler cacheClearerScheduler;

    @DELETE
    @Path("{cacheName}")
    public Response clearCacheByName(@PathParam("cacheName") String cacheName) {
        log.info("Réinitialisation du cahe {} ", cacheName);
        cacheClearerScheduler.evictCacheByName(cacheName);
        return Response.noContent().build();
    }
}
