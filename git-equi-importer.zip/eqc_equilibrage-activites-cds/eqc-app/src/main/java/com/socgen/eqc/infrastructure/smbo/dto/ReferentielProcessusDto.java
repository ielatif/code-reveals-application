package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ReferentielProcessusDto {

    private Long id;
    private String code;
    private String libelle;
    private Source source;
    private LocalDate dateCreation;
    private LocalDate dateDerniereMaj;
    private LocalDate dateDesactivation;
    private List<ReferentielTacheDto> taches;
    private List<NatureDto> natures;
    private String informations;
}
