package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.FamilleService;
import com.socgen.eqc.infrastructure.smbo.dto.RefFamilleDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/familles")
@Api(value = "familles")
public class FamilleResource {

    @Autowired
    private FamilleService familleService;


    @GET
    @ApiOperation(value = "Récupération des Famille", notes = "Récupération de toutes les familles du référentiel")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les familles sont bien récupérées")
    })
    public Response getAll() {
        return Response.ok(familleService.getAll()).build();
    }

    @POST
    @ApiOperation(value = "Créer une famille", notes = "Création d'une famille")
    @ApiResponses({
            @ApiResponse(code = 201, message = "La famille est bien créé"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response createFamille(@Valid RefFamilleDto familleDto) {
        return Response.ok(familleService.saveFamille(familleDto)).build();
    }

    @PUT
    @Path("/{code}")
    @ApiOperation(value = "Mettre à jour une famille", notes = "Mise à jour d'une famille")
    @ApiResponses({
            @ApiResponse(code = 201, message = "La famille est bien mise à jour"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response updateFamille(@Valid RefFamilleDto familleDto, @NotBlank @PathParam("code") String code) {
        familleDto.setCode(code);
        return Response.ok(familleService.saveFamille(familleDto)).build();
    }

    @PUT
    @ApiOperation(value = "Mettre à jour d'une liste de famille", notes = "Mise à jour d'une liste de famille")
    @ApiResponses({
            @ApiResponse(code = 201, message = "Les familles ont été bien mise à jour"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response updateFamille(@Valid List<RefFamilleDto> familleDto) {
        return Response.ok(familleService.saveFamille(familleDto)).build();
    }

    @Path("/{code}/activites")
    public Class<ActiviteResource> activiteResource() {
        return ActiviteResource.class;
    }

}
