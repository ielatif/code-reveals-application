package com.socgen.eqc.infrastructure.people.client;

import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.infrastructure.people.dto.ListPeopleDto;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static org.springframework.util.CollectionUtils.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class PeopleClientImpl implements PeopleClient {

    private final Client restClient;
    private final ApplicationProperties applicationProperties;

    @Override
    @Cacheable(value = EqcCacheConfig.CACHE_PEOPLE_NAME)
    public ListPeopleDto findPeopleByListMatricule(@NonNull List<String> matricules) {
        return isEmpty(matricules) ? new ListPeopleDto() : findPeople(Collections.emptyList(), matricules);
    }

    @Override
    @Cacheable(value = EqcCacheConfig.CACHE_PEOPLE_NAME)
    public ListPeopleDto findPeopleByListCodeSt(@NonNull List<Long> codesSt) {
        return isEmpty(codesSt) ? new ListPeopleDto() : findPeople(codesSt, Collections.emptyList());
    }

	@Override
    @Cacheable(value = EqcCacheConfig.CACHE_PEOPLE_NAME)
    public ListPeopleDto findPeople(@NonNull List<Long> codesSt, @NonNull List<String> matricules) {
        String codesGeoQuery = codesSt.stream().map(Object::toString).collect(Collectors.joining(","));
        String matriculesQuery = String.join(",", matricules);
        Supplier<Response> responseSupplier = () -> restClient.target(applicationProperties.getPeople().getServerUrl())
                .path("peoples").queryParam("matricules", matriculesQuery).queryParam("codes-geo", codesGeoQuery)
                .request(MediaType.APPLICATION_JSON).get();

        Response response = handleExceptions(responseSupplier);
        return response.readEntity(ListPeopleDto.class);
    }

    private Response handleExceptions(Supplier<Response> responseSupplier) {
        Response response = responseSupplier.get();
        if (Response.Status.Family.SUCCESSFUL == response.getStatusInfo().getFamily()) {
            log.info("Appel API People ok, code: {}", response.getStatus());
        } else {
            log.error("Erreur lors de la recuperation des collaborateurs Http_status : {}  body : {} ", response
                    .getStatus(), response.readEntity(String.class));
            throw new BusinessException("Erreur lors de la recuperation des collaborateurs");
        }
        return response;
    }
}
