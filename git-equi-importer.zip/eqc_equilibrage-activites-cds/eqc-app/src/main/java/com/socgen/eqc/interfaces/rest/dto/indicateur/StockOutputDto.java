package com.socgen.eqc.interfaces.rest.dto.indicateur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class StockOutputDto {

    private String day;
    private BigInteger stockTacheTraiter = BigInteger.ZERO;
    private BigInteger stockDossierTraiter = BigInteger.ZERO;
    private BigInteger stockTacheTermine = BigInteger.ZERO;
    private BigInteger stockDossierTermine = BigInteger.ZERO;

}
