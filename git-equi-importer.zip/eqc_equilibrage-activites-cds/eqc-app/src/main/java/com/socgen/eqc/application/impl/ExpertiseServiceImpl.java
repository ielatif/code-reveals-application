package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.ExpertiseService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.domain.model.DefaultExpertise;
import com.socgen.eqc.domain.model.Expertise;
import com.socgen.eqc.domain.model.Niveau;
import com.socgen.eqc.infrastructure.persistance.DefaultExpertiseRepository;
import com.socgen.eqc.infrastructure.persistance.ExpertiseRepository;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ExpertiseDto;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Service;

import javax.persistence.Tuple;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ExpertiseServiceImpl implements ExpertiseService {

    private final ExpertiseRepository expertiseRepository;

    private final DefaultExpertiseRepository defaultExpertiseRepository;

    @Override
    public List<Expertise> getCommonExpertise() {
        return expertiseRepository.findAll();
    }

    @Override
    public List<Expertise> findByCodesActivites(List<String> codesActivites) {
        return expertiseRepository.findByActiviteCodeIn(codesActivites);
    }

    @Override
    public Expertise getExpertiseByActiviteAndNiveau(String codeActivite, Long idNiveau) {
        return expertiseRepository.findByActiviteCodeAndNiveauId(codeActivite, idNiveau);
    }

    @Override
    public Set<Expertise> getExpertiseByActivite(String codeActivite) {
        return expertiseRepository.findByActiviteCode(codeActivite);
    }

    @Override
    public List<Tuple> getExpertiseByActivites(Set<String> activites) {
        return expertiseRepository.findExpertiseByActivites(activites);
    }


    @Override
    public List<Expertise> findByCodeTetePerimetre(@NonNull String codeTetePerimetre) {
        return Collections.emptyList();
    }

    @Override
    public  Set<DefaultExpertise> updateDefaultExpertise(String codeActivite, List<ExpertiseDto> expertiseDto) {

        DefaultExpertise defaultExpertise = defaultExpertiseRepository.findByActiviteCodeAndDateFinIsNull(codeActivite)
                .orElseThrow(() -> new BusinessException("Expertise par defaut non trouvée"));

        Optional<ExpertiseDto> modifiedExpertise = expertiseDto.stream()
                .filter(expertiseInputDto -> BooleanUtils.isTrue(expertiseInputDto.getIsDefault()))
                .findFirst();
        if (modifiedExpertise.isPresent()) {

            ExpertiseDto defaultExpertiseToUpdate = modifiedExpertise.get();

            if (!defaultExpertise.getNiveau().getId().equals(defaultExpertiseToUpdate.getNiveau().getId())) {
                defaultExpertise.setDateFin(LocalDate.now());
                defaultExpertiseRepository.save(defaultExpertise);

                //Création de l'historique pour le niveau d'expertise par defaut
                defaultExpertiseRepository.save(DefaultExpertise.builder()
                        .activite(defaultExpertise.getActivite())
                        .dateDebut(LocalDate.now())
                        .niveau(Niveau.builder().id(defaultExpertiseToUpdate.getNiveau().getId()).build())
                        .build());
            }
        }
        return defaultExpertiseRepository.findByActiviteCode(codeActivite);
    }

}
