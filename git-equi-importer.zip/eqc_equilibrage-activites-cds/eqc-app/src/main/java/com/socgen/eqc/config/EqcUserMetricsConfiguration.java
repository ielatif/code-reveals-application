package com.socgen.eqc.config;

import com.socgen.digital.agence.metric.config.MetricsProperties;
import com.socgen.eqc.infrastructure.entite.structure.EntiteStructureService;
import lombok.RequiredArgsConstructor;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.Optional;

@Configuration
@ConditionalOnProperty(
        name = {"metrics.user.enabled"},
        havingValue = "true"
)
@RequiredArgsConstructor
public class EqcUserMetricsConfiguration {

    private final ResourceConfig resourceConfig;
    private final MetricsProperties metricProperties;
    private final EntiteStructureService entiteStructureService;
    private EqcUserMetricsService eqcUserMetricsService;

    @Bean
    EqcUserMetricsService eqcUserMetricsService() {
        return this.eqcUserMetricsService;
    }

    @Bean
    UserInfoJerseyTagsProvider userInfoJerseyTagsProvider() {
        return new UserInfoJerseyTagsProvider(userInfoCustomTagsExtractor());
    }

    @Bean
    UserInfoWebMvcTagsContributor userInfoWebMvcTagsContributor() {
        return new UserInfoWebMvcTagsContributor(userInfoCustomTagsExtractor());
    }

    @Bean
    UserInfoCustomTagsExtractor userInfoCustomTagsExtractor() {
        return new UserInfoCustomTagsExtractor(entiteStructureService);
    }

    @PostConstruct
    private void registerEqcUserMetricsClientFilter() {
        this.eqcUserMetricsService = new EqcUserMetricsService(new UserInfoCustomTagsExtractor(entiteStructureService));
        EqcUserMetricsContainerFilter var1 = new EqcUserMetricsContainerFilter(Optional.of(this.eqcUserMetricsService), this.metricProperties);
        this.resourceConfig.register(var1);
    }
}
