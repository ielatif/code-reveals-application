package com.socgen.eqc.infrastructure.debranchement;

public enum DebranchementTarget {
    FLG
}
