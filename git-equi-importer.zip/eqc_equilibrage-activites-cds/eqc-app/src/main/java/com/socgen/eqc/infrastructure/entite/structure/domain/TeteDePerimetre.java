package com.socgen.eqc.infrastructure.entite.structure.domain;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TeteDePerimetre implements Serializable {

    private static final long serialVersionUID = 2656337388014839887L;

    public static final String LIBELLE_TPR_NON_DEFINIE = "TPR non définie";
    public static final String ID_TPR_NON_DEFINIE = "0";

    @JsonProperty("id")
    private String id;

    @JsonProperty("libelle")
    private String libelle;

    private Boolean active;

    @JsonProperty("ugs")
    private List<UniteGestion> uniteGestions;
}
