package com.socgen.eqc.infrastructure.entite.structure;

import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.EntiteStructure;
import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;

import java.util.List;
import java.util.Map;

public interface EntiteStructureService {

    List<CentreService> getEntiteStructureFromRes();

    List<CentreService> reworkListCentreService(List<CentreService> centreServiceList, Map<String, TetePerimetre> parametreTetePeri);

    Map<String, EntiteStructure> getEntiteStructureByCodeMap();
}
