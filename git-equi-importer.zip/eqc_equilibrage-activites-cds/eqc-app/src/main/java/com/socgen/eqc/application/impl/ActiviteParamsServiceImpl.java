package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.ActiviteParamsService;
import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.ExpertiseService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.domain.model.DefaultExpertise;
import com.socgen.eqc.domain.model.Niveau;
import com.socgen.eqc.infrastructure.persistance.ActiviteRepository;
import com.socgen.eqc.interfaces.rest.dto.ActiviteOrdreDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteParamsDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ExpertiseDto;
import com.socgen.eqc.mapper.ActiviteParamsMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ActiviteParamsServiceImpl implements ActiviteParamsService {

    public static final String EXPERTISE_PAR_DEFAUT_NON_TROUVEE = "Expertise par defaut non trouvée";
    private final ActiviteRepository activiteRepository;
    private final ActiviteParamsMapper activiteParamsMapper;
    private final ExpertiseService expertiseService;
    private final AffectationService affectationService;

    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = EqcCacheConfig.CACHE_ACTIVITES_NAME)
    public List<ActiviteParamsDto> findAll() {
        return activiteParamsMapper.toDto(activiteRepository.findAll());
    }

    @Override
    @CacheEvict(value = {EqcCacheConfig.CACHE_ACTIVITES_NAME, EqcCacheConfig.CACHE_FAMILLE_NAME}, allEntries = true)
    public ActiviteParamsDto create(ActiviteParamsDto activiteParamsDto) {
        ExpertiseDto defaultExpertise = activiteParamsDto.getExpertises().stream().
                filter(ExpertiseDto::getIsDefault).findAny().orElseThrow(() -> new BusinessException(EXPERTISE_PAR_DEFAUT_NON_TROUVEE));
        ActiviteParams activite = activiteParamsMapper.toDomain(activiteParamsDto);
        activite.getExpertises().forEach(expertise -> expertise.setActivite(activite));
        activite.getDefaultExpertises().add(DefaultExpertise.builder()
                .activite(activite)
                .dateDebut(LocalDate.now())
                .niveau(Niveau.builder().id(defaultExpertise.getNiveau().getId()).build())
                .build());
        return activiteParamsMapper.toDto(activiteRepository.save(activite));
    }

    @Override
    @CacheEvict(value = {EqcCacheConfig.CACHE_ACTIVITES_NAME, EqcCacheConfig.CACHE_FAMILLE_NAME}, allEntries = true)
    public ActiviteParamsDto update(ActiviteParamsDto activiteParamsDto) {
        Assert.notNull(activiteParamsDto.getCode(), "code Activite should not be null");
        ActiviteParams activite = activiteParamsMapper.toDomain(activiteParamsDto);
        activite.getExpertises().forEach(expertise -> expertise.setActivite(activite));
        Set<DefaultExpertise> defaultExpertises = expertiseService.updateDefaultExpertise(activite.getCode(), List.copyOf(activiteParamsDto.getExpertises()));
        activite.setDefaultExpertises(defaultExpertises);
        ActiviteParams activiteParams = activiteRepository.save(activite);
        affectationService.updateCapaciteTheorique(activiteParams.getExpertises());
        return activiteParamsMapper.toDto(activiteParams);
    }


    @Override
    @Transactional
    @CacheEvict(value = EqcCacheConfig.CACHE_ACTIVITES_NAME, allEntries = true)
    public void updateOrdreActivites(List<ActiviteOrdreDto> activiteOrdreDtos) {
        List<ActiviteParams> activites = activiteOrdreDtos.stream().map(activiteOrdreDto -> {
            ActiviteParams activite = activiteRepository.findByCode(activiteOrdreDto.getCode());
            activite.setOrdre(activiteOrdreDto.getOrdre());
            return activite;
        }).collect(Collectors.toList());
        activiteRepository.saveAll(activites);
    }
}
