package com.socgen.eqc.infrastructure.entite.structure;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.config.EqcProperties;
import com.socgen.eqc.domain.model.EsFiliereToExclude;
import com.socgen.eqc.domain.model.LibelleEntiteStructure;
import com.socgen.eqc.domain.model.ParamsFictionalTetePerim;
import com.socgen.eqc.infrastructure.entite.structure.domain.*;
import com.socgen.eqc.infrastructure.persistance.*;
import com.socgen.eqc.infrastructure.res.ResClient;
import com.socgen.eqc.infrastructure.res.dto.TeteDePerimetreDto;
import com.socgen.eqc.infrastructure.smbo.dto.RefActiviteDto;
import com.socgen.eqc.interfaces.rest.error.ExternServiceException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.socgen.eqc.infrastructure.entite.structure.domain.TeteDePerimetre.ID_TPR_NON_DEFINIE;
import static com.socgen.eqc.infrastructure.entite.structure.domain.TeteDePerimetre.LIBELLE_TPR_NON_DEFINIE;
import static java.util.stream.Collectors.toMap;

@Service
@Slf4j
@RequiredArgsConstructor
public class EntiteStructureServiceImpl implements EntiteStructureService, InitializingBean {

    private final ResClient resClient;
    private final EqcProperties eqcProperties;
    private final LibelleEntiteStructureRepository libelleEntiteStructureRepository;
    private final EsFiliereToExcludeRepository esFiliereToExcludeRepository;
    private final ParamsFictionalTetePerimRepository paramsFictionalTetePerimRepository;
    private final TetePerimetreRepository tetePerimetreRepository;
    private final Gson gson = new Gson();


    private List<String> cdsExclus;
    private List<String> filieresExclus;
    private List<String> ugFiliereExclus;
    private List<String> stFiliereExclus;
    private List<String> sigleExclus;
    private Map<String, String> libellesEntiteStructureMap;
    private  List<String> filieres;

    /**
     * Récupération des entites des structure en faisiant appel à une api exeterne
     */
    @Override
    @Retryable(value = {ExternServiceException.class}, maxAttempts = 2, backoff = @Backoff(delay = 2000))
    @Cacheable(value = EqcCacheConfig.CACHE_RES_NAME)
    public List<CentreService> getEntiteStructureFromRes() {

        libellesEntiteStructureMap = libelleEntiteStructureRepository.getAll();

        loadEsFiliereToExclude();

        List<CentreService> centreServices = resClient.getEntiteStructure().stream()
                .peek(this::verifyFiliere)
                .collect(Collectors.toList());

        // appliquer le Filtre pour les CDS
        List<CentreService> filtredCds = applyCdsFilter(centreServices);
        // appliquer le Filtre pour les Filieres
        List<CentreService> filtredFilieres = applyFiliereFilter(centreServices);

        List<CentreService> filieres = Stream.concat(filtredCds.stream(), filtredFilieres.stream())
                .collect(Collectors.toList());

        //Récupérations des tetes perim fictives
        List<ParamsFictionalTetePerim> listFictionalTetePerim = loadFictionalTetePerimetre();


        List<String> filieresCode = listFictionalTetePerim.stream()
                .map(paramsFictionalTetePerim -> paramsFictionalTetePerim.getParamsFictionalTetePerimId().getCodeFiliere().toString()).collect(Collectors.toList());

        List<String> ugsCode = listFictionalTetePerim.stream()
                .map(paramsFictionalTetePerim -> paramsFictionalTetePerim.getParamsFictionalTetePerimId().getCodeUg().toString()).collect(Collectors.toList());

        List<String> stsCode = listFictionalTetePerim.stream()
                .map(paramsFictionalTetePerim -> paramsFictionalTetePerim.getParamsFictionalTetePerimId().getCodeSt().toString()).collect(Collectors.toList());

        Map<String, String> fictionalTetePerimBySt = getFictionalTetePerimBySt(listFictionalTetePerim);

        Map<String, TetePerimetre> parametreTetePerim =  loadParametreTetePerimetre(fictionalTetePerimBySt.values())
                .stream()
                .collect(toMap(TetePerimetre::getId, Function.identity()));

        addFictionalTetePerimitre(filieres, filieresCode, ugsCode, stsCode, fictionalTetePerimBySt, parametreTetePerim);


        addLibelleEsFromRes(filieres);


        return reworkListCentreService(applyCommonFilter(filieres), parametreTetePerim);
    }

    private void addLibelleEsFromRes(List<CentreService> filieres) {
        Map<String, String> mapLibelleFiliereToAdd = filieres.stream().filter(filiere -> !libellesEntiteStructureMap.containsKey(filiere.getId()))
                .collect(toMap(CentreService::getId, CentreService::getLibelle));

        Map<String, String> mapLibelleUgToAdd = filieres.stream()
                .flatMap(filiere -> filiere.getUniteGestions().stream()).filter(uniteGestion -> !libellesEntiteStructureMap.containsKey(uniteGestion.getId()))
                .collect(toMap(UniteGestion::getId, UniteGestion::getLibelle));

        Map<String, String> mapLibelleStToAdd = filieres.stream()
                .flatMap(filiere -> filiere.getUniteGestions().stream())
                .flatMap(uniteGestion -> uniteGestion.getServiceTraitements().stream())
                .filter(serviceTraitement -> !libellesEntiteStructureMap.containsKey(serviceTraitement.getId()))
                .collect(toMap(ServiceTraitement::getId, ServiceTraitement::getLibelle));

        libelleEntiteStructureRepository.saveAll( mapLibelleFiliereToAdd.entrySet().stream().map(elemFil ->
                        LibelleEntiteStructure.builder().code(elemFil.getKey()).libelle(elemFil.getValue()).build())
                .collect(Collectors.toList()));
        libelleEntiteStructureRepository.saveAll(mapLibelleUgToAdd.entrySet().stream().map(elemFil ->
                        LibelleEntiteStructure.builder().code(elemFil.getKey()).libelle(elemFil.getValue()).build())
                .collect(Collectors.toList()));
        libelleEntiteStructureRepository.saveAll(mapLibelleStToAdd.entrySet().stream().map(elemFil ->
                        LibelleEntiteStructure.builder().code(elemFil.getKey()).libelle(elemFil.getValue()).build())
                .collect(Collectors.toList()));
    }

    @Override
    public Map<String, EntiteStructure> getEntiteStructureByCodeMap() {
        Map<String, EntiteStructure> map = new HashMap<>();
        getEntiteStructureFromRes().forEach(cds -> {
            map.put(cds.getId(), cds);
            cds.getUniteGestions().forEach(ug -> {
                ug.setParent(cds);
                map.put(ug.getId(), ug);
                ug.getServiceTraitements().forEach(st -> {
                    st.setParent(ug);
                    map.put(st.getId(), st);
                });
            });
        });
        return map;
    }

    /**
     * Ajout des tetes perimetres fictives pour les st sans tete de perim
     * @param filieres
     * @param filieresCode
     * @param ugsCode
     * @param stsCode
     * @param fictionalTetePerim
     * @param parametreTetePerim
     */
    private void addFictionalTetePerimitre(List<CentreService> filieres, List<String> filieresCode, List<String> ugsCode, List<String> stsCode,
                                           Map<String, String> fictionalTetePerim, Map<String, TetePerimetre> parametreTetePerim) {
        filieres.stream()
                .filter(filiereElem -> filieresCode.contains(filiereElem.getId()))
                .flatMap(filierElem ->
                        filierElem.getUniteGestions().stream()
                                .filter(ugElem -> ugsCode.contains(ugElem.getId()))
                )
                .flatMap(ugElem -> ugElem.getServiceTraitements().stream()
                        .filter(stElem -> stsCode.contains(stElem.getId()))
                        .peek(stElem ->
                                stElem.setListeTetePerimetre(Arrays.asList(parametreTetePerim.get(fictionalTetePerim.get(stElem.getId()))))
                        )
                )
                .collect(Collectors.toList());
    }


    private Map<String, String> getFictionalTetePerimBySt (List<ParamsFictionalTetePerim> listFictionalTetePerim) {
        Map<String, String> fictionalTetePerimBySt = new HashMap<>();
        listFictionalTetePerim.stream().forEach(paramsFictionalTetePerim ->
                fictionalTetePerimBySt.put(paramsFictionalTetePerim.getParamsFictionalTetePerimId().getCodeSt().toString(),
                        paramsFictionalTetePerim.getFictionalTetePerim().toString())
        );
        return fictionalTetePerimBySt;
    }

    private List<ParamsFictionalTetePerim> loadFictionalTetePerimetre() {
        return paramsFictionalTetePerimRepository.findAll();
    }

    private List<TetePerimetre> loadParametreTetePerimetre(Collection<String> listTetePerim) {
        return tetePerimetreRepository.findAllById(listTetePerim);
    }

    public void verifyFiliere(CentreService centreService) {
        centreService.setFiliere(filieres.stream().anyMatch(filiere -> filiere.equalsIgnoreCase(centreService.getId())));
    }

    private List<CentreService> applyCommonFilter(List<CentreService> centreServices) {
        return centreServices.stream()
                .peek(this::excludeEntiteStructure)
                .filter(centreService -> !centreService.getUniteGestions().isEmpty())
                .peek(this::mapLibelleEntiteStructure)
                .collect(Collectors.toList());
    }

    private List<CentreService> applyCdsFilter(List<CentreService> centreServices) {

        return centreServices.stream()
                .filter(centreService -> !centreService.isFiliere())
                .filter(centreService -> !cdsExclus.contains(centreService.getId()))
                .peek(this::reducePerimeter)
                .collect(Collectors.toList());
    }


    private List<CentreService> applyFiliereFilter(List<CentreService> centreServices) {
        return centreServices.stream()
                .filter(CentreService::isFiliere)
                .filter(centreService -> !filieresExclus.contains(centreService.getId()))
                .peek(this::excludeFiliereEntiteStructure)
                .collect(Collectors.toList());
    }

    private void mapLibelleEntiteStructure(CentreService centreService) {
        centreService.setLibelle(getLibelle(centreService.getId(), centreService.getLibelle(), centreService.isFiliere()));
        centreService.setUniteGestions(mapLibelleUgs(centreService));
    }

    private List<UniteGestion> mapLibelleUgs(CentreService centreService) {
        return centreService.getUniteGestions().stream().peek(ug -> {
            ug.setLibelle(getLibelle(ug.getId(), ug.getLibelle(), centreService.isFiliere()));
            ug.setServiceTraitements(mapLibelleSts(ug, centreService.isFiliere()));
        }).collect(Collectors.toList());
    }

    private List<ServiceTraitement> mapLibelleSts(UniteGestion ug, boolean isFiliere) {
        return ug.getServiceTraitements().stream().peek(st -> st.setLibelle(getLibelle(st.getId(), st.getLibelle(), isFiliere)))
                .collect(Collectors.toList());
    }

    private String getLibelle(String id, String libelle, boolean isFiliere) {
        return libellesEntiteStructureMap.getOrDefault(id, isFiliere ? libelle : formatLibelleRes(libelle));
    }

    private void excludeEntiteStructure(CentreService centreService) {
        centreService.getUniteGestions().removeIf(ug -> sigleExclus.stream().anyMatch(ug.getLibelle()::contains));
        centreService.getUniteGestions().forEach(ug -> ug.getServiceTraitements()
                .removeIf(st -> sigleExclus.stream().anyMatch(st.getLibelle()::contains)));
    }

    private void excludeFiliereEntiteStructure(CentreService centreService) {
        centreService.getUniteGestions().removeIf(ug -> ugFiliereExclus.stream().anyMatch(ug.getId()::contains));
        centreService.getUniteGestions().forEach(ug -> ug.getServiceTraitements()
                .removeIf(st -> stFiliereExclus.stream().anyMatch(st.getId()::contains)));
    }

    /**
     * 3 types d'UG font partie du périmètre de démarrage de EQC
     */
    private void reducePerimeter(CentreService centreService) {
        centreService.getUniteGestions().removeIf(uniteGestion -> Stream.of("CLIPRI", "CLICOM", "FLUX")
                .noneMatch(uniteGestion.getLibelle()::contains));
    }

    private String formatLibelleRes(String libelle) {
        try {
            return libelle.split(" ", 4)[3];
        } catch (Exception e) {
            return libelle;
        }
    }

    private List<String> getEsCodeToExcludeByType(List<EsFiliereToExclude> esFiliereToExcludes, String esType) {
       return esFiliereToExcludes.stream()
                .filter(es -> es.getType().equals(esType))
                .map(EsFiliereToExclude::getCode)
                .collect(Collectors.toList());
    }

    private void loadEsFiliereToExclude(){
        List<EsFiliereToExclude> esFiliereToExcludes = esFiliereToExcludeRepository.findAll();
        filieresExclus = getEsCodeToExcludeByType(esFiliereToExcludes,"FILIERE");
        ugFiliereExclus = getEsCodeToExcludeByType(esFiliereToExcludes,"UG");
        stFiliereExclus = getEsCodeToExcludeByType(esFiliereToExcludes,"ST");

    }

    @Override
    public void afterPropertiesSet() {
        filieres = eqcProperties.getContributeur().getFilieres();
        cdsExclus = eqcProperties.getContributeur().getCodeCdsExclus();
        sigleExclus = eqcProperties.getContributeur().getSigleExclus();
    }

    @Override
    public List<CentreService> reworkListCentreService(List<CentreService> centreServiceList,  Map<String, TetePerimetre> parametreTetePerim) {
        List<CentreService> enhancedListCds = new ArrayList<>();
        centreServiceList.forEach(centreService -> {
            List<TeteDePerimetreDto> tprDto = new ArrayList<>();
            centreService.getUniteGestions().forEach(uniteGestion -> {
                uniteGestion.getServiceTraitements().forEach(serviceTraitement -> {
                    if (serviceTraitement.getListeTetePerimetre() != null && !serviceTraitement.getListeTetePerimetre().isEmpty()) {
                        serviceTraitement.getListeTetePerimetre().forEach(tetePerimetre -> {
                            TetePerimetre tetePerimetreToSet;
                            if(parametreTetePerim.get(tetePerimetre.getId()) != null) {
                                tetePerimetreToSet = parametreTetePerim.get(tetePerimetre.getId());
                                tetePerimetre.setLibelle(tetePerimetreToSet.getLibelle());
                                tetePerimetre.setActive(tetePerimetreToSet.getActive());
                            } else {
                                tetePerimetreToSet = tetePerimetre;
                            }
                            tprDto.add(buildTeteDePerimetreDto(tetePerimetreToSet, uniteGestion, serviceTraitement));
                        });
                    } else {
                        TetePerimetre tetePerimetre = TetePerimetre.builder()
                                .libelle(LIBELLE_TPR_NON_DEFINIE)
                                .id(ID_TPR_NON_DEFINIE)
                                .build();
                        tprDto.add(buildTeteDePerimetreDto(tetePerimetre, uniteGestion, serviceTraitement));
                    }
                });
            });
            JsonObject tprs = buildJsonTeteDePerimetre(tprDto);
            enhancedListCds.add(buildCentreService(centreService, tprs));
        });
        return enhancedListCds;
    }

    private JsonObject buildJsonTeteDePerimetre(List<TeteDePerimetreDto> list) {
        Map<TeteDePerimetreDto, List<TeteDePerimetreDto>> mapTprDto = list.stream().collect(Collectors.groupingBy(Function.identity()));
        final JsonObject tprsJson = new JsonObject();
        mapTprDto.forEach(((tprDto, tprDtoList) -> {
            JsonObject ugsJsonList = new JsonObject();
            Map<UniteGestion, List<TeteDePerimetreDto>> mapUg = tprDtoList.stream().collect(Collectors.groupingBy(TeteDePerimetreDto::getUg));
            mapUg.forEach((mapUgDtoKey, ugtprDtoList) -> {
                JsonObject ServiceTraitementJsonList = new JsonObject();
                JsonObject ugJsonObject = new JsonObject();
                ugtprDtoList.forEach(elt -> {
                    ServiceTraitementJsonList.add(elt.getSt().getId(), gson.toJsonTree(elt.getSt()));
                });
                ugJsonObject.addProperty("id", mapUgDtoKey.getId());
                ugJsonObject.addProperty("ville", mapUgDtoKey.getVille());
                ugJsonObject.addProperty("libelle", mapUgDtoKey.getLibelle());
                ugJsonObject.add("sts", ServiceTraitementJsonList);
                ugsJsonList.add(mapUgDtoKey.getId(), ugJsonObject);
            });
            JsonObject tprJsonObject = new JsonObject();
            tprJsonObject.addProperty("id", tprDto.getId());
            tprJsonObject.addProperty("active", tprDto.getActive() != null ? tprDto.getActive() : false);
            tprJsonObject.addProperty("libelle", tprDto.getLibelle());
            tprJsonObject.add("ugs", ugsJsonList);
            tprsJson.add(tprDto.getId(), tprJsonObject);
        }));
        return tprsJson;
    }

    private CentreService buildCentreService(CentreService centreService, JsonObject teteDePerimetres) {
        return CentreService.builder()
                .filiere(centreService.isFiliere())
                .libelle(centreService.getLibelle())
                .id(centreService.getId())
                .ville(centreService.getVille())
                .uniteGestions(centreService.getUniteGestions())
                .teteDePerimetres(teteDePerimetres.toString())
                .build();
    }

    private TeteDePerimetreDto buildTeteDePerimetreDto(TetePerimetre tetePerimetre, UniteGestion uniteGestion,
                                                       ServiceTraitement serviceTraitement) {
        return TeteDePerimetreDto.builder()
                .id(tetePerimetre.getId())
                .libelle(tetePerimetre.getLibelle())
                .active(tetePerimetre.getActive() != null ? tetePerimetre.getActive() : false)
                .ug(uniteGestion)
                .st(serviceTraitement)
                .build();
    }
}
