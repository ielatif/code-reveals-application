package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.ExtensionPerimetre;
import com.socgen.eqc.domain.model.Renfort;

import java.util.List;
import java.util.Optional;

public interface ExtensionPerimetreService {

    Optional<ExtensionPerimetre> createExtension(String matricule, String createurId, Renfort renfort);

    void deleteExtension(List<Renfort> renfortsToDeleteWithExtensionPerimetre) ;

    void deleteExtensionAsync(List<Renfort> renfortsToDeleteWithExtensionPerimetre) ;

}
