package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.ActiviteParamsService;
import com.socgen.eqc.application.ActiviteService;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.domain.model.ActiviteParams;
import com.socgen.eqc.infrastructure.persistance.ActiviteRepository;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.RefActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteParamsDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ActiviteServiceImpl implements ActiviteService {

    private final ActiviteRepository activiteRepository;

    private final ActiviteParamsService activiteParamsService;

    private final SmboClient smboClient;

    @Override
    public List<ActiviteParams> findByIdIn(List<String> activiteCodes) {
        return activiteRepository.findByCodeIn(activiteCodes);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = EqcCacheConfig.CACHE_ACTIVITES_NAME, allEntries = true)
    public ActiviteDto update(ActiviteDto activiteInputDto) {
        RefActiviteDto refActiviteDto = smboClient.saveActivite(activiteInputDto.getRefActiviteDto());
        activiteInputDto.getActiviteParamsDto().setCode(refActiviteDto.getCode());
        ActiviteParamsDto activiteParamsDto = activiteParamsService.update(activiteInputDto.getActiviteParamsDto());
        return ActiviteDto.builder()
                .refActiviteDto(refActiviteDto)
                .activiteParamsDto(activiteParamsDto)
                .build();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = EqcCacheConfig.CACHE_ACTIVITES_NAME, allEntries = true)
    public ActiviteDto create(ActiviteDto activiteInputDto) {
        RefActiviteDto refActiviteDto = smboClient.saveActivite(activiteInputDto.getRefActiviteDto());
        activiteInputDto.getActiviteParamsDto().setCode(refActiviteDto.getCode());
        ActiviteParamsDto activiteParamsDto = activiteParamsService.create(activiteInputDto.getActiviteParamsDto());
        return ActiviteDto.builder()
                .refActiviteDto(refActiviteDto)
                .activiteParamsDto(activiteParamsDto)
                .build();
    }

}
