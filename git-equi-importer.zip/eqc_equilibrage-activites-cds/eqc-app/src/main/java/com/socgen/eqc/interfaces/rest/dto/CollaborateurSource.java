package com.socgen.eqc.interfaces.rest.dto;

public enum CollaborateurSource {
    EQC, SIRH
}
