package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.annotations.SgSignInRolesAllowed;
import com.socgen.eqc.application.CollaborateurService;
import com.socgen.eqc.application.PlanningService;
import com.socgen.eqc.interfaces.rest.dto.CollaborateurSource;
import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

import static com.socgen.eqc.domain.model.RoleEqc.CONSULTER_PLANNING;
import static com.socgen.eqc.domain.model.RoleEqc.GERER_PLANNING;


@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/services-traitements")
@Api(value = "services-traitements")
@Slf4j
public class ServiceTraitementResource {

    @Autowired
    private CollaborateurService collaborateurService;

    @Autowired
    private PlanningService planningService;


    @GET
    @ApiOperation(value = "Récupération des collaborateurs par ST", notes = "Récupération des collaborateurs par ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Le planning est bien récupéré")
    })
    @Path("{codeServiceTraitement}/collaborateurs")
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING })
    public Response getCollaborateur(@QueryParam("source") CollaborateurSource source, @QueryParam("filter") CollaborateurSource filter, @PathParam("codeServiceTraitement") Long codeServiceTraitement) {
        if (source == CollaborateurSource.SIRH && filter == CollaborateurSource.EQC) {
            return Response.ok(collaborateurService.findNewCollaborateurs(codeServiceTraitement)).build();
        } else if (source == CollaborateurSource.EQC) {
            return Response.ok(collaborateurService.findCollaborateurs(codeServiceTraitement)).build();
        }
        return Response.noContent().build();
    }

    @POST
    @ApiOperation(value = "Ajouter un collaborateur", notes = "Ajouter un collaborateur")
    @ApiResponses({
            @ApiResponse(code = 201, message = "Le collaborateur est bien créé"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    @Path("{codeServiceTraitement}/collaborateurs")
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING })
    public Response ajouterCollaborateur(@Valid List<CollaborateurDto> collaborateurDto,
                                         @QueryParam("codeCds") Long codeCds, @QueryParam("codeUg") Long codeUg,
                                         @PathParam("codeServiceTraitement") Long codeServiceTraitement) {
        planningService.ajouterCollaborateur(codeServiceTraitement, codeCds, codeUg, collaborateurDto);
        return Response.status(Response.Status.CREATED).build();
    }

}
