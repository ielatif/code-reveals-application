package com.socgen.eqc.infrastructure.batch.service;

import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import com.socgen.eqc.infrastructure.batch.dto.AffectationDto;
import com.socgen.eqc.infrastructure.batch.dto.AffectationEqcTotal;
import com.socgen.eqc.infrastructure.batch.utils.CalculatorConsolideUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ConsolideInterUgService implements CommonService {

    /**
     * Récupérer les affectations des renforts entrant pour chaque stAide
     * @param affectationDtos
     * @return
     */
    public Map<Long, Map<String, Map<String, List<AffectationEqcTotal>>>> buildTotalAffectationRenfortEntrantsInterUg(List<? extends AffectationDto> affectationDtos) {

        Map<Long, List<AffectationDto>> affectationsByStAide = buildAffecRenfortEntrantsInterUg(affectationDtos);

        return affectationsByStAide.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entryAffBySt -> {

                    Map<String, List<AffectationDto>> mapAffecByMatricule = entryAffBySt.getValue().stream()
                            .collect(Collectors.groupingBy(AffectationDto::getMatricule));

                    Map<String, List<AffectationEqcTotal>> affecEqcTotByMatricule = buildAffecEqcTotal(mapAffecByMatricule, entryAffBySt.getKey());

                    return regroupAffectationByMatriculeAndSumeauActivite(affecEqcTotByMatricule);
                }));
    }

    /**
     * Récuperer la liste des affectations pour les renforts inter UG
     *
     * @param affectationDtos
     * @return
     */
    private Map<Long, List<AffectationDto>> buildAffecRenfortEntrantsInterUg(List<? extends AffectationDto> affectationDtos) {
        return affectationDtos.stream()
                .filter(affectationDto -> affectationDto.getRenfort() != null)
                .filter(affectationDto -> !affectationDto.getRenfort().isRenfortIntraUg())
                .collect(Collectors.groupingBy(affectations -> affectations.getRenfort().getCodeStAide()));
    }

    /**
     * Generer le consolide mensuel pour les renforts inter ug
     * @param mapAffecRenfortInterUgByStAide
     * @param mapCumulMensRenfortInterUg
     * @return
     */
    public Map<Long, List<ConsolideMensuel>> buildConsolideRenfortEntrantsInterUg(Map<Long, Map<String, Map<String, List<AffectationEqcTotal>>>> mapAffecRenfortInterUgByStAide,
                                                                                   Map<String, Long> mapCumulMensRenfortInterUg, Long date) {

        //Calculer les jours de présence pour chaque collaborateur en renforts inetr UG
        Map<Long, Map<String, Double>>  mapPresenceRenfortByStAide = CalculatorConsolideUtils.computePresenceDayForRenfortInterUg(date);

        return mapAffecRenfortInterUgByStAide
                .entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entryAffBySt ->
                        buildListConsolideMensuel(
                                entryAffBySt.getValue(),
                                mapPresenceRenfortByStAide.getOrDefault(entryAffBySt.getKey(), new HashMap<>()), true, mapCumulMensRenfortInterUg, date)));
    }
}
