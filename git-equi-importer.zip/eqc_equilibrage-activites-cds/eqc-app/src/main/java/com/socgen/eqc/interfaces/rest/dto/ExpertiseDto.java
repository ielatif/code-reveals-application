package com.socgen.eqc.interfaces.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExpertiseDto {

    private String codeActivite;

    private String libelleActivite;

    private String idNiveau;

    private String libelleNiveau;

    private Long nombreDossier;
}
