package com.socgen.eqc.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.socgen.eqc.infrastructure.entite.structure.EntiteStructureService;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.entite.structure.domain.EntiteStructure;
import com.socgen.eqc.infrastructure.entite.structure.domain.ServiceTraitement;
import com.socgen.eqc.infrastructure.entite.structure.domain.UniteGestion;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.Base64;
import java.util.Objects;
import java.util.stream.Stream;

@RequiredArgsConstructor
public class UserInfoCustomTagsExtractor {

    private final EntiteStructureService entiteStructureService;

    public Tags extractTagsFromAuthHeader(String authorisation) {

        if (StringUtils.isNotEmpty(authorisation) && authorisation.contains("Bearer")) {
            int dot1 = authorisation.indexOf(".");
            int dot2 = authorisation.indexOf(".", dot1 + 1);
            String userInfo = authorisation.substring(dot1 + 1, dot2);
            byte[] decodedBytes = Base64.getDecoder().decode(userInfo);
            String decodedString = new String(decodedBytes);
            JsonObject jsonObject = new JsonParser().parse(decodedString).getAsJsonObject();

            String esCode = jsonObject.get("socgen:sgservicecodegeo") != null ? jsonObject.get("socgen:sgservicecodegeo").getAsString() : "";
            JsonElement userIdElement = Stream.of(jsonObject.get("socgen:sgtssid"), jsonObject.get("socgen:sgzoneid"), jsonObject.get("sub"))
                    .filter(Objects::nonNull)
                    .findFirst()
                    .orElse(new JsonPrimitive(""));
            String userId = userIdElement.getAsString();
            String userJob = jsonObject.get("socgen:sgjob") != null ? jsonObject.get("socgen:sgjob").getAsString() : "";

            return extractTags(esCode, userId, userJob);
        }

        return emptyTags();
    }

    public Tags extractTags(String esCode, String userId, String userJob) {

        String libelleFiliere = "";
        String codeFiliere = "";
        String libelleUg = "";
        String codeUg = "";
        String libelleSt = "";
        String codeSt = "";
        String esType = "";

        EntiteStructure entiteStructure = this.entiteStructureService.getEntiteStructureByCodeMap().get(esCode);

        if (entiteStructure instanceof CentreService) {
            libelleFiliere = ((CentreService) entiteStructure).getLibelle();
            codeFiliere = ((CentreService) entiteStructure).getId();
            esType = "FILIERE";
        } else if (entiteStructure instanceof UniteGestion) {
            libelleFiliere = ((CentreService) entiteStructure.getParent()).getLibelle();
            libelleUg = ((UniteGestion) entiteStructure).getLibelle();
            codeUg = ((UniteGestion) entiteStructure).getId();
            esType = "UG";
        } else if (entiteStructure instanceof ServiceTraitement) {
            libelleFiliere = ((CentreService) entiteStructure.getParent().getParent()).getLibelle();
            libelleUg = ((UniteGestion) entiteStructure.getParent()).getLibelle();
            libelleSt = ((ServiceTraitement) entiteStructure).getLibelle();
            codeSt = ((ServiceTraitement) entiteStructure).getId();
            esType = "ST";
        }

        return Tags.of(Tag.of("user_id", userId),
                Tag.of("user_filiere_libelle", libelleFiliere),
                Tag.of("user_filiere_code", codeFiliere),
                Tag.of("user_ug_libelle", libelleUg),
                Tag.of("user_ug_code", codeUg),
                Tag.of("user_st_libelle", libelleSt),
                Tag.of("user_st_code", codeSt),
                Tag.of("user_es_code", esCode),
                Tag.of("user_es_type", esType),
                Tag.of("user_job", userJob.toUpperCase()));
    }

    private Tags emptyTags() {
        return Tags.of(Tag.of("user_id", ""),
                Tag.of("user_filiere_libelle", ""),
                Tag.of("user_filiere_code", ""),
                Tag.of("user_ug_libelle", ""),
                Tag.of("user_ug_code", ""),
                Tag.of("user_st_libelle", ""),
                Tag.of("user_st_code", ""),
                Tag.of("user_es_code", ""),
                Tag.of("user_es_type", ""),
                Tag.of("user_job", ""));
    }
}
