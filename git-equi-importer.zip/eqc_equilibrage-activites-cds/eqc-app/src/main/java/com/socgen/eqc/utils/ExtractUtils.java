package com.socgen.eqc.utils;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ExtractUtils {

    public ObjectWriter createObjectWriter(Class classSchema) {
        var csvMapper = new CsvMapper();
        csvMapper.enable(SerializationFeature.INDENT_OUTPUT);
        var csvSchema = csvMapper
                .schemaFor(classSchema)
                .withoutQuoteChar()
                .withColumnSeparator(';')
                .withHeader();
             ;
        return csvMapper.writer(csvSchema);
    }

}
