package com.socgen.eqc.interfaces.rest.dto;

public enum Action {
    CREATE,
    UPDATE,
    DELETE
}
