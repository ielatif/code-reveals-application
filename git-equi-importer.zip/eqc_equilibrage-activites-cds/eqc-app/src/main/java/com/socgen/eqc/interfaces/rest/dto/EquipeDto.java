package com.socgen.eqc.interfaces.rest.dto;

import com.socgen.eqc.domain.model.Equipe;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EquipeDto {

    private Long code;
    private String libelle;
    private Long codeCds;
    private Long codeUg;
    private Byte formatSemainier;

    public Equipe toDomain() {
        return Equipe.builder().code(code).libelle(libelle).codeCds(codeCds).codeUg(codeUg).formatSemainier(formatSemainier).build();
    }
}
