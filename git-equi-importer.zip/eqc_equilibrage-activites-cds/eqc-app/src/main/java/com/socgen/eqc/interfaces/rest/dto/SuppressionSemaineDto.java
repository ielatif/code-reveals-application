package com.socgen.eqc.interfaces.rest.dto;

import lombok.*;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SuppressionSemaineDto {

    @NotNull
    private List<String> matricules;
    @NotNull
    private LocalDate dateDebut;
    @NotNull
    private LocalDate dateFin;
    @NotNull
    private List<String> matriculesRenfort;
    @NotNull
    private Long codeServiceTraitement;
}
