package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import com.socgen.eqc.interfaces.rest.dto.IndicateurSearchDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AffiliationServiceImpl implements AffiliationService {

    private final AffiliationRepository affiliationRepository;

    @Override
    public List<Affiliation> findByPlanningSearchDto(PlanningSearchDto planningSearchDto) {
        if (planningSearchDto.getDateDebut() == null || planningSearchDto.getDateFin() == null || planningSearchDto
                .getCodeServiceTraitement() == null) {
            return Collections.emptyList();
        }
        return affiliationRepository
                .findByEquipeIdAndDates(planningSearchDto.getCodeServiceTraitement(), planningSearchDto
                        .getDateDebut(), planningSearchDto.getDateFin());
    }

    @Override
    public List<Affiliation> findByListEquipe(IndicateurSearchDto indicateurSearchDto) {
        if (indicateurSearchDto.getDateDebut() == null || indicateurSearchDto.getDateFin() == null || indicateurSearchDto
                .getListCodeServiceTraitement() == null) {
            return Collections.emptyList();
        }
        return affiliationRepository
                .findByEquipeIdInAndDates(indicateurSearchDto.getListCodeServiceTraitement(), indicateurSearchDto
                        .getDateDebut(), indicateurSearchDto.getDateFin());
    }

    @Override
    public List<Affiliation> findByEquipeAndDate(@NonNull Long codeEquipe, @NonNull LocalDate date) {
        return affiliationRepository.findByEquipeIdAndDate(codeEquipe, date);
    }


    @Override
    public Affiliation findByPlanningSearchDto(@NonNull PlanningSearchDto planningSearchDto, @NonNull String matricule) {
        return affiliationRepository
                .findByEquipeIdAndDatesAndMatricule(planningSearchDto.getCodeServiceTraitement(), planningSearchDto
                        .getDateDebut(), planningSearchDto.getDateFin(), matricule);
    }

    @Override
    public void saveAll(List<Affiliation> affiliations) {
        affiliationRepository.saveAll(affiliations);
    }

    @Override
    public boolean hasAffiliation(@NonNull String matricule) {
        return affiliationRepository.findActiveByMatricule(matricule) != null;
    }

    @Override
    public void remove(@NonNull String matricule) {
        Affiliation affiliation = affiliationRepository.findActiveByMatricule(matricule);
        if (affiliation.getDateEntree().equals(LocalDate.now())) {
            affiliationRepository.delete(affiliation);
        } else {
            affiliation.setDateSortie(LocalDate.now());
            affiliationRepository.save(affiliation);
        }

    }

    @Override
    public Optional<Affiliation> findLastByMatricule(String matricule) {
        return Optional.ofNullable(affiliationRepository.findTopByCollaborateurMatriculeOrderByDateSortieDesc(matricule));
    }

    @Override
    public List<Affiliation> findActiveByMatricules(List<String> matricules) {
        return affiliationRepository.findActiveByMatricules(matricules);
    }

    @Override
    public Optional<Affiliation> findByMatriculeAndDate(String matricule, LocalDate dateDebut, LocalDate dateFin) {

        List<Affiliation> affiliations = affiliationRepository.findByMatriculeAndDate(matricule, dateDebut, dateFin);

        Optional<Affiliation> lastAffiliation = affiliations.stream().filter(affiliation -> affiliation.getDateSortie() == null).findFirst();

        if (lastAffiliation.isPresent()) {
            return lastAffiliation;
        }

        return affiliations.stream()
        .min(
                Comparator.comparingLong(
                        item -> ChronoUnit.DAYS.between(dateDebut, item.getDateSortie())
                )
        );
    }

    @Override
    public List<Affiliation> findByMatriculeAndDateDebutAndDateFin(String matricule, LocalDate dateDebut, LocalDate dateFin) {
        if (dateDebut == null || dateFin == null) {
            return Collections.emptyList();
        }
        return affiliationRepository.findByMatriculeAndDateDebutAndDateFin(matricule, dateDebut, dateFin);
    }

    @Override
    public  Optional<Affiliation> findByEquipeAndActiveByMatricule(@NonNull Long codeEquipe, @NonNull String matricule) {
        return affiliationRepository.findByEquipeCodeAndCollaborateurMatriculeAndDateSortieIsNull(codeEquipe, matricule);
    }

    @Override
    public List<Affiliation> findByListEquipeAndActive(@NonNull List<Long> idsEquipes) {
        return affiliationRepository.findbyListEquipeAndActive(idsEquipes);
    }
}
