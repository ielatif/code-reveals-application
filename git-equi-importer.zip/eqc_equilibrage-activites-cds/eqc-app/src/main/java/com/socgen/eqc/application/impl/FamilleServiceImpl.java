package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.FamilleService;
import com.socgen.eqc.config.EqcCacheConfig;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.infrastructure.smbo.dto.RefFamilleDto;
import lombok.AllArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class FamilleServiceImpl implements FamilleService {

    private final SmboClient smboClient;

    @Override
    @Cacheable(value = EqcCacheConfig.CACHE_FAMILLE_NAME)
    public List<RefFamilleDto> getAll() {
        return smboClient.getAllFamilles();
    }

    @Override
    @CacheEvict(value = EqcCacheConfig.CACHE_FAMILLE_NAME, allEntries = true)
    public RefFamilleDto saveFamille(RefFamilleDto famille) {
        return smboClient.saveFamilles(famille);
    }

    @Override
    @CacheEvict(value = EqcCacheConfig.CACHE_FAMILLE_NAME, allEntries = true)
    public void updateFamilles(RefFamilleDto famille) {
        smboClient.saveFamilles(famille);
    }

    @Override
    public List<RefFamilleDto> saveFamille(List<RefFamilleDto> famillesDto) {
        return smboClient.updateListFamille(famillesDto);
    }
}
