package com.socgen.eqc.interfaces.rest.dto;

import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPilotageActivitesDto;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPlanningActivitesDto;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractPlanningCollabDto;
import com.socgen.eqc.infrastructure.persistance.extraction.ExtractCompetencesDto;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.stream.Stream;

@AllArgsConstructor
public enum ExtractionTypes {

    PLANNING_COLLABORATEUR("planningCollab") {

        @Override
        public Class getDtoClass () {

            return ExtractPlanningCollabDto.class;
        }

    },
    PLANNING_ACTIVITES("planningActivites") {

        @Override
        public Class getDtoClass () {

            return ExtractPlanningActivitesDto.class;
        }

    },
    PILOTAGE_ACTIVITES("pilotageActivites") {

        @Override
        public Class getDtoClass () {

            return ExtractPilotageActivitesDto.class;
        }

    },
    COMPETENCES("competences") {

        @Override
        public Class getDtoClass () {

            return ExtractCompetencesDto.class;
        }

    };


    @Getter
    private String type;

    public abstract Class getDtoClass();

    public final String getType() {
        return type;
    }


    public static ExtractionTypes instanceByKey(final String type) {
        return Stream.of(ExtractionTypes.values())
                .filter(extractType -> extractType.getType().equals(type))
                .findFirst()
                .orElseThrow(() -> new BusinessException("Extraction type non définie"));
    }

}
