package com.socgen.eqc.config;

import org.springframework.boot.autoconfigure.cache.JCacheManagerCustomizer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.cache.Cache;
import javax.cache.CacheManager;
import javax.cache.configuration.MutableConfiguration;
import java.util.Optional;

@Configuration
@EnableCaching
@EnableScheduling
public class EqcCacheConfig implements JCacheManagerCustomizer {

    public static final String CACHE_RES_NAME = "ResCache";
    public static final String CACHE_PEOPLE_NAME = "PeopleCache";
    public static final String CACHE_GERSHWIN_NAME = "GershwinCache";
    public static final String CACHE_ACTIVITES_NAME = "SmboActivitesCache";
    public static final String CACHE_TETE_PERIMETRES = "SmboTetePerimetresCache";
    public static final String CACHE_FAMILLE_NAME = "SmboFamillesCache";


    @Override
    public void customize(CacheManager cacheManager) {
        createCache(cacheManager, CACHE_RES_NAME);
        createCache(cacheManager, CACHE_PEOPLE_NAME);
        createCache(cacheManager, CACHE_GERSHWIN_NAME);
        createCache(cacheManager, CACHE_ACTIVITES_NAME);
        createCache(cacheManager, CACHE_TETE_PERIMETRES);
        createCache(cacheManager, CACHE_FAMILLE_NAME);
    }

    private void createCache(CacheManager cacheManager, String cacheName) {
        Optional<Cache<Object, Object>> cache = Optional.ofNullable(cacheManager.getCache(cacheName));
        if (cache.isEmpty()) {
            cacheManager.createCache(cacheName, new MutableConfiguration<>());
        }
    }

}
