package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.IncidentService;
import com.socgen.eqc.infrastructure.smbo.SmboClient;
import com.socgen.eqc.interfaces.rest.dto.IncidentDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.Optional;

@Service
@AllArgsConstructor
public class IncidentServiceImpl implements IncidentService {

    private final SmboClient smboClient;

    @Override
    public IncidentDto getIncident() {
        Optional<IncidentDto> incidentDtoOptional = smboClient.getIncident()
                .stream()
                .min(Comparator.comparing(IncidentDto::getDateFichier));
        return incidentDtoOptional.orElse(null);
    }
}
