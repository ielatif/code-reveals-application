package com.socgen.eqc.application;

import com.socgen.eqc.interfaces.rest.dto.AffiliationSousEquipeDto;
import com.socgen.eqc.interfaces.rest.dto.SousEquipeDto;

import java.util.List;

public interface SousEquipeService {

    List<SousEquipeDto> getByCodeEquipe(Long idEquipe);

    SousEquipeDto create(SousEquipeDto sousEquipeDto);

    SousEquipeDto update(SousEquipeDto sousEquipeDto);

    void delete(Long idSousEquipe);

    void delete(List<Long> idSousEquipes);

    void addMembres(Long idSousEquipe, List<Long> idAffiliations);

    void deleteMembres(List<Long> idMemebres);

    List<AffiliationSousEquipeDto> getMembreByCodeEquipe(Long codeServiceTraitement);
}
