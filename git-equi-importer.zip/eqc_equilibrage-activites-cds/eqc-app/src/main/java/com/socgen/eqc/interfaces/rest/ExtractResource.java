package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.impl.ExtractServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/extraction")
@Slf4j
@Api(value = "extraction")
public class ExtractResource {

    @Autowired
    private ExtractServiceImpl extractService;

    @GET
    @Path("{extractionType}")
    @Produces({MediaType.APPLICATION_OCTET_STREAM})
    @ApiOperation(value = "Génération des extractions planning collab sous le format CSV", notes = "Génération des extractions sous le format CSV")
    @ApiResponses({
            @ApiResponse(code = 200, message = "L'exttraction est bien généré")
    })
    public Response extractionPlanningCollab(@PathParam("extractionType") String extractionType, @QueryParam(value = "listCodeSt") List<String> listCodeSt, @QueryParam("from") String from,
                                             @QueryParam("to") String to, @QueryParam(value = "listTetePerim") List<String> tetePerimetre) {

        return Response.ok(extractService.buildExtraction(extractionType, listCodeSt, tetePerimetre, from, to), MediaType.APPLICATION_OCTET_STREAM_TYPE)
                .build();
    }
}
