package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.ExportEtp;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

@Repository
@RequiredArgsConstructor
@Slf4j
public class ExportEtpRepository {

    private final JdbcTemplate jdbcTemplate;

    String EXPORT_ETP_SQL_QUERY = "SELECT *\n" +
            "\n" +
            "FROM (\n" +
            "    SELECT\n" +
            "        null AS cdsLabel,\n" +
            "        null AS cdsCode,\n" +
            "        null AS ugLabel,\n" +
            "        null AS ugCode,\n" +
            "        equipe.id AS stRattachementCode,\n" +
            "        null as stRattachementLabel,\n" +
            "        null as stAideCode,\n" +
            "        null as stAideLabel,\n" +
            "        affectation.date AS day,\n" +
            "        UPPER(affiliation.collaborateur_id) AS collaboratorCode,\n" +
            "        'NON' AS renfort,\n" +
            "        null AS activiteLabel,\n" +
            "        affectation.code_activite  AS activiteCode,\n" +
            "        round(cast(affectation.pourcentage as numeric) / 100, 2) AS etp\n" +
            "    FROM public.affectation\n" +
            "        inner JOIN affiliation ON affectation.affiliation_id = affiliation.id and affectation.date >= affiliation.date_entree\n" +
            "        inner JOIN collaborateur ON affiliation.collaborateur_id = collaborateur.matricule\n" +
            "        inner JOIN equipe ON affiliation.equipe_id = equipe.id\n" +
            "    WHERE affectation.date BETWEEN ? AND ? \n" +
            "\n" +
            "    UNION\n" +
            "\n" +
            "    SELECT\n" +
            "        null AS cdsLabel,\n" +
            "        renfort.code_cds_rattachement AS cdsCode,\n" +
            "        null AS ugLabel,\n" +
            "        renfort.code_ug_rattachement AS ugCode,\n" +
            "        renfort.code_st_rattachement AS stRattachementCode,\n" +
            "        null as stRattachementLabel,\n" +
            "        renfort.code_st_aide as stAideCode,\n" +
            "        null as stAideLabel,\n" +
            "        renfort.date AS day,\n" +
            "        UPPER(renfort.matricule_collaborateur) AS collaboratorCode,\n" +
            "        'OUI' AS renfort,\n" +
            "        'renfort' AS activiteLabel,\n" +
            "        null AS activiteCode,\n" +
            "        CASE\n" +
            "            WHEN renfort.intervalle = 2 THEN 1\n" +
            "            ELSE 0.5 END\n" +
            "        AS etp\n" +
            "    FROM renfort\n" +
            "             inner JOIN collaborateur ON renfort.matricule_collaborateur = collaborateur.matricule\n" +
            "    WHERE renfort.date BETWEEN ? AND ?\n" +
            "            \n" +
            "    UNION\n" +
            "            \n" +
            "    SELECT\n" +
            "         null AS cdsLabel,\n" +
            "         renfort.code_cds_aide AS cdsCode,\n" +
            "         null AS ugLabel,\n" +
            "         renfort.code_ug_aide AS ugCode,\n" +
            "         renfort.code_st_rattachement AS stRattachementCode,\n" +
            "         null AS stRattachementLabel,\n" +
            "         renfort.code_st_aide AS stAideCode,\n" +
            "         null AS stAideLabel,\n" +
            "         affectation.date AS day,\n" +
            "         UPPER(renfort.matricule_collaborateur) AS collaboratorCode,\n" +
            "         'OUI' AS renfort,\n" +
            "         NULL AS activiteLabel,\n" +
            "         affectation.code_activite AS activiteCode,\n" +
            "         round(cast(affectation.pourcentage as numeric) / 100, 2) AS etp\n" +
            "       FROM public.affectation\n" +
            "       inner JOIN renfort ON affectation.renfort_id = renfort.id\n" +
            "       WHERE renfort_id IS NOT NULL AND affectation.date BETWEEN ? AND ?\n" +
            "    ) AS Activity";

    public List<ExportEtp> getEtps(final LocalDate from, final LocalDate to) {
        try {
            log.info("Getting ETP export from {} to {} ", from, to);
            return this.jdbcTemplate.query(
                    EXPORT_ETP_SQL_QUERY, new ExportEtpRowMapper(), from ,to, from, to, from, to);
        } catch (final DataAccessException ex) {
            log.error("An error occurred while getting ETP export from DB", ex);
            return Collections.emptyList();
        }
    }

    static class ExportEtpRowMapper implements RowMapper<ExportEtp> {
        @Override
        public ExportEtp mapRow(ResultSet rs, int rowNum) throws SQLException {

            String stRattachementCollabLabel =  rs.getString("stRattachementLabel");
            String stRattachementCollabCode = rs.getString("stRattachementCode");

            String stAideLabel =  rs.getString("stAideLabel");
            String stAideCode = rs.getString("stAideCode");

            return ExportEtp.builder()
                    .cdsLabel(rs.getString("cdsLabel"))
                    .cdsCode(rs.getString("cdsCode"))
                    .ugLabel(rs.getString("ugLabel"))
                    .ugCode(rs.getString("ugCode"))
                    .stRattachementCollabLabel(stRattachementCollabLabel)
                    .stRattachementCollabCode(stRattachementCollabCode)
                    .stLabel(stAideLabel == null || stAideLabel.isEmpty() ? stRattachementCollabLabel : stAideLabel)
                    .stCode(stAideCode == null ? stRattachementCollabCode: stAideCode)
                    .stAideCode(stAideCode)
                    .stAideLabel(stAideLabel)
                    .day(rs.getString("day"))
                    .collaboratorMatricule(rs.getString("collaboratorCode"))
                    .renfort(rs.getString("renfort"))
                    .activiteCode(rs.getString("activiteCode"))
                    .activiteLabel(rs.getString("activiteLabel"))
                    .etp(rs.getBigDecimal("etp"))
                    .build();
        }
    }
}
