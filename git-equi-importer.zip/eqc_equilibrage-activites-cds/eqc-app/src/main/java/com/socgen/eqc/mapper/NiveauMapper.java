package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.Niveau;
import com.socgen.eqc.interfaces.rest.dto.NiveauDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface NiveauMapper {

     NiveauDto niveauToNiveauDto(Niveau niveau);

     List<NiveauDto> niveauListToNiveauDtoList(List<Niveau> niveaus);

}
