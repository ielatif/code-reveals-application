package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.infrastructure.entite.structure.domain.TetePerimetre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TetePerimetreRepository extends JpaRepository<TetePerimetre, String> {
    TetePerimetre findFirstById(String idTetePerimetre);
}
