package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.CorrespondancesService;
import com.socgen.eqc.infrastructure.smbo.dto.CorrespondanceActiviteDto;
import com.socgen.eqc.infrastructure.smbo.dto.Source;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/correspondances")
@Api(value = "correspondances")
public class CorrespondancesResource {

    @Autowired
    private CorrespondancesService correspondancesService;

    @GET
    @ApiOperation(value = "Récupération des processus par tete de périmetre", notes = "Récupération des processus par tete de périmetre")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les processus sont bien récupérées")
    })
    @Path("/processus")
    public Response getProcessusByTetePerimetre(@QueryParam(value = "tetePerimetres") List<Long> codeTetePerimetres, @QueryParam(value = "source") Source source) {
        return Response.ok(correspondancesService.getProcessusByTetePerimetre(codeTetePerimetres, source)).build();
    }

    @GET
    @ApiOperation(value = "Récupération des correspondances par tete de périmetre", notes = "Récupération des correspondances par tete de périmetre")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les correspondances sont bien récupérées")
    })
    public Response getCorrespondanceByTetePerimetre(@QueryParam(value = "tetePerimetres")  List<Long> codeTetePerimetres) {
        return Response.ok(correspondancesService.getAllCorrespondanceByTetePerimetre(codeTetePerimetres)).build();
    }

    @POST
    @ApiOperation(value = "Créer une correspondance", notes = "Créer une correspondance")
    @ApiResponses({
            @ApiResponse(code = 201, message = "La correspondance est bien créé"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response saveCorrespondances(CorrespondanceActiviteDto correspondanceActiviteDto) {
        correspondancesService.saveCorrespondances(correspondanceActiviteDto);
        return Response.noContent().build();
    }
}
