package com.socgen.eqc.infrastructure.persistance;

import com.socgen.eqc.domain.model.ExtensionPerimetre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExtensionPerimetreRepository extends JpaRepository<ExtensionPerimetre, Long> {

}
