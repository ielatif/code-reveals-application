package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.CollaborateurService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.constraints.NotBlank;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/collaborateurs")
@Slf4j
@Api(value = "collaborateurs")
public class CollaborateurResource {

    @Autowired
    private CollaborateurService collaborateurService;

    @DELETE
    @ApiOperation(value = "Suppression d'un collaborateur", notes = "Suppression d'un collaborateur")
    @ApiResponses({
            @ApiResponse(code = 200, message = "La suppression a été bien faite")
    })
    public Response remove(@QueryParam("matricule") @NotBlank String matricule) {
        collaborateurService.remove(matricule);
        return Response.ok().build();
    }

}
