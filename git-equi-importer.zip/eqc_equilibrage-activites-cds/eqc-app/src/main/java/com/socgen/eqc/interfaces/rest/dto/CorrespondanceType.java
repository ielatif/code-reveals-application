package com.socgen.eqc.interfaces.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum CorrespondanceType {

    PROCESSUS("PROCESSUS"),
    PROCESSUS_NATURE("PROCESSUS_NATURE"),
    PROCESSUS_TACHE("PROCESSUS_TACHE"),
    PROCESSUS_NATURE_TACHE("PROCESSUS_NATURE_TACHE");


    @Getter
    private String type;
}
