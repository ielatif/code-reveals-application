package com.socgen.eqc.application.impl;

import com.socgen.eqc.application.AffectationService;
import com.socgen.eqc.application.AffiliationService;
import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Competence;
import com.socgen.eqc.domain.model.Expertise;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.infrastructure.persistance.AffectationRepository;
import com.socgen.eqc.infrastructure.persistance.CompetenceRepository;
import com.socgen.eqc.interfaces.rest.dto.Action;
import com.socgen.eqc.interfaces.rest.dto.ActionAffectationDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.mapper.ActionMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.DAYS;

@Service
@RequiredArgsConstructor
public class AffectationServiceImpl implements AffectationService {

    private final AffectationRepository affectationRepository;
    private final ActionMapper actionMapper;
    private final AffiliationService affiliationService;
    private final CompetenceRepository competenceRepository;

    @Override
    public List<Affectation> updateOrDelete(List<ActionAffectationDto> actionAffectations) {
        Map<Action, List<ActionAffectationDto>> actionListMap = actionAffectations.stream()
                .collect(Collectors.groupingBy(ActionAffectationDto::getAction));
        List<ActionAffectationDto> actionAffectationDtoToSave = actionListMap
                .getOrDefault(Action.CREATE, new ArrayList<>());
        actionAffectationDtoToSave.addAll(actionListMap.getOrDefault(Action.UPDATE, new ArrayList<>()));
        List<Affectation> affectationToSave = actionMapper.toAffectations(actionAffectationDtoToSave);
        List<ActionAffectationDto> actionAffectationDtoToDelete = actionListMap
                .getOrDefault(Action.DELETE, new ArrayList<>());
        affectationToSave = affectationToSave.stream().map(affectation -> {
            Optional<Affectation> affectationDb = getAffectationFromDb(affectation);
            affectation.setId(affectationDb.map(Affectation::getId).orElse(null));
            return affectation;
        }).collect(Collectors.toList());
        List<Affectation> affectationList = affectationRepository.saveAll(affectationToSave);
        List<Affectation> affectations = actionMapper.toAffectations(actionAffectationDtoToDelete);
        affectationRepository
                .deleteAllByIdIn(affectations.stream().map(Affectation::getId).collect(Collectors.toList()));
        return affectationList;
    }

    private Optional<Affectation> getAffectationFromDb(Affectation affectation) {
        return affectation.getAffiliation() == null ? affectationRepository
                .findByDateAndRenfortIdAndActiviteCode(affectation.getDate(), affectation.getRenfort().getId(), affectation
                        .getActivite().getCode()) : affectationRepository
                .findByDateAndAffiliationIdAndActiviteCode(affectation.getDate(), affectation.getAffiliation()
                        .getId(), affectation.getActivite().getCode());
    }

    @Override
    public Set<Affectation> getAffectationsForRenfort(Long renfortId) {
        return affectationRepository.findByRenfortId(renfortId);
    }

    @Override
    public void removeAll(Affiliation affiliation) {
        affectationRepository.deleteByAffiliationIdAndDateAfter(affiliation.getId(), LocalDate.now().minusDays(1));
    }

    @Override
    public void removeAll(List<Renfort> renforts) {
        List<Long> renfortIds = renforts.stream().map(Renfort::getId).collect(Collectors.toList());
        affectationRepository.deleteByRenfortIdInAndDateAfter(renfortIds, LocalDate.now().minusDays(1));
    }

    @Override
    @Transactional
    public List<Affectation> findByAffiliationsAndPlanningSearchDto(List<Affiliation> affiliations, PlanningSearchDto planningSearch) {
        List<Long> affiliationsIds = affiliations.stream().map(Affiliation::getId).collect(Collectors.toList());
        return affectationRepository
                .findByAffiliationIdInAndDateBetween(affiliationsIds, planningSearch.getDateDebut(), planningSearch
                        .getDateFin());
    }

    @Override
    public List<Affectation> findByRenfortsAndDates(List<Renfort> renfortsEntrant, LocalDate dateDebut, LocalDate dateFin) {
        List<Long> idRenforts = renfortsEntrant.stream().map(Renfort::getId).collect(Collectors.toList());
        return affectationRepository.findByRenfortIdInAndDateBetween(idRenforts, dateDebut, dateFin);
    }

    @Override
    public void updateCapaciteTheorique(String matricule, List<Competence> listUpdateCompetence) {
        List<Affectation> listAffectationByMatricule = affectationRepository
                .findAllByMatricule(matricule, LocalDate.now());
        listUpdateCompetence.forEach(competence -> {
            List<Affectation> listAffectationToupdate = listAffectationByMatricule.stream()
                    .filter(affectation -> filterAffectation(competence, affectation))
                    .map(affectation -> {
                        updateAffectation(competence, affectation);
                        return affectation;
                    }).collect(Collectors.toList());
            affectationRepository.saveAll(listAffectationToupdate);
        });
    }

    @Override
    public void saveAll(List<Affectation> affectations) {
        affectationRepository.saveAll(affectations);
    }

    private Affectation updateAffectation(Competence competence, Affectation affectation) {
        Float nbrDossier = competence.getExpertise().getNombreDossier() == null ? 0 : competence.getExpertise()
            .getNombreDossier();
        affectation.setNombreDossier((double) (affectation.getPourcentage() * nbrDossier) / 100);
        affectation.setExpertise(competence.getExpertise());
        return affectation;
    }

    private boolean filterAffectation(Competence competence, Affectation affectation) {
        return affectation.getActivite().getCode().equals(competence.getExpertise().getActivite().getCode());
    }

    @Override
    public void dupliquerSemaine(LocalDate dateDebutSemaineSource, LocalDate dateDebutSemaineCible, List<String> matricules) {
        var listAffiliations = affiliationService.findActiveByMatricules(matricules);
        var listAffectationSource = findByAffiliationsAndDates(listAffiliations, dateDebutSemaineSource, dateDebutSemaineSource
                .plusDays(6)).stream().filter(affectation -> Objects.isNull(affectation.getActivite().getMaskDate()))
                .collect(Collectors.toList());
        var listAffectationCible = findByAffiliationsAndDates(listAffiliations, dateDebutSemaineCible, dateDebutSemaineCible
                .plusDays(6));
        var mapAffectationSource = getMapAffectation(listAffectationSource);
        var mapAffectationCible = getMapAffectation(listAffectationCible);

        mapAffectationSource.forEach((key, value) -> mapAffectationCible.merge(key, value, (v1, v2) -> v1));

        var listAffectationTosave = getListAffectationTosave(matricules, dateDebutSemaineSource, dateDebutSemaineCible, listAffectationCible, mapAffectationCible);

        affectationRepository.saveAll(listAffectationTosave);
    }

	@Override
    public List<Affectation> findByAffiliationsAndDates(List<Affiliation> affiliations, LocalDate dateDebut, LocalDate dateFin) {
        List<Long> affiliationsIds = affiliations.stream().map(Affiliation::getId).collect(Collectors.toList());
        return affectationRepository.findByAffiliationIdInAndDateBetween(affiliationsIds, dateDebut, dateFin);
    }

    @Override
    public void updateCapaciteTheorique(Set<Expertise> expertises) {
        List<Affectation> affectationList = affectationRepository
                .findByExpertiseIdInAndDateAfter(expertises.stream().map(Expertise::getId)
                        .collect(Collectors.toList()), LocalDate.now().minusDays(1));
        List<Affectation> affectations = affectationList.stream().map(affectation -> {
            Float nbDossierExpertise = affectation.getExpertise().getNombreDossier();
            double nombreDossier = nbDossierExpertise == null ? 0d : (affectation.getPourcentage()
                    .doubleValue() * nbDossierExpertise.doubleValue() / 100);
            affectation.setNombreDossier(nombreDossier);
            return affectation;
        }).collect(Collectors.toList());
        affectationRepository.saveAll(affectations);
    }

    private Map<String, List<Affectation>> getMapAffectation(List<Affectation> affectationSource) {
        return affectationSource.stream().collect(Collectors
            .groupingBy(affectation -> new StringJoiner("-").add(affectation.getActivite().getCode())
                .add(affectation.getAffiliation().getCollaborateur().getMatricule())
                .add(affectation.getDate().getDayOfWeek().toString()).toString()));
    }

    private int getOrdreForDuplication(List<Affectation> listAffectation, Affectation duplicatedAffectation) {
        int maxOrder = listAffectation.stream()
		        .filter(affectation -> {
			        String affectationMatricule = affectation.getAffiliation().getCollaborateur().getMatricule();
			        String duplicatedAffectationMatricule = duplicatedAffectation.getAffiliation().getCollaborateur().getMatricule();
			        return affectation.getDate().isEqual(duplicatedAffectation.getDate()) &&
					        affectationMatricule.equalsIgnoreCase(duplicatedAffectationMatricule);
		        })
		        .mapToInt(Affectation::getOrdre)
		        .max().orElse(0);

        return duplicatedAffectation.getOrdre() + maxOrder + 1;
    }

	private double getNombreDossierForDuplication(List<Competence> competences, Affectation affectation) {
		var mapCompetencesByMatricule = competences.stream().collect(Collectors.groupingBy(competence -> competence.getCollaborateur().getMatricule()));
		Optional<Expertise> optionalExpertise =
				mapCompetencesByMatricule.getOrDefault(affectation.getAffiliation().getCollaborateur().getMatricule(),Collections.emptyList())
						.stream().map(Competence::getExpertise)
						.filter(e -> e.getActivite().getCode().equalsIgnoreCase(affectation.getActivite().getCode()))
						.findFirst();
		Float nbDossierExpertise = optionalExpertise.map(Expertise::getNombreDossier).orElseGet(() -> affectation.getExpertise().getNombreDossier());
		return nbDossierExpertise == null ? 0 : (double) affectation.getPourcentage() * nbDossierExpertise / 100;
	}

	private List<Affectation> getListAffectationTosave(List<String> matricules, LocalDate dateDebutSemaineSource,
	                                                   LocalDate dateDebutSemaineCible, List<Affectation> listAffectationCible,
	                                                   Map<String, List<Affectation>> mapAffectationCible) {
		var mapCompetencesByMatricule = competenceRepository.findByCollaborateurMatriculeIn(matricules);
		return mapAffectationCible.values()
				.stream()
				.flatMap(Collection::stream)
				.filter(affectation -> DAYS.between(affectation.getDate(), dateDebutSemaineCible.plusDays(6)) > 6)
				.filter(affectation -> affectation.getDate().plusDays(DAYS.between(dateDebutSemaineSource, dateDebutSemaineCible)).isAfter(LocalDate.now().minusDays(1)))
				.map(affectation -> {
					affectation.setId(null);
					affectation.setDate(affectation.getDate().plusDays(DAYS.between(dateDebutSemaineSource, dateDebutSemaineCible)));
					affectation.setOrdre(getOrdreForDuplication(listAffectationCible, affectation));
					affectation.setNombreDossier(getNombreDossierForDuplication(mapCompetencesByMatricule, affectation));
					if (affectation.getParametresCarte()!=null) affectation.getParametresCarte().setId(null);
					return affectation;
				}).collect(Collectors.toList());
	}

	@Override
	public void supprimerSemaine(SuppressionSemaineDto dto) {
		if (!dto.getMatricules().isEmpty()) {
			affectationRepository.deleteByMatricules(dto.getMatricules(), dto.getDateDebut(), dto.getDateFin(), dto.getCodeServiceTraitement());
		}
		if (!dto.getMatriculesRenfort().isEmpty()) {
			affectationRepository.deleteRenfortEntrant(dto.getMatriculesRenfort(), dto.getDateDebut(), dto.getDateFin(), dto.getCodeServiceTraitement());
		}
	}
}
