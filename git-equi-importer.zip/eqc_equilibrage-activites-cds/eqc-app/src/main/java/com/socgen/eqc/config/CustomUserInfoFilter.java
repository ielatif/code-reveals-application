package com.socgen.eqc.config;

import com.socgen.dga.idp.jaxrs.commons.ConfigKey;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Priority;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.ext.Provider;

@Provider
@Priority(CustomUserInfoFilter.PRIORITY_USER_INFO)
public class CustomUserInfoFilter implements ContainerRequestFilter {

    public static final int PRIORITY_USER_INFO = -11200;

    @Autowired
    private HttpServletRequest servletRequest;

    @Override
    public void filter(ContainerRequestContext requestContext) {
        servletRequest.setAttribute("userInfo", requestContext.getHeaderString("userInfo"));
        servletRequest.setAttribute(HttpHeaders.AUTHORIZATION, requestContext.getHeaderString(HttpHeaders.AUTHORIZATION));
        servletRequest.setAttribute(ConfigKey.X_IBM_CLIENT_ID, requestContext.getHeaderString(ConfigKey.X_IBM_CLIENT_ID));
    }

}
