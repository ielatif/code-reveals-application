package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.annotations.SgSignInRolesAllowed;
import com.socgen.eqc.application.ConsolideMensuelService;
import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.interfaces.rest.dto.ConsolideMensSearch;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.constraints.NotNull;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.LocalDate;

import static com.socgen.eqc.domain.model.RoleEqc.CONSULTER_MOIS;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/consolideMensuel")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Slf4j
public class ConsolideMensuelResource {


    private final ConsolideMensuelService consolideMensuelService;
    private final JobLauncher jobLauncher;
    private final Job cmBatchJob;

    @GET
    @ApiOperation(value = "Récupération du consolidé mensuel par ST", notes = "Récupération du consolidé mensuel par ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Le consolidé mensuel a été bien récupéré")
    })
    @SgSignInRolesAllowed({CONSULTER_MOIS })
    public Response getPlannigByServiceTraitement(@BeanParam ConsolideMensSearch consolideMensSearch) {
        return Response.ok(consolideMensuelService.getConsolideMensuel(consolideMensSearch)).build();
    }

    @POST
    @ApiOperation(value = "Genérer le consolde mensuel", notes = "Genérer le consolde mensuel")
    @ApiResponses({
            @ApiResponse(code = 201, message = "Le consolidé mensuel est bien généré"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response generate(@QueryParam("date") @NotNull LocalDate date) {

        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
                .addLong("date", date.toEpochDay()).toJobParameters();
        try {
            JobExecution run = jobLauncher.run(cmBatchJob, jobParameters);
            log.info("JobExecution : {}", run.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
            throw new BusinessException("Erreur lors du lancement du batch ", e);
        }
        return Response.ok().build();
    }
}
