package com.socgen.eqc.application;

import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.interfaces.rest.dto.ActionAffectationDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface AffectationService {

    Set<Affectation> getAffectationsForRenfort(Long renortId);

    void removeAll(Affiliation matricule);

    void removeAll(List<Renfort> renforts);

    List<Affectation> findByAffiliationsAndPlanningSearchDto(List<Affiliation> affiliations, PlanningSearchDto planningSearch);

    List<Affectation> findByAffiliationsAndDates(List<Affiliation> affiliations, LocalDate dateDebut, LocalDate dateFin);

    List<Affectation> findByRenfortsAndDates(List<Renfort> renfortsEntrant, LocalDate dateDebut, LocalDate dateFin);

    void updateCapaciteTheorique(String matricule, List<Competence> listUpdateCompetence);

    void saveAll(List<Affectation> affectations);

    void dupliquerSemaine(LocalDate dateDebutSemaineSource,LocalDate dateDebutSemaineCible, List<String> matricules);

    void updateCapaciteTheorique(Set<Expertise> expertises);

    List<Affectation> updateOrDelete(List<ActionAffectationDto> actionAffectations);

    void supprimerSemaine(SuppressionSemaineDto suppressionSemaineDto);
}

