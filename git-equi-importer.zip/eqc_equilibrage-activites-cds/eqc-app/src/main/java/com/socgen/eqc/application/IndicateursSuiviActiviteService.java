package com.socgen.eqc.application;

import com.google.gson.JsonObject;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;

public interface IndicateursSuiviActiviteService {
    JsonObject getIndicateurSuiviActivite(IndicateurInputDto indicateurInputDto);
}
