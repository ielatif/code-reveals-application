package com.socgen.eqc.infrastructure.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Builder
@Data
public class AffectationConsolide {

    private LocalDate date;

    private Long pourcentage;

    private String matricule;

    private String codeActivite;
}
