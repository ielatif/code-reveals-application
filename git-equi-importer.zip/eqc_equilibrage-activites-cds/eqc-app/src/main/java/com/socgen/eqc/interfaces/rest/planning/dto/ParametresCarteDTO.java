package com.socgen.eqc.interfaces.rest.planning.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ParametresCarteDTO {

    private String commentPrincipale;
    private String commentSecondaire;
    private String customStyle;
}
