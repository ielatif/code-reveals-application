package com.socgen.eqc.infrastructure.smbo;

import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.smbo.dto.*;
import com.socgen.eqc.interfaces.rest.dto.IncidentDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurActiviteDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ActiviteSmboDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.TetePerimetreDto;
import com.socgen.eqc.interfaces.rest.error.ErrorDto;
import com.socgen.eqc.interfaces.rest.error.ExternServiceException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

@Slf4j
@AllArgsConstructor
public class SmboClientImpl implements SmboClient {

    public static final String PATH_CORRESPONDANCE_ACTIVITE = "correspondance-activite";
    public static final String PATH_PROCESSUS = "processus";
    public static final String PATH_TETE_PERIMETRE = "tetePerimetre";
    public static final String PATH_FAMILLES = "familles";
    public static final String LIST_CODE_SERVICE_TRAITEMENT = "listCodeServiceTraitement";
    public static final String DATE_DEBUT = "dateDebut";
    public static final String DATE_FIN = "dateFin";
    public static final String TETE_PERIMETRE = "tetePerimetre";
    public static final String SOURCE = "source";
    public static final String INDICATEURS = "indicateurs";
    public static final String INDICATEURS_SUIVIE_ACTIVITE = INDICATEURS + "-suivi-activite";
    public static final String PATH_INCIDENT = "incidents";
    private static final String EMPTY_STRING = "";
    public static final String PATH_SAISIE_GLOBALE = "saisie-globale";

    private final Client smboClient;
    private final ApplicationProperties applicationProperties;

    @Override
    public RefActiviteDto saveActivite(RefActiviteDto refActiviteDto) {
        try {
            Assert.hasText(refActiviteDto.getCodeFamille(), "code Famille should be not blank");
            String path = "familles/" + refActiviteDto.getCodeFamille() + "/activites";
            Invocation.Builder invocationBuilder = getInvocationBuilder(refActiviteDto.getCode() == null ? path : String.format("%s/%s", path, refActiviteDto.getCode()));
            Entity<RefActiviteDto> entity = Entity.json(
                    refActiviteDto);
            Response response = refActiviteDto.getCode() == null ? invocationBuilder
                    .post(entity) : invocationBuilder
                    .put(entity);
            GenericType<RefActiviteDto> activiteSmboDtoType = new GenericType<>() {
            };
            return handleResponse(response, activiteSmboDtoType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return new RefActiviteDto();
    }

    @Override
    public List<TetePerimetreDto> getAllTetePerimetres() {
        try {
            String path = applicationProperties.getSmbo().getReferentielTetePerimetrePath();
            Response response = getInvocationBuilder(path).get();
            GenericType<List<TetePerimetreDto>> listTetePerimetres = new GenericType<>() {
            };
            return handleResponse(response, listTetePerimetres);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();
    }

    @Override
    public List<ReferentielProcessusDto> getAllProcessusByTetePerimetre(List<Long> codeTetePerimetres, Source source) {
        try {
            UriBuilder uriBuilder = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_PROCESSUS);
            codeTetePerimetres.forEach(tetePerimetre -> uriBuilder.queryParam(PATH_TETE_PERIMETRE, tetePerimetre));
            uriBuilder.queryParam(SOURCE, source);
            Response response = smboClient.target(uriBuilder.build()).request(MediaType.APPLICATION_JSON_TYPE).get();
            GenericType<List<ReferentielProcessusDto>> listProcessusType = new GenericType<>() {
            };
            return handleResponse(response, listProcessusType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();
    }

    @Override
    public List<RefFamilleDto> getAllFamilles() {
        try {
            URI path = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_FAMILLES).build();
            Response response = smboClient.target(path).request(MediaType.APPLICATION_JSON_TYPE).get();
            GenericType<List<RefFamilleDto>> listProcessusType = new GenericType<>() {
            };
            return handleResponse(response, listProcessusType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();
    }

    @Override
    public List<IndicateurActiviteDto> getIndicateurBrut(List<String> listCodeServiceTraitement, LocalDate dateDebut, LocalDate dateFin, List<String> tetePerimetres) {
        try {
            UriBuilder uriBuilder = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(INDICATEURS)
                    .queryParam(DATE_DEBUT, dateDebut)
                    .queryParam(DATE_FIN, dateFin);

            listCodeServiceTraitement.forEach(codeSt -> uriBuilder.queryParam(LIST_CODE_SERVICE_TRAITEMENT, codeSt));
            tetePerimetres.forEach(tp -> uriBuilder.queryParam(TETE_PERIMETRE, tp));

            Response response = smboClient.target(uriBuilder.build()).request(MediaType.APPLICATION_JSON_TYPE).get();
            GenericType<List<IndicateurActiviteDto>> listActiviteSmboDtoType = new GenericType<>() {
            };
            return handleResponse(response, listActiviteSmboDtoType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();
    }

    public RefFamilleDto saveFamilles(RefFamilleDto refFamilleDto) {
        try {
            URI path = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_FAMILLES).build();
            Response response = smboClient.target(path).request(MediaType.APPLICATION_JSON_TYPE).post(Entity.json(
                    refFamilleDto));
            GenericType<RefFamilleDto> listProcessusType = new GenericType<>() {
            };
            return handleResponse(response, listProcessusType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return new RefFamilleDto();
    }

    @Override
    public void saveCorrespondances(CorrespondanceActiviteDto correspondanceActiviteDto) {
        try {
            Response response = getInvocationBuilder(PATH_CORRESPONDANCE_ACTIVITE)
                    .post(Entity.json(correspondanceActiviteDto));
            GenericType<ActiviteSmboDto> activiteSmboDtoType = new GenericType<>() {
            };
            handleResponse(response, activiteSmboDtoType);
        } catch (Exception e) {
            handleExceptions(e);
        }
    }

    @Override
    public List<CorrespondanceActiviteDto> getAllCorrespondanceByTetePerimetre(List<Long> tetePerimetres) {
        try {
            UriBuilder uriBuilder = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_CORRESPONDANCE_ACTIVITE);
            tetePerimetres.forEach(tetePerimetre -> uriBuilder.queryParam(PATH_TETE_PERIMETRE, tetePerimetre));
            Response response = smboClient.target(uriBuilder.build()).request(MediaType.APPLICATION_JSON_TYPE).get();
            GenericType<List<CorrespondanceActiviteDto>> correspondanceActiviteType = new GenericType<>() {
            };
            return handleResponse(response, correspondanceActiviteType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();
    }

    @Override
    public List<RefFamilleDto> updateListFamille(List<RefFamilleDto> famillesDto) {

        try {
            URI path = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_FAMILLES).build();
            Response response = smboClient.target(path).request(MediaType.APPLICATION_JSON_TYPE).put(Entity.json(
                    famillesDto));
            GenericType<List<RefFamilleDto>> listProcessusType = new GenericType<>() {
            };
            return handleResponse(response, listProcessusType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();

    }

    @Override
    public List<IncidentDto> getIncident() {
        try {
            URI path = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_INCIDENT).build();
            Response response = smboClient.target(path).request(MediaType.APPLICATION_JSON_TYPE).get();
            GenericType<List<IncidentDto>> incidentDto = new GenericType<>() {
            };
            return handleResponse(response, incidentDto);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();
    }

    @Override
    public SaisieGlobaleOutputDto addStockSaisieGlobale(SaisieGlobaleInputDto saisieGlobaleInputDto) {

        try {
            URI path = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_SAISIE_GLOBALE).build();
            Response response = smboClient.target(path).request(MediaType.APPLICATION_JSON_TYPE).post(Entity.json(
                    saisieGlobaleInputDto));
            GenericType<SaisieGlobaleOutputDto> listProcessusType = new GenericType<SaisieGlobaleOutputDto>() {
            };
            return handleResponse(response, listProcessusType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return new SaisieGlobaleOutputDto();
    }

    @Override
    public List<SaisieGlobaleStockOutputDto> getSaisieGlobaleIndicateurs(List<Long> tetePerimtres, String codeSt, String userId) {
        try {

            UriBuilder uriBuilder = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(
                    new StringBuilder(PATH_SAISIE_GLOBALE)
                            .append("/").append(INDICATEURS).toString()
            )
                    .queryParam("codeSt", codeSt)
                    .queryParam("userId", userId);
            tetePerimtres.forEach(tetePerimetre -> uriBuilder.queryParam(PATH_TETE_PERIMETRE, tetePerimetre));
            Response response = smboClient.target(uriBuilder.build()).request(MediaType.APPLICATION_JSON).get();
            GenericType<List<SaisieGlobaleStockOutputDto>> indicateurs = new GenericType<>() {
            };
            return handleResponse(response, indicateurs);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return Collections.emptyList();
    }

    private Invocation.Builder getInvocationBuilder(String stringPath) {
        URI path = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(stringPath).build();
        log.info("call Smbo {} ", path);
        return smboClient.target(path).request(MediaType.APPLICATION_JSON_TYPE);
    }

    private <T> T handleResponse(Response response, GenericType<T> genericType) {
        try (response) {
            if (response.getStatusInfo().getFamily() != Response.Status.Family.SUCCESSFUL) {
                log.error("Une erreur s'est produite lors de l'appel au référentiel d'activité, status {} ", response.getStatus());
                ErrorDto errorDto = response.readEntity(ErrorDto.class);
                throw new ExternServiceException(errorDto.getMessageFonctionnel());
            }
            return response.readEntity(genericType);
        }
    }

    private void handleExceptions(Exception e) {
        if (e.getCause() instanceof SocketTimeoutException) {
            log.error("Erreur technique, TimeOut SMBO, une relance sera executée", e);
            throw new ExternServiceException("Erreur technique, problème d'accès à l'application SMBO");
        }
        log.error("Une erreur s'est produite lors de l'appel au référentiel d'activité", e);
        throw new BusinessException(e.getLocalizedMessage());
    }

    public RefProcessusOutputDto saveOrUpdateProcessus(RefProcessusInputDto processus) {
        try {
            URI path = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(PATH_PROCESSUS).build();
            Response response = smboClient.target(path).request(MediaType.APPLICATION_JSON_TYPE).post(Entity.json(processus));
            GenericType<RefProcessusOutputDto> listProcessusType = new GenericType<RefProcessusOutputDto>() {
            };
            return handleResponse(response, listProcessusType);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return new RefProcessusOutputDto();
    }

    @Override
    public String getIndicateurSuivieActivite(String dateDebut, String dateFin, List<String> tetePerimetre, List<String> listCodeServiceTraitement) {
        try {
            UriBuilder uriBuilder = UriBuilder.fromPath(applicationProperties.getSmbo().getServerUrl()).path(INDICATEURS_SUIVIE_ACTIVITE)
                    .queryParam(DATE_DEBUT, dateDebut)
                    .queryParam(DATE_FIN, dateFin);

            tetePerimetre.forEach(tetPerimtre -> uriBuilder.queryParam(TETE_PERIMETRE, tetPerimtre));
            listCodeServiceTraitement.forEach(listCodeSt -> uriBuilder.queryParam(LIST_CODE_SERVICE_TRAITEMENT, listCodeSt));

            Response response = smboClient.target(uriBuilder.build()).request(MediaType.APPLICATION_JSON).get();
            GenericType<String> jsonIndicateurSuivieActivite = new GenericType<>() {
            };
            return handleResponse(response, jsonIndicateurSuivieActivite);
        } catch (Exception e) {
            handleExceptions(e);
        }
        return EMPTY_STRING;
    }

}
