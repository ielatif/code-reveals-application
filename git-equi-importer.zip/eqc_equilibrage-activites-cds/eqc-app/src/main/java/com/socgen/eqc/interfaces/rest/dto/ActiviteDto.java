package com.socgen.eqc.interfaces.rest.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ActiviteDto {

    private Long id;
    private String code;
    private String libelle;
    private LocalDate date;
    private Long pourcentage;
    private String tetePerimetre;
    private String famille;
}