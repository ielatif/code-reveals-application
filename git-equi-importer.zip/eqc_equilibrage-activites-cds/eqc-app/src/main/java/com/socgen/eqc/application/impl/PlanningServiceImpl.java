package com.socgen.eqc.application.impl;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.*;
import com.socgen.eqc.domain.model.*;
import com.socgen.eqc.interfaces.rest.dto.*;
import com.socgen.eqc.interfaces.rest.planning.dto.CompetenceDto;
import com.socgen.eqc.interfaces.rest.planning.dto.*;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;

@Service
@RequiredArgsConstructor
@Slf4j
public class PlanningServiceImpl implements PlanningService {

    private final CollaborateurService collaborateurService;
    private final EquipeService equipeService;

    private final AffiliationService affiliationService;
    private final AffectationService affectationService;
    private final RenfortService renfortService;
    private final AbsenceService absenceService;
    private final CompetenceService competenceService;

    @Override
    public PlanningStDto findByPlanningSearchDto(PlanningSearchDto planningSearch) {
        // Affiliations
        List<Affectation> affectationAffiliation = emptyList();
        List<Collaborateur> collaborateursAffiliation = emptyList();
        List<Competence> profilesCollaborateursAffiliation = emptyList();
        List<Renfort> renfortSortant = emptyList();

        // Renforts entrants
        List<Collaborateur> collaborateursRenfort;
        List<Competence> profilesCollaborateursRenfort = emptyList();

        // Affiliations
        List<Affiliation> affiliations = affiliationService.findByPlanningSearchDto(planningSearch);
        if (!affiliations.isEmpty()) {
            affectationAffiliation = affectationService.findByAffiliationsAndPlanningSearchDto(affiliations, planningSearch);
            collaborateursAffiliation = affiliations.stream().map(Affiliation::getCollaborateur).distinct().collect(Collectors.toList());
            Map<String, List<Affiliation>> affiliationByCollab = affiliations.stream().collect(Collectors.groupingBy(affiliation -> affiliation.getCollaborateur().getMatricule()));
            profilesCollaborateursAffiliation = competenceService.getProfilByCollaborateurs(collaborateursAffiliation, affiliationByCollab);
            renfortSortant = renfortService.findRenfortSortant(planningSearch);
        }

        // Renforts entrants
        List<Renfort> renfortsEntrant = renfortService
            .findRenfortEntrant(singletonList(planningSearch.getCodeServiceTraitement()), planningSearch
                .getDateDebut(), planningSearch.getDateFin());
        if (!renfortsEntrant.isEmpty()) {
            collaborateursRenfort = renfortsEntrant.stream().map(Renfort::getCollaborateur)
                .collect(Collectors.toList());
            Map<String, List<Affiliation>> affiliationByRenfort = new HashMap<>();
            renfortsEntrant.stream().forEach(renfort -> {
                String renfortMatricule = renfort.getCollaborateur().getMatricule();
                List<Affiliation> renfortAffiliations = affiliationService
                        .findByMatriculeAndDateDebutAndDateFin(renfortMatricule, planningSearch.getDateDebut(), planningSearch.getDateFin());

                affiliationByRenfort.put(renfortMatricule, renfortAffiliations);
            });

            profilesCollaborateursRenfort = competenceService.getProfilByCollaborateurs(collaborateursRenfort, affiliationByRenfort);
        }
        // @formatter:off
        return PlanningStDto.builder()
                .affectations(AffectationDto.fromDomain(affectationAffiliation))
                .renforts(RenfortDto.fromDomain(renfortSortant))
                .collaborateurs(CollaborateurDto.fromDomain(collaborateursAffiliation, false))
                .affiliations(AffiliationDto.fromDomain(affiliations))
                .competences(concat(CompetenceDto.fromDomain(profilesCollaborateursRenfort), CompetenceDto.fromDomain(profilesCollaborateursAffiliation)))
                .build();
        // @formatter:on
    }

    private <T> List<T> concat(List<T> list, List<T> list2) {
        return Stream.concat(list.stream(), list2.stream()).collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public UpdatePlaningStResponse update(@NonNull PlanningSearchDto planningSearchDto, @NonNull ActionsPlanningDto actionsPlanningDto, SgUserPrincipal sgUserPrincipal) {
        if (!CollectionUtils.isEmpty(actionsPlanningDto.getActionAffectations())) {
            actionsPlanningDto.getActionAffectations().forEach(affectation -> affectation
                .setCodeServiceTraitement(planningSearchDto.getCodeServiceTraitement()));
        }
        List<Affectation> affectations = affectationService.updateOrDelete(actionsPlanningDto.getActionAffectations());
        List<Renfort> renforts = renfortService.updateOrDelete(actionsPlanningDto.getActionRenforts(), sgUserPrincipal);
        List<Absence> absences = absenceService.updateOrDelete(actionsPlanningDto.getActionAbsences());
        return UpdatePlaningStResponse.builder()
            .absences(AbsenceDto.fromDomain(absences))
            .affectations(AffectationDto.fromDomain(affectations))
            .renforts(RenfortDto.fromDomain(renforts))
            .build();
    }

    @Override
    public void ajouterCollaborateur(@NonNull Long codeEquipe, Long codeCds, Long codeUg, @NonNull List<CollaborateurDto> collaborateurs) {
        Optional<Equipe> findEquipe = equipeService.findByCode(codeEquipe);
        Equipe equipe = findEquipe.orElseGet(() -> equipeService.saveDto(new EquipeDto(codeEquipe, "", codeCds, codeUg, (byte) 5)));
        var affiliations = collaborateurs.stream().map(collaborateurDto -> {
            Collaborateur collaborateur = collaborateurService.save(collaborateurDto);
            String matricule = collaborateur.getMatricule();
            if (affiliationService.hasAffiliation(matricule)) {
                collaborateurService.remove(matricule);
            }
            return Affiliation.builder().dateEntree(LocalDate.now()).collaborateur(collaborateur).equipe(equipe)
                    .build();
        }).collect(Collectors.toList());
        affiliationService.saveAll(affiliations);
    }

    private LocalDate getDateDebutSemaine(LocalDate date) {
        return date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    }
    @Override
    public void dupliquerSemaine(DuplicationDto duplicationDto, SgUserPrincipal sgUserPrincipal) {
        if (!duplicationDto.getMatricules().isEmpty()) {
            var dateDebutSemaineSource = getDateDebutSemaine(duplicationDto.getDateSource());
            var dateDebutSemaineCible = getDateDebutSemaine(duplicationDto.getDateCible());
            affectationService.dupliquerSemaine(dateDebutSemaineSource, dateDebutSemaineCible, duplicationDto.getMatricules());
            renfortService.dupliquerSemaine(dateDebutSemaineSource, dateDebutSemaineCible, duplicationDto.getMatricules(), sgUserPrincipal);
        }
    }

    @Override
    @Transactional
    public void supprimerSemaine(SuppressionSemaineDto suppressionSemaineDto) {
        affectationService.supprimerSemaine(suppressionSemaineDto);
        renfortService.supprimerSemaine(suppressionSemaineDto);
        absenceService.supprimerSemaine(suppressionSemaineDto);
    }

    @Override
    public PlanningStDto findPlanningRenfortByPlanningSearchDto(PlanningSearchDto planningSearch) {
        // Renforts entrants
        List<Affectation> affectationsRenforts = emptyList();
        List<Collaborateur> collaborateursRenfort = emptyList();
        // Renforts entrants
        List<Renfort> renfortsEntrant = renfortService
                .findRenfortEntrant(singletonList(planningSearch.getCodeServiceTraitement()), planningSearch
                        .getDateDebut(), planningSearch.getDateFin());
        if (!renfortsEntrant.isEmpty()) {
            affectationsRenforts = affectationService
                    .findByRenfortsAndDates(renfortsEntrant, planningSearch.getDateDebut(), planningSearch.getDateFin());
            collaborateursRenfort = renfortsEntrant.stream().map(Renfort::getCollaborateur)
                    .collect(Collectors.toList());
        }
        // @formatter:off
        return PlanningStDto.builder()
                .affectations(AffectationDto.fromDomain(affectationsRenforts))
                .renforts(RenfortDto.fromDomain(renfortsEntrant))
                .collaborateurs(CollaborateurDto.fromDomain(collaborateursRenfort, true))
                .build();
        // @formatter:on
    }

}
