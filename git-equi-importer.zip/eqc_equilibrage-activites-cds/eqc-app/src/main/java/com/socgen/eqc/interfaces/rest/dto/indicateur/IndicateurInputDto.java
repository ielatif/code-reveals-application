package com.socgen.eqc.interfaces.rest.dto.indicateur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class IndicateurInputDto {

    @QueryParam("listCodeServiceTraitement")
    @NotNull
    private List<String> listCodeServiceTraitement;

    @QueryParam("tetePerimetre")
    @NotNull
    private List<String> tetePerimetre;

    @QueryParam("dateDebut")
    @NotNull
    private String dateDebut;

    @QueryParam("dateFin")
    @NotNull
    private String dateFin;
}
