package com.socgen.eqc.application;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.interfaces.rest.dto.ActionsPlanningDto;
import com.socgen.eqc.interfaces.rest.dto.DuplicationDto;
import com.socgen.eqc.interfaces.rest.dto.PlanningSearchDto;
import com.socgen.eqc.interfaces.rest.dto.SuppressionSemaineDto;
import com.socgen.eqc.interfaces.rest.planning.dto.CollaborateurDto;
import com.socgen.eqc.interfaces.rest.planning.dto.PlanningStDto;
import com.socgen.eqc.interfaces.rest.planning.dto.UpdatePlaningStResponse;
import lombok.NonNull;

import java.util.List;

public interface PlanningService {

    PlanningStDto findByPlanningSearchDto(PlanningSearchDto planningSearchDto);

    UpdatePlaningStResponse update(PlanningSearchDto planningSearchDto, ActionsPlanningDto actionsPlanningDto, SgUserPrincipal sgUserPrincipal);

    void ajouterCollaborateur(@NonNull Long codeEquipe, Long codeCds, Long codeUg, @NonNull List<CollaborateurDto> collaborateurs);

    void dupliquerSemaine(DuplicationDto duplicationDto, SgUserPrincipal sgUserPrincipal);

    void supprimerSemaine(SuppressionSemaineDto suppressionSemaineDto);

    PlanningStDto findPlanningRenfortByPlanningSearchDto(PlanningSearchDto planningSearch);
}
