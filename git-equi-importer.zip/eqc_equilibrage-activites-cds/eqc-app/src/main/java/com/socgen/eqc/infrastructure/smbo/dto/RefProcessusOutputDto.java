package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class RefProcessusOutputDto implements Serializable {

    private static final long serialVersionUID = 619988598821149051L;

    private String code;

    private String dateCreation;

    @NotBlank
    private String libelle;

    private Source source;

    @NotBlank
    private List<String> codesTetePerimetre;

    private LocalDate dateDesactivation;

    private String informations;

}
