package com.socgen.eqc.domain.model;


import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "COLLABORATEUR")
@Builder
@EqualsAndHashCode(exclude = {"renforts", "affiliations"})
public class Collaborateur implements Serializable {

    private static final long serialVersionUID = 7934660222339286503L;

    @Id
    @Column(name = "MATRICULE", unique = true)
    private String matricule;

    @Column(name = "NOM")
    private String nom;

    @Column(name = "PRENOM")
    private String prenom;

    @Column(name = "LOGIN_WINDOWS", unique = true)
    private String loginWindows;

    @Column(name = "ID_RH_LOCAL", unique = true)
    private String idRhLocal;

    @OneToMany(mappedBy = "collaborateur", fetch = FetchType.LAZY)
    private Set<Affiliation> affiliations;

    @OneToMany(mappedBy = "collaborateur", fetch = FetchType.LAZY)
    private Set<Renfort> renforts;

}
