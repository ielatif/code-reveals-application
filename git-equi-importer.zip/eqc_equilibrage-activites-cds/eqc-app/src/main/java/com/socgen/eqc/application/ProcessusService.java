package com.socgen.eqc.application;

import com.socgen.eqc.infrastructure.smbo.dto.RefProcessusInputDto;
import com.socgen.eqc.infrastructure.smbo.dto.RefProcessusOutputDto;

public interface ProcessusService {

    RefProcessusOutputDto saveOrUpdateProcessus(RefProcessusInputDto processus);

}
