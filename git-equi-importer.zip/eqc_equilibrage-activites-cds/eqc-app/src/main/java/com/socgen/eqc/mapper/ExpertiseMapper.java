package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.DefaultExpertise;
import com.socgen.eqc.domain.model.Expertise;
import com.socgen.eqc.interfaces.rest.dto.CompetenceDto;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.ExpertiseDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.Optional;

@Mapper(componentModel = "spring",
        uses = {NiveauMapper.class},
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ExpertiseMapper {

    @Mapping(target = "isDefault", source = "expertise", qualifiedByName = "getDefaultExpertise")
    ExpertiseDto toDto(Expertise expertise);

    Expertise toDomain(ExpertiseDto dto);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "codeActivite", source = "activite.code")
    @Mapping(target = "idNiveau", source = "niveau.id")
    @Mapping(target = "libelleNiveau", source = "niveau.libelle")
    @Mapping(target = "ordreActivite", source = "activite.ordre")
    CompetenceDto expertiseToCompetenceDto(Expertise expertise);

    @Named("getDefaultExpertise")
    default Boolean getDefaultExpertise(Expertise expertise) {
        if (expertise.getActivite().getDefaultExpertises().isEmpty()) {
            return false;
        }
        Optional<DefaultExpertise> defaultExpertise = expertise.getActivite().getDefaultExpertises()
                .stream().filter(defExpertise -> defExpertise.getDateFin() == null)
                .findFirst();
        return defaultExpertise.filter(value -> expertise.getNiveau().getId().equals(value.getNiveau().getId())).isPresent();
    }
}
