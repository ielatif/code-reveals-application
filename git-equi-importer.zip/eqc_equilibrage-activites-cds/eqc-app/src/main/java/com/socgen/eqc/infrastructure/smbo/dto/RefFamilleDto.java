package com.socgen.eqc.infrastructure.smbo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class RefFamilleDto implements Serializable {

    private static final long serialVersionUID = 619988598821149079L;
    private String code;
    private int ordre;
    @NotBlank
    private String libelle;
    @NotBlank
    private String codeTetePerimetre;
    private Set<RefActiviteDto> activites = new HashSet<>();
    private LocalDate maskDatePilotage;
    private LocalDate maskDateCompetence;
    private String libelleLong;
    private List<String> uniteMesure;
}
