package com.socgen.eqc.infrastructure.ressourceshumaines.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Collaborateur {

    @JsonProperty("matricule")
    private String matricule;
    @JsonProperty("login_windows")
    private String loginWindows;
    @JsonProperty("nom")
    private String nom;
    @JsonProperty("prenom")
    private String prenom;
    @JsonProperty("date_arrive_es")
    private String dateArriveEs;
    @JsonProperty("date_fin_juridique")
    private String dateFinJuridique;
    @JsonProperty("nature_contrat")
    private String natureContrat;
    @JsonProperty("statut_emploi")
    private String statutEmploi;
    @JsonProperty("code_entity_emploi")
    private Long codeEntityEmploi;
    @JsonProperty("label_es")
    private String labelEs;
    @JsonProperty("sg_regime_ouvert")
    private String sgRegimeOuvert;
}
