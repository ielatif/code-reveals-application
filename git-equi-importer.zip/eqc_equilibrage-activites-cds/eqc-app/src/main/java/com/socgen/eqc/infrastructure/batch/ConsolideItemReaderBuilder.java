package com.socgen.eqc.infrastructure.batch;

import com.socgen.eqc.domain.model.Affectation;
import com.socgen.eqc.infrastructure.persistance.AffectationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.data.builder.RepositoryItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Configuration
public class ConsolideItemReaderBuilder {


    @Bean
    @StepScope
    public RepositoryItemReader<Affectation> reader(AffectationRepository repository, @Value("#{jobParameters['date']}") Long date) {

        log.info("date: {}", LocalDate.ofEpochDay(date));
        Map<String, Sort.Direction> sorts = new HashMap<>();
        sorts.put("id", Sort.Direction.ASC);
        List<LocalDate> parameters = new ArrayList<>();
        LocalDate month = LocalDate.now().minusMonths(1);
        if (date != null) {
            month = LocalDate.ofEpochDay(date);
        }
        parameters.add(month.with(TemporalAdjusters.firstDayOfMonth()));
        parameters.add(month.with(TemporalAdjusters.lastDayOfMonth()));
        return new RepositoryItemReaderBuilder<Affectation>().methodName("findAllByDateBetween").repository(repository)
                .name("ConsolideItemReader").arguments(parameters).sorts(sorts).build();
    }

}
