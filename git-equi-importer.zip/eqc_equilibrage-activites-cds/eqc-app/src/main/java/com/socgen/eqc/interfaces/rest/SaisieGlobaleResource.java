package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.SaisieGlobaleService;
import com.socgen.eqc.infrastructure.smbo.dto.SaisieGlobaleInputDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/saisie-globale")
@Api(value = "saisie-globale")
@Slf4j
public class SaisieGlobaleResource {

    @Autowired
    private SaisieGlobaleService saisieGlobaleService;


    @GET
    @Path("/indicateurs")
    @ApiOperation(value = "Récupération des indicateurs saisie globale", notes = "Récupération des indicateurs saisie globale")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les processus sont bien récupérés")
    })
    public Response getIndicateurs(@QueryParam(value = "tetePerimetres") List<Long> tetePerimetres,
                                   @QueryParam(value = "codeSt") String codeSt, @BeanParam SgUserPrincipal sgUserPrincipal) {

        return Response.ok(saisieGlobaleService.getIndicateurs(tetePerimetres, codeSt, sgUserPrincipal))
                .build();
    }


    @POST
    @ApiOperation(value = "Ajouter du stock à un processus saisie globale", notes = "Ajouter du stock à un processus saisie globale")
    @ApiResponses({
            @ApiResponse(code = 201, message = "Le stock a été bien rajouté"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response addStock(@Valid SaisieGlobaleInputDto saisieGlobaleInputDto) {
        return Response.status(Response.Status.CREATED)
                .entity(saisieGlobaleService.addStock(saisieGlobaleInputDto))
                .build();
    }
}
