package com.socgen.eqc.interfaces.rest.dto.referentiel.activite;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.socgen.eqc.domain.model.Niveau;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DefaultExpertiseDto implements Serializable {

    private static final long serialVersionUID = 4803506881790420738L;
    private Long id;
    private Niveau niveau;
    private LocalDate dateDebut;
    private LocalDate dateFin;
}
