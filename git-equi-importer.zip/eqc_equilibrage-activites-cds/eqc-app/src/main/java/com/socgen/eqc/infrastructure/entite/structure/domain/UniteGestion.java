package com.socgen.eqc.infrastructure.entite.structure.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UniteGestion extends EntiteStructure implements Serializable {

    private static final long serialVersionUID = -3133837705266511148L;

    @JsonProperty("id")
    private String id;

    @JsonProperty("libelle")
    private String libelle;

    private String ville;

    @JsonProperty("sts")
    private List<ServiceTraitement> serviceTraitements;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UniteGestion that = (UniteGestion) o;
        return Objects.equals(id, that.id) && Objects.equals(libelle, that.libelle) && Objects.equals(ville, that.ville);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, libelle, ville);
    }
}
