package com.socgen.eqc.infrastructure.batch.service;

import com.socgen.eqc.infrastructure.batch.domain.ConsolideMensuel;
import com.socgen.eqc.infrastructure.batch.dto.AffectationDto;
import com.socgen.eqc.infrastructure.batch.dto.AffectationEqcTotal;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ConsolideIntraUgService implements CommonService {

    /**
     * Calculer le consolide Mensuel pour le ST Actif
     * en prenant en compte les renforts Intra UGgetTauxActiviteSumeau
     * @param affectationDtos
     * @param mapCumulMensRenfortInterUg
     * @return
     */
    public Map<Long, List<ConsolideMensuel>> builConsolideForEquipeAndIntraUg(List<? extends AffectationDto> affectationDtos,
                                                                               Map<String, Long> mapCumulMensRenfortInterUg,
                                                                              Map<String, Double> listPresenceByMatricule,
                                                                              Long date) {

        Map<Long, List<ConsolideMensuel>> affectationsOnlyRenfort = new HashMap<>();
        Map<Long, List<ConsolideMensuel>> affectationsEqpAndRenfort;

        List<? extends AffectationDto> affectationDtosEquipe = affectationDtos.stream()
                .filter(affectation -> affectation.getRenfort() == null)
                .collect(Collectors.toList());

        Map<Long, List<AffectationDto>> affectationsByST = buildAffectationByST((List<AffectationDto>) affectationDtosEquipe);

        Map<Long, List<AffectationDto>> affectRenfortIntraUg = buildAffecRenfortSortantIntraUg(affectationDtos);

        //Calcul du consolide pour les collaborateurs qui travaillent dans des services traitements qui ne font que du renfort
        if (affectationsByST.size()> 0) {
            affectationsOnlyRenfort = affectRenfortIntraUg.entrySet().stream()
                    .filter(elemStKey -> affectationsByST.get(elemStKey.getKey()) == null)
                    .collect(Collectors.toMap(Map.Entry::getKey, affectRenfortBySt -> {

                        Map<String, List<AffectationDto>> mapAffecByMatricule = affectRenfortBySt.getValue().stream()
                                .collect(Collectors.groupingBy(AffectationDto::getMatricule));

                        Map<String, List<AffectationEqcTotal>> affecEqcTotByMatricule = buildAffecEqcTotal(mapAffecByMatricule, affectRenfortBySt.getKey());

                        return buildListConsolideMensuel(regroupAffectationByMatriculeAndSumeauActivite(affecEqcTotByMatricule),
                                listPresenceByMatricule, false, mapCumulMensRenfortInterUg, date);
                    }));
        }


        affectationsEqpAndRenfort = getAffectations(affectationsByST, affectRenfortIntraUg, !affectationsByST.isEmpty()).entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, affectByST -> {

                    Map<String, List<AffectationDto>> mapAffecByMatricule = combineAffecRenfortIntraUgAndEquipe(affectByST,
                            getAffectations(affectationsByST, affectRenfortIntraUg, affectationsByST.size() == 0));

                    Map<String, List<AffectationEqcTotal>> affecEqcTotByMatricule = buildAffecEqcTotal(mapAffecByMatricule, affectByST.getKey());

                    return buildListConsolideMensuel(regroupAffectationByMatriculeAndSumeauActivite(affecEqcTotByMatricule),
                            listPresenceByMatricule, false, mapCumulMensRenfortInterUg, date);
                }));

        return flatMapWithSameKey(affectationsEqpAndRenfort, affectationsOnlyRenfort);
    }


    /**
     * Grouper les affectations par ST et supprimer les affectations qui n'ont pas de
     * correspondance d'activités Sumeau afin de faciliter le traitement de calcul
     *
     * @param affectationDtos
     * @return
     */
    private Map<Long, List<AffectationDto>> buildAffectationByST(List<AffectationDto> affectationDtos) {
        return affectationDtos.stream().filter(Objects::nonNull)
                .collect(Collectors.groupingBy(AffectationDto::getIdServiceTraitement));
    }

    /**
     * Récupérer la liste des affectations pour le Renfort Sortant intra UG
     *
     * @param affectationDtos
     * @return
     */
    private Map<Long, List<AffectationDto>> buildAffecRenfortSortantIntraUg(List<? extends AffectationDto> affectationDtos) {

        return affectationDtos.stream()
                .filter(affectationDto -> affectationDto.getRenfort() != null)
                .filter(affectationDto -> affectationDto.getRenfort().isRenfortIntraUg())
                .collect(Collectors.groupingBy(AffectationDto::getIdServiceTraitement));
    }

    /**
     * Générer une map contenant la l'ensemble des affectations de l'ST actif ainsi que les affectations
     * des collaborateurs qui sont en Renfort Intra Ug
     *
     * @param affectByST
     * @param affectRenfortIntraUg
     * @return
     */
    private Map<String, List<AffectationDto>> combineAffecRenfortIntraUgAndEquipe(Map.Entry<Long, List<AffectationDto>> affectByST,
                                                                                  Map<Long, List<AffectationDto>> affectRenfortIntraUg) {
        Map<String, List<AffectationDto>> mapAffecByMatricule = affectByST.getValue().stream()
                .collect(Collectors.groupingBy(AffectationDto::getMatricule));

        Map<String, List<AffectationDto>> renfortIntraUgBySt = affectRenfortIntraUg.getOrDefault(affectByST.getKey(), new ArrayList<>())
                .stream().collect(Collectors.groupingBy(AffectationDto::getMatricule));

        return flatMapWithSameKey(mapAffecByMatricule, renfortIntraUgBySt);
    }

    private  Map<Long, List<AffectationDto>> getAffectations( Map<Long, List<AffectationDto>> affectationsByST,
                                                              Map<Long, List<AffectationDto>> affectRenfortIntraUg,
                                                              boolean isAffNotEmpty) {
        return isAffNotEmpty ? affectationsByST : affectRenfortIntraUg;
    }

}
