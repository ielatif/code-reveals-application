package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.annotations.SgSignInRolesAllowed;
import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.interfaces.rest.dto.EquipeDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.socgen.eqc.domain.model.RoleEqc.*;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/equipes")
@Api(value = "equipes")
@Slf4j
public class EquipeResource {

    @Autowired
    private EquipeService equipeService;

    @GET
    @ApiOperation(value = "Récupération des equipes", notes = "Récupération des equipes")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les equipes sont bien récupérées")
    })
    @SgSignInRolesAllowed({CONSULTER_PLANNING, GERER_PLANNING, CONSULTER_VUE_COLLAB })
    public Response getEquipes() {
        return Response.ok(equipeService.findAll()).build();
    }

    @PUT
    @ApiOperation(value = "Mettre à jour une equipe", notes = "Mettre à jour une equipe")
    @ApiResponses({
            @ApiResponse(code = 201, message = "L'équipe est bien mise à jour"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    @SgSignInRolesAllowed({GERER_PLANNING })
    public Response updateEquipe(EquipeDto equipeDto){
        return Response.ok(equipeService.saveDto(equipeDto)).build();
    }
}
