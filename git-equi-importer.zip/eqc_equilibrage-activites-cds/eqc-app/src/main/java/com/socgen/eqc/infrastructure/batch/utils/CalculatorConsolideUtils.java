package com.socgen.eqc.infrastructure.batch.utils;

import com.socgen.eqc.application.impl.AbsenceServiceImpl;
import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Affiliation;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Equipe;
import com.socgen.eqc.domain.model.Intervalle;
import com.socgen.eqc.domain.model.Renfort;
import com.socgen.eqc.infrastructure.batch.dto.AbsenceBatchDto;
import com.socgen.eqc.infrastructure.batch.dto.AffectationDto;
import com.socgen.eqc.infrastructure.batch.mapper.AbsenceMapper;
import com.socgen.eqc.infrastructure.persistance.AffiliationRepository;
import com.socgen.eqc.infrastructure.persistance.EquipeRepository;
import com.socgen.eqc.infrastructure.persistance.RenfortRepository;
import lombok.experimental.UtilityClass;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@UtilityClass
public class CalculatorConsolideUtils {

    private static AbsenceMapper absenceMapper;

    private static RenfortRepository renfortRepository;

    private static EquipeRepository equipeRepository;

    private static AffiliationRepository affiliationRepository;

    private static AbsenceServiceImpl absenceService;

    /**
     * Calculer les jpurs de présence pour chaque collaborateur dans tous les ST dans lesquels il a travaille pendant
     * le mois calculé du consolide Mensuel
     *
     */
    public static Map<String, Double> computePrenseceDays(List<? extends AffectationDto> affectationDtos, Long date) {

        Map<String, List<Renfort>> renfortsByMatricule = getRenforts(date)
                .stream().collect(Collectors.groupingBy(renfort -> renfort.getCollaborateur().getMatricule()));

        Map<String, Double> presencesByMatricule = new HashMap<>();

        Map<String, List<AbsenceBatchDto>> absencesByMatricule = getAbsencesForAllMatricule(date);

        affectationDtos.stream()
                .collect(Collectors.groupingBy(AffectationDto::getMatricule))
                .entrySet()
                .forEach(affectByCollab -> {
                    Double nbrAffecteDdays = buildNbrAffectedDays(affectByCollab, absencesByMatricule, renfortsByMatricule);

                    presencesByMatricule.put(affectByCollab.getKey(), customRoundPresenceDays(nbrAffecteDdays));
                });

        return presencesByMatricule;
    }

    /**
     * Calcul des nombres de jours travaillés pour chaque Collaborateur
     */
    private Double buildNbrAffectedDays(Map.Entry<String, ? extends List<? extends AffectationDto>> affectByCollab,
                                       Map<String, List<AbsenceBatchDto>> absencesByMatricule,
                                       Map<String, List<Renfort>> renfortsByMatricule) {

        Map<LocalDate, List<AffectationDto>> affecByDate = affectByCollab.getValue().stream().collect(Collectors.groupingBy(AffectationDto::getDate));
        List<Renfort> listRenfortByMatricule = renfortsByMatricule.getOrDefault(affectByCollab.getKey(), new ArrayList<>());

        List<LocalDate> workedDayList = computeWorkedDay(affecByDate, listRenfortByMatricule);

        double nbrAffecteDdays = computeAffectedDate(affecByDate, listRenfortByMatricule);

        double nbrJourAbsences = buildNbrJoursAbsences(absencesByMatricule, affectByCollab, workedDayList);
        nbrAffecteDdays -= nbrJourAbsences * 0.01;
        return nbrAffecteDdays;

    }

    /**
     * Calcul de Nombre de jours d'absences
     *
     */
    private double buildNbrJoursAbsences(Map<String, List<AbsenceBatchDto>> absencesByMatricule,
                                         Map.Entry<String, ? extends List<? extends AffectationDto>> affectByCollab,
                                         List<LocalDate> workedDayList) {
        return absencesByMatricule.getOrDefault(affectByCollab.getKey(), new ArrayList<>())
                .stream()
                .filter(absenceBatchDto -> workedDayList.contains(absenceBatchDto.getDate()))
                .map(AbsenceBatchDto::getPourcentage)
                .reduce(0L, Long::sum);
    }


    /**
     * +     * Calcul des jours de travail : en se basant sur les affectations :
     * +     * Si on a des affectations dans une journée, alors cette journée est considérée comme un jour travaillé
     * +     * Si un jour contien un renfort alors il considéré comme un jour travaillé (peut importe si on des affectations pour le renfort ou pas)
     * +
     */
    private List<LocalDate> computeWorkedDay(Map<LocalDate, List<AffectationDto>> affecByDate,
                                             List<Renfort> listRenfortByMatricule) {
        List<LocalDate> workedDayList = new ArrayList<>(affecByDate.keySet());

        List<LocalDate> workedRenfortDayList = new ArrayList<>(listRenfortByMatricule.stream().collect(Collectors.groupingBy(Renfort::getDate))
            .keySet());

        //Ajouter les jours des renforts parmi les jours travaillés (jours ou on a des affectations)
        if (!CollectionUtils.isEmpty(workedRenfortDayList)) {
            workedDayList.addAll(workedRenfortDayList);
        }

        return workedDayList;
    }


    /**
     * Calculer le nombre de jours des renforts dans un St Aidé
     *
     */
    public Map<Long, Map<String, Double>> computePresenceDayForRenfortInterUg(Long date) {

        Map<Long, List<Renfort>> renfortByStAide = getRenforts(date)
                .stream().collect(Collectors.groupingBy(renfort -> renfort.getEquipe().getCode()));

        return renfortByStAide.entrySet()
                .stream().collect(Collectors.toMap(Map.Entry::getKey, entryByStAide -> {

                    Map<String, List<Renfort>> mapRenfortByMatricule = entryByStAide.getValue()
                            .stream().collect(Collectors.groupingBy(renfort -> renfort.getCollaborateur().getMatricule()));

                    return mapRenfortByMatricule.entrySet().stream()
                            .collect(Collectors.toMap(Map.Entry::getKey, entryByMatricule -> entryByMatricule.getValue().stream()
                                    .map(renfort -> getNumberDaysRenfort(renfort.getIntervalle()))
                                    .reduce(0d, Double::sum)));
                }));
    }

    private Double getNumberDaysRenfort(Intervalle intervalle) {
        if (intervalle == Intervalle.MATIN || intervalle == Intervalle.APRES_MIDI) {
            return 0.5;
        }
        return 1d;
    }


    /**
     * Récupérer les abcenses pour tous les collaborateurs dans le mois du consolide Mens
     *
     */
    private Map<String, List<AbsenceBatchDto>> getAbsencesForAllMatricule(Long date) {

        List<Absence> absencesManualAndGershwin = new ArrayList<>();
        LocalDate month = LocalDate.now().minusMonths(1);
        if (date != null) {
            month = LocalDate.ofEpochDay(date);
        }
        LocalDate dateDebut = month.with(TemporalAdjusters.firstDayOfMonth());
        LocalDate dateFin = month.with(TemporalAdjusters.lastDayOfMonth());

        List<Long> equipeIds = equipeRepository.findAll().stream().map(Equipe::getCode).collect(Collectors.toList());
        equipeIds.forEach(equipeId -> absencesManualAndGershwin.addAll(getMergedManuelAndGershwinAbsences(equipeId, dateDebut, dateFin)));

        return absencesManualAndGershwin.stream()
                .map(absence -> absenceMapper.absenceToAbsenceBatchDto(absence))
                .collect(Collectors.groupingBy(AbsenceBatchDto::getMatriculeCollaborateur));
    }

    /**
     * Récupérations des absences manuelles et Gershwin mergées pour chaque ST
     *
     */
    private List<Absence> getMergedManuelAndGershwinAbsences(Long equipeId, LocalDate dateDebut, LocalDate dateFin) {
        List<Affiliation> affiliations = affiliationRepository.findByEquipeIdAndDates(equipeId, dateDebut, dateFin);
        List<Collaborateur> collaborateursAffiliation = affiliations.stream().map(Affiliation::getCollaborateur).distinct().collect(Collectors.toList());
        //récupération des absences manuelles et Gershwin mergées
        return absenceService.findAbsences(equipeId, collaborateursAffiliation, dateDebut, dateFin);
    }

    /**
     * Arrondir le nombre de jour de présence
     * ToSee : https://jira.socgen/browse/EQCH-310
     * Example
     * Décimale <= 2  arrondi de l’unité
     * Décimale entre 3 et 7  arrondi à ,5
     * Décimale >= 8  arrondi à l’unité supérieure
     *
     */
    private double customRoundPresenceDays(double nbrJoursPresence) {

        double nbPresenceDecimalPart = getDecimalPart(nbrJoursPresence);

        if (nbPresenceDecimalPart <= 0.2) {

            return Math.floor(nbrJoursPresence);

        } else if (nbPresenceDecimalPart > 0.2 && nbPresenceDecimalPart <= 0.7) {

            return Math.floor(nbrJoursPresence) + 0.5;

        } else {
            return Math.ceil(nbrJoursPresence);
        }
    }

    private static double getDecimalPart(double nbrJoursPresence) {
        return nbrJoursPresence - Math.floor(nbrJoursPresence);
    }

    /**
     * Calculer le nombre de jours affectés d'un collaborateur en prenant en compte
     * les jours travaillés en renfort
     *
     */
    private Double computeAffectedDate(Map<LocalDate, List<AffectationDto>> mapAffecByDate, List<Renfort> renforts) {

        Set<LocalDate> affectationsDate = mapAffecByDate.keySet();
        Map<LocalDate, List<Renfort>> renfortByDate = renforts.stream().collect(Collectors.groupingBy(Renfort::getDate));

        Set<LocalDate> renfortsDate = renfortByDate.keySet()
                .stream().filter(renfortDate -> !affectationsDate.contains(renfortDate))
                .collect(Collectors.toSet());

        return (double) affectationsDate.size() + (double) renfortsDate.size();
    }

    /**
     * Récupérer tous les renforts du mois de consolidé
     *
     */
    private List<Renfort> getRenforts(Long date) {

        LocalDate month = getConsolideDate(date);

        return renfortRepository.findByDateBetween(month.with(TemporalAdjusters.firstDayOfMonth()), month.with(TemporalAdjusters.lastDayOfMonth()));
    }

    public static void setAbsenceMapper(AbsenceMapper absenceMapper) {
        CalculatorConsolideUtils.absenceMapper = absenceMapper;
    }

    public static void setRenfortRepository(RenfortRepository renfortRepository) {
        CalculatorConsolideUtils.renfortRepository = renfortRepository;
    }

    public static void setEquipeRepository(EquipeRepository equipeRepository) {
        CalculatorConsolideUtils.equipeRepository = equipeRepository;
    }

    public static void setAffiliationRepository(AffiliationRepository affiliationRepository) {
        CalculatorConsolideUtils.affiliationRepository = affiliationRepository;
    }

    public static void setAbsenceService(AbsenceServiceImpl absenceService) {
        CalculatorConsolideUtils.absenceService = absenceService;
    }

    public static LocalDate getConsolideDate(Long date) {
        return (date != null) ? LocalDate.ofEpochDay(date) : LocalDate.now().minusMonths(1);
    }

}
