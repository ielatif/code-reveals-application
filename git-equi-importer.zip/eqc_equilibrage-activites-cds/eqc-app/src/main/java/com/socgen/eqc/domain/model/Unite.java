package com.socgen.eqc.domain.model;

import com.socgen.eqc.application.exception.BusinessException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.stream.Stream;

@AllArgsConstructor
public enum Unite {
    NA("N/A"),
    TACHES("TACHES"),
    DOSSIERS("DOSSIERS");

    @Getter
    @Setter
    private String code;

    public static Unite of(String code) {
        return Stream.of(Unite.values())
                .filter(p -> p.getCode().equals(code))
                .findFirst()
                .orElseThrow(() -> new BusinessException(String
                        .format("L'Unité %s n'est pas reconnue pour ce code: ", code)));
    }
}
