package com.socgen.eqc.infrastructure.batch.config;

import com.socgen.eqc.infrastructure.batch.repository.ConsolideRepository;
import com.socgen.eqc.infrastructure.batch.utils.CalculatorConsolideUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;

@Slf4j
public class JobConsolideListener implements JobExecutionListener {

    @Autowired
    private ConsolideRepository repositoryWriter;


    @Override
    public void beforeJob(JobExecution jobExecution) {
        Long date =  jobExecution.getJobParameters().getLong("date");
        resetConsolideMensuel(date);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        // do nothing
    }

    public void resetConsolideMensuel(Long date) {
        log.info("Reset consolide pour la date: {}", LocalDate.ofEpochDay(date));
        LocalDate consoldeDate = CalculatorConsolideUtils.getConsolideDate(date);
        repositoryWriter.deleteAllByMonthYearConsolide(String.format("%02d", consoldeDate.getMonthValue()) + "-" + consoldeDate.getYear());
    }

}
