package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;

@AllArgsConstructor
public enum Intervalle {
	MATIN("MATIN", LocalTime.of(19,30), LocalTime.of(19,0)),
	APRES_MIDI("APRES_MIDI", LocalTime.of(19,30), LocalTime.of(19,0)),
	TOUTE_JOURNEE("TOUTE_JOURNEE", LocalTime.of(19,30), LocalTime.of(19,0));

	@Getter
	@Setter
	private String code;

	@Getter
	@Setter
	private LocalTime heureDebut;

	@Getter
	@Setter
	private LocalTime heureFin;
}

