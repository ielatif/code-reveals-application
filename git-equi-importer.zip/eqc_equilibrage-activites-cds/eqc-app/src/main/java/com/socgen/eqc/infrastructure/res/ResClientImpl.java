package com.socgen.eqc.infrastructure.res;

import com.socgen.eqc.application.exception.BusinessException;
import com.socgen.eqc.config.EqcProperties;
import com.socgen.eqc.infrastructure.entite.structure.domain.CentreService;
import com.socgen.eqc.infrastructure.res.dto.EsInputDTO;
import com.socgen.eqc.interfaces.rest.error.ExternServiceException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@AllArgsConstructor
@Service
public class ResClientImpl implements ResClient {

    private final Client restClient;
    private final EqcProperties eqcProperties;

    @Override
    public List<CentreService> getEntiteStructure() {
        try {
            String path = eqcProperties.getContributeur().getEsWithTetePerimetrePath();
            EsInputDTO body = EsInputDTO.builder()
                    .listeDepartements(eqcProperties.getContributeur().getDepartementBddf())
                    .listeCodeTypes(eqcProperties.getContributeur().getCodeType()).build();

            log.info("call Res {} ", UriBuilder.fromPath(eqcProperties.getContributeur().getResUrl()).path(path).build());
            Response response = restClient
                    .target(UriBuilder.fromPath(eqcProperties.getContributeur().getResUrl()).path(path).build())
                    .request(MediaType.APPLICATION_JSON_TYPE).buildPost(Entity.json(body)).invoke(Response.class);
            return buildResponse(response);
        } catch (Exception e) {
            //propager une erreur de type ExternServiceException dans le cas d'une erreur de timeOut, afin de
            //faire un retry de la meme requete si jamais y'a un probleme d eréseau ou autre
            if (e.getCause() instanceof SocketTimeoutException) {
                log.error("Erreur technique, TimeOut Res, une relance sera executée", e);
                throw new ExternServiceException("Erreur technique, problème d'accès à l'application partenaire RES");
            }

            log.error("Une erreur s'est produite lors de l'appel à RES", e);
            throw new BusinessException("Une erreur s'est produite lors de l'appel à RES");
        }

    }

    private List<CentreService> buildResponse(Response response) {
        try (response) {
            if (response.getStatus() != 200) {
                log.error("Une erreur s'est produite lors de l'appel à Res, status {} ", response.getStatus());
                throw new ExternServiceException("Une erreur s'est produite lors de l'appel à Res ");
            }

            return Optional.ofNullable(response.readEntity(new GenericType<List<CentreService>>() {
            })).orElseGet(ArrayList::new);
        }
    }
}
