package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.IndicateurService;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurEtpInputDto;
import com.socgen.eqc.interfaces.rest.dto.indicateur.IndicateurInputDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Path("/indicateurs")
@Api(value = "indicateurs")
public class IndicateurResource {

    @Autowired
    private IndicateurService indicateurService;

    @GET
    @ApiOperation(value = "Récupération des stocks à traiter", notes = "Récupération des stocks à traiter")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les stocks sont bien récupérées")
    })
    public Response getStockTrait(@BeanParam IndicateurInputDto indicateurInputDto) {

        return Response.ok(indicateurService.getStockTraiter(indicateurInputDto, false)).build();
    }

    @GET
    @Path("/etps")
    public Response getEtpIndicateurs(@BeanParam IndicateurEtpInputDto indicateurInputDto) {

        log.debug("Getting ETP indicators for STs {} between {} and {} ", indicateurInputDto.getDateDebut(), indicateurInputDto.getDateFin(), indicateurInputDto.getListCodeServiceTraitement());

        return Response.ok(indicateurService.getEtps(indicateurInputDto).toString())
                .build();
    }
}
