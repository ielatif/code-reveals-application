package com.socgen.eqc.interfaces.rest.dto.indicateur;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@AllArgsConstructor
@Slf4j
public enum StockATraiterType {

    STOCK_DOSSIER_A_TRAITER {

        @Override
        public void computeStockATraiter(LocalDate dateDebut,
                                         LocalDate dateFin,
                                         List<StockOutputDto> listStockATraiter,
                                         Map.Entry<String, Map<String, List<Stocks>>> stockByProcessType) {

            buildStockATraiter(dateDebut, dateFin, listStockATraiter, stockByProcessType);
        }

        @Override
        public void setStockATraiterJourEchus(StockOutputDto stocksOutput, Stocks stock) {
            stocksOutput.setStockDossierTraiter(stocksOutput.getStockDossierTraiter().add(stock.getStockVeille()).add(stock.getStockRecu()));
        }

        @Override
        public void setStockATraiterJourJ(StockOutputDto stocksOutput, BigInteger stock) {
            stocksOutput.setStockDossierTraiter(stocksOutput.getStockDossierTraiter().add(stock));
        }

        @Override
        public void setStockTermine(StockOutputDto stocksOutput, Stocks stock) {
            stocksOutput.setStockDossierTermine(stocksOutput.getStockDossierTermine().add(stock.getStockTermine()));
        }

    },
    STOCK_TACHE_A_TRAITER {

        @Override
        public void computeStockATraiter(LocalDate dateDebut,
                                                      LocalDate dateFin,
                                                      List<StockOutputDto> listStockATraiter,
                                                      Map.Entry<String, Map<String, List<Stocks>>> stockByProcessType) {

            buildStockATraiter(dateDebut, dateFin, listStockATraiter, stockByProcessType);
        }

        @Override
        public void setStockATraiterJourEchus(StockOutputDto stocksOutput, Stocks stock) {
            stocksOutput.setStockTacheTraiter(stocksOutput.getStockTacheTraiter().add(stock.getStockVeille()).add(stock.getStockRecu()));
        }

        @Override
        public void setStockATraiterJourJ(StockOutputDto stocksOutput, BigInteger stock) {
            stocksOutput.setStockTacheTraiter(stocksOutput.getStockTacheTraiter().add(stock));

        }

        @Override
        public void setStockTermine(StockOutputDto stocksOutput, Stocks stock) {
            stocksOutput.setStockTacheTermine(stocksOutput.getStockTacheTermine().add(stock.getStockTermine()));
        }

    };

    public abstract void computeStockATraiter(LocalDate dateDebut,
                                                             LocalDate dateFin,
                                                             List<StockOutputDto> stockOutputDtos,
                                                             Map.Entry<String, Map<String, List<Stocks>>> stockByProcessType);

    public abstract void setStockATraiterJourEchus(
                                            StockOutputDto stocksOutput,
                                            Stocks stock);

    public abstract void setStockATraiterJourJ(StockOutputDto stocksOutput, BigInteger stock);

    public abstract void setStockTermine (StockOutputDto stocksOutput, Stocks stock);


    BigInteger computeArithemeticAverage(Map<String, List<Stocks>> stockForAverage) {
        AtomicReference<BigInteger> sumStockRecu = new AtomicReference<>(BigInteger.ZERO);

        stockForAverage.forEach((key, value) -> {
            Optional<BigInteger> stockRecu = value.stream()
                    .map(Stocks::getStockRecu).reduce(BigInteger::add);

            sumStockRecu.set(sumStockRecu.get().add(stockRecu.orElse(BigInteger.ZERO)));
        });

        return BigInteger.valueOf(new BigDecimal(sumStockRecu.get()).divide(new BigDecimal(BigInteger.valueOf(7)), RoundingMode.HALF_UP).longValue());
    }

    void buildStockATraiter(LocalDate dateDebut,
                       LocalDate dateFin,
                       List<StockOutputDto> listStockATraiter,
                       Map.Entry<String, Map<String, List<Stocks>>> stockByProcessType) {
        stockByProcessType.getValue().entrySet()
                .stream().filter( stockByDate ->
                LocalDate.parse(stockByDate.getKey()).isAfter(dateDebut) ||  LocalDate.parse(stockByDate.getKey()).isEqual(dateDebut) &&
                        LocalDate.parse(stockByDate.getKey()).isBefore(dateFin))
                .forEach(stockByDate -> {
                    Optional<StockOutputDto> stocksSaved = listStockATraiter.stream().filter(stock -> stock.getDay().equals(stockByDate.getKey())).findFirst();

                    StockOutputDto stocksOutput = stocksSaved.orElseGet(() -> StockOutputDto.builder().day(stockByDate.getKey())
                            .stockTacheTraiter(BigInteger.ZERO)
                            .stockDossierTraiter(BigInteger.ZERO)
                            .stockDossierTermine(BigInteger.ZERO)
                            .stockTacheTermine(BigInteger.ZERO).build());

                    stocksSaved.ifPresent(listStockATraiter::remove);

                    if(LocalDate.parse(stockByDate.getKey()).isBefore(LocalDate.now())) {
                        //calcul Stock des jours Echus
                        computeStockDuJourEchus(stockByDate, stocksOutput);
                        computeStockTermine(stockByDate, stocksOutput);


                    } else if(LocalDate.parse(stockByDate.getKey()).isEqual(LocalDate.now())) {
                        //calcul Stock du jour J
                        computeStockDuJourJ(stockByProcessType, stockByDate, stocksOutput);

                    }

                    listStockATraiter.add(stocksOutput);
                });
    }

    private void computeStockDuJourEchus(Map.Entry<String, List<Stocks>> stockByDate, StockOutputDto stocksOutput) {
        stockByDate.getValue().forEach(stock -> setStockATraiterJourEchus(stocksOutput, stock));
    }

    private void computeStockTermine(Map.Entry<String, List<Stocks>> stockByDate, StockOutputDto stocksOutput) {
        stockByDate.getValue().forEach(stock -> setStockTermine(stocksOutput, stock));
    }

    private void computeStockDuJourJ(Map.Entry<String, Map<String, List<Stocks>>> stockByProcessType, Map.Entry<String, List<Stocks>> stockByDate, StockOutputDto stocksOutput) {
        Map<String, List<Stocks>> stockForAverage = stockByProcessType.getValue().entrySet()
                .stream().filter( stock ->
                        (LocalDate.parse(stock.getKey()).isAfter(LocalDate.parse(stockByDate.getKey()).minusDays(7))
                                || LocalDate.parse(stock.getKey()).isEqual(LocalDate.parse(stockByDate.getKey()).minusDays(7)))
                                && (LocalDate.parse(stock.getKey()).isBefore(LocalDate.parse(stockByDate.getKey()).minusDays(1)))
                )
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        BigInteger sumStockVeilleJ = stockByDate.getValue().stream()
                .map(Stocks::getStockVeille)
                .reduce(BigInteger.ZERO, BigInteger::add);

        BigInteger averageSevenDays = computeArithemeticAverage(stockForAverage);
        setStockATraiterJourJ(stocksOutput, sumStockVeilleJ.add(averageSevenDays));
    }
}
