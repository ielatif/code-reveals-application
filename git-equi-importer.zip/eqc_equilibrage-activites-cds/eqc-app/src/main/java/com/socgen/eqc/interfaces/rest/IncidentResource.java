package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.IncidentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Slf4j
@Path("/incidents")
@Api(value = "incidents")
public class IncidentResource {
    @Autowired
    private IncidentService incidentService;

    @GET
    @ApiOperation(value = "Récupération des incidents pour les stocks", notes = "Récupération des incidents pour les stocks")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les incidents sont bien récupérés")
    })
    public Response getIncident() {
        return Response.ok(incidentService.getIncident()).build();
    }
}
