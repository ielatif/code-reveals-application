package com.socgen.eqc.interfaces.rest.converters;

import javax.ws.rs.ext.ParamConverter;
import java.time.LocalDate;

public class LocalDateConverter implements ParamConverter<LocalDate> {
    @Override
    public LocalDate fromString(String s) {
        return LocalDate.parse(s);
    }

    @Override
    public String toString(LocalDate localDate) {
        return localDate.toString();
    }
}
