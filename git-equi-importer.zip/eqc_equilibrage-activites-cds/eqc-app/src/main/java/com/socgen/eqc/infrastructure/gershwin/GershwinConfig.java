package com.socgen.eqc.infrastructure.gershwin;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.config.ApplicationProperties.Gershwin;
import com.socgen.eqc.infrastructure.gershwin.client.GershwinClient;
import com.socgen.eqc.infrastructure.gershwin.client.GershwinClientImpl;
import com.socgen.eqc.infrastructure.gershwin.service.GershwinService;
import com.socgen.eqc.infrastructure.gershwin.service.GershwinServiceImpl;
import lombok.RequiredArgsConstructor;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.logging.LoggingFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.ext.ContextResolver;
import java.util.logging.Level;
import java.util.logging.Logger;

@Configuration
public class GershwinConfig {


	@Bean
	public GershwinService gershwinService(EquipeService equipeService, GershwinClient gershwinClient) {
		return new GershwinServiceImpl(equipeService, gershwinClient);
	}

	@Bean
	public GershwinClient gershwinClient(Client bscRestClient, ApplicationProperties applicationProperties) {
		Gershwin gershwin = applicationProperties.getGershwin();
		WebTarget webTarget = bscRestClient.target(gershwin.getServerUrl());
		return new GershwinClientImpl(webTarget, gershwin);
	}

	@Bean(name = "bscRestClient")
	public Client bscRestClient() {
		LoggingFeature loggingFeature = new LoggingFeature(Logger.getLogger("bscRestClient"), Level.INFO,
				LoggingFeature.Verbosity.PAYLOAD_TEXT, LoggingFeature.DEFAULT_MAX_ENTITY_SIZE);
		return ClientBuilder.newBuilder()
				.register(objectMapperContextResolver())
				.register(loggingFeature)
				.property(ClientProperties.CONNECT_TIMEOUT, 2000)
				.property(ClientProperties.READ_TIMEOUT, 25000)
				.build();
	}

	private ContextResolver<ObjectMapper> objectMapperContextResolver() {
		final ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.findAndRegisterModules();
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		return new ObjectMapperContextResolver(objectMapper);
	}

	@RequiredArgsConstructor
	private static final class ObjectMapperContextResolver implements ContextResolver<ObjectMapper> {

		private final ObjectMapper objectMapper;

		@Override
		public ObjectMapper getContext(final Class<?> type) {
			return objectMapper;
		}
	}
}
