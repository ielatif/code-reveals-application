package com.socgen.eqc.interfaces.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsolideMensSearch {

    @QueryParam("st")
    @NotNull
    private Long idServiceTraitement;

    @QueryParam("date")
    @NotNull
    private String dateDebut;
}
