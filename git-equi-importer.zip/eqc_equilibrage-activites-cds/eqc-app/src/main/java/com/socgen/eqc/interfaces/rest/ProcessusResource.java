package com.socgen.eqc.interfaces.rest;

import com.socgen.eqc.application.ProcessusService;
import com.socgen.eqc.infrastructure.smbo.dto.RefProcessusInputDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/processus")
@Api(value = "processus")
public class ProcessusResource {

    @Autowired
    private ProcessusService processusService;

    @POST
    @ApiOperation(value = "Créer un processus", notes = "Création d'un processus")
    @ApiResponses({
            @ApiResponse(code = 201, message = "Le processus est bien créé"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    public Response createProcessus(@Valid RefProcessusInputDto processusDto) {
        return Response.ok(processusService.saveOrUpdateProcessus(processusDto)).build();
    }
}
