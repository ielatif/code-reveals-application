package com.socgen.eqc.config;

import com.socgen.dga.idp.jaxrs.commons.SgUser;
import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.digital.agence.metric.config.MetricsProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Optional;

@Priority(Priorities.USER)
public class EqcUserMetricsContainerFilter implements ContainerRequestFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(EqcUserMetricsContainerFilter.class);
    private static final String SG_SIGN_IN_USER_INFO_HEADER = "userInfo";

    private Optional<EqcUserMetricsService> usersMetrics;
    private MetricsProperties metricsProperties;

    @Autowired
    public EqcUserMetricsContainerFilter(final Optional<EqcUserMetricsService> usersMetrics, final MetricsProperties metricsProperties) {
        this.usersMetrics = usersMetrics;
        this.metricsProperties = metricsProperties;
    }

    @Override
    public void filter(final ContainerRequestContext requestContext) throws IOException {

        // Ignorer les requêtes basé sur les patterns fournis dans la configuration
        // applicative.
        if (shouldIgnore(requestContext)) {
            LOGGER.debug(MessageFormat.format("EqcUserMetricContainerFilter is ignored for path %s",
                    requestContext.getUriInfo().getPath()));
            return;
        }

        usersMetrics.ifPresent((final EqcUserMetricsService um) -> {
            final String userInfo = requestContext.getHeaderString(SG_SIGN_IN_USER_INFO_HEADER);
            final SgUser sgUser = new SgUserPrincipal(userInfo).getCurrentUser();
            um.registerUser(sgUser);
        });
    }

    private boolean shouldIgnore(final ContainerRequestContext requestContext) {

        if (requestContext == null || requestContext.getUriInfo() == null
                || requestContext.getUriInfo().getPath() == null) {
            return false;
        }

        //@formatter:off
        return this.metricsProperties.getUser().getIgnores()
                .stream()
                .map((ignore) -> {
                    return requestContext.getUriInfo().getPath().contains(ignore);
                }).reduce((a, b) -> {
                    return a | b;
                }).orElse(false);
        //@formatter:off
    }

}
