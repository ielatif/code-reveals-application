package com.socgen.eqc.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParamsFictionalTetePerimId implements Serializable {


    @Column(name = "code_filiere", nullable = false)
    private Long codeFiliere;

    @Column(name = "code_ug", nullable = false)
    private Long codeUg;

    @Column(name = "code_st", nullable = false)
    private Long codeSt;
}
