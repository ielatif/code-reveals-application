package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.PerimetreService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/entites-structure")
@Api(value = "entites-structure")
public class EntiteStructureResource {

    @Autowired
    private PerimetreService perimetreService;

    @GET
    @ApiOperation(value = "Récupération des entités de structure par ST", notes = "Récupération des entités de structure par ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les entités sont bien récupérées")
    })
    public Response getAllEntiteStructure(@QueryParam("codeServiceRattachement") String codeServiceRattachement, @BeanParam SgUserPrincipal sgUserPrincipal) {
        return Response.ok(perimetreService.getPerimetre(codeServiceRattachement, sgUserPrincipal)).build();
    }
}
