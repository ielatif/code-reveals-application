package com.socgen.eqc.mapper;

import com.socgen.eqc.domain.model.DefaultExpertise;
import com.socgen.eqc.interfaces.rest.dto.referentiel.activite.DefaultExpertiseDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DefaultExpertiseMapper {

    DefaultExpertiseDto toDefaultExpertiseDto(DefaultExpertise defaultExpertise);

    DefaultExpertise toDefaultExpertise(DefaultExpertiseDto defaultExpertiseDto);
}
