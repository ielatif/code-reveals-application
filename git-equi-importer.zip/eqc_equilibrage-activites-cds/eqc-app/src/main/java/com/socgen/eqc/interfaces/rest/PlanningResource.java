package com.socgen.eqc.interfaces.rest;

import com.socgen.dga.idp.jaxrs.annotations.SgSignInRolesAllowed;
import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.eqc.application.IndicateurUgService;
import com.socgen.eqc.application.PlanningService;
import com.socgen.eqc.interfaces.rest.dto.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.socgen.eqc.domain.model.RoleEqc.*;


@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Path("/plannings")
@Api(value = "plannings")
@Slf4j
public class PlanningResource {

    @Autowired
    private PlanningService planningService;

    @Autowired
    private IndicateurUgService indicateurUgService;

    @GET
    @ApiOperation(value = "Récupération des planning par ST", notes = "Récupération des planning par ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Le planning est bien récupéré")
    })
    @Path("/services-traitements/{codeServiceTraitement}")
    @SgSignInRolesAllowed({CONSULTER_VUE_COLLAB, CONSULTER_PLANNING, GERER_PLANNING})
    public Response getPlannigByServiceTraitement(@BeanParam PlanningSearchDto planningSearchDto) {
        return Response.ok(planningService.findByPlanningSearchDto(planningSearchDto)).build();
    }

    @POST
    @ApiOperation(value = "Mettre à jour un palnning", notes = "Mettre à jour un palnning")
    @ApiResponses({
            @ApiResponse(code = 201, message = "Le planning a été bien mis à jour"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    @Path("/services-traitements/{codeServiceTraitement}")
    @SgSignInRolesAllowed({CONSULTER_VUE_COLLAB, CONSULTER_PLANNING, GERER_PLANNING })
    public Response updatePlanning(@BeanParam PlanningSearchDto planningSearchDto, @BeanParam SgUserPrincipal sgUserPrincipal, @Valid ActionsPlanningDto actionsPlanningDto) {
        log.info("actionsPlanningDto: {}", actionsPlanningDto);
        return Response.ok(planningService.update(planningSearchDto, actionsPlanningDto, sgUserPrincipal)).build();
    }


    @POST
    @ApiOperation(value = "Dupliquer un planning", notes = "Dupliquer un planning")
    @ApiResponses({
            @ApiResponse(code = 201, message = "La planning dupliqué est bien créé"),
            @ApiResponse(code = 405, message = "Mauvaise données entrantes")
    })
    @Path("/services-traitements/{codeServiceTraitement}/duplication")
    @SgSignInRolesAllowed({CONSULTER_VUE_COLLAB, CONSULTER_PLANNING, GERER_PLANNING})
    public Response dupliquer(@Valid DuplicationDto duplicationDto,  @BeanParam SgUserPrincipal sgUserPrincipal, @PathParam("codeServiceTraitement") Long codeServiceTraitement) {
        planningService.dupliquerSemaine(duplicationDto, sgUserPrincipal);
        return Response.ok().build();
    }

    @GET
    @ApiOperation(value = "Calcul des indicateurs (etp, capacité, contributeurs) pour chaque activité d'un ST", notes = "Calcul des indicateurs (etp, capacité, contributeurs) pour chaque activité d'un ST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "L'indicateur est bien récupéré")
    })
    @Path("/indicateurs")
    @SgSignInRolesAllowed({CONSULTER_VUE_COLLAB, CONSULTER_PLANNING, GERER_PLANNING})
    public Response getIndicateur(@BeanParam IndicateurSearchDto indicateurSearchDto) {
        return Response.ok(indicateurUgService.computeIndicateur(indicateurSearchDto)).build();
    }

    @DELETE
    @ApiOperation(value = "Suppression du planning d'une semaine", notes = "Suppression du planning d'une semaine")
    @ApiResponses({
            @ApiResponse(code = 200, message = "La suppression a été bien faite")
    })
    @Path("/services-traitements/{codeServiceTraitement}")
    @SgSignInRolesAllowed({CONSULTER_VUE_COLLAB, CONSULTER_PLANNING, GERER_PLANNING})
    public Response supprimer(@Valid @NotNull SuppressionSemaineDto suppressionSemaineDto, @PathParam("codeServiceTraitement") Long codeServiceTraitement) {
        planningService.supprimerSemaine(suppressionSemaineDto);
        return Response.ok().build();
    }

    @GET
    @ApiOperation(value = "Récupération des renforts entrant par planning", notes = "Récupération des renforts entrant par planning")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Les renforts sont bien récupérés")
    })
    @Path("/renforts/services-traitements/{codeServiceTraitement}")
    @SgSignInRolesAllowed({CONSULTER_VUE_COLLAB, CONSULTER_PLANNING, GERER_PLANNING})
    public Response getRenfortsByServiceTraitement(@BeanParam PlanningSearchDto planningSearchDto) {
        return Response.ok(planningService.findPlanningRenfortByPlanningSearchDto(planningSearchDto)).build();
    }
}
