package com.socgen.eqc.infrastructure.gershwin.service;

import com.socgen.eqc.application.EquipeService;
import com.socgen.eqc.domain.model.Absence;
import com.socgen.eqc.domain.model.Collaborateur;
import com.socgen.eqc.domain.model.Intervalle;
import com.socgen.eqc.infrastructure.gershwin.client.GershwinClient;
import com.socgen.eqc.infrastructure.gershwin.model.Day;
import com.socgen.eqc.infrastructure.gershwin.model.PlanView;
import com.socgen.eqc.infrastructure.gershwin.model.UserDataCalendar;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

@AllArgsConstructor
@Slf4j
public class GershwinServiceImpl implements GershwinService {

    private final EquipeService equipeService;
    private final GershwinClient gershwinClient;

    @Override
    public List<Absence> findAbsence(Long idEquipe, List<Collaborateur> collaborateurs, LocalDate dateDebut,
                                     LocalDate dateFin) {

        if (idEquipe.equals(3000324055L)) {
            return mockHmlAbsences();
        }

        try {
            Map<String, String> matriculesByIdRh = collaborateurs.stream()
                    .distinct()
                    .collect(Collectors.toMap(Collaborateur::getIdRhLocal, Collaborateur::getMatricule));
            // Récupérer les managers de l'équipe
            Set<String> managersIdRh = equipeService.findManagersIdRh(idEquipe);
            // Merger les managers et les approvers
            managersIdRh.addAll(getApproversIdRh(matriculesByIdRh, managersIdRh));
            // Appeler Gershwin en parallèle
            List<PlanView> teamCalendar = managersIdRh.stream()
                    .map(idRh -> getTeamCalendar(idRh, dateDebut, dateFin))
                    .flatMap(Collection::stream)
                    .collect(toList());
            // Filter les collaborateurs ajoutés dans l'équipe
            List<PlanView> filtredTeamCalendar = filterByCollaborateursAndDates(matriculesByIdRh, dateDebut, dateFin, teamCalendar);

            return mapToAbsences(matriculesByIdRh, filtredTeamCalendar);
        } catch (Exception e) {
            log.error("Problème Gershwin : ", e);
            return emptyList();
        }
    }

    private static List<Absence> mockHmlAbsences() {
        List<Absence> absences = new ArrayList<>();
        LocalDate monday = LocalDate.now().with(DayOfWeek.MONDAY);

        Absence absence1 = new Absence();
        absence1.setIntervalle(Intervalle.MATIN);
        absence1.setDate(monday);
        absence1.setMatriculeCollaborateur("z017335");
        absences.add(absence1);

        Absence absence2 = new Absence();
        absence2.setIntervalle(Intervalle.APRES_MIDI);
        absence2.setDate(monday.plusDays(1));
        absence2.setMatriculeCollaborateur("z017335");
        absences.add(absence2);

        Absence absence3 = new Absence();
        absence3.setIntervalle(Intervalle.TOUTE_JOURNEE);
        absence3.setDate(monday.plusDays(2));
        absence3.setMatriculeCollaborateur("z017335");
        absences.add(absence3);

        return absences;
    }

    private Set<String> getApproversIdRh(Map<String, String> matriculesByIdRh, Set<String> managersIdRh) {
        return managersIdRh.stream()
                .filter(matriculesByIdRh::containsKey)
                .map(gershwinClient::getApprover)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .map(approver -> approver.getId().toUpperCase())
                .collect(Collectors.toSet());
    }

    private List<PlanView> getTeamCalendar(String idRhManager, LocalDate dateDebut, LocalDate dateFin) {
        List<PlanView> teamCalendar = new ArrayList<>();
        String startMonth = YearMonth.from(dateDebut).toString();
        String endMonth = YearMonth.from(dateFin).toString();
        UserDataCalendar startMonthCalendar = gershwinClient.getTeamCalendar(idRhManager, startMonth);
        Optional.ofNullable(startMonthCalendar.getData().getCalendar()).ifPresent(teamCalendar::addAll);
        if (!startMonth.equals(endMonth)) {
            UserDataCalendar endMonthCalendar = gershwinClient.getTeamCalendar(idRhManager, endMonth);
            Optional.ofNullable(endMonthCalendar.getData().getCalendar()).ifPresent(teamCalendar::addAll);
        }
        return teamCalendar;
    }

    private List<PlanView> filterByCollaborateursAndDates(Map<String, String> matriculesByIdRh, LocalDate dateDebut, LocalDate dateFin, List<PlanView> teamCalendar) {
        Predicate<Day> dayInWeek = day -> (day.getDate().isAfter(dateDebut) || day.getDate().equals(dateDebut)) &&
                (day.getDate().isBefore(dateFin) || day.getDate().equals(dateFin));
        Predicate<Day> absenceValidated = day -> day.isMorningOff() || day.isAfternoonOff();
        return teamCalendar.stream()
                .filter(planView -> matriculesByIdRh.keySet().stream().anyMatch(idRhLocal -> idRhLocal.equalsIgnoreCase(planView.getUserId())))
                .peek(planView -> {
                    // exclure les jours hors semaine et les absences non validées
                    List<Day> days = planView.getDays()
                            .stream()
                            .filter(dayInWeek.and(absenceValidated))
                            .collect(toList());
                    planView.setDays(days);
                })
                .collect(toList());
    }

    private List<Absence> mapToAbsences(Map<String, String> matriculesByIdRh, List<PlanView> planViews) {
        return planViews.stream()
                .map(planView -> planView.getDays().stream()
                        .map(day -> Absence.builder()
                                .date(day.getDate())
                                .matriculeCollaborateur(matriculesByIdRh.get(planView.getUserId()))
                                .intervalle(getIntervalle(day))
                                .build())
                        .collect(toList()))
                .flatMap(List::stream)
                .collect(toList());
    }

    private Intervalle getIntervalle(Day day) {
        Intervalle intervalle = null;
        if (day.isMorningOff() && day.isAfternoonOff()) {
            intervalle = Intervalle.TOUTE_JOURNEE;
        } else if (day.isMorningOff() && !day.isAfternoonOff()) {
            intervalle = Intervalle.MATIN;
        } else if (!day.isMorningOff() && day.isAfternoonOff()) {
            intervalle = Intervalle.APRES_MIDI;
        }
        return intervalle;
    }
}
