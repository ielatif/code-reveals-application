package com.socgen.eqc.interfaces.rest.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@ToString
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = ActionAffectationDto.class, name = "AFFECTATION"),
        @JsonSubTypes.Type(value = ActionAbsenceDto.class, name = "ABSENCE"),
        @JsonSubTypes.Type(value = ActionRenfortDto.class, name = "RENFORT")
})
@SuperBuilder
public class ActionDto {

    private Long id;

    @NotBlank
    private String matricule;

    @NonNull
    private LocalDate date;

    private Action action;

    private String customStyle;

    private String commentPrincipale;

    private String commentSecondaire;
}
