package com.socgen.eqc.infrastructure.ghabi;

import com.socgen.eqc.application.exception.GhabiException;
import com.socgen.eqc.config.ApplicationProperties;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionDto;
import com.socgen.eqc.infrastructure.ghabi.dto.GhabiExtensionResponseDto;
import com.socgen.eqc.interfaces.rest.error.ExternServiceException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;

@Slf4j
@AllArgsConstructor
@Service
public class GhabiClientImpl implements GhabiClient {

    private final Client ghabiClient;
    private final ApplicationProperties applicationProperties;
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CREATEUR_ID = "CreateurId";
    public static final String DATE_DEBUT = "DateDebut";
    public static final String DATE_FIN = "DateFin";
    public static final String PERIME_ST_IDS = "PerimStIds";
    public static final String UTILISATEUR_ID = "UtilisateurId";
    public static final String UTILISATEUR_ST_ID = "UtilisateurStId";

    @Override
    public GhabiExtensionResponseDto createExtension(GhabiExtensionDto ghabiExtensionDto) throws GhabiException {
	    MultivaluedMap<String, String> formBody = buildFormBody(ghabiExtensionDto);
        try {
	        Response response = ghabiClient.target(buildGhabiPath())
                    .request()
                    .header(CONTENT_TYPE, MediaType.MULTIPART_FORM_DATA)
                    .accept(MediaType.APPLICATION_JSON_TYPE)
                    .post(Entity.form(formBody));

            GenericType<GhabiExtensionResponseDto> ghabiExtensionResponseDto = new GenericType<>() {};
            return handleResponse(response, ghabiExtensionResponseDto   );
        } catch (Exception e) {
        	String messageErreur = "Votre demande d’extension d’habilitation n'a pas pu être prise en compte par Ghabi. \n {}";
	        throw new GhabiException(messageErreur, e);
        }
    }

	@Override
    public void deleteExtension(Long idExtensionPerimetre) {
		Form form = new Form();
		try {
	        URI path = buildGhabiPath();
            form.param("id", idExtensionPerimetre.toString());
            ghabiClient.target(path)
                    .request(MediaType.MULTIPART_FORM_DATA)
                    .accept(MediaType.APPLICATION_JSON_TYPE)
                    .build("DELETE", Entity.form(form))
		            .invoke();

        } catch (Exception e) {
	        log.error("Votre demande d’extension d’habilitation n'a pas pu être supprimée dans Ghabi. \n {}", form, e);
        }
    }

	private URI buildGhabiPath() {
		return UriBuilder.fromPath(applicationProperties.getGhabi().getServerUrl())
				.path(applicationProperties.getGhabi().getExtensionPerimetrePath())
				.build();
	}

    private <T> T  handleResponse(Response response, GenericType<T> genericType) {
        try (response) {
            if (response.getStatusInfo().getFamily() != Response.Status.Family.SUCCESSFUL) {
                log.error("Une erreur s'est produite lors de l'appel à Ghabi pour les extensions des périmètres, status {} ", response.getStatus());
                throw new ExternServiceException("Une erreur s'est produite lors de l'appel à Ghabi pour les extensions des périmètres ");
            }
            return response.readEntity(genericType);
        }
    }

    @Override
    public GhabiExtensionResponseDto getExtensionDetail(Long id) {
        Response response = ghabiClient.target(buildGhabiPath())
                .path(String.valueOf((id)))
                .request()
                .accept(MediaType.APPLICATION_JSON_TYPE).buildGet().invoke();

        GenericType<GhabiExtensionResponseDto> ghabiExtensionResponseDto = new GenericType<>() {};
        return handleResponse(response, ghabiExtensionResponseDto );
    }

    @Override
    public GhabiExtensionResponseDto updateExtension(GhabiExtensionDto ghabiExtensionDto) {

        Response response = ghabiClient.target(buildGhabiPath())
                .request()
                .header(CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON  )
                .buildPut(Entity.json(ghabiExtensionDto)).invoke();
        GenericType<GhabiExtensionResponseDto> ghabiExtensionResponseDto = new GenericType<>() {};
        return handleResponse(response, ghabiExtensionResponseDto );
    }

    private MultivaluedMap<String, String> buildFormBody (GhabiExtensionDto ghabiExtensionDto) {
        MultivaluedMap<String, String> extensionPerimetreForm = new MultivaluedHashMap<>();
        extensionPerimetreForm.putSingle(CREATEUR_ID, ghabiExtensionDto.getCreateurId());
        extensionPerimetreForm.putSingle(DATE_DEBUT, ghabiExtensionDto.getDateDebut());
        extensionPerimetreForm.putSingle(DATE_FIN, ghabiExtensionDto.getDateFin());
        extensionPerimetreForm.addAll(PERIME_ST_IDS, ghabiExtensionDto.getPerimStIds());
        extensionPerimetreForm.putSingle(UTILISATEUR_ID, ghabiExtensionDto.getUtilisateurId().toUpperCase());
        extensionPerimetreForm.putSingle(UTILISATEUR_ST_ID, ghabiExtensionDto.getUtilisateurStId());

        return extensionPerimetreForm;
    }
}
