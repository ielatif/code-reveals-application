ALTER TABLE public.activite
DROP COLUMN FAMILLE_ID,
DROP COLUMN   CODE_TETE_PERIMETRE;
DROP TABLE public.famille;
ALTER TABLE public.activite RENAME TO activite_params;