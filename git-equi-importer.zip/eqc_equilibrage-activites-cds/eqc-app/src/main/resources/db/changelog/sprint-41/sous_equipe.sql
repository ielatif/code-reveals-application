create table sous_equipe
(
    id bigint not null
        constraint sous_equipe_pkey
            primary key,
    libelle varchar not null,
    description varchar,
    equipe_id bigint not null
        constraint fk9c0hmdd379f9ehxigxkp4d8fd
            references equipe
);