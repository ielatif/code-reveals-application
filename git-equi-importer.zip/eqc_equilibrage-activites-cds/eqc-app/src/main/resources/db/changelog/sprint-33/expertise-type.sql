ALTER TABLE expertise
ALTER COLUMN nombre_dossier TYPE float;