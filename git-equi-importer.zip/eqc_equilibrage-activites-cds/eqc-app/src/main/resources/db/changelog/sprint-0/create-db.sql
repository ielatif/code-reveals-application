create sequence batch_job_execution_seq;
create sequence batch_job_seq;
create sequence batch_step_execution_seq;
create sequence hibernate_sequence;

create table if not exists databasechangeloglock
(
    id integer not null
        constraint databasechangeloglock_pkey
            primary key,
    locked boolean not null,
    lockgranted timestamp,
    lockedby varchar(255)
);

create table if not exists databasechangelog
(
    id varchar(255) not null,
    author varchar(255) not null,
    filename varchar(255) not null,
    dateexecuted timestamp not null,
    orderexecuted integer not null,
    exectype varchar(10) not null,
    md5sum varchar(35),
    description varchar(255),
    comments varchar(255),
    tag varchar(255),
    liquibase varchar(20),
    contexts varchar(255),
    labels varchar(255),
    deployment_id varchar(10)
);

create table batch_job_instance
(
    job_instance_id bigint not null
        constraint batch_job_instance_pkey
            primary key,
    version bigint,
    job_name varchar(100) not null,
    job_key varchar(32) not null,
    constraint job_inst_un
        unique (job_name, job_key)
);

create table batch_job_execution
(
    job_execution_id bigint not null
        constraint batch_job_execution_pkey
            primary key,
    version bigint,
    job_instance_id bigint not null
        constraint job_inst_exec_fk
            references batch_job_instance,
    create_time timestamp not null,
    start_time timestamp,
    end_time timestamp,
    status varchar(10),
    exit_code varchar(2500),
    exit_message varchar(2500),
    last_updated timestamp,
    job_configuration_location varchar(2500)
);

create table batch_job_execution_context
(
    job_execution_id bigint not null
        constraint batch_job_execution_context_pkey
            primary key
        constraint job_exec_ctx_fk
            references batch_job_execution,
    short_context varchar(2500) not null,
    serialized_context text
);

create table batch_job_execution_params
(
    job_execution_id bigint not null
        constraint job_exec_params_fk
            references batch_job_execution,
    type_cd varchar(6) not null,
    key_name varchar(100) not null,
    string_val varchar(250),
    date_val timestamp,
    long_val bigint,
    double_val double precision,
    identifying char not null
);

create table batch_step_execution
(
    step_execution_id bigint not null
        constraint batch_step_execution_pkey
            primary key,
    version bigint not null,
    step_name varchar(100) not null,
    job_execution_id bigint not null
        constraint job_exec_step_fk
            references batch_job_execution,
    start_time timestamp not null,
    end_time timestamp,
    status varchar(10),
    commit_count bigint,
    read_count bigint,
    filter_count bigint,
    write_count bigint,
    read_skip_count bigint,
    write_skip_count bigint,
    process_skip_count bigint,
    rollback_count bigint,
    exit_code varchar(2500),
    exit_message varchar(2500),
    last_updated timestamp
);

create table batch_step_execution_context
(
    step_execution_id bigint not null
        constraint batch_step_execution_context_pkey
            primary key
        constraint step_exec_ctx_fk
            references batch_step_execution,
    short_context varchar(2500) not null,
    serialized_context text
);

create table absence
(
    id bigint not null
        constraint absence_pkey
            primary key,
    date date not null,
    intervalle integer not null,
    matricule_collaborateur varchar(255) not null,
    constraint ukothy0w5fs9ypugpo5qqe7w5hf
        unique (matricule_collaborateur, date)
);

create table activite_sumeau
(
    code varchar(255) not null
        constraint activite_sumeau_pkey
            primary key,
    libelle varchar(255),
    ordre integer
);

create table collaborateur
(
    matricule varchar(255) not null
        constraint collaborateur_pkey
            primary key,
    login_windows varchar(255)
        constraint uk_j409ahjr5q3wnxxctow3w40r5
            unique,
    nom varchar(255),
    prenom varchar(255)
);

create table consolide_mensuel
(
    id bigint not null
        constraint consolide_mensuel_pkey
            primary key,
    id_activite_sumeau varchar(255),
    st_actif bigint,
    st_rattachement bigint,
    ug_rattachement bigint,
    cds_rattachement bigint,
    jours_presence double precision,
    matricule_collaborateur varchar(255),
    month_year_consolide varchar(255),
    sumeau_libelle_activite varchar(255),
    taux_activite_sumeau numeric(19),
    taux_hors_ug numeric(19),
    is_renfort_inter_ug boolean
);

create table equipe
(
    id bigint not null
        constraint equipe_pkey
            primary key,
    libelle varchar(255),
    code_cds bigint not null,
    code_ug bigint not null
);

create table affiliation
(
    id bigint not null
        constraint affiliation_pkey
            primary key,
    date_entree date not null,
    date_sortie date,
    collaborateur_id varchar(255) not null
        constraint fkjfm7srb1as5coqp83s28s02ma
            references collaborateur,
    equipe_id bigint not null
        constraint fk9c0hmdd379f9ehxigxkp4d8fd
            references equipe,
    constraint ukpqa5w741v8fxa1wt6uw6y16n9
        unique (date_entree, collaborateur_id, equipe_id)
);

create index idx_affiliation_equipe_id
    on affiliation (equipe_id);

create table famille
(
    code varchar(255) not null
        constraint famille_pkey
            primary key,
    libelle varchar(255),
    ordre integer
);

create table ref_data_libelle_es
(
    code varchar(255) not null
        constraint ref_data_libelle_es_pkey
            primary key,
    libelle varchar(255)
);

create table renfort
(
    id bigint not null
        constraint renfort_pkey
            primary key,
    code_cds_aide bigint not null,
    code_cds_rattachement bigint not null,
    code_ug_rattachement bigint not null,
    code_st_rattachement bigint not null,
    code_ug_aide bigint not null,
    date date not null,
    intervalle integer not null,
    libelle_renfort varchar(255) not null,
    matricule_collaborateur varchar(255) not null
        constraint fkg3uvxyw990371y1tehcwlbwxj
            references collaborateur,
    code_st_aide bigint not null
        constraint fk5sbqh3c5c54u5pyt5bchxtk55
            references equipe,
    constraint ukgmjhryv87pa623pqf4p01hq84
        unique (matricule_collaborateur, date, intervalle, code_st_rattachement, code_st_aide)
);

create table tete_perimetre
(
    code varchar(255) not null
        constraint tete_perimetre_pkey
            primary key,
    libelle varchar(255)
);

create table activite
(
    code varchar(255) not null
        constraint activite_pkey
            primary key,
    libelle varchar(255),
    libelle_long varchar(255),
    ordre integer,
    activite_sumeau_id varchar(255)
        constraint fk3ofcma4kxrf6k674idby5usjm
            references activite_sumeau,
    famille_id varchar(255)
        constraint fk9p6f132ynv9r4x9ig4qsf13f
            references famille,
    tete_perimetre_id varchar(255)
        constraint fk32dskignfhuqlrclc0drels07
            references tete_perimetre
);

create table affectation
(
    id bigint not null
        constraint affectation_pkey
            primary key,
    date date not null,
    nombre_dossier decimal,
    ordre integer,
    pourcentage bigint,
    code_activite varchar(255) not null
        constraint fkbes7ae6mb3jf958kxjgjhp34d
            references activite,
    affiliation_id bigint
        constraint fklii2on06j34sdn4we9qm6cxh8
            references affiliation,
    renfort_id bigint
        constraint fkq85a9n6p9srre5agrqjkkyvmp
            references renfort,
    constraint ukm5ys3r3pcnl4ot8w8mr81veo7
        unique (affiliation_id, code_activite, date)
);

create table niveau
(
    id      bigint not null
        constraint niveau_pkey
            primary key,
    libelle varchar(255)
);

create table expertise
(
    id             bigint not null
        constraint expertise_pkey
            primary key,
    is_default     boolean,
    nombre_dossier bigint,
    code_activite  varchar(255) not null
        constraint fk9k0686lh11pybdgylpu1kfp44
            references activite,
    id_niveau      bigint       not null
        constraint fkovrjgpjc4acdid5dbrkm1eph1
            references niveau,
    constraint ukprglac9uqm7ast4a9umpjscx0
        unique (code_activite, id_niveau)
);

create table competence
(
    id           bigint       not null
        constraint competence_pkey
            primary key,
    matricule    varchar(255) not null
        constraint fkpm1w9a2b7wvkxwg97pgru5psu
            references collaborateur,
    id_expertise bigint not null
        constraint fk6533m93v2g8pyoksqf1fvkm37
            references expertise,
    constraint ukgnufp9ai0gdr7c22yhhkougd7
        unique (matricule, id_expertise)
);