create table affiliation_sous_equipe
(
    id bigint not null
        constraint affiliation_sous_equipe_pkey
            primary key,
    sous_equipe_id bigint not null
        constraint fk9c0hmdd379f9ehxigxkp4d8ef
            references sous_equipe,
    affiliation_id bigint not null
        constraint fk9c0hmdd379f9ehxigxkp4d8eg
            references AFFILIATION,
    constraint ukm5ys3r3pcnl4ot8w8mr81ve45
        unique (affiliation_id, sous_equipe_id)
);