INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000359241', 'PSC CRE CLICOM', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000359242', 'PSC OPE CLICOM', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000359243', 'PSC FLUX', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000359244', 'PSC CRE CLIPRI', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000359245', 'PSC OPE CLIPRI', true);