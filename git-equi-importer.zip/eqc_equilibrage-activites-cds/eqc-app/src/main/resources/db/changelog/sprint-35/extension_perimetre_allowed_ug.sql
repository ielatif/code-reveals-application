create table extension_perimetre_allowed_ug
(
  code varchar(255),
  libelle varchar(255)
);
