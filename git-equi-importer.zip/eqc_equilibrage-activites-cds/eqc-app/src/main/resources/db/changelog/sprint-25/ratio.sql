create table ratio_type
(
  id      bigint       not null
    constraint ratio_type_pkey
    primary key,
  code    varchar(255) not null
    constraint uk_q3ii95ktbipn07m4m6axv643c
    unique,
  libelle varchar(255)
);

ALTER TABLE public.activite
  DROP COLUMN activite_sumeau_id;

ALTER TABLE public.activite ADD activite_ratio_id varchar(255);

create table activite_ratio
(
  code       varchar(255) not null
    constraint activite_ratio_pkey
    primary key,
  libelle    varchar(255),
  ratio_type bigint       not null
    constraint fkafs1ptd5ykvm14xisreqfbk5w
    references ratio_type
);

drop table activite_sumeau;

CREATE SEQUENCE expertise_id_seq;


ALTER SEQUENCE expertise_id_seq
OWNED BY expertise.id;


ALTER TABLE expertise ALTER COLUMN id SET DEFAULT nextval('expertise_id_seq');

ALTER SEQUENCE expertise_id_seq RESTART WITH 10001 ;

--Insert ratio types
INSERT INTO public.ratio_type (id, code, libelle) VALUES (1, 'SUM', 'sumeau');


--Insert ratio activites
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM01', 'Espèces (ajustage coffres tire-lire, MISTRAL)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM03', 'DAR technique, MURCEF, rejets physiques et autres activités chèque', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM04', 'Autres voies d''exécution', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM05', 'Saisies (attribution, conservatoire)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM06', 'Recherches dont RNI, Réquisitions', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM07', 'Titres / fiscalité (PRI)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM08', 'Fichier clients / vie du compte', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM09', 'ERS (PRI)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM10', 'Dossiers Recouvrement PRI/PRO VD', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM11', 'Analyses et montages PPI (crédits réglementés, Vérifimmo…)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM12', 'Emissions, complétude et suivi des offres PPI, Assurances, garanties', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM13', 'Qualifications, décaissements, vérif avant clôture, paiement primes diverses', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM14', 'Traitement des prêts en Francs Suisses', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM15', 'Actions de suivi et de surveillance, traitement factures prescripteurs, traitement copies executoires, Préparation des dossiers Audit', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM16', 'Evénements standards (renégociations, remboursements anticipés, modularité…)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM17', 'Evénements complexes (désolidarisations, transferts, gestion des garanties, avenants manuels…)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM18', 'Autres crédits PRI (avances patrimoniales, découverts en compte spécial)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM19', 'Cautions PRI : émission, suivi et mainlevée', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM20', 'Sinistres Assurances (emprunteurs, crédits PRI), Sinistres sur biens immobiliers', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM21', 'Crédits CONSO (contrôle de conformité, évènements de gestion)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM22', 'Gestion des assurances (déliaison/substitution)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM23', 'EER ENT et PRO', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM24', 'Revues KYC ENT et PRO', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM25', 'Circularisations', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM26', 'Vie du compte', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM27', 'Placement de la trésorerie du client', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM28', 'Gestion fin de relation', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM29', 'Monétique / Télématique', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM30', 'Suivi des professions réglementées PRO/COM', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM31', 'Analyse et montage des dossiers, suivi des dossiers complexes', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM32', 'Rédaction et mise en force des CMT (hors Sogepro)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM33', 'Evénements ENT et PRO', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM34', 'Mise en place crédits PRO (SOGEPRO et PRO en ligne)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM35', 'Mise en place et Renouvellement CT', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM36', 'Cautions domestiques', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM37', 'Correspondants (CTLM)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM38', 'Correspondants Flux Int (CFI)', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM39', 'Virements Papier', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM40', 'Remises télématiques', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM41', 'Portefeuille FRA', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM42', 'Portefeuille INT et remises documentaires', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM43', 'Avances et blocages Devises', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM44', 'Recherches Flux', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM45', 'RST', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM46', 'RST et correspondant Prêts Immobiliers', 1);
INSERT INTO public.activite_ratio (code, libelle, ratio_type) VALUES ('SUM47', 'RDO', 1);

