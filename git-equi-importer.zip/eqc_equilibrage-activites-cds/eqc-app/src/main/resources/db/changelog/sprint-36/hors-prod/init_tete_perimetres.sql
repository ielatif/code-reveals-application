INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000350985', 'PSC CRE CLICOM', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000350986', 'PSC OPE CLICOM', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000350987', 'PSC FLUX', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000350988', 'PSC CRE CLIPRI', true);
INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3000350989', 'PSC OPE CLIPRI', true);