INSERT INTO public.ref_data_libelle_es (code, libelle) VALUES ('3000349287', 'FIA');
INSERT INTO public.ref_data_libelle_es (code, libelle) VALUES ('3000346491', 'OPP');
INSERT INTO public.ref_data_libelle_es (code, libelle) VALUES ('3000349290', 'OPE');
INSERT INTO public.ref_data_libelle_es (code, libelle) VALUES ('3000349288', 'FPE');
INSERT INTO public.ref_data_libelle_es (code, libelle) VALUES ('3000349289', 'FTI');