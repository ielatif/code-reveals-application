create table params_fictional_tete_perim
(
  code_filiere         bigint not null,
  code_st              bigint not null,
  code_ug              bigint not null,
  fictional_tete_perim bigint not null,
  constraint params_fictional_tete_perim_pkey
  primary key (code_filiere, code_st, code_ug)
);