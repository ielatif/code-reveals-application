ALTER TABLE public.famille ADD code_tete_perimetre varchar(255) not null default 'to_be_replaced';
