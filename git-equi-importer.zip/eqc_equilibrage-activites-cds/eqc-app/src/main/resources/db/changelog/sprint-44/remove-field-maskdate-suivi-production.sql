
ALTER TABLE public.activite_params DROP COLUMN mask_date_production;
