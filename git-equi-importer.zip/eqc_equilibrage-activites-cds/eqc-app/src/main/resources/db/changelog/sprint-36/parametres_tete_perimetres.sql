create table parametres_tete_perimetre
(
  id varchar(255),
  libelle varchar(255),
  is_active boolean  not null
);
