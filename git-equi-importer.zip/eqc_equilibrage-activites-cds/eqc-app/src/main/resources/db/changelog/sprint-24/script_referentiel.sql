ALTER TABLE public.activite
  DROP COLUMN TETE_PERIMETRE_ID;

  ALTER TABLE public.activite
  ADD display boolean;

ALTER TABLE public.activite ADD code_tete_perimetre varchar(255) not null default 'to_be_replaced';

ALTER TABLE public.activite
  DROP COLUMN libelle;

ALTER TABLE public.activite
  DROP COLUMN libelle_long;

drop table public.tete_perimetre;
