INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000387713, 3000338721, 3000359529);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000387711, 3000338721, 3000359529);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000317829, 3000347828, 1);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000317478, 3000347477, 2);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000319425, 3000347477, 3);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000319426, 3000348041, 4);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000319766, 3000348041, 4);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349291, 3000387547, 3000348041, 4);

INSERT INTO params_fictional_tete_perim (code_filiere, code_st, code_ug, fictional_tete_perim) VALUES (3000349288, 3000318042, 3000336431, 5);



INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('1', 'PSC VAD STD', true);

INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('2', 'PSC VAD SQY', true);

INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('3', 'PSC CNTOE', true);

INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('4', 'PSC ARS VDF', true);

INSERT INTO public.parametres_tete_perimetre (id, libelle, is_active) VALUES ('5', 'PSC ARS COT', true);