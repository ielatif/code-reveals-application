ALTER TABLE public.activite
    DROP COLUMN IF EXISTS display;
ALTER TABLE public.activite
    ADD COLUMN mask_date date;
