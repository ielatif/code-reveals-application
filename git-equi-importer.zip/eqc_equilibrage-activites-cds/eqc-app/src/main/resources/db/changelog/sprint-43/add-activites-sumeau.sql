--pour le tete perimetre Négociation Amiable
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM66', 'Dossiers simples', 1, '3000359360');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM67', 'Dossiers PRI complexes', 1, '3000359360');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM68', 'Dossiers PRO complexes', 1, '3000359360');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM69', 'RST', 1, '3000359360');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM83', 'RDO', 1, '3000359360');


--pour le tete perimetre Recouvrement
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM70', 'Gestion opérations', 1, '3000359008');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM71', 'Judiciaire', 1, '3000359008');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM72', 'Autres portefeuilles en pool', 1, '3000359008');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM73', 'RST', 1, '3000359008');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM74', 'RDO', 1, '3000359008');


--pour le tete perimetre CRE CLICOM
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM75', 'Analyse et montage des dossiers, suivi des dossiers complexes', 1, '3000359241');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM76', 'Cautions domestiques', 1, '3000359241');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM77', 'Evénements ENT et PRO', 1, '3000359241');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM78', 'Mise en place crédits PRO (SOGEPRO et PRO en ligne)', 1, '3000359241');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM79', 'Mise en place et Renouvellement CT', 1, '3000359241');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM80', 'Rédaction et mise en force des CMT (hors Sogepro)', 1, '3000359241');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM81', 'RST', 1, '3000359241');
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM82', 'RDO', 1, '3000359241');
