-- OPE CLIPRI
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM01';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM03';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM04';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM05';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM06';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM07';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM08';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM09';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM10';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359245' WHERE code = 'SUM45';
-- CRE CLIPRI
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM11';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM12';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM13';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM14';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM15';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM16';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM17';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM18';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM19';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM20';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM21';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM22';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM46';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359244' WHERE code = 'SUM47';
-- OPE CLICOM
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM23';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM24';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM25';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM26';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM27';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM28';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM29';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359242' WHERE code = 'SUM30';
-- CRE CLICOM
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359241' WHERE code = 'SUM31';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359241' WHERE code = 'SUM32';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359241' WHERE code = 'SUM33';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359241' WHERE code = 'SUM34';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359241' WHERE code = 'SUM35';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359241' WHERE code = 'SUM36';
-- FLUX
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM37';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM38';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM39';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM40';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM41';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM42';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM43';
UPDATE public.activite_ratio SET code_tete_perimetre = '3000359243' WHERE code = 'SUM44';
--NEW ACT SUMEAU
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM02', 'Divers (chèques, oppositions, impayés)', 1, '3000359245')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM58', 'RDO', 1, '3000359245')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM52', 'RDO', 1, '3000359242')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM53', 'RST', 1, '3000359242')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM50', 'RDO', 1, '3000359241')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM51', 'RST', 1, '3000359241')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM54', 'RDO', 1, '3000359243')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM55', 'RST', 1, '3000359243')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM56', 'Correspondants (CTLM)', 1, '3000359243')
ON CONFLICT(code) DO NOTHING;
INSERT INTO public.activite_ratio (code, libelle, ratio_type, code_tete_perimetre) VALUES ('SUM57', 'Correspondants Flux Int (CFI)', 1, '3000359243')
ON CONFLICT(code) DO NOTHING;
