ALTER TABLE public.renfort
DROP COLUMN libelle_renfort;
