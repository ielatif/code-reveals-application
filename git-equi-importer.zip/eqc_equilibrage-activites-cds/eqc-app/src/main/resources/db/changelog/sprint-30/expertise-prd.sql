create table default_expertise
(
  id            bigint       not null
    constraint default_expertise_pkey
    primary key,
  code_activite varchar(255) not null
    constraint fkpuga4b1n0bhk7qjmmmlwtwma0
    references activite,
  id_niveau     bigint       not null
    constraint fko9knkh7tqivdpyw0gim44rdx6
    references niveau,
   date_debut    date         not null,
  date_fin      date,
  constraint activ_niv_date
  unique (code_activite, date_debut, id_niveau)
);


INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (1, 'CRI04', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (2, 'CRI05', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (3, 'CRI06', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (4, 'CRI07', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (5, 'CRI08', 4, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (6, 'CRI09', 4, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (7, 'CRI10', 4, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (8, 'CRI11', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (9, 'CRI12', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (10, 'CRI13', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (11, 'CRI14', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (12, 'CRI15', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (13, 'CRI16', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (14, 'CRI17', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (15, 'CRI18', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (16, 'CRI19', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (17, 'CRI26', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (18, 'CRI03', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (19, 'CRI24', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (20, 'CRI25', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (21, 'CRI02', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (22, 'CRI27', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (23, 'CRI28', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (24, 'OPE01', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (25, 'OPE02', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (26, 'OPE03', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (27, 'OPE04', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (28, 'OPE05', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (29, 'OPE06', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (30, 'OPE07', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (31, 'OPE08', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (32, 'OPE09', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (33, 'OPE10', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (34, 'OPE11', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (35, 'OPE12', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (36, 'OPE13', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (37, 'OPE14', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (38, 'OPE15', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (39, 'OPE16', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (40, 'OPE22', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (41, 'OPE21', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (42, 'OPE19', 1, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (43, 'OPE20', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (44, 'OPE23', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (45, 'OPE24', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (46, 'OPE25', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (47, 'OPE26', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (48, 'OPE27', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (49, 'OPE28', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (50, 'OPE29', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (51, 'OPE30', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (52, 'OPE31', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (53, 'OPE32', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (54, 'OPE33', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (55, 'OPE34', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (56, 'OPE35', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (57, 'OPE36', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (58, 'OPE37', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (59, 'OPE38', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (60, 'OPE39', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (61, 'OPE40', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (62, 'OPE41', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (63, 'OPE42', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (64, 'OPE43', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (65, 'OPI02', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (66, 'OPI03', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (67, 'OPI04', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (68, 'OPI07', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (69, 'OPI08', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (70, 'OPI09', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (71, 'OPI10', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (72, 'OPI11', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (73, 'OPI12', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (74, 'OPI13', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (75, 'OPI14', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (76, 'OPI15', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (77, 'OPI19', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (78, 'OPI23', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (79, 'OPI24', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (80, 'OPI25', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (81, 'OPI20', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (82, 'OPI26', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (83, 'OPI18', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (84, 'OPI17', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (85, 'OPI27', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (86, 'OPI28', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (87, 'OPI29', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (88, 'OPI30', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (89, 'OPI31', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (99, 'OPI52', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (100, 'OPI54', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (101, 'OPI32', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (102, 'OPI33', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (103, 'OPI34', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (104, 'OPI35', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (105, 'OPI36', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (106, 'OPI37', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (107, 'OPI38', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (108, 'OPI39', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (109, 'OPI40', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (110, 'OPI41', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (111, 'OPI42', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (112, 'OPI43', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (113, 'OPI44', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (114, 'OPI45', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (115, 'OPI46', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (116, 'OPI47', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (117, 'OPI48', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (118, 'OPI49', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (119, 'OPI55', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (120, 'TRA01', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (121, 'TRA06', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (122, 'TRA07', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (123, 'TRA08', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (124, 'TRA09', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (125, 'TRA10', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (126, 'TRA11', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (127, 'TRA12', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (128, 'TRA13', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (129, 'ACT140', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (130, 'OPI21', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (131, 'OPI16', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (132, 'OPI50', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (133, 'ACT144', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (134, 'ACT141', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (135, 'TRA15', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (136, 'ACT143', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (137, 'OPI51', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (138, 'TRA03', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (139, 'TRA14', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (140, 'TRA02', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (141, 'ACT152', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (142, 'TRA18', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (143, 'OPI06', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (144, 'TRA16', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (145, 'TRA04', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (146, 'TRA05', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (147, 'ACT150', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (148, 'ACT142', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (149, 'ACT155', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (150, 'ACT156', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (151, 'TRA17', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (152, 'OPE18', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (153, 'ACT161', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (154, 'ACT146', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (155, 'CRI22', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (156, 'CRI23', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (157, 'ACT145', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (158, 'OPE17', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (159, 'OPI53', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (160, 'ACT148', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (161, 'ACT149', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (162, 'ACT157', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (163, 'ACT151', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (164, 'ACT153', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (165, 'ACT162', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (166, 'OPI01', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (167, 'ACT158', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (168, 'ACT147', 3, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (169, 'ACT154', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (170, 'ACT159', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (171, 'ACT160', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (172, 'ACT163', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (173, 'ACT164', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (174, 'ACT165', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (175, 'ACT166', 0, '2020-10-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (176, 'CRI01', 3, '2020-10-01', null);


alter table expertise drop column if exists is_default;

