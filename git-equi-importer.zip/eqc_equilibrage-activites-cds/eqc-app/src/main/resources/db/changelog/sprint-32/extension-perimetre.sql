create table extension_perimetre
(
  id            bigint not null
    constraint extension_perimetre_pkey
    primary key,
  date_creation timestamp,
  etat          integer,
  id_ghabi      bigint
);


ALTER TABLE renfort
    ADD id_extension_perimetre INTEGER,
    ADD FOREIGN KEY ("id_extension_perimetre")
REFERENCES extension_perimetre;


ALTER TABLE renfort
  ADD CONSTRAINT peimetre_cascade_delete
FOREIGN KEY ("id_extension_perimetre")
REFERENCES extension_perimetre
ON DELETE CASCADE;