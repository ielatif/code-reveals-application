ALTER TABLE public.activite_ratio ADD code_tete_perimetre varchar(255) not null default '3000350985';
