-- *****
-- initialisation code_tete_perimetre des familles en homologation
-- ****
UPDATE public.famille SET code_tete_perimetre = '3000350988' WHERE code LIKE 'CRE%' ESCAPE '#';
UPDATE public.famille SET code_tete_perimetre = '3000350986' WHERE code LIKE 'OPECLICOM%' ESCAPE '#';
UPDATE public.famille SET code_tete_perimetre = '3000350989' WHERE code LIKE 'OPECLIPRI%' ESCAPE '#';

