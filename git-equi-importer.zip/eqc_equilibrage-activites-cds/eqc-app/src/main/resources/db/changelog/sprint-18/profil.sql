INSERT INTO public.niveau (id, libelle) VALUES (0, 'niveau 0');
INSERT INTO public.niveau (id, libelle) VALUES (1, 'niveau 1');
INSERT INTO public.niveau (id, libelle) VALUES (2, 'niveau 2');
INSERT INTO public.niveau (id, libelle) VALUES (3, 'niveau 3');
INSERT INTO public.niveau (id, libelle) VALUES (4, 'niveau 4');
