
CREATE SEQUENCE parametres_carte_id_seq;

create table parametres_carte
(
  id bigint not null DEFAULT nextval('parametres_carte_id_seq')
    constraint  parametres_carte_pkey
      primary key,
  titre varchar(50),
  commentaire varchar(255),
  couleur varchar(50),
  updated_at timestamp,
  updated_by varchar(255)
);

ALTER TABLE affectation
  ADD COLUMN parametres_carte_id bigint
    constraint parametres_carte_fk
      references parametres_carte;

ALTER TABLE renfort
  ADD COLUMN parametres_carte_id bigint
    constraint parametres_carte_fk
      references parametres_carte;