ALTER TABLE activite
    add column unite  int NOT NULL default 0,
    add column type  int NOT NULL default 0,
    ADD COLUMN mask_date_production date,
    ADD COLUMN mask_date_pilotage date,
    ADD COLUMN mask_date_competence date;;
