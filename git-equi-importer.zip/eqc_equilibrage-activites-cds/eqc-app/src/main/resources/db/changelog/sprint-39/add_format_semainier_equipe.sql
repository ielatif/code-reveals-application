ALTER TABLE  equipe
    add column format_semainier integer NOT NULL default 5;