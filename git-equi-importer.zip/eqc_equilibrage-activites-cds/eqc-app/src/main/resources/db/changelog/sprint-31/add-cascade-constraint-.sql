ALTER TABLE affiliation
  ADD CONSTRAINT collab_cascade_delete
FOREIGN KEY ("collaborateur_id")
REFERENCES collaborateur
ON DELETE CASCADE;

ALTER TABLE affiliation
  DROP CONSTRAINT if exists fkjfm7srb1as5coqp83s28s02ma;



ALTER TABLE affectation
  ADD CONSTRAINT affiliation_cascade_delete
FOREIGN KEY ("affiliation_id")
REFERENCES affiliation
ON DELETE CASCADE;

ALTER TABLE affectation
  DROP CONSTRAINT if exists fklii2on06j34sdn4we9qm6cxh8;
