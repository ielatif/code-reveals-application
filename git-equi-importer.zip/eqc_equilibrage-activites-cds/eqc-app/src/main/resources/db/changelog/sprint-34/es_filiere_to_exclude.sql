create table es_fliere_to_exclude
(
  id   bigint not null
    constraint es_fliere_to_exclude_pkey
    primary key,
  code varchar(255),
  type varchar(255)
);
