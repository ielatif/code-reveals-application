create table default_expertise
(
  id            bigint       not null
    constraint default_expertise_pkey
    primary key,
  code_activite varchar(255) not null
    constraint fkpuga4b1n0bhk7qjmmmlwtwma0
    references activite,
  id_niveau     bigint       not null
    constraint fko9knkh7tqivdpyw0gim44rdx6
    references niveau,
   date_debut    date         not null,
  date_fin      date
);

INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (1,  'OPI02', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (2,  'OPI03', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (3,  'OPI04', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (4,  'OPI06', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (5,  'OPI08', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (6,  'OPI09', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (7,  'OPI10', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (8,  'OPI11', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (9,  'OPI12', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (10,  'OPI13', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (11,  'OPI14', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (12,  'OPI15', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (13,  'OPI16', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (14,  'OPI17', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (15,  'OPI18', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (16,  'OPI19', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (17,  'OPI20', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (18,  'OPI21', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (19,  'OPI23', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (20,  'OPI24', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (21,  'OPI25', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (22, 'OPI01', 2, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (23, 'OPI26', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (24, 'OPI27', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (25, 'OPI28', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (26, 'OPI29', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (27, 'OPI30', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (28, 'OPI31', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (29, 'OPI32', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (30, 'OPI33', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (31,  'OPI34', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (32,  'OPI35', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (33, 'OPI36', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (34, 'OPI37', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (35, 'OPI38', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (36,  'OPI39', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (37, 'OPI40', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (38, 'OPI41', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (39, 'OPI42', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (40, 'OPI43', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (41, 'OPI44', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (42, 'OPI45', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (43, 'OPI46', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (44, 'OPI47', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (45,  'OPI48', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (46,  'OPI49', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (47, 'CRI01', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (48, 'CRI02', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (49, 'CRI03', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (50, 'CRI04', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (51, 'CRI05', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (52, 'CRI06', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (53, 'CRI07', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (54, 'CRI11', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (55, 'CRI12', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (56, 'CRI13', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (57, 'CRI14', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (58, 'CRI15', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (59, 'CRI16', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (60, 'CRI17', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (61, 'CRI18', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (62, 'CRI19', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (63,  'TRA01', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (64,  'TRA02', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (65,  'TRA03', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (66, 'OPI07', 4, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (67,  'CRI08', 4, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (68, 'CRI09', 4, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (69, 'CRI10', 4, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (70, 'OPI50', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (71,  'OPI51', 2, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (72, 'OPI52', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (73,  'OPI53', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (74, 'CRI22', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (75, 'CRI23', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (76, 'CRI24', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (77, 'CRI25', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (78, 'CRI26', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (79, 'CRI27', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (80, 'CRI28', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (81,  'TRA04', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (82,  'TRA05', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (83,  'OPE01', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (84,  'OPE02', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (85,  'OPE03', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (86,  'OPE04', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (87,  'OPE05', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (88,  'OPE06', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (89, 'OPE07', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (90,  'OPE08', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (91,  'OPE09', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (92,  'OPE10', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (93,  'OPE11', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (94,  'OPE12', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (95,  'OPE13', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (96,  'OPE14', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (97,  'OPE15', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (98,  'OPE16', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (99,  'OPE17', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (100,  'OPE18', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (101,  'OPE19', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (102,  'OPE20', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (103,  'OPE21', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (104,  'OPE22', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (105,  'OPE23', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (106,  'OPE24', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (107,  'OPE25', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (108,  'OPE26', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (109,  'OPE27', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (110,  'OPE28', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (111,  'OPE29', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (112,  'OPE30', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (113,  'OPE31', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (114,  'OPE32', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (115,  'OPE33', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (116,  'OPE34', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (117,  'OPE35', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (118,  'OPE36', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (119,  'OPE37', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (120,  'OPE38', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (121,  'OPE39', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (122, 'OPE40', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (123,  'OPE41', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (124,  'OPE42', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (125,  'OPE43', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (126,  'TRA11', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (127,  'TRA12', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (128,  'TRA13', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (129,  'TRA14', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (130,  'TRA15', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (131,  'TRA07', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (132,  'TRA08', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (133,  'TRA09', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (134,  'TRA10', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (135,  'OPI54', 0, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (136,  'OPI55', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (137,  'TRA16', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (138,  'TRA06', 3, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (139, 'TRA17', 4, '2020-09-01', null);
INSERT INTO public.default_expertise (id, code_activite, id_niveau, date_debut, date_fin) VALUES (140, 'TRA18', 3, '2020-09-01', null);

alter table expertise drop column if exists is_default;

