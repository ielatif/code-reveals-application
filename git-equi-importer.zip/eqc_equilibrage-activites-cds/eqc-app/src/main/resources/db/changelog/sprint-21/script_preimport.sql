DELETE FROM public.competence;
DELETE FROM public.expertise;
DELETE FROM public.activite;
DELETE FROM public.activite_sumeau;
DELETE FROM public.famille;
DELETE FROM public.TETE_PERIMETRE;
