drop table if exists affectation cascade;
create table affectation
(
    id bigint not null
        constraint affectation_pkey
            primary key,
    date date not null,
    nombre_dossier double precision,
    ordre integer,
    pourcentage bigint,
    code_activite varchar(255) not null
        constraint fkbes7ae6mb3jf958kxjgjhp34d
            references activite,
    affiliation_id bigint
        constraint fklii2on06j34sdn4we9qm6cxh8
            references affiliation,
    expertise_id bigint
        constraint fkixfdt5o3nb6ej4icktc7nbhwu
            references expertise,
    renfort_id bigint
        constraint fkq85a9n6p9srre5agrqjkkyvmp
            references renfort,
    constraint ukm5ys3r3pcnl4ot8w8mr81veo7
        unique (affiliation_id, code_activite, date)
);

