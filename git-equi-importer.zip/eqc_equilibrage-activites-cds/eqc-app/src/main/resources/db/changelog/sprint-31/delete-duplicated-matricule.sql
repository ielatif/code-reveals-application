
CREATE or replace FUNCTION "deleteDuplicatedMatricule"() RETURNS boolean
LANGUAGE plpgsql
AS
$$
DECLARE
  COLLABORATEUR_RECORD RECORD;

BEGIN
  FOR COLLABORATEUR_RECORD IN select matricule, LOWER(matricule) lowerMatricule, LOWER(login_windows) lowerLogin
      from collaborateur where matricule != LOWER(matricule)
  LOOP
    delete from collaborateur where matricule = COLLABORATEUR_RECORD.matricule ;
  END LOOP;
   RETURN TRUE;
END
$$;

select "deleteDuplicatedMatricule"();