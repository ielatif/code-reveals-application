package org.example.library;

import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

public class TypeScriptLibraryExtractor extends LibraryExtractor {
    @Override
    Collection<Pattern> getPatterns() {
        return List.of(Pattern.compile("require\\([\"\\'](.+)[\"\\']\\);?\\s"),
                Pattern.compile("import\\s*(?:.+ from)?\\s?\\(?[\\'\"](.+)[\\'\"]\\)?;?\\s"));
    }
}
