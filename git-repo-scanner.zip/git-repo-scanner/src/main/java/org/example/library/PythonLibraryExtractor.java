package org.example.library;

import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

public class PythonLibraryExtractor extends LibraryExtractor {

    @Override
    Collection<Pattern> getPatterns() {
        return List.of(Pattern.compile("from (.+) import"),
                Pattern.compile("import ([a-zA-Z0-9_-]+)(?:\\s| as)"));
    }
}
