package org.example.library;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class LibraryExtractor {

    public Set<String> extractLibraries(String content) {
        Set<String> libaries = new HashSet<>();

            for (Pattern pattern : getPatterns()) {
                Matcher matcher = pattern.matcher(content);
                while (matcher.find()) {
                    libaries.add(matcher.group(1));
                }
            }

        return libaries;
    }

    abstract Collection<Pattern> getPatterns();
}
