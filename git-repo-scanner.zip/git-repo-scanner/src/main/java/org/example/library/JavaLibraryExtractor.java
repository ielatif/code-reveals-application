package org.example.library;

import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

public class JavaLibraryExtractor extends LibraryExtractor {

    @Override
    Collection<Pattern> getPatterns() {
        return List.of(Pattern.compile("import ([^java][a-zA-Z0-9]*\\.[a-zA-Z0-9]*)"),
                Pattern.compile("import ([^java][a-zA-Z0-9]*\\.[a-zA-Z0-9]*\\.[a-zA-Z0-9]*)"),
                Pattern.compile("import static ([^java][a-zA-Z0-9]*\\.[a-zA-Z0-9]*)"),
                Pattern.compile("import static ([^java][a-zA-Z0-9]*\\.[a-zA-Z0-9]*\\.[a-zA-Z0-9]*)"));
    }
}
