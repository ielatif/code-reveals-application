package org.example.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Map;

@Data
@Builder
public class RepositoryStats {
    private String id;
    private LocalDateTime firstCommitDate;
    private LocalDateTime lastCommitDate;
    private Long commitCount;
    private Map<String, LanguageStats> languages;
    private Map<String, UserStats> users;
}
