package org.example.model;

import lombok.Builder;
import lombok.Data;

import java.util.Collection;

@Data
@Builder
public class LanguageStats {
    private String language;
    private Long additions;
    private Long deletions;
    private Collection<String> libraries;
}
