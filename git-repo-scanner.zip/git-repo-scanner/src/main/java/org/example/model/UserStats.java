package org.example.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Map;

@Data
@Builder
public class UserStats {
    private String userName;
    private String userEmail;
    private LocalDateTime firstCommitDate;
    private LocalDateTime lastCommitDate;
    private Long commitCount;
    private Map<String, LanguageStats> languages;
}
