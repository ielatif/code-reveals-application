package org.example;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.bind.DateTypeAdapter;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.NoHeadException;
import org.eclipse.jgit.blame.BlameResult;
import org.eclipse.jgit.diff.*;
import org.eclipse.jgit.lib.*;
import org.eclipse.jgit.patch.FileHeader;
import org.eclipse.jgit.patch.HunkHeader;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.transport.RemoteConfig;
import org.eclipse.jgit.treewalk.AbstractTreeIterator;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;
import org.eclipse.jgit.treewalk.EmptyTreeIterator;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;
import org.eclipse.jgit.util.io.DisabledOutputStream;
import org.example.library.*;
import org.example.model.LanguageStats;
import org.example.model.RepositoryStats;
import org.example.model.UserStats;
import tech.sourced.enry.Enry;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    static Map<String, UserStats> userStatsMap = new HashMap<>();
    static Map<String, LibraryExtractor> librariesExtractorMap = new HashMap<>();
    static RepositoryStats repositoryStats = RepositoryStats.builder().build();

    public static void main(String[] args) throws IOException {

        librariesExtractorMap = initLibraryExtractors();

        // now open the resulting repository with a FileRepositoryBuilder
        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        File gitDir = new File("C:\\Users\\X168845\\IdeaProjects\\dnc_entree-relation-clicom\\.git");

        try (Repository repository = builder.setGitDir(gitDir)
                .readEnvironment() // scan environment GIT_* variables
                .findGitDir() // scan up the file system tree
                .build()) {
            System.out.println("Having repository: " + repository.getDirectory());

            // get a list of all known heads, tags, remotes, ...
            Collection<Ref> allRefs = repository.getRefDatabase().getRefs();

            Git git = new Git(repository);

            // fetch all branches
            List<RemoteConfig> remotes = git.remoteList().call();
            for(RemoteConfig remote : remotes) {
                git.fetch()
                        .setRemote(remote.getName())
                        .setRefSpecs(remote.getFetchRefSpecs())
                        .call();
            }

            RevCommit latestCommit = new Git(repository).
                    log().
                    call().
                    iterator().
                    next();

            LocalDateTime latestCommitDate = LocalDateTime.ofInstant(Instant.ofEpochSecond(latestCommit.getCommitTime()), ZoneId.systemDefault());

            repositoryStats.setLastCommitDate(latestCommitDate);

            // a RevWalk allows to walk over commits based on some filtering that is defined
            try (RevWalk revWalk = new RevWalk( repository )) {
                for( Ref ref : allRefs ) {
                    revWalk.markStart( revWalk.parseCommit( ref.getObjectId() ));
                }
                System.out.println("Walking all commits starting with " + allRefs.size() + " refs: " + allRefs);
                String email;
                Long count = 0L;
                for( RevCommit commit : revWalk ) {
                    System.out.println();
                    System.out.println("commit " + commit.getName());
                    System.out.println(commit.getShortMessage());
                    System.out.println("Author: " + commit.getAuthorIdent().getName());
                    System.out.println("Author e-mail: " + commit.getAuthorIdent().getEmailAddress());
                    System.out.println("Date: " + LocalDateTime.ofInstant(Instant.ofEpochSecond(commit.getCommitTime()), ZoneId.systemDefault()));

                    email = commit.getAuthorIdent().getEmailAddress();

                    if (userStatsMap.containsKey(email)) {
                        UserStats userStats = userStatsMap.get(email);
                        // First commit is scanned last
                        userStats.setFirstCommitDate(LocalDateTime.ofInstant(Instant.ofEpochSecond(commit.getCommitTime()), ZoneId.systemDefault()));
                        userStats.setCommitCount(userStats.getCommitCount() + 1L);
                        userStatsMap.put(email, userStats);
                    } else {
                        // Last commit is scanned first
                        userStatsMap.put(email, UserStats.builder()
                                .userName(commit.getAuthorIdent().getName())
                                .userEmail(email)
                                .firstCommitDate(LocalDateTime.ofInstant(Instant.ofEpochSecond(commit.getCommitTime()), ZoneId.systemDefault()))
                                .lastCommitDate(LocalDateTime.ofInstant(Instant.ofEpochSecond(commit.getCommitTime()), ZoneId.systemDefault()))
                                .languages(new HashMap<>())
                                .commitCount(1L)
                                .build());
                    }

                    listDiff(repository, git, commit);

                    count++;
                }

                repositoryStats.setUsers(userStatsMap);
                repositoryStats.setCommitCount(count);

                Map<String, LanguageStats> languageStatsMap = userStatsMap.values()
                        .stream()
                        .map(UserStats::getLanguages)
                        .flatMap(x -> x.values().stream())
                        .collect(Collectors.groupingBy(LanguageStats::getLanguage))
                        .values().stream()
                        .map(languageStats -> LanguageStats.builder()
                                .additions(languageStats.stream().mapToLong(LanguageStats::getAdditions).sum())
                                .deletions(languageStats.stream().mapToLong(LanguageStats::getDeletions).sum())
                                .language(languageStats.get(0).getLanguage())
                                .build())
                        .collect(Collectors.toMap(LanguageStats::getLanguage, e -> e));
                repositoryStats.setLanguages(languageStatsMap);

                try (Writer writer = new FileWriter(repository.getDirectory().getParentFile().getName() + ".json")) {
                    // convert map to JSON File
                    Gson gson = new GsonBuilder()
                            .registerTypeAdapter(Date.class, new DateTypeAdapter())
                            .registerTypeAdapter(java.sql.Date.class, new DateTypeAdapter())
                            .setDateFormat("yyyy-MM-dd HH:mm:ss.SSS").create();
                    gson.toJson(repositoryStats, writer);
                }

                System.out.println("Had " + count + " commits");
            } catch (GitAPIException e) {
                throw new RuntimeException(e);
            }
        } catch (NoHeadException e) {
            throw new RuntimeException(e);
        } catch (GitAPIException e) {
            throw new RuntimeException(e);
        }
    }

    private static void listDiff(Repository repository, Git git, RevCommit commit) throws GitAPIException, IOException {
        // Use a DiffFormatter to compare new and old tree and return a list of changes
        DiffFormatter diffFormatter = new DiffFormatter( DisabledOutputStream.INSTANCE );
        diffFormatter.setRepository( git.getRepository() );
        diffFormatter.setContext( 0 );
        List<DiffEntry> diffs;
        if (commit.getParentCount() == 0) {
            repositoryStats.setFirstCommitDate(LocalDateTime.ofInstant(Instant.ofEpochSecond(commit.getCommitTime()), ZoneId.systemDefault()));
            diffs = diffFormatter.scan(new EmptyTreeIterator(), prepareTreeParser(repository, commit.getName()));
        } else {
            diffs = diffFormatter.scan(prepareTreeParser(repository, commit.getName()+ "^"), prepareTreeParser(repository, commit.getName()));
        }

        System.out.println("Found: " + diffs.size() + " differences");
        for (DiffEntry diff : diffs) {
            String filePath = diff.getOldPath().equals(diff.getNewPath()) ? diff.getNewPath() : diff.getOldPath();
            FileHeader fileHeader = diffFormatter.toFileHeader( diff );
            List<? extends HunkHeader> hunks = fileHeader.getHunks();
            Long additions = 0l;
            Long deletions = 0l;
            for( HunkHeader hunk : hunks ) {
                for (Edit edit : hunk.toEditList()) {
                    if (edit.getType() == Edit.Type.INSERT) {
                        additions += edit.getLengthB();
                    } else if (edit.getType() == Edit.Type.DELETE) {
                        deletions += edit.getLengthA();
                    } else if (edit.getType() == Edit.Type.REPLACE) {
                        deletions += edit.getLengthA();
                        additions += edit.getLengthB();
                    }
                }
            }

            System.out.print("Diff: " + diff.getChangeType() + " " + additions + " additions " + deletions + " deletions " + diff.getNewPath() );
            String language = null;
            Set<String> libraries = null;
            if (DiffEntry.ChangeType.ADD.equals(diff.getChangeType()) || DiffEntry.ChangeType.MODIFY.equals(diff.getChangeType())) {
                // and using commit's tree find the path
                RevTree tree = commit.getTree();
                try (TreeWalk treeWalk = new TreeWalk(repository)) {
                    treeWalk.addTree(tree);
                    treeWalk.setRecursive(true);
                    treeWalk.setFilter(PathFilter.create(diff.getNewPath()));
                    if (!treeWalk.next()) {
                        throw new IllegalStateException("Did not find expected file " +  diff.getNewPath());
                    }

                    ObjectId objectId = treeWalk.getObjectId(0);
                    ObjectLoader loader = repository.open(objectId);

                    // and then one can the loader to read the file
                    //loader.copyTo(System.out);
                    language = Enry.getLanguage(diff.getNewPath(), loader.getBytes());
                    System.out.println("  Language: " + language);
                    if (librariesExtractorMap.containsKey(language)) {
                        LibraryExtractor libraryExtractor = librariesExtractorMap.get(language);
                        libraries = libraryExtractor.extractLibraries(new String(loader.getBytes()));
                    }

                    /*System.out.println("\n\nBlaming " + diff.getNewPath());
                    final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("YYYY-MM-dd HH:mm");
                    final BlameResult result = new Git(repository).blame().setFilePath(diff.getNewPath())
                            .setTextComparator(RawTextComparator.WS_IGNORE_ALL).call();
                    if (result != null) {
                        final RawText rawText = result.getResultContents();
                        for (int i = 0; i < rawText.size(); i++) {
                            final PersonIdent sourceAuthor = result.getSourceAuthor(i);
                            final RevCommit sourceCommit = result.getSourceCommit(i);
                            System.out.println(sourceAuthor.getName() +
                                    (sourceCommit != null ? " - " + DATE_FORMAT.format(((long) sourceCommit.getCommitTime()) * 1000) +
                                            " - " + sourceCommit.getName() : "") +
                                    ": " + rawText.getString(i));
                        }
                    }*/
                }
            } else {
                System.out.println("");
            }

            UserStats userStats = userStatsMap.get(commit.getAuthorIdent().getEmailAddress());
            if (librariesExtractorMap.containsKey(language)) {
                Map<String, LanguageStats> languagesStats = userStats.getLanguages();
                if (languagesStats.containsKey(language)) {
                    LanguageStats languageStats = languagesStats.get(language);
                    languageStats.setAdditions(languageStats.getAdditions() + additions);
                    languageStats.setDeletions(languageStats.getDeletions() + deletions);
                    Collection<String> libraries1 = languageStats.getLibraries();
                    if (libraries != null) {
                        libraries1.addAll(libraries);
                    }
                    languageStats.setLibraries(libraries1);
                    languagesStats.put(language, languageStats);
                } else {
                    languagesStats.put(language, LanguageStats.builder()
                            .language(language)
                            .additions(additions)
                            .deletions(deletions)
                            .libraries(libraries)
                            .build());
                }
                userStats.setLanguages(languagesStats);
                userStatsMap.put(commit.getAuthorIdent().getEmailAddress(), userStats);
            }
        }
    }

    private static AbstractTreeIterator prepareTreeParser(Repository repository, String objectId) throws IOException {
        // from the commit we can build the tree which allows us to construct the TreeParser
        //noinspection Duplicates
        try (RevWalk walk = new RevWalk(repository)) {
            RevCommit commit = walk.parseCommit(repository.resolve(objectId));
            RevTree tree = walk.parseTree(commit.getTree().getId());

            CanonicalTreeParser treeParser = new CanonicalTreeParser();
            try (ObjectReader reader = repository.newObjectReader()) {
                treeParser.reset(reader, tree.getId());
            }

            walk.dispose();

            return treeParser;
        }
    }

    private static Map<String, LibraryExtractor> initLibraryExtractors() {
        Map<String, LibraryExtractor> libraryExtractorMap = new HashMap<>();
        libraryExtractorMap.put("Java", new JavaLibraryExtractor());
        libraryExtractorMap.put("JavaScript", new JavaScriptLibraryExtractor());
        libraryExtractorMap.put("TypeScript", new TypeScriptLibraryExtractor());
        libraryExtractorMap.put("Pyton", new PythonLibraryExtractor());
        return libraryExtractorMap;
    }
}